# Aurum AI 37 Integrated LAB

Alpha integrada criada sobre o core v0.6.3 Balanced Calibrado.

### Segurança
- não captura credenciais;
- não usa `addJavascriptInterface`;
- não contorna SOP/cross-origin/DRM;
- não automatiza apostas;
- não contém keystore de release.

### Build
`./gradlew clean assembleDebug`
