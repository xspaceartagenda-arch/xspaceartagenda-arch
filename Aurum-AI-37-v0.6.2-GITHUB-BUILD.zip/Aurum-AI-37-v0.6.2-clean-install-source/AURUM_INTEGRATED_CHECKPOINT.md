# AURUM AI 37 Integrated LAB — Checkpoint

## Versão
0.7.0-integrated-alpha

## Base congelada
Aurum AI 37 v0.6.3 Balanced Calibrado. Os arquivos em `app/src/main/java/com/xspaceart/radar30/core/` foram preservados byte a byte.

## Implementado nesta Alpha
- applicationId separado (`com.xspaceart.aurumai37.integratedlab`);
- launcher IntegratedActivity;
- WebView interna segura, cookies e DOM storage;
- URL/reload/back internos;
- scanner DOM genérico sem contornar cross-origin;
- detector básico de ambiente/provedor;
- normalizador 0–36 e sincronização via ScanSynchronizer;
- bridge para o RadarSession v0.6.3;
- Signal Hero;
- Precision/Balanced;
- Secondary;
- Raio-X resumido e completo;
- EvidenceGraph para fontes/correlação;
- fallback para as ferramentas OCR/overlay existentes;
- sessão local mínima;
- sem automação de aposta.

## Limitações conhecidas
- páginas dentro de iframe cross-origin podem impedir leitura DOM; o app sinaliza e oferece OCR fallback;
- o extrator DOM genérico precisa ser calibrado/adaptado por plataforma depois dos testes físicos;
- primeira ordem do histórico é configurável porque cada plataforma apresenta a grade de forma diferente;
- ainda não existem adapters específicos por provider.

## Próxima tarefa exata
Compilar no GitHub Actions, instalar ao lado do Stable no S25 FE e testar primeiro: startup, navegação, login manual, scanner e sincronização do histórico.
