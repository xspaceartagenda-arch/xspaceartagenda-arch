package com.xspaceart.radar30.integrated.scanner;

public final class SourceHunter {
    private SourceHunter() {}

    /**
     * Lê somente DOM permitida pelo WebView/SOP. Além do documento principal,
     * percorre shadow roots abertos e iframes same-origin acessíveis. Iframes
     * cross-origin são apenas contabilizados para que a UI possa pedir OCR.
     */
    public static String discoveryScript() {
        return "(function(){try{" +
                "var kw=/(history|recent|result|last|roulette|roleta|spin|number|numero|número|winner|winning|outcome|statistics|estat)/i;" +
                "var best={score:-1,nums:[],hint:''};var scanned=0,accessible=0,blocked=0,candidates=0;" +
                "function numsFrom(t){var m=(t||'').match(/(^|\\s|[^0-9])([0-9]|[12][0-9]|3[0-6])(?=$|\\s|[^0-9])/g)||[];var a=[];for(var j=0;j<m.length;j++){var q=m[j].match(/([0-9]|[12][0-9]|3[0-6])/);if(q)a.push(parseInt(q[1],10));}return a;}" +
                "function inspectRoot(root,label){if(!root||!root.querySelectorAll)return;var els=root.querySelectorAll('[class],[id],[aria-label],[data-testid],[data-number],[data-value],[role]');" +
                "for(var i=0;i<els.length;i++){var e=els[i];scanned++;var meta=((e.id||'')+' '+(typeof e.className==='string'?e.className:'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('data-testid')||'')+' '+(e.getAttribute('role')||''));" +
                "if(kw.test(meta)){var t=(e.innerText||e.textContent||'').trim();if(t&&t.length<=6000){var ns=numsFrom(t);if(ns.length>=8&&ns.length<=500){candidates++;var score=ns.length+20;if(/history|recent|result|last|winner|winning/i.test(meta))score+=35;if(/statistics|estat/i.test(meta))score+=8;if(score>best.score)best={score:score,nums:ns.slice(0,500),hint:(label+' '+meta).slice(0,180)};}}}" +
                "if(e.shadowRoot)inspectRoot(e.shadowRoot,label+' shadow');}" +
                "var frames=root.querySelectorAll('iframe');for(var f=0;f<frames.length;f++){try{var d=frames[f].contentDocument;if(d&&d.documentElement){accessible++;inspectRoot(d,label+' iframe');}else blocked++;}catch(x){blocked++;}}}" +
                "inspectRoot(document,'main');" +
                "var out={url:location.href,title:document.title||'',iframes:document.querySelectorAll('iframe').length,accessibleFrames:accessible,blockedFrames:blocked,scannedNodes:scanned,candidates:candidates,history:best.nums,hint:best.hint};" +
                "return JSON.stringify(out); }catch(e){return JSON.stringify({error:String(e),url:location.href,title:document.title||'',iframes:0,accessibleFrames:0,blockedFrames:0,scannedNodes:0,candidates:0,history:[],hint:''});}})();";
    }
}
