package com.xspaceart.radar30.integrated.session;

import android.content.Context;
import android.content.SharedPreferences;

public final class IntegratedSessionStore {
    private static final String P = "aurum_integrated_session";
    private IntegratedSessionStore() {}
    private static SharedPreferences p(Context c) { return c.getSharedPreferences(P, Context.MODE_PRIVATE); }

    public static void start(Context c, String url) {
        p(c).edit().putLong("start", System.currentTimeMillis()).putString("url", sanitize(url))
                .putInt("signals", 0).apply();
    }
    public static void recordSignal(Context c) { p(c).edit().putInt("signals", p(c).getInt("signals",0)+1).apply(); }
    public static int signals(Context c) { return p(c).getInt("signals",0); }
    public static long startedAt(Context c) { return p(c).getLong("start",0); }
    public static void finish(Context c) { p(c).edit().putLong("end",System.currentTimeMillis()).apply(); }
    private static String sanitize(String s) { return s == null ? "" : s.split("[?#]",2)[0]; }
}
