package com.xspaceart.radar30.integrated;

import android.net.Uri;
import android.webkit.WebSettings;
import android.webkit.WebView;

public final class BrowserSecurityPolicy {
    private BrowserSecurityPolicy() {}

    public static void apply(WebView webView) {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        if (android.os.Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
    }

    public static boolean isAllowed(Uri uri) {
        if (uri == null || uri.getScheme() == null) return false;
        String scheme = uri.getScheme().toLowerCase();
        return "https".equals(scheme) || "http".equals(scheme) || "about".equals(scheme);
    }

    public static String sanitize(String raw) {
        if (raw == null) return "";
        try {
            Uri u = Uri.parse(raw);
            return new Uri.Builder().scheme(u.getScheme()).encodedAuthority(u.getEncodedAuthority())
                    .path(u.getPath()).build().toString();
        } catch (RuntimeException ignored) {
            return raw.split("[?#]", 2)[0];
        }
    }
}
