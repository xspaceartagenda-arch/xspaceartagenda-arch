package com.xspaceart.radar30.integrated;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.xspaceart.radar30.AppStateStore;
import com.xspaceart.radar30.CalibrationActivity;
import com.xspaceart.radar30.CaptureRepository;
import com.xspaceart.radar30.MainActivity;
import com.xspaceart.radar30.ScreenCaptureService;
import com.xspaceart.radar30.SessionLedger;
import com.xspaceart.radar30.Ui;
import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.CurrentTableHistory;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.integrated.normalize.SpinNormalizer;
import com.xspaceart.radar30.integrated.scanner.EnvironmentScanner;
import com.xspaceart.radar30.integrated.scanner.EvidenceGraph;
import com.xspaceart.radar30.integrated.scanner.SourceHunter;
import com.xspaceart.radar30.integrated.session.IntegratedSessionStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class IntegratedActivity extends Activity {
    private static final long SCAN_MS = 2200L;
    private static final long UI_TICK_MS = 750L;
    private static final int REQUEST_CAPTURE = 7101;
    private static final int FAMILY_COUNT = EvidenceFamily.values().length;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final IntegratedSignalBridge bridge = new IntegratedSignalBridge();
    private final SpinNormalizer normalizer = new SpinNormalizer();
    private final EnvironmentScanner environmentScanner = new EnvironmentScanner();
    private final EvidenceGraph evidenceGraph = new EvidenceGraph();

    private WebView webView;
    private EditText urlInput;
    private ProgressBar pageProgress, confluenceBar;
    private TextView liveBadge, signalTitle, signalTarget, signalMeta, secondaryText;
    private TextView scannerText, rayText, sessionText, sourceText;
    private TextView pipelineText, confluenceText, historyPreviewText, activityText, captureStatusText;
    private Switch balancedSwitch;
    private Button scanToggle, orderToggle, visualCaptureButton, calibrateButton;

    private boolean scannerRunning = true;
    private boolean firstIsNewest = true;
    private boolean receiverRegistered;
    private String lastDomFingerprint = "";
    private String lastOcrFingerprint = "";
    private String lastAcceptedSource = "—";
    private long lastScanAttemptAt;
    private long lastDataAt;
    private long scanAttempts;
    private int domHistoryCount;
    private int ocrHistoryCount;
    private int accessibleFrames;
    private int blockedFrames;
    private ConfluenceVerdict lastVerdict;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            syncFromVisualHistory();
            refreshCaptureStatus();
        }
    };

    private final Runnable scanLoop = new Runnable() {
        @Override public void run() {
            if (scannerRunning && webView != null) discoverPage();
            handler.postDelayed(this, SCAN_MS);
        }
    };

    private final Runnable uiTicker = new Runnable() {
        @Override public void run() {
            refreshTelemetryClock();
            handler.postDelayed(this, UI_TICK_MS);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        setContentView(buildUi());
        configureWebView();
        bridge.setPrecision(true);
        IntegratedSessionStore.start(this, "");
        registerStateReceiver();
        handler.postDelayed(scanLoop, 900L);
        handler.post(uiTicker);
        refreshSession();
        refreshCaptureStatus();
        syncFromVisualHistory();
    }

    @Override protected void onResume() {
        super.onResume();
        syncFromVisualHistory();
        refreshCaptureStatus();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); } catch (IllegalArgumentException ignored) {}
            receiverRegistered = false;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Leitura visual não autorizada.", Toast.LENGTH_LONG).show();
            refreshCaptureStatus();
            return;
        }
        SessionLedger.ensureActive(this, AppStateStore.provider(this), AppStateStore.dealer(this));
        Intent service = new Intent(this, ScreenCaptureService.class)
                .setAction(ScreenCaptureService.ACTION_START)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data);
        startForegroundService(service);
        captureStatusText.setText("LEITURA VISUAL • iniciando captura autorizada…");
        captureStatusText.setTextColor(Ui.CYAN);
        Toast.makeText(this,
                AppStateStore.isCalibrated(this)
                        ? "Leitura visual ativada. O histórico será sincronizado automaticamente."
                        : "Leitura visual ativada. Agora calibre a área dos últimos resultados.",
                Toast.LENGTH_LONG).show();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this,14),Ui.dp(this,9),Ui.dp(this,14),Ui.dp(this,7));
        TextView brand = Ui.text(this,"AURUM AI 37",22,Ui.GREEN,true);
        TextView lab = Ui.text(this,"  INTEGRATED",11,Ui.AMBER,true);
        liveBadge = Ui.text(this,"● INICIANDO",11,Ui.CYAN,true);
        top.addView(brand);
        top.addView(lab, new LinearLayout.LayoutParams(0,-2,1));
        top.addView(liveBadge);
        root.addView(top);

        LinearLayout address = new LinearLayout(this);
        address.setPadding(Ui.dp(this,10),0,Ui.dp(this,10),Ui.dp(this,6));
        urlInput = new EditText(this);
        urlInput.setHint("https://..."); urlInput.setSingleLine(true); urlInput.setTextColor(Ui.TEXT); urlInput.setHintTextColor(Ui.MUTED);
        urlInput.setTextSize(12); urlInput.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        Button open = Ui.button(this,"Abrir",Ui.AMBER,Color.BLACK);
        Button reload = Ui.button(this,"↻",Ui.SURFACE,Ui.TEXT);
        address.addView(urlInput,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));
        address.addView(open, new LinearLayout.LayoutParams(Ui.dp(this,76),Ui.dp(this,44)));
        address.addView(reload,new LinearLayout.LayoutParams(Ui.dp(this,50),Ui.dp(this,44)));
        root.addView(address);
        pageProgress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        pageProgress.setMax(100); pageProgress.setVisibility(View.GONE);
        root.addView(pageProgress,new LinearLayout.LayoutParams(-1,Ui.dp(this,2)));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        root.addView(webView,new LinearLayout.LayoutParams(-1,Ui.dp(this,360)));

        ScrollView lowerScroll = new ScrollView(this);
        lowerScroll.setFillViewport(true);
        LinearLayout lower = new LinearLayout(this);
        lower.setOrientation(LinearLayout.VERTICAL);
        lower.setPadding(Ui.dp(this,12),Ui.dp(this,10),Ui.dp(this,12),Ui.dp(this,18));
        lowerScroll.addView(lower);

        LinearLayout statusCard = Ui.card(this);
        LinearLayout statusHeader = new LinearLayout(this);
        statusHeader.setOrientation(LinearLayout.HORIZONTAL);
        statusHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView statusTitle = Ui.text(this,"LEITURA AO VIVO",14,Ui.CYAN,true);
        activityText = Ui.text(this,"aguardando primeira varredura",11,Ui.MUTED,false);
        activityText.setGravity(Gravity.RIGHT);
        statusHeader.addView(statusTitle,new LinearLayout.LayoutParams(0,-2,1));
        statusHeader.addView(activityText,new LinearLayout.LayoutParams(0,-2,1));
        statusCard.addView(statusHeader);
        pipelineText = Ui.text(this,"CAPTURA …   →   HISTÓRICO …   →   MOTOR …",13,Ui.TEXT,true);
        captureStatusText = Ui.text(this,"LEITURA VISUAL • parada",12,Ui.MUTED,false);
        historyPreviewText = Ui.text(this,"Últimos: —",12,Ui.MUTED,false);
        statusCard.addView(pipelineText,Ui.margins(-1,-2,this,0,8,0,0));
        statusCard.addView(captureStatusText,Ui.margins(-1,-2,this,0,5,0,0));
        statusCard.addView(historyPreviewText,Ui.margins(-1,-2,this,0,5,0,0));
        lower.addView(statusCard,Ui.margins(-1,-2,this,0,0,0,10));

        LinearLayout hero = Ui.card(this);
        signalTitle = Ui.text(this,"SCANNING • PRECISION",12,Ui.CYAN,true);
        signalTarget = Ui.text(this,"SEM SINAL ATIVO",28,Ui.TEXT,true);
        signalMeta = Ui.text(this,"Aguardando histórico suficiente da mesa",13,Ui.MUTED,false);
        secondaryText = Ui.text(this,"",12,Ui.AMBER,true); secondaryText.setVisibility(View.GONE);
        hero.addView(signalTitle); hero.addView(signalTarget); hero.addView(signalMeta); hero.addView(secondaryText);

        TextView conflTitle = Ui.text(this,"CONFLUÊNCIA • famílias independentes alinhadas",11,Ui.MUTED,true);
        confluenceBar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        confluenceBar.setMax(FAMILY_COUNT); confluenceBar.setProgress(0);
        confluenceText = Ui.text(this,"0/"+FAMILY_COUNT+" famílias • ainda sem leitura profunda",12,Ui.CYAN,true);
        hero.addView(conflTitle,Ui.margins(-1,-2,this,0,11,0,4));
        hero.addView(confluenceBar,new LinearLayout.LayoutParams(-1,Ui.dp(this,8)));
        hero.addView(confluenceText,Ui.margins(-1,-2,this,0,5,0,0));
        lower.addView(hero,Ui.margins(-1,-2,this,0,0,0,10));

        LinearLayout controls = Ui.card(this);
        controls.addView(Ui.text(this,"CONTROLE DA LEITURA",12,Ui.MUTED,true));
        balancedSwitch = new Switch(this); balancedSwitch.setText("Balanced calibrado"); balancedSwitch.setTextColor(Ui.TEXT);
        scanToggle = Ui.button(this,"DOM scanner: ATIVO",Ui.CYAN,Color.BLACK);
        orderToggle = Ui.button(this,"Ordem: primeiro = recente",Ui.SURFACE,Ui.TEXT);
        visualCaptureButton = Ui.button(this,"Ativar leitura visual / OCR",Ui.GREEN,Color.BLACK);
        calibrateButton = Ui.button(this,"Calibrar área dos resultados",Ui.AMBER,Color.BLACK);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(scanToggle,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        row.addView(orderToggle,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        controls.addView(balancedSwitch);
        controls.addView(row,Ui.margins(-1,Ui.dp(this,48),this,0,5,0,0));
        controls.addView(visualCaptureButton,Ui.margins(-1,Ui.dp(this,48),this,0,7,0,0));
        controls.addView(calibrateButton,Ui.margins(-1,Ui.dp(this,48),this,0,5,0,0));
        lower.addView(controls,Ui.margins(-1,-2,this,0,0,0,10));

        LinearLayout scanCard = Ui.card(this);
        scanCard.addView(Ui.text(this,"DIAGNÓSTICO DO SCANNER",14,Ui.CYAN,true));
        scannerText = Ui.text(this,"MESA —\nPROVEDOR —\nDOM 0 • OCR 0 • CORE 0",13,Ui.TEXT,false);
        sourceText = Ui.text(this,"FONTES 0 • GRUPOS 0",12,Ui.MUTED,false);
        scanCard.addView(scannerText); scanCard.addView(sourceText);
        lower.addView(scanCard,Ui.margins(-1,-2,this,0,0,0,10));

        LinearLayout ray = Ui.card(this);
        ray.addView(Ui.text(this,"RAIO-X DO MOMENTO",14,Ui.CYAN,true));
        rayText = Ui.text(this,"Aguardando dados suficientes para leitura profunda.",13,Ui.TEXT,false);
        Button rayOpen = Ui.button(this,"Abrir Raio-X completo",Ui.SURFACE,Ui.TEXT);
        ray.addView(rayText); ray.addView(rayOpen,Ui.margins(-1,Ui.dp(this,48),this,0,8,0,0));
        lower.addView(ray,Ui.margins(-1,-2,this,0,0,0,10));

        LinearLayout tools = Ui.card(this);
        tools.addView(Ui.text(this,"SESSÃO / FERRAMENTAS",14,Ui.AMBER,true));
        sessionText = Ui.text(this,"Sessão iniciada • 0 sinais",12,Ui.MUTED,false);
        Button stableTools = Ui.button(this,"Abrir ferramentas Stable",Ui.AMBER,Color.BLACK);
        Button finish = Ui.button(this,"Finalizar sessão",Ui.SURFACE,Ui.TEXT);
        tools.addView(sessionText); tools.addView(stableTools,Ui.margins(-1,Ui.dp(this,48),this,0,8,0,0)); tools.addView(finish,Ui.margins(-1,Ui.dp(this,48),this,0,6,0,0));
        lower.addView(tools);

        TextView footer = Ui.text(this,"Aurum Integrated • captura + histórico + core em tempo real",11,Ui.MUTED,true);
        footer.setGravity(Gravity.CENTER); lower.addView(footer,Ui.margins(-1,-2,this,0,14,0,0));
        root.addView(lowerScroll,new LinearLayout.LayoutParams(-1,0,1));

        open.setOnClickListener(v -> openEnteredUrl());
        reload.setOnClickListener(v -> webView.reload());
        scanToggle.setOnClickListener(v -> {
            scannerRunning=!scannerRunning;
            scanToggle.setText(scannerRunning?"DOM scanner: ATIVO":"DOM scanner: PAUSADO");
            if (scannerRunning) { lastDomFingerprint=""; discoverPage(); }
            refreshTelemetryClock();
        });
        orderToggle.setOnClickListener(v -> {
            firstIsNewest=!firstIsNewest;
            orderToggle.setText(firstIsNewest?"Ordem: primeiro = recente":"Ordem: último = recente");
            lastDomFingerprint="";
            discoverPage();
        });
        balancedSwitch.setOnCheckedChangeListener((b,checked) -> {
            bridge.setPrecision(!checked);
            signalMeta.setText(checked?"Balanced calibrado ativo":"Precision ativo");
            lastDomFingerprint="";
            lastOcrFingerprint="";
            syncFromVisualHistory();
        });
        visualCaptureButton.setOnClickListener(v -> requestVisualCapture());
        calibrateButton.setOnClickListener(v -> openCalibration());
        rayOpen.setOnClickListener(v -> showFullRayX());
        stableTools.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
        finish.setOnClickListener(v -> { IntegratedSessionStore.finish(this); refreshSession(); Toast.makeText(this,"Sessão registrada localmente.",Toast.LENGTH_SHORT).show(); });
        return root;
    }

    private void configureWebView() {
        BrowserSecurityPolicy.apply(webView);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView,true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int newProgress) {
                pageProgress.setProgress(newProgress); pageProgress.setVisibility(newProgress>=100?View.GONE:View.VISIBLE);
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u=req.getUrl();
                if(!BrowserSecurityPolicy.isAllowed(u)) {
                    Toast.makeText(IntegratedActivity.this,"Link externo bloqueado no LAB.",Toast.LENGTH_SHORT).show();
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView view,String url) {
                urlInput.setText(BrowserSecurityPolicy.sanitize(url));
                lastDomFingerprint="";
                IntegratedSessionStore.start(IntegratedActivity.this,url);
                discoverPage();
            }
        });
        webView.loadUrl("about:blank");
    }

    private void openEnteredUrl() {
        String raw=urlInput.getText().toString().trim(); if(raw.isEmpty()) return;
        if(!raw.contains("://")) raw="https://"+raw;
        Uri u=Uri.parse(raw);
        if(!BrowserSecurityPolicy.isAllowed(u)){ Toast.makeText(this,"Use endereço http/https.",Toast.LENGTH_SHORT).show(); return; }
        webView.loadUrl(raw);
    }

    @SuppressWarnings("deprecation")
    private void requestVisualCapture() {
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    private void openCalibration() {
        if (!CaptureRepository.hasLatest()) {
            Toast.makeText(this,
                    "Ative primeiro a leitura visual. Depois de aparecer a mesa, toque em calibrar novamente.",
                    Toast.LENGTH_LONG).show();
            requestVisualCapture();
            return;
        }
        startActivity(new Intent(this, CalibrationActivity.class));
    }

    private void registerStateReceiver() {
        IntentFilter filter = new IntentFilter(MainActivity.ACTION_STATE_UPDATED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(stateReceiver, filter);
        receiverRegistered = true;
    }

    private void discoverPage() {
        if (webView == null) return;
        lastScanAttemptAt = System.currentTimeMillis();
        scanAttempts++;
        webView.evaluateJavascript(SourceHunter.discoveryScript(), value -> {
            try {
                String decoded = decodeJsString(value);
                JSONObject o = new JSONObject(decoded);
                JSONArray a = o.optJSONArray("history");
                List<Integer> raw = new ArrayList<>();
                if(a!=null) for(int i=0;i<a.length();i++) raw.add(a.optInt(i,-1));
                List<Integer> history = normalizer.normalize(raw, firstIsNewest);
                domHistoryCount = history.size();
                accessibleFrames = o.optInt("accessibleFrames",0);
                blockedFrames = o.optInt("blockedFrames",0);
                String fingerprint = normalizer.fingerprint(history);
                String pageUrl=o.optString("url",webView.getUrl());
                String title=o.optString("title","");
                int iframes=o.optInt("iframes",0);
                String hint=o.optString("hint","");
                EnvironmentScanner.Snapshot env=environmentScanner.inspect(pageUrl,title,iframes,history.size(),hint,accessibleFrames,blockedFrames);
                renderEnvironment(env);
                if(history.size()>=8) {
                    evidenceGraph.upsert("dom-history","DOM_HISTORY",0.82,fingerprint,"current-history");
                    if(!fingerprint.equals(lastDomFingerprint)) {
                        lastDomFingerprint=fingerprint;
                        renderBridge(bridge.acceptScan(history),"DOM");
                    }
                }
                refreshSourceLine();
                refreshTelemetryClock();
            } catch(Exception error) {
                scannerText.setText("DOM • resposta indisponível\nOCR "+ocrHistoryCount+" • CORE "+bridge.historySize()+"\nLeitura visual continua disponível");
                refreshTelemetryClock();
            }
        });
    }

    private void syncFromVisualHistory() {
        List<Integer> visual = AppStateStore.loadHistory(this);
        ocrHistoryCount = visual.size();
        if (visual.size() < 8) {
            refreshSourceLine();
            refreshHistoryPreview();
            refreshTelemetryClock();
            return;
        }
        String fingerprint = normalizer.fingerprint(visual);
        evidenceGraph.upsert("ocr-history","VISUAL_OCR",0.90,fingerprint,"current-history");
        if (!fingerprint.equals(lastOcrFingerprint)) {
            lastOcrFingerprint = fingerprint;
            renderBridge(bridge.acceptScan(visual), "OCR");
        }
        refreshSourceLine();
        refreshHistoryPreview();
        refreshTelemetryClock();
    }

    private void renderEnvironment(EnvironmentScanner.Snapshot s) {
        String domState = s.historyCount >= 8 ? "✓ "+s.historyCount : "— "+s.historyCount;
        String frameState = s.blockedFrames > 0 ? " • iframe bloqueado "+s.blockedFrames : (s.accessibleFrames > 0 ? " • iframe acessível "+s.accessibleFrames : "");
        scannerText.setText("MESA "+(s.table.startsWith("Mesa não")?"—":"✓ "+shorten(s.table,32))+"\n"+
                "PROVEDOR "+("Não definido".equals(s.provider)?"—":"✓ "+s.provider)+"\n"+
                "DOM "+domState+" • OCR "+ocrHistoryCount+" • CORE "+bridge.historySize()+"\n"+
                "VARREDURAS "+scanAttempts+frameState);
    }

    private void renderBridge(IntegratedSignalBridge.Result r, String source) {
        if(!r.accepted){
            signalMeta.setText(source+" • "+r.message+" • histórico preservado");
            refreshTelemetryClock();
            return;
        }
        lastAcceptedSource = source;
        lastDataAt = System.currentTimeMillis();
        SignalUpdate u=r.update;
        lastVerdict=r.verdict;
        if(u==null) return;
        int accent=accent(u.kind);
        signalTitle.setText(u.kind.name()+" • "+(bridge.isPrecision()?"PRECISION":"BALANCED")); signalTitle.setTextColor(accent);
        signalTarget.setText(u.target>=0?(u.playLabel.isEmpty()?u.target+" + VIZINHOS":u.playLabel):u.headline);
        String score=lastVerdict==null?"—":String.valueOf(lastVerdict.aurumScore);
        String families=lastVerdict==null?"0":String.valueOf(lastVerdict.independentFamilies);
        signalMeta.setText("Fonte "+source+" • score interno "+score+"/100 • "+families+" famílias • "+r.message+" • "+r.history.size()+" giros");
        if(u.secondaryTarget>=0 && !u.secondaryCoverage.isEmpty()) {
            secondaryText.setVisibility(View.VISIBLE);
            secondaryText.setText("SECONDARY • "+u.secondaryPlayLabel+" • score "+u.secondaryStrength);
        } else secondaryText.setVisibility(View.GONE);
        updateConfluence(lastVerdict);
        renderRayX(lastVerdict,u);
        refreshHistoryPreview();
        if(u.kind==SignalUpdate.Kind.ENTRY) IntegratedSessionStore.recordSignal(this);
        refreshSession();
        refreshTelemetryClock();
    }

    private void updateConfluence(ConfluenceVerdict v) {
        if (v == null) {
            confluenceBar.setProgress(0);
            confluenceText.setText("0/"+FAMILY_COUNT+" famílias • ainda sem leitura profunda");
            confluenceText.setTextColor(Ui.CYAN);
            return;
        }
        int families=Math.min(FAMILY_COUNT,v.independentFamilies);
        confluenceBar.setProgress(families);
        String phase;
        int color;
        switch (v.decision) {
            case ENTRY: phase="SINAL CONFIRMADO"; color=Ui.GREEN; break;
            case PREPARE: phase="PREPARAR • confluência forte se formando"; color=Ui.AMBER; break;
            case OBSERVE: phase="CONFLUÊNCIA EM CONSTRUÇÃO"; color=Ui.AMBER; break;
            default: phase="LENDO • sem convergência suficiente"; color=Ui.CYAN; break;
        }
        confluenceText.setText(families+"/"+FAMILY_COUNT+" famílias alinhadas • "+phase);
        confluenceText.setTextColor(color);
    }

    private void refreshHistoryPreview() {
        List<Integer> h = bridge.historySnapshot();
        if (h.isEmpty()) { historyPreviewText.setText("Últimos: —"); return; }
        StringBuilder b=new StringBuilder("Últimos: ");
        int n=Math.min(10,h.size());
        for(int i=0;i<n;i++){ if(i>0)b.append(" • "); b.append(h.get(i)); }
        historyPreviewText.setText(b.toString());
    }

    private void refreshSourceLine() {
        sourceText.setText("FONTES "+evidenceGraph.sourceCount()+" • GRUPOS "+evidenceGraph.independentGroups()+
                " • DOM "+(domHistoryCount>=8?"✓":"—")+" • OCR "+(ocrHistoryCount>=8?"✓":"—")+" • CORE "+bridge.historySize());
    }

    private void refreshCaptureStatus() {
        String status=AppStateStore.getStatus(this);
        boolean active=status!=null && (status.toLowerCase(Locale.ROOT).contains("captura ativa") || status.toLowerCase(Locale.ROOT).contains("aguardando") || status.toLowerCase(Locale.ROOT).contains("histórico limpo"));
        boolean calibrated=AppStateStore.isCalibrated(this);
        captureStatusText.setText("LEITURA VISUAL • "+(active?"ATIVA":"PARADA")+" • "+(calibrated?"área calibrada":"falta calibrar")+" • "+shorten(status,58));
        captureStatusText.setTextColor(active?(calibrated?Ui.GREEN:Ui.AMBER):Ui.MUTED);
        visualCaptureButton.setText(active?"Reautorizar leitura visual / OCR":"Ativar leitura visual / OCR");
        calibrateButton.setText(calibrated?"Recalibrar área dos resultados":"Calibrar área dos resultados");
    }

    private void refreshTelemetryClock() {
        int core=bridge.historySize();
        boolean hasCapture=domHistoryCount>=8 || ocrHistoryCount>=8;
        boolean deep=core>=CurrentTableHistory.MIN_DEEP_SCAN_RESULTS;
        boolean engine=core>=8;
        pipelineText.setText("CAPTURA "+(hasCapture?"✓":"…")+"   →   HISTÓRICO "+(core>0?"✓ "+core:"…")+"   →   MOTOR "+(engine?"✓":"…")+"   →   PROFUNDO "+(deep?"✓":"…"));
        pipelineText.setTextColor(deep?Ui.GREEN:(engine?Ui.AMBER:Ui.TEXT));

        long now=System.currentTimeMillis();
        long age=lastScanAttemptAt<=0?-1:(now-lastScanAttemptAt)/1000L;
        long dataAge=lastDataAt<=0?-1:(now-lastDataAt)/1000L;
        String scanAge=age<0?"—":age+"s";
        String data=dataAge<0?"sem dados":(dataAge<2?"agora":dataAge+"s atrás");
        activityText.setText("scan "+scanAge+" • dado "+data);

        if (!scannerRunning && ocrHistoryCount < 8) {
            liveBadge.setText("● PAUSADO"); liveBadge.setTextColor(Ui.MUTED);
        } else if (core >= 8 && dataAge >= 0 && dataAge <= 8) {
            liveBadge.setText("● ANALISANDO"); liveBadge.setTextColor(Ui.GREEN);
        } else if (core >= 8) {
            liveBadge.setText("● MONITORANDO"); liveBadge.setTextColor(Ui.CYAN);
        } else if (blockedFrames > 0 && ocrHistoryCount < 8) {
            liveBadge.setText("● PRECISA OCR"); liveBadge.setTextColor(Ui.AMBER);
        } else {
            liveBadge.setText("● PROCURANDO"); liveBadge.setTextColor(Ui.CYAN);
        }

        if (core < 8) {
            signalTitle.setText("SCANNING • "+(bridge.isPrecision()?"PRECISION":"BALANCED"));
            signalTitle.setTextColor(Ui.CYAN);
            signalTarget.setText("AGUARDANDO HISTÓRICO");
            if (blockedFrames > 0 && ocrHistoryCount < 8) {
                signalMeta.setText("A roleta abriu, mas a DOM está isolada. Ative a leitura visual/OCR e calibre a grade de resultados.");
            } else {
                signalMeta.setText("Procurando resultados da mesa • DOM "+domHistoryCount+" • OCR "+ocrHistoryCount);
            }
            updateConfluence(null);
        }
        refreshHistoryPreview();
        refreshSourceLine();
    }

    private void renderRayX(ConfluenceVerdict v, SignalUpdate u) {
        if(v==null){ rayText.setText("Aguardando dados suficientes para leitura profunda."); return; }
        String mode=bridge.isPrecision()?"Precision":"Balanced";
        rayText.setText("GATE AO VIVO • "+mode+" • "+v.decision+"\n"+
                "ALINHADAS "+v.independentFamilies+"/"+FAMILY_COUNT+" • CONTRADIÇÃO "+pct(v.contradictionScore)+" • DOMINÂNCIA "+pct(v.dominanceMargin)+"\n"+
                "REGIME "+v.spatialRegime+" • "+v.signalShape+"\n"+
                (u.detail==null?"":shorten(u.detail.replace('\n',' '),170)));
    }

    private void showFullRayX() {
        if(lastVerdict==null){ Toast.makeText(this,"Raio-X ainda sem veredito.",Toast.LENGTH_SHORT).show(); return; }
        StringBuilder b=new StringBuilder(); ConfluenceVerdict v=lastVerdict;
        b.append("FONTE ATUAL: ").append(lastAcceptedSource).append("\nDECISÃO: ").append(v.decision).append("\nALVO: ").append(v.target).append("\nAURUM SCORE: ").append(v.aurumScore).append("/100\n")
                .append("FAMÍLIAS: ").append(v.independentFamilies).append('/').append(FAMILY_COUNT).append("\nCONTRADIÇÃO: ").append(pct(v.contradictionScore)).append("\nDOMINÂNCIA: ").append(pct(v.dominanceMargin)).append("\nDISPERSÃO: ").append(pct(v.evidenceDispersion)).append("\nREGIME: ").append(v.spatialRegime).append("\nSHAPE: ").append(v.signalShape).append("\n\nFAMÍLIAS ALINHADAS:\n");
        for(EvidenceFamily f:v.supportingFamilies) b.append("• ").append(f.name()).append('\n');
        b.append("\nRAZÕES:\n"); for(String s:v.reasons) b.append("• ").append(s).append('\n');
        if(v.hasSecondary()){ b.append("\nSECONDARY: ").append(v.secondaryTarget).append(" • score ").append(v.secondaryScore).append('\n'); for(String s:v.secondaryReasons) b.append("• ").append(s).append('\n'); }
        TextView t=Ui.text(this,b.toString(),13,Ui.TEXT,false); t.setPadding(Ui.dp(this,16),Ui.dp(this,10),Ui.dp(this,16),Ui.dp(this,20));
        ScrollView s=new ScrollView(this); s.setBackgroundColor(Ui.BG); s.addView(t);
        new AlertDialog.Builder(this).setTitle("RAIO-X • INTEGRATED").setView(s).setPositiveButton("Fechar",null).show();
    }

    private void refreshSession() {
        long start=IntegratedSessionStore.startedAt(this); long mins=start<=0?0:Math.max(0,(System.currentTimeMillis()-start)/60000L);
        sessionText.setText("Sessão • "+mins+" min • "+IntegratedSessionStore.signals(this)+" sinais publicados • core "+bridge.historySize()+" giros");
    }

    private static String decodeJsString(String value) throws Exception {
        if(value==null||"null".equals(value)) return "{}";
        if(value.startsWith("\"")&&value.endsWith("\"")) return new JSONArray("["+value+"]").getString(0);
        return value;
    }
    private static String shorten(String s,int n){ if(s==null)return ""; s=s.trim(); return s.length()<=n?s:s.substring(0,n-1)+"…"; }
    private static String pct(double v){ return String.format(Locale.US,"%.0f%%",v*100.0); }
    private static int accent(SignalUpdate.Kind k){ if(k==SignalUpdate.Kind.ENTRY||k==SignalUpdate.Kind.ACTIVE||k==SignalUpdate.Kind.HIT||k==SignalUpdate.Kind.SECONDARY_HIT)return Ui.GREEN; if(k==SignalUpdate.Kind.PREPARE||k==SignalUpdate.Kind.OBSERVE)return Ui.AMBER; if(k==SignalUpdate.Kind.INVALIDATED||k==SignalUpdate.Kind.EXPIRED)return Ui.RED; return Ui.CYAN; }
}
