# Integrated LAB — Preflight Report

Versão: 0.7.0-integrated-alpha
Base: Aurum AI 37 v0.6.3 Balanced Calibrado

## Verificações executadas
- AndroidManifest.xml: XML válido — PASS
- applicationId independente: com.xspaceart.aurumai37.integratedlab — PASS
- core v0.6.3 preservado byte a byte (17 arquivos Java) — PASS
- compilação Java pura do core + bridge + normalizer + EvidenceGraph + SourceHunter — PASS
- CoreSmokeTest — PASS
- DualTargetCoreTest — PASS
- V063BalancedCalibrationTest — PASS (Precision=0, Balanced=5 no vetor de calibração)
- keystore de release/teste removida do pacote Integrated — PASS
- sem addJavascriptInterface — PASS
- sem automação de aposta — PASS

## Ainda exige GitHub/Android build
A Activity/WebView depende do Android SDK e precisa ser compilada pelo GitHub Actions.
O projeto não deve ser considerado funcional até instalar e abrir fisicamente no Samsung S25 FE.

## Primeiro teste físico
1. Instalar ao lado do Stable.
2. Abrir 3 vezes.
3. Abrir URL dentro da WebView.
4. Confirmar login manual e navegação.
5. Confirmar Auto Discovery.
6. Ver se DOM HISTORY aparece; se não, validar fallback OCR.
7. Conferir Signal Hero/Raio-X com histórico real.
