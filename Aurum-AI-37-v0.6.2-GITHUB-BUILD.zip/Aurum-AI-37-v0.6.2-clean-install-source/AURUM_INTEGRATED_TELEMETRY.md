# Aurum Integrated Telemetry

- Interface agora separa CAPTURA -> HISTORICO -> MOTOR -> LEITURA PROFUNDA.
- DOM scanner continua sem violar same-origin policy.
- SourceHunter percorre shadow roots abertos e iframes same-origin.
- Iframes cross-origin sao detectados e exibidos como necessidade de OCR.
- IntegratedActivity pode iniciar MediaProjection/OCR sem sair da roleta.
- Historico OCR e sincronizado ao mesmo IntegratedSignalBridge/core.
- Barra de confluencia usa numero de familias independentes (0..11), nao probabilidade.
- Ultimos resultados, fonte aceita, idade do ultimo dado e heartbeat de scanner ficam visiveis.
- Motor de sinais/core nao foi alterado.
