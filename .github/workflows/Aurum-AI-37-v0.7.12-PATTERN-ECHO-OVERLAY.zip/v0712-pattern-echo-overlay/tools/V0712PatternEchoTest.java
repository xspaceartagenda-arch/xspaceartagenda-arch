import com.xspaceart.radar30.echo.PatternEchoEngine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class V0712PatternEchoTest {
    public static void main(String[] args) {
        terminalCamouflageExample();
        physicalWheelTransformExample();
        exactEchoExample();
        futureLeakageGuard();
        invalidNumberGuard();
        System.out.println("OK v0.7.12 pattern echo");
    }

    private static void terminalCamouflageExample() {
        // Historical: 33,12,15 -> 16. Current: 23,32,35.
        // Both windows share terminal signature 3,2,5; historical follower has terminal 6.
        List<Integer> h = Arrays.asList(33,12,15,16, 7,20,8,14,31, 23,32,35);
        PatternEchoEngine.Result r = PatternEchoEngine.analyze(h,
                new PatternEchoEngine.Settings(3, PatternEchoEngine.Mode.AUTO, 20, 2, 82));
        PatternEchoEngine.Match m = find(r, Arrays.asList(33,12,15));
        require(m != null, "terminal echo not found");
        require(m.matchedBy == PatternEchoEngine.Mode.TERMINAL, "expected TERMINAL, got " + m.matchedBy);
        require(m.historicalFollower == 16, "historical follower should be 16");
        require(m.projectedTerminal == 6, "projected terminal should be 6");
        require(m.compatibility >= 99.0, "terminal compatibility should be full");
    }

    private static void physicalWheelTransformExample() {
        // Every current number is one clockwise wheel position after historical sequence.
        // Historical 32,15,19 -> 4. Shift +1 projects follower 4 -> 21.
        List<Integer> h = Arrays.asList(32,15,19,4, 8,23,10,7,28, 15,19,4);
        PatternEchoEngine.Result r = PatternEchoEngine.analyze(h,
                new PatternEchoEngine.Settings(3, PatternEchoEngine.Mode.STRUCTURAL, 20, 2, 78));
        PatternEchoEngine.Match m = find(r, Arrays.asList(32,15,19));
        require(m != null, "structural wheel echo not found");
        require(m.projectedPrimary == 21, "wheel shift should project 4 -> 21, got " + m.projectedPrimary);
        require(m.transformConsistency >= 0.99, "wheel transform should be consistent");
    }

    private static void exactEchoExample() {
        List<Integer> h = Arrays.asList(5,24,16,33, 2,25,17, 5,24,16);
        PatternEchoEngine.Result r = PatternEchoEngine.analyze(h,
                new PatternEchoEngine.Settings(3, PatternEchoEngine.Mode.EXACT, 10, 2, 82));
        PatternEchoEngine.Match m = find(r, Arrays.asList(5,24,16));
        require(m != null, "exact echo not found");
        require(m.historicalFollower == 33, "exact follower should be 33");
        require(m.compatibility > 99.999, "exact score should be 100");
    }

    private static void futureLeakageGuard() {
        // The active suffix must never be used as its own historical match.
        List<Integer> h = new ArrayList<>(Arrays.asList(0,32,15,19,4,21,2,25,17,34, 13,33,34));
        PatternEchoEngine.Result r = PatternEchoEngine.analyze(h,
                new PatternEchoEngine.Settings(3, PatternEchoEngine.Mode.EXACT, 20, 2, 0));
        for (PatternEchoEngine.Match m : r.matches) {
            require(m.historicalStart + 3 < h.size() - 3,
                    "leakage: follower overlaps current suffix");
        }
    }

    private static void invalidNumberGuard() {
        boolean failed = false;
        try {
            PatternEchoEngine.analyze(Arrays.asList(1,2,3,4,5,6,37), PatternEchoEngine.Settings.defaults(3));
        } catch (IllegalArgumentException expected) {
            failed = true;
        }
        require(failed, "invalid roulette number should fail validation");
    }

    private static PatternEchoEngine.Match find(PatternEchoEngine.Result r, List<Integer> seq) {
        for (PatternEchoEngine.Match m : r.matches) if (m.historicalSequence.equals(seq)) return m;
        return null;
    }

    private static void require(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
}
