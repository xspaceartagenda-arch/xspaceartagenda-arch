#!/usr/bin/env python3
from pathlib import Path
import re

root = Path.cwd()
engine = root / 'app/src/main/java/com/xspaceart/radar30/echo/PatternEchoEngine.java'
activity = root / 'app/src/main/java/com/xspaceart/radar30/echo/PatternEchoActivity.java'
manifest = root / 'app/src/main/AndroidManifest.xml'
gradle = root / 'app/build.gradle'
for p in (engine, activity, manifest, gradle):
    assert p.exists(), f'missing {p}'

e = engine.read_text(encoding='utf-8')
a = activity.read_text(encoding='utf-8')
m = manifest.read_text(encoding='utf-8')
g = gradle.read_text(encoding='utf-8')

assert 'class PatternEchoEngine' in e
assert 'Mode.AUTO' in e or 'AUTO' in e
assert 'wheelDistance' in e
assert 'terminalScore' in e
assert 'structuralScore' in e
assert 'i + len < currentStart' in e, 'future-leakage guard missing'
assert 'never a probability' in e.lower() or 'never a probability' in e
assert 'AppStateStore.loadHistory(this)' in a
assert 'PatternEchoEngine.analyze' in a
assert 'PatternEchoActivity' in m
assert re.search(r'versionCode\s+13\b', g), 'versionCode must be 13'
assert re.search(r'versionName\s+["\']0\.7\.12-pattern-echo["\']', g), 'versionName must be 0.7.12-pattern-echo'
print('V0712_STATIC_VALIDATION=PASS')
