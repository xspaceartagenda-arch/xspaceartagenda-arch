#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
gradle = root / 'app/build.gradle'
manifest = root / 'app/src/main/AndroidManifest.xml'
if not gradle.exists() or not manifest.exists():
    raise SystemExit('project root invalid: app/build.gradle or AndroidManifest.xml missing')

g = gradle.read_text(encoding='utf-8')
g2, n1 = re.subn(r'(?m)(\bversionCode\s+)\d+', r'\g<1>13', g, count=1)
g2, n2 = re.subn(r'(?m)(\bversionName\s+)["\'][^"\']+["\']', r'\g<1>"0.7.12-pattern-echo"', g2, count=1)
if n1 != 1 or n2 != 1:
    raise SystemExit(f'could not patch app/build.gradle (versionCode={n1}, versionName={n2})')
gradle.write_text(g2, encoding='utf-8')

m = manifest.read_text(encoding='utf-8')
if 'com.xspaceart.radar30.echo.PatternEchoActivity' not in m:
    marker = '</application>'
    if marker not in m:
        raise SystemExit('AndroidManifest.xml has no </application>')
    block = '''\n        <!-- v0.7.12: isolated read-only Pattern Echo mode.\n             Separate launcher keeps v0.7.11 StandaloneActivity untouched. -->\n        <activity\n            android:name="com.xspaceart.radar30.echo.PatternEchoActivity"\n            android:exported="true"\n            android:label="Aurum Echo">\n            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />\n                <category android:name="android.intent.category.LAUNCHER" />\n            </intent-filter>\n        </activity>\n'''
    m = m.replace(marker, block + '    ' + marker, 1)
    manifest.write_text(m, encoding='utf-8')
print('PATCH_V0712=PASS')
