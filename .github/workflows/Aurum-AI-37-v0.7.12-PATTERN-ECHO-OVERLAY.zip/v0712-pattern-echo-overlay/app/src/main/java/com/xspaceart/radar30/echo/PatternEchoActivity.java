package com.xspaceart.radar30.echo;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.xspaceart.radar30.AppStateStore;

import java.util.List;

/**
 * Isolated read-only mode for Pattern Echo.
 * Reads the canonical saved history and never pushes data into the live CORE.
 */
public final class PatternEchoActivity extends Activity {
    private static final int BG = Color.rgb(7, 10, 13);
    private static final int CARD = Color.rgb(18, 24, 29);
    private static final int TEXT = Color.rgb(235, 242, 246);
    private static final int MUTED = Color.rgb(150, 169, 180);
    private static final int ACCENT = Color.rgb(74, 231, 166);
    private static final int CYAN = Color.rgb(70, 205, 235);

    private Spinner lengthSpinner;
    private Spinner modeSpinner;
    private TextView status;
    private TextView output;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        setContentView(buildUi());
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView brand = text("AURUM AI 37", 24, ACCENT, true);
        root.addView(brand);
        TextView title = text("PATTERN ECHO • SEQUÊNCIA CAMUFLADA", 14, CYAN, true);
        title.setPadding(0, dp(2), 0, dp(12));
        root.addView(title);

        TextView explainer = text(
                "Modo auxiliar e somente leitura. Procura no histórico sequências antigas parecidas com a sequência atual — exatas, por terminal, vizinhos físicos da roda ou estrutura — e mostra o que veio depois. Compatibilidade não é probabilidade.",
                13, MUTED, false);
        explainer.setLineSpacing(0f, 1.15f);
        root.addView(explainer);

        LinearLayout controls = card();
        controls.setPadding(dp(12), dp(12), dp(12), dp(12));
        controls.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(14);
        root.addView(controls, cp);

        controls.addView(text("Tamanho da sequência", 12, MUTED, true));
        lengthSpinner = new Spinner(this);
        lengthSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"AUTO • 3–5 giros", "3 giros", "4 giros", "5 giros"}));
        controls.addView(lengthSpinner, new LinearLayout.LayoutParams(-1, -2));

        TextView modeLabel = text("Tipo de comparação", 12, MUTED, true);
        modeLabel.setPadding(0, dp(10), 0, 0);
        controls.addView(modeLabel);
        modeSpinner = new Spinner(this);
        modeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"AUTO • melhor assinatura", "EXATO", "TERMINAL", "VIZINHOS DA RODA", "ESTRUTURA"}));
        controls.addView(modeSpinner, new LinearLayout.LayoutParams(-1, -2));

        Button refresh = new Button(this);
        refresh.setText("ATUALIZAR LEITURA");
        refresh.setAllCaps(false);
        refresh.setOnClickListener(v -> refresh());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(50));
        bp.topMargin = dp(12);
        controls.addView(refresh, bp);

        status = text("", 12, MUTED, false);
        status.setPadding(0, dp(14), 0, dp(8));
        root.addView(status);

        output = text("", 14, TEXT, false);
        output.setTextIsSelectable(true);
        output.setLineSpacing(0f, 1.14f);
        LinearLayout resultCard = card();
        resultCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        resultCard.addView(output, new LinearLayout.LayoutParams(-1, -2));
        root.addView(resultCard, new LinearLayout.LayoutParams(-1, -2));

        TextView footer = text(
                "O Pattern Echo não publica sinal, não altera pesos e não modifica o histórico. Ele serve como uma camada de investigação para comparar ecos passados com a mesa atual.",
                12, MUTED, false);
        footer.setPadding(0, dp(14), 0, 0);
        root.addView(footer);
        return scroll;
    }

    private void refresh() {
        if (lengthSpinner == null || modeSpinner == null) return;
        List<Integer> history = AppStateStore.loadHistory(this);
        int lengthChoice = lengthSpinner.getSelectedItemPosition();
        PatternEchoEngine.Mode mode = modeFromPosition(modeSpinner.getSelectedItemPosition());
        try {
            if (lengthChoice == 0) {
                StringBuilder all = new StringBuilder();
                int totalEchoes = 0;
                for (int len : new int[]{5, 4, 3}) {
                    PatternEchoEngine.Settings settings = new PatternEchoEngine.Settings(len, mode, 8, 2, 82.0);
                    PatternEchoEngine.Result result = PatternEchoEngine.analyze(history, settings);
                    totalEchoes += result.matches.size();
                    if (all.length() > 0) all.append("\n\n────────────────────\n\n");
                    all.append(PatternEchoEngine.describe(result));
                }
                status.setText("Histórico confirmado: " + history.size() + " giros • varredura 3–5 • " + mode + " • ecos " + totalEchoes);
                output.setText(all.toString());
            } else {
                int len = lengthChoice + 2;
                PatternEchoEngine.Settings settings = new PatternEchoEngine.Settings(len, mode, 12, 2, 82.0);
                PatternEchoEngine.Result result = PatternEchoEngine.analyze(history, settings);
                status.setText("Histórico confirmado: " + history.size() + " giros • janela " + len + " • " + mode);
                output.setText(PatternEchoEngine.describe(result));
            }
        } catch (RuntimeException ex) {
            status.setText("Leitura indisponível");
            output.setText("Não foi possível analisar o histórico: " + ex.getMessage());
        }
    }

    private static PatternEchoEngine.Mode modeFromPosition(int p) {
        switch (p) {
            case 1: return PatternEchoEngine.Mode.EXACT;
            case 2: return PatternEchoEngine.Mode.TERMINAL;
            case 3: return PatternEchoEngine.Mode.NEIGHBOR;
            case 4: return PatternEchoEngine.Mode.STRUCTURAL;
            default: return PatternEchoEngine.Mode.AUTO;
        }
    }

    private LinearLayout card() {
        LinearLayout v = new LinearLayout(this);
        v.setBackgroundColor(CARD);
        v.setGravity(Gravity.START);
        return v;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        return v;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
