package com.xspaceart.radar30.echo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Read-only historical similarity engine for Aurum AI 37.
 *
 * It never publishes a live signal and never modifies the strategic CORE.
 * It compares the current suffix (3..5 spins) with older historical windows,
 * including exact, terminal, physical-wheel-neighbor and structural echoes.
 * The value returned is a similarity/compatibility score, never a probability.
 */
public final class PatternEchoEngine {
    private PatternEchoEngine() {}

    // European single-zero wheel, clockwise.
    private static final int[] WHEEL = {
            0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10,
            5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
    };
    private static final int[] WHEEL_INDEX = new int[37];
    static {
        Arrays.fill(WHEEL_INDEX, -1);
        for (int i = 0; i < WHEEL.length; i++) WHEEL_INDEX[WHEEL[i]] = i;
    }

    public enum Mode {
        AUTO, EXACT, TERMINAL, NEIGHBOR, STRUCTURAL
    }

    public static final class Settings {
        public final int windowLength;
        public final Mode mode;
        public final int maxMatches;
        public final int neighborRadius;
        public final double minimumCompatibility;

        public Settings(int windowLength, Mode mode, int maxMatches, int neighborRadius,
                        double minimumCompatibility) {
            if (windowLength < 3 || windowLength > 5) {
                throw new IllegalArgumentException("windowLength must be 3..5");
            }
            this.windowLength = windowLength;
            this.mode = mode == null ? Mode.AUTO : mode;
            this.maxMatches = Math.max(1, Math.min(30, maxMatches));
            this.neighborRadius = Math.max(1, Math.min(3, neighborRadius));
            this.minimumCompatibility = clamp(minimumCompatibility, 0.0, 100.0);
        }

        public static Settings defaults(int windowLength) {
            return new Settings(windowLength, Mode.AUTO, 12, 2, 82.0);
        }
    }

    public static final class Match {
        public final int historicalStart;
        public final int distanceFromCurrent;
        public final List<Integer> historicalSequence;
        public final List<Integer> currentSequence;
        public final int historicalFollower;
        public final Mode matchedBy;
        public final double compatibility;
        public final int projectedPrimary;
        public final List<Integer> projectedRegion;
        public final int projectedTerminal;
        public final double transformConsistency;

        Match(int historicalStart, int distanceFromCurrent, List<Integer> historicalSequence,
              List<Integer> currentSequence, int historicalFollower, Mode matchedBy,
              double compatibility, int projectedPrimary, List<Integer> projectedRegion,
              int projectedTerminal, double transformConsistency) {
            this.historicalStart = historicalStart;
            this.distanceFromCurrent = distanceFromCurrent;
            this.historicalSequence = historicalSequence;
            this.currentSequence = currentSequence;
            this.historicalFollower = historicalFollower;
            this.matchedBy = matchedBy;
            this.compatibility = compatibility;
            this.projectedPrimary = projectedPrimary;
            this.projectedRegion = projectedRegion;
            this.projectedTerminal = projectedTerminal;
            this.transformConsistency = transformConsistency;
        }

        public String projectionLabel() {
            if (matchedBy == Mode.TERMINAL) return "terminal " + projectedTerminal;
            return String.valueOf(projectedPrimary);
        }
    }

    public static final class Aggregate {
        public final String key;
        public final String label;
        public final int occurrences;
        public final double weightedSupport;
        public final double bestCompatibility;

        Aggregate(String key, String label, int occurrences, double weightedSupport,
                  double bestCompatibility) {
            this.key = key;
            this.label = label;
            this.occurrences = occurrences;
            this.weightedSupport = weightedSupport;
            this.bestCompatibility = bestCompatibility;
        }
    }

    public static final class Result {
        public final int windowLength;
        public final List<Integer> currentSequence;
        public final List<Match> matches;
        public final List<Aggregate> aggregates;
        public final String note;

        Result(int windowLength, List<Integer> currentSequence, List<Match> matches,
               List<Aggregate> aggregates, String note) {
            this.windowLength = windowLength;
            this.currentSequence = currentSequence;
            this.matches = matches;
            this.aggregates = aggregates;
            this.note = note;
        }

        public boolean hasEcho() { return !matches.isEmpty(); }
    }

    public static Result analyze(List<Integer> canonicalHistory, Settings settings) {
        if (canonicalHistory == null) canonicalHistory = Collections.emptyList();
        validateHistory(canonicalHistory);
        if (settings == null) settings = Settings.defaults(3);

        final int n = canonicalHistory.size();
        final int len = settings.windowLength;
        if (n < (len * 2 + 1)) {
            return new Result(len, suffix(canonicalHistory, Math.min(len, n)),
                    Collections.emptyList(), Collections.emptyList(),
                    "Histórico insuficiente para comparar uma janela atual com uma ocorrência antiga e seu giro seguinte.");
        }

        final int currentStart = n - len;
        final List<Integer> current = copyRange(canonicalHistory, currentStart, n);
        final List<Match> found = new ArrayList<>();

        // Leakage guard: i+len is the historical follower and must be strictly before currentStart.
        for (int i = 0; i + len < currentStart; i++) {
            List<Integer> historical = copyRange(canonicalHistory, i, i + len);
            int follower = canonicalHistory.get(i + len);
            ScoredMode sm = score(historical, current, settings.mode, settings.neighborRadius);
            if (sm.score + 1e-9 < thresholdFor(settings, sm.mode)) continue;

            Projection p = project(historical, current, follower, sm.mode, settings.neighborRadius);
            int distance = currentStart - (i + len);
            found.add(new Match(i, distance, historical, current, follower, sm.mode, sm.score,
                    p.primary, p.region, p.terminal, p.transformConsistency));
        }

        found.sort(Comparator
                .comparingDouble((Match m) -> m.compatibility).reversed()
                .thenComparingInt(m -> m.distanceFromCurrent)
                .thenComparingInt(m -> m.historicalStart));

        if (found.size() > settings.maxMatches) {
            found.subList(settings.maxMatches, found.size()).clear();
        }

        List<Aggregate> aggregates = aggregate(found, len);
        String note = found.isEmpty()
                ? "Nenhum eco histórico atingiu a régua configurada."
                : "Eco = similaridade histórica. O resultado posterior observado não é probabilidade nem garantia do próximo giro.";
        return new Result(len, current, Collections.unmodifiableList(found),
                Collections.unmodifiableList(aggregates), note);
    }

    private static double thresholdFor(Settings s, Mode actualMode) {
        double base = s.minimumCompatibility;
        if (actualMode == Mode.EXACT) return Math.max(base, 99.999);
        if (actualMode == Mode.TERMINAL) return Math.max(base, 99.0);
        return base;
    }

    private static final class ScoredMode {
        final Mode mode; final double score;
        ScoredMode(Mode mode, double score) { this.mode = mode; this.score = score; }
    }

    private static ScoredMode score(List<Integer> h, List<Integer> q, Mode requested, int radius) {
        if (requested != Mode.AUTO) return new ScoredMode(requested, scoreMode(h, q, requested, radius));
        ScoredMode best = new ScoredMode(Mode.EXACT, scoreMode(h, q, Mode.EXACT, radius));
        for (Mode mode : new Mode[]{Mode.TERMINAL, Mode.NEIGHBOR, Mode.STRUCTURAL}) {
            double s = scoreMode(h, q, mode, radius);
            // Prefer more specific modes on effectively equal scores.
            if (s > best.score + 0.001 || (Math.abs(s - best.score) <= 0.001 && specificity(mode) < specificity(best.mode))) {
                best = new ScoredMode(mode, s);
            }
        }
        return best;
    }

    private static int specificity(Mode m) {
        switch (m) {
            case EXACT: return 0;
            case TERMINAL: return 1;
            case NEIGHBOR: return 2;
            case STRUCTURAL: return 3;
            default: return 9;
        }
    }

    private static double scoreMode(List<Integer> h, List<Integer> q, Mode mode, int radius) {
        switch (mode) {
            case EXACT: return exactScore(h, q);
            case TERMINAL: return terminalScore(h, q);
            case NEIGHBOR: return neighborScore(h, q, radius);
            case STRUCTURAL: return structuralScore(h, q);
            case AUTO:
            default: throw new IllegalArgumentException("AUTO is resolved before scoreMode");
        }
    }

    private static double exactScore(List<Integer> a, List<Integer> b) {
        int hit = 0;
        for (int i = 0; i < a.size(); i++) if (a.get(i).intValue() == b.get(i).intValue()) hit++;
        return 100.0 * hit / a.size();
    }

    private static double terminalScore(List<Integer> a, List<Integer> b) {
        int hit = 0;
        for (int i = 0; i < a.size(); i++) if (terminal(a.get(i)) == terminal(b.get(i))) hit++;
        return 100.0 * hit / a.size();
    }

    private static double neighborScore(List<Integer> a, List<Integer> b, int radius) {
        double total = 0.0;
        for (int i = 0; i < a.size(); i++) {
            int d = wheelDistance(a.get(i), b.get(i));
            if (d == 0) total += 100.0;
            else if (d == 1) total += 94.0;
            else if (d == 2 && radius >= 2) total += 86.0;
            else if (d == 3 && radius >= 3) total += 76.0;
        }
        return total / a.size();
    }

    private static double structuralScore(List<Integer> a, List<Integer> b) {
        if (a.size() < 2) return 0.0;
        double transitions = 0.0;
        for (int i = 1; i < a.size(); i++) {
            int da = signedWheelStep(a.get(i - 1), a.get(i));
            int db = signedWheelStep(b.get(i - 1), b.get(i));
            int delta = Math.abs(da - db);
            delta = Math.min(delta, WHEEL.length - Math.min(delta, WHEEL.length));
            transitions += Math.max(0.0, 100.0 - 12.0 * delta);
        }
        transitions /= (a.size() - 1);

        Transform t = dominantTransform(a, b);
        double transform = 100.0 * t.consistency;
        return 0.58 * transitions + 0.42 * transform;
    }

    private static final class Projection {
        final int primary, terminal; final List<Integer> region; final double transformConsistency;
        Projection(int primary, int terminal, List<Integer> region, double transformConsistency) {
            this.primary = primary; this.terminal = terminal; this.region = region;
            this.transformConsistency = transformConsistency;
        }
    }

    private static Projection project(List<Integer> historical, List<Integer> current, int follower,
                                      Mode mode, int radius) {
        if (mode == Mode.TERMINAL) {
            return new Projection(follower, terminal(follower), terminalMembers(terminal(follower)), 1.0);
        }
        if (mode == Mode.STRUCTURAL) {
            Transform t = dominantTransform(historical, current);
            int shifted = shiftOnWheel(follower, t.offset);
            return new Projection(shifted, terminal(shifted), wheelRegion(shifted, radius), t.consistency);
        }
        // Exact and neighbor modes intentionally report what historically followed plus its physical region.
        return new Projection(follower, terminal(follower), wheelRegion(follower, radius),
                mode == Mode.EXACT ? 1.0 : neighborTransformConsistency(historical, current));
    }

    private static final class Transform {
        final int offset; final double consistency;
        Transform(int offset, double consistency) { this.offset = offset; this.consistency = consistency; }
    }

    private static Transform dominantTransform(List<Integer> from, List<Integer> to) {
        Map<Integer, Integer> counts = new LinkedHashMap<>();
        for (int i = 0; i < from.size(); i++) {
            int offset = normalizeOffset(WHEEL_INDEX[to.get(i)] - WHEEL_INDEX[from.get(i)]);
            counts.put(offset, counts.getOrDefault(offset, 0) + 1);
        }
        int bestOffset = 0, bestCount = -1;
        for (Map.Entry<Integer,Integer> e : counts.entrySet()) {
            if (e.getValue() > bestCount) { bestOffset = e.getKey(); bestCount = e.getValue(); }
        }
        return new Transform(bestOffset, bestCount <= 0 ? 0.0 : bestCount / (double) from.size());
    }

    private static double neighborTransformConsistency(List<Integer> from, List<Integer> to) {
        return dominantTransform(from, to).consistency;
    }

    private static int normalizeOffset(int d) {
        int n = WHEEL.length;
        d %= n;
        if (d > n / 2) d -= n;
        if (d < -n / 2) d += n;
        return d;
    }

    private static int signedWheelStep(int from, int to) {
        return normalizeOffset(WHEEL_INDEX[to] - WHEEL_INDEX[from]);
    }

    private static int shiftOnWheel(int number, int offset) {
        int idx = WHEEL_INDEX[number];
        int n = WHEEL.length;
        int out = (idx + offset) % n;
        if (out < 0) out += n;
        return WHEEL[out];
    }

    public static int wheelDistance(int a, int b) {
        int ia = WHEEL_INDEX[a], ib = WHEEL_INDEX[b];
        int d = Math.abs(ia - ib);
        return Math.min(d, WHEEL.length - d);
    }

    public static List<Integer> wheelRegion(int center, int radius) {
        validateNumber(center);
        radius = Math.max(1, Math.min(3, radius));
        int idx = WHEEL_INDEX[center];
        List<Integer> out = new ArrayList<>();
        for (int d = -radius; d <= radius; d++) {
            int p = (idx + d) % WHEEL.length;
            if (p < 0) p += WHEEL.length;
            out.add(WHEEL[p]);
        }
        return Collections.unmodifiableList(out);
    }

    public static int terminal(int n) {
        validateNumber(n);
        return n % 10;
    }

    public static List<Integer> terminalMembers(int terminal) {
        if (terminal < 0 || terminal > 9) throw new IllegalArgumentException("terminal must be 0..9");
        List<Integer> out = new ArrayList<>();
        for (int n = 0; n <= 36; n++) if (n % 10 == terminal) out.add(n);
        return Collections.unmodifiableList(out);
    }

    private static List<Aggregate> aggregate(List<Match> matches, int len) {
        final class Mutable {
            String key, label; int count; double support, best;
            Mutable(String key, String label) { this.key = key; this.label = label; }
        }
        Map<String, Mutable> map = new LinkedHashMap<>();
        for (Match m : matches) {
            String key = m.matchedBy == Mode.TERMINAL ? "T" + m.projectedTerminal : "N" + m.projectedPrimary;
            String label = m.matchedBy == Mode.TERMINAL
                    ? "Terminal " + m.projectedTerminal + " " + terminalMembers(m.projectedTerminal)
                    : m.projectedPrimary + " + vizinhos " + m.projectedRegion;
            Mutable x = map.computeIfAbsent(key, k -> new Mutable(k, label));
            x.count++;
            double recency = 1.0 / (1.0 + Math.min(120, m.distanceFromCurrent) / 40.0);
            double lengthBonus = 1.0 + 0.12 * (len - 3);
            x.support += m.compatibility * recency * lengthBonus;
            x.best = Math.max(x.best, m.compatibility);
        }
        List<Aggregate> out = new ArrayList<>();
        for (Mutable x : map.values()) out.add(new Aggregate(x.key, x.label, x.count, x.support, x.best));
        out.sort(Comparator.comparingDouble((Aggregate a) -> a.weightedSupport).reversed()
                .thenComparingDouble(a -> a.bestCompatibility).reversed());
        return out;
    }

    public static String describe(Result r) {
        StringBuilder b = new StringBuilder();
        b.append("PATTERN ECHO • janela ").append(r.windowLength).append("\n");
        b.append("Atual: ").append(r.currentSequence).append("\n");
        if (!r.hasEcho()) {
            b.append("\n").append(r.note);
            return b.toString();
        }
        b.append("Ecos encontrados: ").append(r.matches.size()).append("\n");
        if (!r.aggregates.isEmpty()) {
            b.append("\nCONCENTRAÇÕES HISTÓRICAS\n");
            int limit = Math.min(3, r.aggregates.size());
            for (int i = 0; i < limit; i++) {
                Aggregate a = r.aggregates.get(i);
                b.append(i + 1).append(". ").append(a.label)
                        .append(" • ocorrências ").append(a.occurrences)
                        .append(" • melhor compat. ").append(fmt(a.bestCompatibility)).append("\n");
            }
        }
        b.append("\nMELHORES ECOS\n");
        int limit = Math.min(8, r.matches.size());
        for (int i = 0; i < limit; i++) {
            Match m = r.matches.get(i);
            b.append("• ").append(m.historicalSequence)
                    .append(" → veio ").append(m.historicalFollower)
                    .append(" • ").append(m.matchedBy)
                    .append(" • compat. ").append(fmt(m.compatibility))
                    .append(" • projeção histórica: ").append(m.projectionLabel())
                    .append("\n");
        }
        b.append("\n").append(r.note);
        return b.toString();
    }

    private static String fmt(double v) { return String.format(Locale.US, "%.0f/100", v); }

    private static void validateHistory(List<Integer> history) {
        for (Integer n : history) {
            if (n == null) throw new IllegalArgumentException("history contains null");
            validateNumber(n);
        }
    }

    private static void validateNumber(int n) {
        if (n < 0 || n > 36) throw new IllegalArgumentException("roulette number out of range: " + n);
    }

    private static List<Integer> suffix(List<Integer> src, int len) {
        if (len <= 0) return Collections.emptyList();
        return copyRange(src, src.size() - len, src.size());
    }

    private static List<Integer> copyRange(List<Integer> src, int from, int to) {
        return Collections.unmodifiableList(new ArrayList<>(src.subList(from, to)));
    }

    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
}
