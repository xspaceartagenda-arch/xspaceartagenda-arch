package com.xspaceart.radar30;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.WindowMetrics;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.ScanStabilizer;
import com.xspaceart.radar30.core.ScanSynchronizer;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.integrated.IntegratedActivity;

import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ScreenCaptureService extends Service {
    public static final String ACTION_START = "com.xspaceart.radar30.START";
    public static final String ACTION_STOP = "com.xspaceart.radar30.STOP";
    public static final String ACTION_MANUAL = "com.xspaceart.radar30.MANUAL";
    public static final String ACTION_RESET = "com.xspaceart.radar30.RESET";
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String EXTRA_MANUAL_NUMBER = "manual_number";
    public static final String EXTRA_PIPELINE_MODE = "pipeline_mode";
    public static final String MODE_INTEGRATED_SOURCE_ONLY = "integrated_source_only";

    private static final String CHANNEL_ID = "radar30_capture";
    private static final int NOTIFICATION_ID = 3030;
    private static final long FRAME_INTERVAL_MS = 650L;

    private final AtomicBoolean ocrBusy = new AtomicBoolean(false);
    private final ScanStabilizer stabilizer = new ScanStabilizer();
    private final ScanSynchronizer synchronizer = new ScanSynchronizer();
    private final RadarSession radarSession = new RadarSession();
    private final OcrHistoryParser parser = new OcrHistoryParser();

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private TextRecognizer recognizer;
    private OverlayController overlay;
    private AlertPlayer alerts;
    private int captureWidth;
    private int captureHeight;
    private int captureDensity;
    private long lastFrameAt;
    private long lastWaitingNoticeAt;
    private long lastSessionId = -1L;
    private boolean destroying;
    private boolean integratedSourceOnly;
    private long lastSnapshotBroadcastAt;
    private long lastSnapshotPersistAt;
    private String lastSnapshotFingerprint = "";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        overlay = new OverlayController(this);
        alerts = new AlertPlayer(this);
        synchronizer.restore(AppStateStore.loadHistory(this));
        lastSessionId = SessionLedger.activeSessionId(this);
        AppStateStore.setCaptureActive(this, false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        ensureForeground("Preparando leitura");

        if (ACTION_STOP.equals(action)) {
            SessionLedger.cancelPending(this);
            radarSession.resetSignal();
            AppStateStore.saveStatus(this, "Leitura parada", "SCANNING • sem sinal ativo");
            broadcastState();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_RESET.equals(action)) {
            boolean captureWasActive = mediaProjection != null;
            synchronizer.restore(Collections.emptyList());
            radarSession.resetSignal();
            SessionLedger.cancelPending(this);
            AppStateStore.clearHistory(this);
            ShadowAuditStore.clearLive(this);
            AppStateStore.saveStatus(this, mediaProjection == null ? "Leitura parada" : "Histórico limpo; aguardando OCR",
                    "SCANNING • sem sinal ativo");
            overlay.show("HISTÓRICO LIMPO", "Aguardando nova leitura", Ui.AMBER);
            updateNotification("Histórico limpo");
            broadcastState();
            if (!captureWasActive) stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_MANUAL.equals(action)) {
            int number = intent.getIntExtra(EXTRA_MANUAL_NUMBER, -1);
            handleMerge(synchronizer.prependManual(number));
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            integratedSourceOnly = MODE_INTEGRATED_SOURCE_ONLY.equals(intent.getStringExtra(EXTRA_PIPELINE_MODE));
            if (mediaProjection != null) updateNotification(integratedSourceOnly
                    ? "Captura integrada • fonte visual ativa"
                    : "Captura Stable ativa");
        }
        if (ACTION_START.equals(action) && mediaProjection == null) {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
            Intent resultData = projectionData(intent);
            if (resultCode == Activity.RESULT_OK && resultData != null) startProjection(resultCode, resultData);
            else setOperationalStatus("Falha: autorização de captura ausente", "SCANNING • sem sinal ativo");
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        destroying = true;
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        if (mediaProjection != null) {
            try {
                mediaProjection.stop();
            } catch (RuntimeException ignored) {
                // Projeção já encerrada pelo sistema.
            }
            mediaProjection = null;
        }
        if (captureThread != null) {
            captureThread.quitSafely();
            captureThread = null;
        }
        if (recognizer != null) recognizer.close();
        if (alerts != null) alerts.shutdown();
        if (overlay != null) overlay.hide();
        CaptureRepository.clear();
        AppStateStore.setCaptureActive(this, false);
        AppStateStore.saveStatus(this, "Leitura parada", "SCANNING • sem sinal ativo");
        broadcastState();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private Intent projectionData(Intent source) {
        if (Build.VERSION.SDK_INT >= 33) {
            return source.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        }
        return source.getParcelableExtra(EXTRA_RESULT_DATA);
    }

    private void startProjection(int resultCode, Intent resultData) {
        try {
            MediaProjectionManager manager = (MediaProjectionManager)
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mediaProjection = manager.getMediaProjection(resultCode, resultData);
            AppStateStore.setCaptureActive(this, true);
            if (!integratedSourceOnly) {
                lastSessionId = SessionLedger.ensureActive(this,
                        AppStateStore.provider(this), AppStateStore.dealer(this));
            }
            calculateCaptureSize();

            captureThread = new HandlerThread("radar30-capture");
            captureThread.start();
            captureHandler = new Handler(captureThread.getLooper());
            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    if (!destroying) stopSelf();
                }
            }, captureHandler);

            imageReader = ImageReader.newInstance(captureWidth, captureHeight,
                    PixelFormat.RGBA_8888, 2);
            imageReader.setOnImageAvailableListener(this::onImageAvailable, captureHandler);
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "Radar30Capture",
                    captureWidth,
                    captureHeight,
                    captureDensity,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    captureHandler);
            setOperationalStatus("Captura ativa • " + AppStateStore.provider(this)
                            + dealerSuffix(),
                    AppStateStore.isCalibrated(this) ? "Aguardando números" : "Toque em Calibrar pela notificação");
            if (!integratedSourceOnly) {
                overlay.show(AppStateStore.isCalibrated(this) ? "ANALISANDO" : "CALIBRAR LEITURA",
                        AppStateStore.isCalibrated(this)
                                ? "Painel ativo • aguardando o próximo resultado"
                                : "Abra a notificação e marque a grade de resultados",
                        AppStateStore.isCalibrated(this) ? Ui.GREEN : Ui.AMBER);
            }
            updateNotification("Captura ativa • toque para calibrar");
        } catch (RuntimeException error) {
            setOperationalStatus("Falha ao iniciar captura: " + error.getClass().getSimpleName(),
                    "Autorize novamente");
            stopSelf();
        }
    }

    private void calculateCaptureSize() {
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        captureDensity = metrics.densityDpi;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowMetrics windowMetrics = windowManager.getMaximumWindowMetrics();
            Rect bounds = windowMetrics.getBounds();
            captureWidth = bounds.width();
            captureHeight = bounds.height();
        } else {
            captureWidth = metrics.widthPixels;
            captureHeight = metrics.heightPixels;
        }
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = reader.acquireLatestImage();
        if (image == null) return;
        long now = SystemClock.elapsedRealtime();
        try {
            if (now - lastFrameAt < FRAME_INTERVAL_MS) return;
            lastFrameAt = now;
            Bitmap full = imageToBitmap(image);
            if (full == null) return;
            CaptureRepository.setLatest(full);

            if (!AppStateStore.isCalibrated(this)) {
                if (now - lastWaitingNoticeAt > 5000L) {
                    lastWaitingNoticeAt = now;
                    setOperationalStatus("Captura ativa • falta calibrar a área", "Abra a notificação e toque em Calibrar");
                }
                return;
            }
            if (!ocrBusy.compareAndSet(false, true)) return;

            Bitmap crop = cropForOcr(full, AppStateStore.getRoi(this));
            if (crop == null) {
                ocrBusy.set(false);
                return;
            }
            recognizer.process(InputImage.fromBitmap(crop, 0))
                    .addOnSuccessListener(text -> {
                        List<Integer> numbers = parser.parse(text);
                        if (numbers.size() >= 8) {
                            long observedAt = System.currentTimeMillis();
                            CaptureRepository.setLatestNumbers(numbers, observedAt);
                            String fingerprint = numbers.toString();
                            if (!fingerprint.equals(lastSnapshotFingerprint)
                                    || observedAt - lastSnapshotPersistAt >= 2_000L) {
                                lastSnapshotFingerprint = fingerprint;
                                lastSnapshotPersistAt = observedAt;
                                AppStateStore.saveOcrSnapshot(this, numbers, observedAt);
                            }
                            if (observedAt - lastSnapshotBroadcastAt >= 700L) {
                                lastSnapshotBroadcastAt = observedAt;
                                broadcastState();
                            }
                        }
                        // Na Integrated a captura é SOMENTE uma fonte de dados. Ela não pode
                        // executar ScanSynchronizer/RadarSession/overlay em paralelo.
                        if (integratedSourceOnly) return;
                        if (stabilizer.accept(numbers)) handleMerge(synchronizer.merge(numbers));
                    })
                    .addOnFailureListener(error -> setOperationalStatus(
                            "OCR indisponível: " + error.getClass().getSimpleName(),
                            "Confira a área de leitura"))
                    .addOnCompleteListener(task -> {
                        crop.recycle();
                        ocrBusy.set(false);
                    });
        } finally {
            image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;
        Image.Plane plane = planes[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * captureWidth;
        int paddedWidth = captureWidth + Math.max(0, rowPadding / pixelStride);
        Bitmap padded = Bitmap.createBitmap(paddedWidth, captureHeight, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        padded.copyPixelsFromBuffer(buffer);
        if (paddedWidth == captureWidth) return padded;
        Bitmap exact = Bitmap.createBitmap(padded, 0, 0, captureWidth, captureHeight).copy(
                Bitmap.Config.ARGB_8888, false);
        padded.recycle();
        return exact;
    }

    private Bitmap cropForOcr(Bitmap source, RectF roi) {
        int left = bound(Math.round(roi.left * source.getWidth()), 0, source.getWidth() - 2);
        int top = bound(Math.round(roi.top * source.getHeight()), 0, source.getHeight() - 2);
        int right = bound(Math.round(roi.right * source.getWidth()), left + 2, source.getWidth());
        int bottom = bound(Math.round(roi.bottom * source.getHeight()), top + 2, source.getHeight());
        try {
            Bitmap window = Bitmap.createBitmap(source, left, top, right - left, bottom - top);
            Bitmap copy = window.copy(Bitmap.Config.ARGB_8888, false);
            if (window != source) window.recycle();
            return copy;
        } catch (IllegalArgumentException error) {
            return null;
        }
    }

    private void handleMerge(ScanSynchronizer.MergeResult merge) {
        if (integratedSourceOnly) {
            // Defesa extra: nenhuma ação Stable deve tocar histórico, overlay ou motor
            // enquanto a Integrated for dona da sessão.
            broadcastState();
            return;
        }
        if (!merge.accepted) {
            setOperationalStatus("Leitura rejeitada: " + merge.message,
                    "O histórico anterior foi preservado");
            overlay.show("CONFERIR LEITURA", merge.message, Ui.AMBER);
            return;
        }
        AppStateStore.saveHistory(this, merge.history);
        syncSessionBoundary();
        LearningModel learning = SessionLedger.learningModel(this);
        SignalUpdate update = radarSession.update(merge.history, merge.newNumbers,
                learning, AppStateStore.conservativeMode(this));
        ShadowAuditStore.record(this, SessionLedger.activeSessionId(this),
                merge.history, merge.newNumbers, radarSession.state(),
                update, radarSession.lastVerdict(), radarSession.lastChampionShadow());
        SessionLedger.recordUpdate(this, update, merge.newNumbers);
        present(update, merge.message);
    }

    private void present(SignalUpdate update, String scanMessage) {
        int accent = accentFor(update.kind, update.strength);
        String body = update.detail;
        overlay.show(update.headline, body, accent);
        AppStateStore.saveStatus(this,
                scanMessage + " • " + synchronizer.current().size() + " números",
                update.headline + "\n" + update.detail);
        updateNotification(update.headline);
        alerts.play(update);
        broadcastState();
    }

    private int accentFor(SignalUpdate.Kind kind, int strength) {
        if (kind == SignalUpdate.Kind.HIT
                || kind == SignalUpdate.Kind.SECONDARY_HIT) return Ui.GREEN;
        if (kind == SignalUpdate.Kind.ENTRY || kind == SignalUpdate.Kind.ACTIVE) return Ui.GREEN;
        if (kind == SignalUpdate.Kind.BUILDING || kind == SignalUpdate.Kind.SCANNING) return Ui.CYAN;
        if (kind == SignalUpdate.Kind.PREPARE || kind == SignalUpdate.Kind.OBSERVE) return Ui.AMBER;
        if (kind == SignalUpdate.Kind.INVALIDATED || kind == SignalUpdate.Kind.COOLDOWN) {
            return kind == SignalUpdate.Kind.INVALIDATED ? Ui.RED : Ui.CYAN;
        }
        if (kind == SignalUpdate.Kind.TRIAL || kind == SignalUpdate.Kind.LATE_WATCH
                || kind == SignalUpdate.Kind.LATE_HIT) return Ui.AMBER;
        if (kind == SignalUpdate.Kind.EXPIRED || kind == SignalUpdate.Kind.NO_ENTRY
                || kind == SignalUpdate.Kind.LATE_MISS) return Ui.RED;
        return Ui.AMBER;
    }

    private void syncSessionBoundary() {
        long current = SessionLedger.activeSessionId(this);
        if (current == lastSessionId) return;
        radarSession.resetSignal();
        lastSessionId = current;
    }

    private String dealerSuffix() {
        String dealer = AppStateStore.dealer(this);
        return dealer == null || dealer.trim().isEmpty() ? "" : " • " + dealer.trim();
    }

    private void setOperationalStatus(String status, String signal) {
        AppStateStore.saveStatus(this, status, signal);
        updateNotification(status);
        broadcastState();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Leitura ao vivo", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Mantém a captura autorizada da mesa enquanto a leitura estiver ativa.");
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }

    private void ensureForeground(String text) {
        startForeground(NOTIFICATION_ID, buildNotification(text));
    }

    private void updateNotification(String text) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private Notification buildNotification(String text) {
        Intent mainIntent = new Intent(this,
                integratedSourceOnly ? IntegratedActivity.class : MainActivity.class);
        PendingIntent main = PendingIntent.getActivity(this, 1, mainIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent calibrationIntent = new Intent(this, CalibrationActivity.class);
        PendingIntent calibrate = PendingIntent.getActivity(this, 2, calibrationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, ScreenCaptureService.class).setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 3, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(com.xspaceart.radar30.R.drawable.ic_radar)
                .setContentTitle(integratedSourceOnly ? "Aurum AI 37 • Integrated" : "Aurum AI 37")
                .setContentText(text)
                .setContentIntent(main)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(
                        com.xspaceart.radar30.R.drawable.ic_radar, "Calibrar", calibrate).build())
                .addAction(new Notification.Action.Builder(
                        com.xspaceart.radar30.R.drawable.ic_radar, "Parar", stop).build())
                .build();
    }

    private void broadcastState() {
        sendBroadcast(new Intent(MainActivity.ACTION_STATE_UPDATED).setPackage(getPackageName()));
    }

    private static int bound(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
