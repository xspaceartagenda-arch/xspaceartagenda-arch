# Integrated Operational — Preflight Report

Versão preparada: `0.7.2-integrated-operational` / code `3`.
Base física: v0.7.1 Integrated Telemetry STABLE.

## PASS

- CORE preservado 17/17 hashes.
- PrecisionCoreTest.
- DualTargetCoreTest A–H.
- V063BalancedCalibrationTest.
- IntegratedOperationalTest.
- SourceHunter JavaScript syntax.
- Semantic DOM synthetic filter.
- DOM signature lock/tracking synthetic test.
- Keystore certificate = v0.7.1 STABLE certificate.
- applicationId base preservado e debug suffix preservado no workflow.
- sem automação de aposta.
- login password não persistido em texto puro.

## PENDENTE

- Gradle/Android compile: ambiente local sem Gradle 8.9/SDK 35 e DNS bloqueado.
- GitHub Actions build.
- APK v0.7.2.
- instalação por atualização no S25 FE.
- teste físico DOM/OCR/CORE/sessão.

Não considerar a versão concluída antes do teste físico.
