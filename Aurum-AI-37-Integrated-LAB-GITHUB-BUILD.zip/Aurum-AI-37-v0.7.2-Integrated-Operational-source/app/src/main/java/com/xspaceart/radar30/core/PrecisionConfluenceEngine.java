package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Precision Mode: procura convergência transversal excepcional e não tenta
 * produzir uma opinião a cada giro.
 *
 * <p>Cada família deposita um único voto no heatmap. Indicadores derivados do
 * mesmo fenômeno são fundidos dentro da própria família antes da votação.</p>
 */
public final class PrecisionConfluenceEngine {
    private static final int RADIUS = 2;
    private static final int SIGNAL_ROUNDS = 3;
    private static final int[] SIGNATURE_WINDOWS = {3, 5, 7, 10, 15, 20, 30};
    private static final int[] CONTEXT_WINDOWS = {3, 5, 7, 10, 15, 20, 30, 50, 100, 500};
    private final RegimeDetector regimeDetector = new RegimeDetector();

    public ConfluenceVerdict analyze(List<Integer> input) {
        return analyze(input, ConfluenceVerdict.Mode.PRECISION);
    }

    public ConfluenceVerdict analyze(List<Integer> input,
                                     ConfluenceVerdict.Mode requestedMode) {
        ConfluenceVerdict.Mode mode = requestedMode == null
                ? ConfluenceVerdict.Mode.PRECISION : requestedMode;
        List<Integer> history = CurrentTableHistory.clean(input);
        if (history.size() < CurrentTableHistory.MIN_DEEP_SCAN_RESULTS) {
            return ConfluenceVerdict.insufficient(history.size(), mode);
        }

        RegimeDetector.Snapshot regime = regimeDetector.detect(history);
        Map<Integer, TableSignature> signatures = currentSignatures(history);
        List<Evidence> evidence = new ArrayList<>();
        add(evidence, recencyEvidence(history, regime, signatures));
        add(evidence, transitionEvidence(history, regime));
        add(evidence, exactSequenceEvidence(history, regime));
        add(evidence, historicalSimilarityEvidence(history, regime));
        add(evidence, wheelGeometryEvidence(history, regime));
        add(evidence, terminalEvidence(history, regime));
        add(evidence, frequencyEvidence(history, regime));
        add(evidence, gapEvidence(history, regime));
        add(evidence, arithmeticEvidence(history, regime));
        add(evidence, regimeEvidence(history, regime));

        if (evidence.size() < 4) {
            return emptyVerdict(regime, mode,
                    "Evidências independentes insuficientes");
        }

        double[] centralHeat = fuse(evidence);
        TargetRanking targetRanking = TargetRanking.fromHeatMap(centralHeat);
        SectorScore leader = scoreOf(targetRanking.primary);
        SectorScore runner = scoreOf(targetRanking.secondary);
        SectorScore third = scoreOf(targetRanking.third);
        double second = runner.score;
        double dominance = targetRanking.primaryMargin;
        double dispersion = TableSignature.normalizedEntropy(centralHeat);

        Fusion fusion = evaluateFamilies(evidence, leader.center);
        CandidateAssessment secondary = assessCandidate(evidence, runner,
                leader.score, targetRanking.secondaryMargin, dispersion);
        CandidateAssessment thirdAssessment = assessCandidate(evidence, third,
                leader.score, 0.0, dispersion);
        boolean secondaryPrecision = qualifiesSecondary(secondary,
                targetRanking, ConfluenceVerdict.Mode.PRECISION);
        boolean secondaryBalanced = qualifiesSecondary(secondary,
                targetRanking, ConfluenceVerdict.Mode.BALANCED);
        boolean secondaryQualified = mode == ConfluenceVerdict.Mode.PRECISION
                ? secondaryPrecision : secondaryBalanced;
        TargetRanking.SignalShape signalShape = targetRanking.shape(secondaryQualified);

        double breadth = Math.min(1.0, fusion.supporting.size() / 8.0);
        double dominanceQuality = clamp01(dominance / 0.34);
        if (secondaryQualified) {
            double dualTopology = 0.60 * clamp01(targetRanking.secondaryMargin / 0.28)
                    + 0.40 * clamp01(dominance / 0.18);
            dominanceQuality = Math.max(dominanceQuality, dualTopology);
        }
        double concentrationQuality = clamp01((1.0 - dispersion) / 0.28);
        double currentContext = currentContextSupport(evidence, leader.center);
        double alignment = fusion.supporting.isEmpty() ? 0.0
                : fusion.alignment / fusion.supporting.size();
        double scoreValue = 0.25 * alignment
                + 0.20 * breadth
                + 0.18 * dominanceQuality
                + 0.12 * concentrationQuality
                + 0.15 * (1.0 - fusion.contradiction)
                + 0.10 * currentContext;
        if (targetRanking.highDispersion) scoreValue -= 0.08;
        else if (targetRanking.spatialRegime == TargetRanking.SpatialRegime.DISPERSED) {
            scoreValue -= 0.035;
        }
        int aurumScore = clampScore((int) Math.round(100.0 * scoreValue));

        int predictiveSamples = predictiveSamples(evidence, fusion.supporting);
        boolean predictivePath = hasAny(fusion.supporting,
                EvidenceFamily.TRANSITION, EvidenceFamily.SEQUENCE,
                EvidenceFamily.HISTORICAL_SIMILARITY, EvidenceFamily.WHEEL_GEOMETRY);
        boolean recentPath = hasAny(fusion.supporting,
                EvidenceFamily.RECENCY, EvidenceFamily.REGIME,
                EvidenceFamily.TRANSITION);
        boolean fiveExceptional = fusion.supporting.size() >= 5
                && alignment >= 0.90 && currentContext >= 0.82
                && fusion.contradiction <= 0.12
                && predictiveSamples >= 45;
        boolean primaryDominance = dominance >= 0.16
                || (secondaryPrecision && targetRanking.secondaryMargin >= 0.12
                && targetRanking.dualDominance >= 0.55
                && aurumScore >= secondary.score + 4);
        boolean precision = aurumScore >= 82
                && (fusion.supporting.size() >= 6 || fiveExceptional)
                && fusion.contradiction <= 0.16
                && primaryDominance
                && signalShape != TargetRanking.SignalShape.HIGH_DISPERSION
                && predictivePath
                && recentPath
                && predictiveSamples >= 30;
        boolean fourExceptional = fusion.supporting.size() >= 4
                && alignment >= 0.92 && currentContext >= 0.84
                && fusion.contradiction <= 0.14
                && predictiveSamples >= 38;
        boolean balancedDominance = dominance >= 0.10
                || (secondaryBalanced && targetRanking.secondaryMargin >= 0.10
                && targetRanking.dualDominance >= 0.50
                && aurumScore >= secondary.score + 3);
        boolean balanced = aurumScore >= 76
                && (fusion.supporting.size() >= 5 || fourExceptional)
                && fusion.contradiction <= 0.22
                && balancedDominance
                && signalShape != TargetRanking.SignalShape.HIGH_DISPERSION
                && predictivePath && recentPath && predictiveSamples >= 22;
        boolean entryQualified = mode == ConfluenceVerdict.Mode.PRECISION
                ? precision : balanced;

        ConfluenceVerdict.Decision decision;
        if (entryQualified) {
            decision = ConfluenceVerdict.Decision.ENTRY;
        } else if (aurumScore >= (mode == ConfluenceVerdict.Mode.PRECISION ? 70 : 66)
                && (fusion.supporting.size() >= 5
                || (fusion.supporting.size() >= 4 && alignment >= 0.84))
                && fusion.contradiction <= 0.30
                && (dominance >= 0.07 || secondaryQualified)
                && signalShape != TargetRanking.SignalShape.HIGH_DISPERSION
                && predictivePath && recentPath) {
            decision = ConfluenceVerdict.Decision.PREPARE;
        } else if (aurumScore >= 56 && fusion.supporting.size() >= 4
                && fusion.contradiction <= 0.42) {
            decision = ConfluenceVerdict.Decision.OBSERVE;
        } else {
            decision = ConfluenceVerdict.Decision.NO_READING;
        }

        List<Integer> coverage = Wheel.coverage(leader.center, RADIUS);
        List<Integer> nucleus = nucleus(coverage, centralHeat);
        List<String> reasons = reasons(evidence, fusion, regime, leader,
                runner, third, aurumScore, dispersion, predictiveSamples,
                targetRanking, secondary, secondaryQualified);
        List<String> features = featureKeys(fusion, regime, aurumScore,
                dominance, dispersion, mode, targetRanking, secondaryQualified);
        List<Integer> secondaryCoverage = secondaryQualified
                ? Wheel.coverage(runner.center, RADIUS) : Collections.emptyList();
        List<Integer> secondaryNucleus = secondaryQualified
                ? nucleus(secondaryCoverage, centralHeat) : Collections.emptyList();
        List<String> secondaryReasons = secondaryReasons(secondary,
                targetRanking, secondaryQualified);
        return new ConfluenceVerdict(decision, leader.center, coverage, nucleus,
                aurumScore, fusion.supporting.size(), fusion.contradiction,
                dominance, dispersion, leader.score, second, regime,
                fusion.supporting, reasons, features, centralHeat, precision,
                balanced, entryQualified, mode,
                secondaryQualified ? runner.center : -1,
                secondaryCoverage, secondaryNucleus,
                secondaryQualified ? secondary.score : 0,
                secondaryQualified ? secondary.fusion.supporting.size() : 0,
                secondaryQualified ? secondary.fusion.contradiction : 1.0,
                targetRanking.secondaryMargin, targetRanking.dualDominance,
                third.center, thirdAssessment.score, third.score,
                targetRanking.spatialRegime, signalShape,
                secondaryQualified ? secondary.fusion.supporting
                        : Collections.emptyList(),
                secondaryReasons, secondaryQualified);
    }

    private static Map<Integer, TableSignature> currentSignatures(List<Integer> history) {
        Map<Integer, TableSignature> result = new LinkedHashMap<>();
        for (int window : SIGNATURE_WINDOWS) {
            int end = Math.min(window, history.size());
            result.put(window, TableSignature.from(history, 0, end));
        }
        return result;
    }

    private static Evidence recencyEvidence(List<Integer> history,
                                            RegimeDetector.Snapshot regime,
                                            Map<Integer, TableSignature> signatures) {
        double[] heat = new double[37];
        List<Integer> peaks = new ArrayList<>();
        int used = 0;
        for (int requested : CONTEXT_WINDOWS) {
            int window = Math.min(requested, history.size());
            if (window < 3 || (used > 0 && window == Math.min(CONTEXT_WINDOWS[used - 1], history.size()))) {
                used++;
                continue;
            }
            double[] local = new double[37];
            for (int i = 0; i < window; i++) {
                double decay = Math.exp(-i / Math.max(4.0, window * 0.55));
                double regimeWeight = i < regime.currentRegimeStart
                        ? 1.0 : regime.previousRegimeWeight;
                addKernel(local, history.get(i), decay * regimeWeight, 2);
            }
            normalizeMax(local);
            TableSignature windowSignature = TableSignature.from(history, 0, window);
            double similarity = windowSignature.similarity(regime.currentRegimeSignature);
            double importance = recencyWindowWeight(requested)
                    * (0.42 + 0.58 * similarity)
                    * (window <= regime.currentRegimeStart
                    ? 1.0 : 0.55 + 0.45 * regime.previousRegimeWeight);
            addScaled(heat, local, importance);
            peaks.add(bestSector(local).center);
            used++;
            if (window == history.size()) break;
        }
        double agreement = physicalAgreement(peaks);
        double focus = spatialFocus(heat);
        return new Evidence(EvidenceFamily.RECENCY, heat,
                0.34 + 0.42 * focus + 0.24 * agreement,
                1.0, Math.min(history.size(), 500),
                0.30 + 0.50 * agreement,
                0.78 + 0.22 * regime.regimeConfidence, 0.0,
                "janelas 3–500 ponderadas pelo regime atual");
    }

    private static Evidence transitionEvidence(List<Integer> history,
                                                RegimeDetector.Snapshot regime) {
        double[] heat = new double[37];
        int recent = Math.min(10, history.size());
        int samples = 0;
        int matches = 0;
        for (int r = 0; r < recent; r++) {
            int trigger = history.get(r);
            double triggerWeight = Math.exp(-r / 5.5);
            for (int j = Math.max(recent + 5, r + 6); j < history.size(); j++) {
                if (history.get(j) != trigger) continue;
                matches++;
                double context = historicalContextWeight(j, regime);
                for (int step = 1; step <= 5 && j - step >= 0; step++) {
                    double weight = triggerWeight * context * (1.08 - step * 0.12);
                    addKernel(heat, history.get(j - step), weight, 1);
                    samples++;
                }
            }
        }
        if (matches < 3 || samples < 12) return null;
        double focus = spatialFocus(heat);
        double reliability = Math.min(1.0, samples / 80.0) * (0.45 + 0.55 * focus);
        return new Evidence(EvidenceFamily.TRANSITION, heat,
                0.28 + 0.72 * focus, 0.94, samples, reliability,
                0.72 + 0.28 * regime.regimeConfidence, 0.0,
                recent + " gatilhos recentes confrontados em " + matches + " ocorrências");
    }

    private static Evidence exactSequenceEvidence(List<Integer> history,
                                                   RegimeDetector.Snapshot regime) {
        double[] heat = new double[37];
        int matches = 0;
        int samples = 0;
        for (int length = 2; length <= 3; length++) {
            for (int j = length + 6; j + length <= history.size(); j++) {
                if (!exactWindow(history, 0, j, length)) continue;
                matches++;
                double context = historicalContextWeight(j, regime);
                for (int step = 1; step <= 5 && j - step >= 0; step++) {
                    addKernel(heat, history.get(j - step),
                            context * (1.05 - step * 0.11) * (length == 3 ? 1.25 : 0.82), 1);
                    samples++;
                }
            }
        }
        if (matches < 2 || samples < 8) return null;
        double focus = spatialFocus(heat);
        return new Evidence(EvidenceFamily.SEQUENCE, heat,
                0.34 + 0.66 * focus, 0.96, samples,
                Math.min(1.0, matches / 8.0) * (0.42 + 0.58 * focus),
                0.68 + 0.32 * regime.regimeConfidence, 0.0,
                matches + " pares/trincas exatos encontrados");
    }

    private static Evidence historicalSimilarityEvidence(
            List<Integer> history, RegimeDetector.Snapshot regime) {
        double[] heat = new double[37];
        int matches = 0;
        int samples = 0;
        int[] lengths = {4, 5, 6, 7, 10};
        for (int length : lengths) {
            if (history.size() < length + 12) continue;
            int lastAccepted = -100;
            for (int j = length + 6; j + length <= history.size(); j++) {
                if (j - lastAccepted < Math.max(2, length / 2)) continue;
                double similarity = sequenceSimilarity(history, j, length);
                double threshold = length >= 7 ? 0.69 : 0.73;
                if (similarity < threshold) continue;
                lastAccepted = j;
                matches++;
                double context = historicalContextWeight(j, regime);
                for (int step = 1; step <= 5 && j - step >= 0; step++) {
                    double weight = Math.pow(similarity, 3.0) * context
                            * (1.05 - step * 0.11) * (0.7 + length / 12.0);
                    addKernel(heat, history.get(j - step), weight, 1);
                    samples++;
                }
            }
        }
        if (matches < 3 || samples < 12) return null;
        double focus = spatialFocus(heat);
        return new Evidence(EvidenceFamily.HISTORICAL_SIMILARITY, heat,
                0.30 + 0.70 * focus, 0.90, samples,
                Math.min(1.0, matches / 14.0) * (0.38 + 0.62 * focus),
                0.62 + 0.38 * regime.regimeConfidence, 0.0,
                matches + " sequências estruturalmente semelhantes");
    }

    private static Evidence wheelGeometryEvidence(List<Integer> history,
                                                   RegimeDetector.Snapshot regime) {
        double[] heat = new double[37];
        int recentSteps = Math.min(6, history.size() - 1);
        int matches = 0;
        int samples = 0;
        for (int r = 0; r < recentSteps; r++) {
            int currentStep = signedWheelStep(history.get(r + 1), history.get(r));
            double recentWeight = Math.exp(-r / 3.5);
            for (int j = 8; j + 1 < history.size(); j++) {
                int oldStep = signedWheelStep(history.get(j + 1), history.get(j));
                if (Math.abs(currentStep - oldStep) > 1) continue;
                matches++;
                double context = historicalContextWeight(j, regime);
                for (int step = 1; step <= 3 && j - step >= 0; step++) {
                    addKernel(heat, history.get(j - step),
                            recentWeight * context * (1.0 - 0.17 * step), 1);
                    samples++;
                }
            }
        }
        if (matches < 5 || samples < 15) return null;
        double focus = spatialFocus(heat);
        return new Evidence(EvidenceFamily.WHEEL_GEOMETRY, heat,
                0.26 + 0.74 * focus, 0.88, samples,
                Math.min(1.0, matches / 28.0) * (0.40 + 0.60 * focus),
                0.70 + 0.30 * regime.regimeConfidence, 0.0,
                "deslocamentos físicos recentes comparados em " + matches + " transições");
    }

    private static Evidence terminalEvidence(List<Integer> history,
                                              RegimeDetector.Snapshot regime) {
        double[] terminal = new double[10];
        int samples = 0;
        int[] windows = {5, 10, 20, 30};
        for (int requested : windows) {
            int end = Math.min(requested, history.size());
            double scale = requested <= 10 ? 1.0 : requested <= 20 ? 0.78 : 0.62;
            for (int i = 0; i < end; i++) {
                terminal[history.get(i) % 10] += scale * Math.exp(-i / (double) requested);
                samples++;
            }
        }
        int recent = Math.min(7, history.size());
        for (int r = 0; r < recent; r++) {
            int trigger = history.get(r) % 10;
            for (int j = recent + 5; j < history.size(); j++) {
                if (history.get(j) % 10 != trigger) continue;
                double context = historicalContextWeight(j, regime);
                for (int step = 1; step <= 5 && j - step >= 0; step++) {
                    terminal[history.get(j - step) % 10] += context * (0.8 - step * 0.08);
                    samples++;
                }
            }
        }
        double[] heat = new double[37];
        for (int number = 0; number <= 36; number++) heat[number] = terminal[number % 10];
        double margin = topMargin(terminal);
        double focus = spatialFocus(heat);
        return new Evidence(EvidenceFamily.TERMINAL, heat,
                0.25 + 0.40 * margin + 0.35 * focus, 0.90, samples,
                Math.min(0.88, 0.22 + margin * 0.90 + focus * 0.35),
                0.76 + 0.24 * regime.regimeConfidence, 0.0,
                "terminais recentes e seus retornos históricos fundidos");
    }

    private static Evidence frequencyEvidence(List<Integer> history,
                                               RegimeDetector.Snapshot regime) {
        double[] shortHeat = density(history, 0, Math.min(10, history.size()), 1);
        double[] momentHeat = density(history, 0, Math.min(30, history.size()), 1);
        double[] contextHeat = density(history, 0,
                Math.min(Math.max(30, regime.currentRegimeStart), history.size()), 1);
        normalizeMax(shortHeat);
        normalizeMax(momentHeat);
        normalizeMax(contextHeat);
        double[] heat = new double[37];
        for (int i = 0; i < 37; i++) {
            double acceleration = Math.max(0.0, shortHeat[i] - 0.72 * momentHeat[i]);
            heat[i] = 0.50 * shortHeat[i] + 0.32 * momentHeat[i]
                    + 0.18 * contextHeat[i] + 0.45 * acceleration;
        }
        double focus = spatialFocus(heat);
        return new Evidence(EvidenceFamily.FREQUENCY, heat,
                0.20 + 0.48 * focus, 0.98, Math.min(30, history.size()),
                Math.min(0.58, 0.18 + 0.50 * focus),
                0.84, 0.0,
                "quente/frio usado apenas como contexto de aceleração");
    }

    private static Evidence gapEvidence(List<Integer> history,
                                         RegimeDetector.Snapshot regime) {
        double[] heat = new double[37];
        int stableCycles = 0;
        int intervalSamples = 0;
        for (int center : Wheel.EUROPEAN) {
            List<Integer> zone = Wheel.coverage(center, RADIUS);
            List<Integer> positions = new ArrayList<>();
            for (int i = 0; i < history.size(); i++) {
                if (zone.contains(history.get(i))) positions.add(i);
            }
            if (positions.size() < 7) continue;
            List<Integer> intervals = new ArrayList<>();
            for (int i = 1; i < positions.size(); i++) {
                intervals.add(positions.get(i) - positions.get(i - 1));
                if (intervals.size() >= 20) break;
            }
            double mean = mean(intervals);
            double spread = standardDeviation(intervals, mean);
            if (mean <= 1.0 || spread / mean > 0.72) continue;
            int currentGap = positions.get(0);
            double closeness = 1.0 - Math.min(1.0, Math.abs(currentGap - mean) / mean);
            if (closeness < 0.48) continue;
            stableCycles++;
            intervalSamples += intervals.size();
            for (int number : zone) heat[number] += closeness;
        }
        if (stableCycles < 2) return null;
        double focus = spatialFocus(heat);
        return new Evidence(EvidenceFamily.GAP, heat,
                Math.min(0.62, 0.20 + focus * 0.48), 0.72,
                intervalSamples, Math.min(0.60, stableCycles / 10.0),
                0.54 + 0.30 * regime.previousRegimeWeight, 0.0,
                stableCycles + " ciclos com intervalo recorrente; ausência não aumenta força sozinha");
    }

    private static Evidence arithmeticEvidence(List<Integer> history,
                                                RegimeDetector.Snapshot regime) {
        double[] heat = new double[37];
        Set<String> used = new HashSet<>();
        int validatedRelations = 0;
        int totalTrials = 0;
        for (int r = 0; r < Math.min(5, history.size()); r++) {
            int number = history.get(r);
            int tens = number / 10;
            int units = number % 10;
            int[] targets = number < 10
                    ? new int[]{number}
                    : new int[]{(tens + units) % 10, Math.abs(units - tens)};
            for (int target : targets) {
                String key = (targets.length == 1 ? "u" : "r") + target;
                if (!used.add(key)) continue;
                int trials = 0;
                int successes = 0;
                for (int j = 6; j < history.size(); j++) {
                    int source = history.get(j);
                    int sourceTens = source / 10;
                    int sourceUnits = source % 10;
                    boolean relation = source < 10
                            ? source == target
                            : (sourceTens + sourceUnits) % 10 == target
                            || Math.abs(sourceUnits - sourceTens) == target;
                    if (!relation) continue;
                    trials++;
                    boolean hit = false;
                    for (int step = 1; step <= 5 && j - step >= 0; step++) {
                        if (history.get(j - step) % 10 == target) hit = true;
                    }
                    if (hit) successes++;
                }
                int pockets = target <= 6 ? 4 : 3;
                double baseline = 1.0 - Math.pow(1.0 - pockets / 37.0, 5);
                double rate = trials == 0 ? 0.0 : successes / (double) trials;
                double lift = rate - baseline;
                if (trials < 10 || lift < 0.08) continue;
                validatedRelations++;
                totalTrials += trials;
                double weight = Math.min(1.0, lift / 0.24)
                        * Math.min(1.0, trials / 28.0) * Math.exp(-r / 4.0);
                for (int value = target; value <= 36; value += 10) {
                    addKernel(heat, value, weight, 1);
                }
            }
        }
        if (validatedRelations == 0) return null;
        double focus = spatialFocus(heat);
        return new Evidence(EvidenceFamily.ARITHMETIC, heat,
                Math.min(0.72, 0.25 + 0.50 * focus), 0.80,
                totalTrials, Math.min(0.68, 0.24 + totalTrials / 90.0),
                0.48 + 0.35 * regime.previousRegimeWeight, 0.0,
                validatedRelations + " relações soma/subtração validadas na própria mesa");
    }

    private static Evidence regimeEvidence(List<Integer> history,
                                            RegimeDetector.Snapshot regime) {
        double[] heat = new double[37];
        if (regime.changeDetected) {
            for (int i = 0; i < 37; i++) {
                heat[i] = Math.max(0.0, regime.currentRegimeSignature.wheelHeat[i]
                        - regime.previousRegimeWeight
                        * regime.previousRegimeSignature.wheelHeat[i]);
            }
        } else {
            double[] recent = density(history, 0, Math.min(30, history.size()), 2);
            double[] context = density(history, 30, Math.min(150, history.size()), 2);
            normalizeMax(recent);
            normalizeMax(context);
            for (int i = 0; i < 37; i++) heat[i] = 0.78 * recent[i] + 0.22 * context[i];
        }
        double focus = spatialFocus(heat);
        double reliability = regime.changeDetected
                ? 0.26 + 0.66 * regime.regimeConfidence : 0.28;
        return new Evidence(EvidenceFamily.REGIME, heat,
                0.24 + 0.56 * focus + 0.20 * regime.regimeConfidence,
                0.98, regime.currentRegimeStart, reliability,
                1.0, 0.0,
                regime.changeDetected
                        ? "novo regime provável nos últimos " + regime.currentRegimeStart + " giros"
                        : "regime estável; últimos 30 mantêm prioridade");
    }

    private static double[] fuse(List<Evidence> evidence) {
        double[] heat = new double[37];
        double total = 0.0;
        for (Evidence item : evidence) {
            double weight = Math.min(1.0, item.weight());
            addScaled(heat, item.heat, weight);
            total += weight;
        }
        if (total > 0.0) {
            for (int i = 0; i < heat.length; i++) heat[i] /= total;
        }
        normalizeMax(heat);
        return heat;
    }

    private static Fusion evaluateFamilies(List<Evidence> evidence, int target) {
        List<EvidenceFamily> supporting = new ArrayList<>();
        double contradiction = 0.0;
        double totalWeight = 0.0;
        double alignment = 0.0;
        Map<EvidenceFamily, Double> relativeSupport = new HashMap<>();
        for (Evidence item : evidence) {
            SectorScore best = bestSector(item.heat);
            double candidate = sectorSupport(item.heat, target);
            double relative = best.score <= 0.0 ? 0.0 : candidate / best.score;
            relativeSupport.put(item.family, relative);
            double weight = Math.min(1.0, item.weight());
            totalWeight += weight;
            boolean independentPeak = relative >= 0.78
                    && candidate >= 0.34 && weight >= 0.16;
            if (independentPeak) {
                supporting.add(item.family);
                alignment += relative;
            }
            if (Wheel.distance(best.center, target) >= 5 && relative < 0.72) {
                contradiction += weight * (1.0 - relative);
            }
            contradiction += weight * item.contradiction * 0.5;
        }
        double normalizedContradiction = totalWeight <= 0.0 ? 1.0
                : clamp01(contradiction / totalWeight);
        return new Fusion(supporting, normalizedContradiction, alignment, relativeSupport);
    }

    private static double currentContextSupport(List<Evidence> evidence, int target) {
        double total = 0.0;
        double weights = 0.0;
        for (Evidence item : evidence) {
            if (item.family != EvidenceFamily.RECENCY
                    && item.family != EvidenceFamily.REGIME
                    && item.family != EvidenceFamily.TRANSITION) continue;
            SectorScore best = bestSector(item.heat);
            if (best.score <= 0.0) continue;
            double weight = item.weight();
            total += weight * sectorSupport(item.heat, target) / best.score;
            weights += weight;
        }
        return weights <= 0.0 ? 0.0 : clamp01(total / weights);
    }

    private static SectorScore scoreOf(TargetRanking.Candidate candidate) {
        if (candidate == null || candidate.target < 0) return new SectorScore(-1, 0.0);
        return new SectorScore(candidate.target, candidate.score);
    }

    private static CandidateAssessment assessCandidate(List<Evidence> evidence,
                                                        SectorScore candidate,
                                                        double leaderScore,
                                                        double margin,
                                                        double dispersion) {
        if (candidate == null || candidate.center < 0 || candidate.score <= 0.0) {
            return CandidateAssessment.empty();
        }
        Fusion fusion = evaluateFamilies(evidence, candidate.center);
        double alignment = fusion.supporting.isEmpty() ? 0.0
                : fusion.alignment / fusion.supporting.size();
        double breadth = Math.min(1.0, fusion.supporting.size() / 7.0);
        double relativeStrength = leaderScore <= 0.0 ? 0.0
                : clamp01(candidate.score / leaderScore);
        double marginQuality = clamp01(margin / 0.28);
        double context = currentContextSupport(evidence, candidate.center);
        double concentration = clamp01((1.0 - dispersion) / 0.28);
        double quality = 0.26 * alignment
                + 0.19 * breadth
                + 0.15 * relativeStrength
                + 0.12 * marginQuality
                + 0.13 * (1.0 - fusion.contradiction)
                + 0.10 * context
                + 0.05 * concentration;
        int score = clampScore((int) Math.round(quality * 100.0));
        int samples = predictiveSamples(evidence, fusion.supporting);
        boolean predictivePath = hasAny(fusion.supporting,
                EvidenceFamily.TRANSITION, EvidenceFamily.SEQUENCE,
                EvidenceFamily.HISTORICAL_SIMILARITY,
                EvidenceFamily.WHEEL_GEOMETRY);
        boolean recentPath = hasAny(fusion.supporting,
                EvidenceFamily.RECENCY, EvidenceFamily.REGIME,
                EvidenceFamily.TRANSITION);
        return new CandidateAssessment(candidate, fusion, score, samples,
                context, alignment, predictivePath, recentPath);
    }

    private static boolean qualifiesSecondary(CandidateAssessment assessment,
                                               TargetRanking ranking,
                                               ConfluenceVerdict.Mode mode) {
        if (assessment == null || assessment.candidate.center < 0
                || ranking == null || ranking.highDispersion
                || ranking.spatialRegime != TargetRanking.SpatialRegime.BIMODAL) {
            return false;
        }
        double ratio = ranking.primary.score <= 0.0 ? 0.0
                : ranking.secondary.score / ranking.primary.score;
        boolean precision = mode == ConfluenceVerdict.Mode.PRECISION;
        int minimumFamilies = precision ? 4 : 4;
        int minimumScore = precision ? 70 : 66;
        int minimumSamples = precision ? 15 : 12;
        double maximumContradiction = precision ? 0.30 : 0.34;
        double minimumMargin = precision ? 0.12 : 0.10;
        double minimumDualDominance = precision ? 0.55 : 0.50;
        boolean exceptionalThree = !precision
                && assessment.fusion.supporting.size() == 3
                && assessment.alignment >= 0.94
                && assessment.currentContext >= 0.86
                && assessment.fusion.contradiction <= 0.16
                && assessment.predictiveSamples >= 30;
        return assessment.score >= minimumScore
                && (assessment.fusion.supporting.size() >= minimumFamilies
                || exceptionalThree)
                && assessment.fusion.contradiction <= maximumContradiction
                && ranking.secondaryMargin >= minimumMargin
                && ranking.dualDominance >= minimumDualDominance
                && ratio >= 0.54
                && assessment.predictivePath
                && assessment.recentPath
                && assessment.predictiveSamples >= minimumSamples;
    }

    private static List<String> secondaryReasons(CandidateAssessment assessment,
                                                  TargetRanking ranking,
                                                  boolean qualified) {
        if (!qualified || assessment == null) return Collections.emptyList();
        List<String> reasons = new ArrayList<>();
        reasons.add(assessment.fusion.supporting.size()
                + " famílias próprias convergem no polo secundário");
        reasons.add("Margem sobre terceiro " + percent(ranking.secondaryMargin)
                + " • dual dominance " + percent(ranking.dualDominance));
        reasons.add("Contradição secundária "
                + percent(assessment.fusion.contradiction)
                + " • contexto atual " + percent(assessment.currentContext));
        reasons.add("Secondary é opcional; não aumenta exposição automaticamente");
        return reasons;
    }

    private static int predictiveSamples(List<Evidence> evidence,
                                         List<EvidenceFamily> supporting) {
        int samples = 0;
        for (Evidence item : evidence) {
            if (!supporting.contains(item.family)) continue;
            if (item.family == EvidenceFamily.TRANSITION
                    || item.family == EvidenceFamily.SEQUENCE
                    || item.family == EvidenceFamily.HISTORICAL_SIMILARITY
                    || item.family == EvidenceFamily.WHEEL_GEOMETRY
                    || item.family == EvidenceFamily.ARITHMETIC) {
                samples += item.sampleSize;
            }
        }
        return samples;
    }

    private static List<String> reasons(List<Evidence> evidence, Fusion fusion,
                                        RegimeDetector.Snapshot regime,
                                        SectorScore leader, SectorScore runner,
                                        SectorScore third, int score,
                                        double dispersion, int predictiveSamples,
                                        TargetRanking ranking,
                                        CandidateAssessment secondary,
                                        boolean secondaryQualified) {
        List<String> reasons = new ArrayList<>();
        reasons.add(fusion.supporting.size() + " famílias independentes convergem: "
                + joinFamilies(fusion.supporting));
        reasons.add("Dominância " + percent(runner == null || leader.score <= 0.0
                ? 1.0 : (leader.score - runner.score) / leader.score)
                + " • contradição " + percent(fusion.contradiction)
                + " • dispersão " + percent(dispersion));
        reasons.add("Regime espacial " + ranking.spatialRegime
                + " • formato " + ranking.shape(secondaryQualified)
                + " • margem do segundo " + percent(ranking.secondaryMargin));
        if (secondaryQualified) {
            reasons.add("Secondary opcional " + runner.center + " ("
                    + secondary.score + "/100, "
                    + secondary.fusion.supporting.size()
                    + " famílias) • terceiro " + third.center);
        }
        reasons.add(regime.changeDetected
                ? "Mudança de regime detectada • contexto atual estimado em "
                + regime.currentRegimeStart + " giros • confiança "
                + percent(regime.regimeConfidence)
                : "Regime sem quebra clara • últimos 30 mantêm prioridade");
        reasons.add("Amostras de transição/sequência alinhadas: " + predictiveSamples);
        List<Evidence> ranked = new ArrayList<>(evidence);
        ranked.sort(Comparator.comparingDouble((Evidence item) -> {
            double relative = fusion.relativeSupport.getOrDefault(item.family, 0.0);
            return item.weight() * relative;
        }).reversed());
        for (Evidence item : ranked) {
            if (!fusion.supporting.contains(item.family)) continue;
            reasons.add(label(item.family) + ": " + item.explanation);
            if (reasons.size() >= 9) break;
        }
        reasons.add("Aurum Score " + score + "/100 mede confluência; não é probabilidade matemática");
        return reasons;
    }

    private static List<String> featureKeys(Fusion fusion,
                                            RegimeDetector.Snapshot regime,
                                            int score, double dominance,
                                            double dispersion,
                                            ConfluenceVerdict.Mode mode,
                                            TargetRanking ranking,
                                            boolean secondaryQualified) {
        List<String> features = new ArrayList<>();
        features.add("confluence_engine_v2");
        features.add("mode_" + mode.name().toLowerCase(Locale.ROOT));
        for (EvidenceFamily family : fusion.supporting) {
            features.add("family_" + family.name().toLowerCase(Locale.ROOT));
        }
        features.add("families_" + Math.min(9, fusion.supporting.size()));
        features.add(score >= 82 ? "aurum_score_82_plus" : score >= 72
                ? "aurum_score_72_81" : "aurum_score_below_72");
        features.add(dominance >= 0.16 ? "dominance_approved" : "dominance_low");
        features.add(fusion.contradiction <= 0.16
                ? "contradiction_low" : "contradiction_present");
        features.add(dispersion <= 0.94 ? "dispersion_compact" : "dispersion_wide");
        features.add(regime.changeDetected ? "regime_change" : "regime_stable");
        features.add("regime_length_" + regimeBucket(regime.currentRegimeStart));
        features.add("dominance_bp_" + basisPoints(dominance));
        features.add("contradiction_bp_" + basisPoints(fusion.contradiction));
        features.add("dispersion_bp_" + basisPoints(dispersion));
        features.add("spatial_" + ranking.spatialRegime.name().toLowerCase(Locale.ROOT));
        features.add("shape_" + ranking.shape(secondaryQualified)
                .name().toLowerCase(Locale.ROOT));
        features.add(secondaryQualified ? "secondary_qualified" : "primary_only");
        features.add("secondary_margin_bp_" + basisPoints(ranking.secondaryMargin));
        features.add("dual_dominance_bp_" + basisPoints(ranking.dualDominance));
        return features;
    }

    private static ConfluenceVerdict emptyVerdict(RegimeDetector.Snapshot regime,
                                                   ConfluenceVerdict.Mode mode,
                                                   String reason) {
        return new ConfluenceVerdict(ConfluenceVerdict.Decision.NO_READING,
                -1, Collections.emptyList(), Collections.emptyList(), 0, 0,
                1.0, 0.0, 1.0, 0.0, 0.0, regime,
                Collections.emptyList(), Collections.singletonList(reason),
                Collections.singletonList("confluence_engine_v2"),
                new double[37], false, false, false, mode,
                -1, Collections.emptyList(), Collections.emptyList(),
                0, 0, 1.0, 0.0, 0.0, -1, 0, 0.0,
                TargetRanking.SpatialRegime.DISPERSED,
                TargetRanking.SignalShape.SINGLE_TARGET,
                Collections.emptyList(), Collections.emptyList(), false);
    }

    private static List<SectorScore> rankSectors(double[] heat) {
        List<SectorScore> result = new ArrayList<>();
        for (int center : Wheel.EUROPEAN) {
            result.add(new SectorScore(center, sectorSupport(heat, center)));
        }
        result.sort(Comparator.comparingDouble((SectorScore item) -> item.score)
                .reversed().thenComparingInt(item -> item.center));
        return result;
    }

    private static SectorScore bestSector(double[] heat) {
        return rankSectors(heat).get(0);
    }

    private static SectorScore independentRunner(List<SectorScore> sectors,
                                                  SectorScore leader) {
        List<Integer> leaderZone = Wheel.coverage(leader.center, RADIUS);
        for (SectorScore candidate : sectors) {
            if (candidate.center == leader.center) continue;
            if (overlap(leaderZone, Wheel.coverage(candidate.center, RADIUS)) <= 1) {
                return candidate;
            }
        }
        return null;
    }

    private static double sectorSupport(double[] heat, int center) {
        List<Integer> zone = Wheel.coverage(center, RADIUS);
        if (zone.size() != 5) return 0.0;
        double[] weights = {0.62, 0.84, 1.0, 0.84, 0.62};
        double total = 0.0;
        double weight = 0.0;
        for (int i = 0; i < zone.size(); i++) {
            total += heat[zone.get(i)] * weights[i];
            weight += weights[i];
        }
        return weight <= 0.0 ? 0.0 : clamp01(total / weight);
    }

    private static List<Integer> nucleus(List<Integer> coverage, double[] heat) {
        List<Integer> result = new ArrayList<>(coverage);
        result.sort(Comparator.comparingDouble((Integer number) -> heat[number]).reversed());
        if (result.size() > 3) result = new ArrayList<>(result.subList(0, 3));
        return result;
    }

    private static double sequenceSimilarity(List<Integer> history, int historicalStart,
                                             int length) {
        double position = 0.0;
        double terminal = 0.0;
        for (int i = 0; i < length; i++) {
            int current = history.get(i);
            int old = history.get(historicalStart + i);
            position += 1.0 - Math.min(1.0, Wheel.distance(current, old) / 9.0);
            int terminalDistance = Math.abs(current % 10 - old % 10);
            terminal += terminalDistance == 0 ? 1.0 : terminalDistance == 1 ? 0.45 : 0.0;
        }
        position /= length;
        terminal /= length;
        double steps = 0.0;
        for (int i = 0; i + 1 < length; i++) {
            int currentStep = signedWheelStep(history.get(i + 1), history.get(i));
            int oldStep = signedWheelStep(history.get(historicalStart + i + 1),
                    history.get(historicalStart + i));
            steps += 1.0 - Math.min(1.0, Math.abs(currentStep - oldStep) / 9.0);
        }
        steps = length <= 1 ? 0.0 : steps / (length - 1);
        TableSignature currentSignature = TableSignature.from(history, 0, length);
        TableSignature oldSignature = TableSignature.from(history,
                historicalStart, historicalStart + length);
        double signature = currentSignature.similarity(oldSignature);
        return clamp01(0.35 * position + 0.30 * steps
                + 0.15 * terminal + 0.20 * signature);
    }

    private static boolean exactWindow(List<Integer> history, int first,
                                       int second, int length) {
        if (first + length > history.size() || second + length > history.size()) return false;
        for (int i = 0; i < length; i++) {
            if (!history.get(first + i).equals(history.get(second + i))) return false;
        }
        return true;
    }

    private static int signedWheelStep(int older, int newer) {
        int oldIndex = Wheel.EUROPEAN.indexOf(older);
        int newIndex = Wheel.EUROPEAN.indexOf(newer);
        if (oldIndex < 0 || newIndex < 0) return 0;
        int step = newIndex - oldIndex;
        if (step > 18) step -= 37;
        if (step < -18) step += 37;
        return step;
    }

    private static double[] density(List<Integer> history, int start, int end, int radius) {
        double[] heat = new double[37];
        int safeEnd = Math.min(history.size(), end);
        for (int i = Math.max(0, start); i < safeEnd; i++) {
            addKernel(heat, history.get(i), 1.0, radius);
        }
        return heat;
    }

    private static void addKernel(double[] heat, int number, double weight, int radius) {
        int index = Wheel.EUROPEAN.indexOf(number);
        if (index < 0) return;
        int size = Wheel.EUROPEAN.size();
        heat[number] += weight;
        if (radius >= 1) {
            heat[Wheel.EUROPEAN.get((index + 1) % size)] += weight * 0.48;
            heat[Wheel.EUROPEAN.get((index - 1 + size) % size)] += weight * 0.48;
        }
        if (radius >= 2) {
            heat[Wheel.EUROPEAN.get((index + 2) % size)] += weight * 0.18;
            heat[Wheel.EUROPEAN.get((index - 2 + size) % size)] += weight * 0.18;
        }
    }

    private static double historicalContextWeight(int index,
                                                  RegimeDetector.Snapshot regime) {
        if (index < regime.currentRegimeStart) return 1.0;
        double distanceDecay = Math.exp(-(index - regime.currentRegimeStart) / 280.0);
        return Math.max(0.08, regime.previousRegimeWeight * distanceDecay);
    }

    private static double recencyWindowWeight(int window) {
        if (window <= 3) return 0.58;
        if (window <= 7) return 0.84;
        if (window <= 15) return 1.0;
        if (window <= 30) return 1.08;
        if (window <= 50) return 0.78;
        if (window <= 100) return 0.55;
        return 0.34;
    }

    private static double physicalAgreement(List<Integer> centers) {
        if (centers.size() < 2) return 0.0;
        double best = 0.0;
        for (int anchor : centers) {
            double support = 0.0;
            for (int center : centers) {
                int distance = Wheel.distance(anchor, center);
                support += distance <= 2 ? 1.0 : distance <= 4 ? 0.45 : 0.0;
            }
            best = Math.max(best, support / centers.size());
        }
        return clamp01(best);
    }

    private static double spatialFocus(double[] heat) {
        List<SectorScore> sectors = rankSectors(heat);
        double mean = 0.0;
        for (SectorScore sector : sectors) mean += sector.score;
        mean /= sectors.size();
        if (mean <= 0.0) return 0.0;
        return clamp01((sectors.get(0).score / mean - 1.0) / 1.15);
    }

    private static double topMargin(double[] values) {
        double first = 0.0;
        double second = 0.0;
        for (double value : values) {
            if (value >= first) {
                second = first;
                first = value;
            } else if (value > second) {
                second = value;
            }
        }
        return first <= 0.0 ? 0.0 : clamp01((first - second) / first);
    }

    private static int overlap(List<Integer> first, List<Integer> second) {
        int count = 0;
        for (int number : first) if (second.contains(number)) count++;
        return count;
    }

    private static double mean(List<Integer> values) {
        if (values.isEmpty()) return 0.0;
        double total = 0.0;
        for (int value : values) total += value;
        return total / values.size();
    }

    private static double standardDeviation(List<Integer> values, double mean) {
        if (values.size() < 2) return 0.0;
        double total = 0.0;
        for (int value : values) {
            double delta = value - mean;
            total += delta * delta;
        }
        return Math.sqrt(total / values.size());
    }

    private static void addScaled(double[] target, double[] source, double weight) {
        for (int i = 0; i < Math.min(target.length, source.length); i++) {
            target[i] += source[i] * weight;
        }
    }

    private static void normalizeMax(double[] values) {
        double max = 0.0;
        for (double value : values) max = Math.max(max, value);
        if (max <= 0.0) return;
        for (int i = 0; i < values.length; i++) values[i] /= max;
    }

    private static boolean hasAny(List<EvidenceFamily> values,
                                  EvidenceFamily... expected) {
        for (EvidenceFamily family : expected) if (values.contains(family)) return true;
        return false;
    }

    private static String joinFamilies(List<EvidenceFamily> families) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < families.size(); i++) {
            if (i > 0) out.append(" • ");
            out.append(label(families.get(i)));
        }
        return out.toString();
    }

    private static String label(EvidenceFamily family) {
        switch (family) {
            case SEQUENCE: return "sequências";
            case TRANSITION: return "transições";
            case WHEEL_GEOMETRY: return "geometria da roda";
            case TERMINAL: return "terminais";
            case RECENCY: return "multiescala";
            case FREQUENCY: return "aceleração";
            case ARITHMETIC: return "soma/subtração";
            case HISTORICAL_SIMILARITY: return "similaridade histórica";
            case REGIME: return "regime atual";
            case GAP: return "ciclos";
            case CLUSTER: return "cluster";
            default: return family.name().toLowerCase(Locale.ROOT);
        }
    }

    private static String regimeBucket(int length) {
        if (length <= 24) return "18_24";
        if (length <= 40) return "25_40";
        if (length <= 70) return "41_70";
        if (length <= 110) return "71_110";
        return "111_plus";
    }

    private static String percent(double value) {
        return String.format(new Locale("pt", "BR"), "%.0f%%", clamp01(value) * 100.0);
    }

    private static int clampScore(int value) {
        return Math.max(0, Math.min(100, value));
    }

    private static int basisPoints(double value) {
        return (int) Math.round(clamp01(value) * 1000.0);
    }

    private static double clamp01(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }

    private static void add(List<Evidence> evidence, Evidence item) {
        if (item != null && item.weight() > 0.04) evidence.add(item);
    }

    private static final class SectorScore {
        final int center;
        final double score;

        SectorScore(int center, double score) {
            this.center = center;
            this.score = score;
        }
    }

    private static final class Fusion {
        final List<EvidenceFamily> supporting;
        final double contradiction;
        final double alignment;
        final Map<EvidenceFamily, Double> relativeSupport;

        Fusion(List<EvidenceFamily> supporting, double contradiction,
               double alignment, Map<EvidenceFamily, Double> relativeSupport) {
            this.supporting = supporting;
            this.contradiction = contradiction;
            this.alignment = alignment;
            this.relativeSupport = relativeSupport;
        }
    }

    private static final class CandidateAssessment {
        final SectorScore candidate;
        final Fusion fusion;
        final int score;
        final int predictiveSamples;
        final double currentContext;
        final double alignment;
        final boolean predictivePath;
        final boolean recentPath;

        CandidateAssessment(SectorScore candidate, Fusion fusion, int score,
                            int predictiveSamples, double currentContext,
                            double alignment, boolean predictivePath,
                            boolean recentPath) {
            this.candidate = candidate;
            this.fusion = fusion;
            this.score = score;
            this.predictiveSamples = predictiveSamples;
            this.currentContext = currentContext;
            this.alignment = alignment;
            this.predictivePath = predictivePath;
            this.recentPath = recentPath;
        }

        static CandidateAssessment empty() {
            return new CandidateAssessment(new SectorScore(-1, 0.0),
                    new Fusion(Collections.emptyList(), 1.0, 0.0,
                            Collections.emptyMap()),
                    0, 0, 0.0, 0.0, false, false);
        }
    }
}
