package com.xspaceart.radar30.integrated.scanner;

/**
 * Scanner semântico da DOM. O script nunca trata um 0-36 isolado como giro:
 * primeiro classifica a região, aplica sinais negativos e só então devolve
 * histórico quando a região alcança confiança suficiente.
 */
public final class SourceHunter {
    private SourceHunter() {}

    public static String discoveryScript(String lockedSignature) {
        String wanted = js(lockedSignature == null ? "" : lockedSignature);
        return "(function(){try{" +
                "var wanted=\"" + wanted + "\";" +
                "var best=null,locked=null,scanned=0,accessible=0,blocked=0,candidates=0;" +
                "var context={history:0,current:0,race:0,timeline:0,stats:0,bet:0,balance:0,controls:0,ignored:0};" +
                "function txt(e){try{return ((e.innerText||e.textContent||'')+'').trim();}catch(x){return '';}}" +
                "function meta(e){var p=e&&e.parentElement;return (((e.id||'')+' '+(typeof e.className==='string'?e.className:'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('data-testid')||'')+' '+(e.getAttribute('data-name')||'')+' '+(e.getAttribute('data-type')||'')+' '+(e.getAttribute('role')||'')+' '+(e.getAttribute('title')||''))+' '+(p?((p.id||'')+' '+(typeof p.className==='string'?p.className:'')+' '+(p.getAttribute('aria-label')||'')+' '+(p.getAttribute('data-testid')||'')):'')).toLowerCase();}" +
                "function numsFrom(e,t){var a=[],nodes=[];try{nodes=e.querySelectorAll('[data-number],[data-value]');}catch(x){}for(var i=0;i<nodes.length;i++){var v=nodes[i].getAttribute('data-number');if(v==null)v=nodes[i].getAttribute('data-value');if(/^(?:[0-9]|[12][0-9]|3[0-6])$/.test((v||'').trim()))a.push(parseInt(v,10));}" +
                "if(a.length>=6)return a.slice(0,500);var m=(t||'').match(/(?:^|\\s|[^0-9])(3[0-6]|[12][0-9]|[0-9])(?=$|\\s|[^0-9])/g)||[];a=[];for(var j=0;j<m.length;j++){var q=m[j].match(/(3[0-6]|[12][0-9]|[0-9])/);if(q)a.push(parseInt(q[1],10));}return a.slice(0,500);}" +
                "function cls(m){" +
                "if(/race.?track|racetrack|voisins|orphelins|tiers|neighbors?|vizinhos|wheel.?sector/.test(m))return 'RACETRACK';" +
                "if(/statistics?|estat[ií]st|hot.?numbers?|cold.?numbers?|frequency|distribution|percent|porcent/.test(m))return 'STATISTICS';" +
                "if(/balance|saldo|wallet|cash|credit|currency|deposit|withdraw/.test(m))return 'BALANCE_VALUES';" +
                "if(/bet.?grid|betting|bets?|stake|chips?|wager|payout|odds|straight|split|street|corner|dozen|column/.test(m))return 'BETTING_TABLE';" +
                "if(/timeline|roadmap|trend.?line/.test(m))return 'TIMELINE';" +
                "if(/timer|countdown|seconds?|remaining.?time|controls?|button|toolbar|menu/.test(m))return 'CONTROLS';" +
                "if(/current.?result|last.?result|winner|winning.?number|latest.?number/.test(m))return 'CURRENT_RESULT';" +
                "if(/history|recent.?results?|result.?history|spin.?history|previous.?results?|last.?spins?|winning.?numbers?|outcomes?/.test(m))return 'HISTORY';" +
                "return 'IGNORE';}" +
                "function sig(e,label,m){var tag=(e.tagName||'').toLowerCase();var id=e.id||'';var cl=typeof e.className==='string'?e.className:'';var dt=e.getAttribute('data-testid')||'';var ar=e.getAttribute('aria-label')||'';var role=e.getAttribute('role')||'';return (label+'|'+tag+'|'+id+'|'+cl+'|'+dt+'|'+ar+'|'+role).slice(0,700);}" +
                "function scoreCandidate(kind,m,ns,t){if(kind!=='HISTORY')return 0;if(ns.length<8||ns.length>500)return 0;var s=48;" +
                "if(/history|result.?history|spin.?history|previous.?results?/.test(m))s+=22;" +
                "if(/recent|last.?spins?|winning.?numbers?|outcomes?/.test(m))s+=12;" +
                "if(/data-number|data-value/.test(m))s+=4;" +
                "var distinct={};for(var i=0;i<Math.min(ns.length,80);i++)distinct[ns[i]]=1;var d=Object.keys(distinct).length;" +
                "if(ns.length>=12)s+=5;if(ns.length>=20)s+=4;if(d>=6)s+=4;" +
                "if(ns.length===37&&d===37)s-=28;" +
                "if(/race.?track|statistics?|estat|balance|saldo|betting|bet.?grid|stake|chip|timer|countdown/.test(m))s-=55;" +
                "if(t.length>12000)s-=15;return Math.max(0,Math.min(100,s));}" +
                "function inspectRoot(root,label){if(!root||!root.querySelectorAll)return;var els=root.querySelectorAll('[class],[id],[aria-label],[data-testid],[data-number],[data-value],[data-name],[data-type],[role]');" +
                "for(var i=0;i<els.length;i++){var e=els[i];scanned++;var m=meta(e),kind=cls(m);if(kind==='HISTORY')context.history++;else if(kind==='CURRENT_RESULT')context.current++;else if(kind==='RACETRACK')context.race++;else if(kind==='TIMELINE')context.timeline++;else if(kind==='STATISTICS')context.stats++;else if(kind==='BETTING_TABLE')context.bet++;else if(kind==='BALANCE_VALUES')context.balance++;else if(kind==='CONTROLS')context.controls++;else context.ignored++;" +
                "if(kind==='HISTORY'){var t=txt(e);if(t&&t.length<=20000){var ns=numsFrom(e,t),conf=scoreCandidate(kind,m,ns,t);if(conf>=55){candidates++;var sg=sig(e,label,m),c={confidence:conf,history:ns,hint:(label+' '+m).slice(0,240),signature:sg,classification:kind};if(wanted&&sg===wanted)locked=c;if(!best||conf>best.confidence||(conf===best.confidence&&ns.length>best.history.length))best=c;}}}" +
                "try{if(e.shadowRoot)inspectRoot(e.shadowRoot,label+' shadow');}catch(x){} }" +
                "var frames=root.querySelectorAll('iframe');for(var f=0;f<frames.length;f++){try{var d=frames[f].contentDocument;if(d&&d.documentElement){accessible++;inspectRoot(d,label+' iframe['+f+']');}else blocked++;}catch(x){blocked++;}}}" +
                "inspectRoot(document,'main');var chosen=locked||best;" +
                "var current=-1;try{var ces=document.querySelectorAll('[class],[id],[aria-label],[data-testid],[data-number],[data-value]');for(var z=0;z<ces.length;z++){var cm=meta(ces[z]);if(cls(cm)==='CURRENT_RESULT'){var cn=numsFrom(ces[z],txt(ces[z]));if(cn.length){current=cn[0];break;}}}}catch(x){}" +
                "var out={url:location.href,title:document.title||'',iframes:document.querySelectorAll('iframe').length,accessibleFrames:accessible,blockedFrames:blocked,scannedNodes:scanned,candidates:candidates,history:chosen?chosen.history:[],hint:chosen?chosen.hint:'',signature:chosen?chosen.signature:'',classification:chosen?chosen.classification:'',confidence:chosen?chosen.confidence:0,lockRequested:!!wanted,lockMatched:!!locked,currentResult:current,context:context};return JSON.stringify(out);" +
                "}catch(e){return JSON.stringify({error:String(e),url:location.href,title:document.title||'',iframes:0,accessibleFrames:0,blockedFrames:0,scannedNodes:0,candidates:0,history:[],hint:'',signature:'',classification:'',confidence:0,lockRequested:false,lockMatched:false,currentResult:-1,context:{}});}})();";
    }

    public static String discoveryScript() { return discoveryScript(""); }

    private static String js(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }
}
