package com.xspaceart.radar30.integrated;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.xspaceart.radar30.AppStateStore;
import com.xspaceart.radar30.CalibrationActivity;
import com.xspaceart.radar30.CaptureRepository;
import com.xspaceart.radar30.MainActivity;
import com.xspaceart.radar30.ScreenCaptureService;
import com.xspaceart.radar30.SessionLedger;
import com.xspaceart.radar30.Ui;
import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.integrated.normalize.SpinNormalizer;
import com.xspaceart.radar30.integrated.normalize.SourceDelta;
import com.xspaceart.radar30.integrated.normalize.SourceOrderTracker;
import com.xspaceart.radar30.integrated.normalize.ManualEchoReconciler;
import com.xspaceart.radar30.integrated.scanner.DomSourceMemory;
import com.xspaceart.radar30.integrated.scanner.EnvironmentScanner;
import com.xspaceart.radar30.integrated.scanner.EvidenceGraph;
import com.xspaceart.radar30.integrated.scanner.SourceHunter;
import com.xspaceart.radar30.integrated.session.IntegratedSessionStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class IntegratedActivity extends Activity {
    private static final long SCAN_MS = 1900L;
    private static final long UI_TICK_MS = 700L;
    private static final int REQUEST_CAPTURE = 7101;
    private static final int FAMILY_COUNT = EvidenceFamily.values().length;
    private static final int DOM_LOCK_CONFIDENCE = 76;
    private static final int DOM_TRACK_CONFIDENCE = 68;
    private static final String BROWSER_PREFS = "aurum_integrated_browser";
    private static final String LAST_URL = "last_url";

    private enum DomState { DISCOVERY, LOCKED, TRACKING, BLOCKED }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final IntegratedSignalBridge bridge = new IntegratedSignalBridge();
    private final SpinNormalizer normalizer = new SpinNormalizer();
    private final SourceOrderTracker domOrderTracker = new SourceOrderTracker();
    private final ManualEchoReconciler manualEchoReconciler = new ManualEchoReconciler();
    private final EnvironmentScanner environmentScanner = new EnvironmentScanner();
    private final EvidenceGraph evidenceGraph = new EvidenceGraph();

    private WebView webView;
    private EditText urlInput;
    private ProgressBar pageProgress, confluenceBar;
    private TextView liveBadge, signalTitle, signalTarget, signalMeta, secondaryText;
    private TextView scannerText, rayText, sessionText, sourceText, contextText;
    private TextView pipelineText, confluenceText, historyPreviewText, activityText, captureStatusText;
    private Switch balancedSwitch;
    private Button startReadingButton, finishButton, newSessionButton, scanToggle;

    private boolean scannerRunning = true;
    private boolean readingActive;
    private boolean receiverRegistered;
    private boolean incrementalSourceMode;
    private boolean ocrFallbackActive;
    private boolean initialBootstrapPending = true;
    private DomState domState = DomState.DISCOVERY;

    private String currentHost = "";
    private String lockedDomSignature = "";
    private String lastDomFingerprint = "";
    private String lastOcrFingerprint = "";
    private String lastAcceptedSource = "—";
    private String domHint = "";
    private String tableContext = "sem contexto auxiliar confirmado";
    private long lastScanAttemptAt;
    private long lastDataAt;
    private long scanAttempts;
    private int domHistoryCount;
    private int ocrHistoryCount;
    private int accessibleFrames;
    private int blockedFrames;
    private int domLockFailures;
    private int domDiscoveryFailures;
    private int domConfidence;
    private int currentResult = -1;
    private ConfluenceVerdict lastVerdict;
    private List<Integer> lastDomObserved = new ArrayList<>();
    private List<Integer> lastOcrObserved = new ArrayList<>();

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            syncFromVisualHistory();
            refreshCaptureStatus();
        }
    };

    private final Runnable scanLoop = new Runnable() {
        @Override public void run() {
            if (scannerRunning && webView != null) discoverPage();
            handler.postDelayed(this, SCAN_MS);
        }
    };

    private final Runnable uiTicker = new Runnable() {
        @Override public void run() {
            refreshTelemetryClock();
            handler.postDelayed(this, UI_TICK_MS);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        setContentView(buildUi());
        bridge.setPrecision(true);
        configureWebView();
        registerStateReceiver();
        handler.postDelayed(scanLoop, 700L);
        handler.post(uiTicker);
        refreshSession();
        refreshCaptureStatus();
        syncFromVisualHistory();
        refreshTelemetryClock();
    }

    @Override protected void onResume() {
        super.onResume();
        syncFromVisualHistory();
        refreshCaptureStatus();
    }

    @Override protected void onPause() {
        try { CookieManager.getInstance().flush(); } catch (RuntimeException ignored) {}
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); } catch (IllegalArgumentException ignored) {}
            receiverRegistered = false;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Leitura visual não autorizada.", Toast.LENGTH_LONG).show();
            refreshCaptureStatus();
            return;
        }
        SessionLedger.ensureActive(this, AppStateStore.provider(this), AppStateStore.dealer(this));
        Intent service = new Intent(this, ScreenCaptureService.class)
                .setAction(ScreenCaptureService.ACTION_START)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data);
        startForegroundService(service);
        captureStatusText.setText("OCR • captura autorizada, aguardando ROI estável");
        captureStatusText.setTextColor(Ui.CYAN);
        Toast.makeText(this,
                AppStateStore.isCalibrated(this)
                        ? "OCR disponível como fallback. DOM continua sendo a fonte principal."
                        : "Captura ativada. Calibre somente a área do histórico para habilitar o fallback OCR.",
                Toast.LENGTH_LONG).show();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this,14),Ui.dp(this,9),Ui.dp(this,14),Ui.dp(this,7));
        TextView brand = Ui.text(this,"AURUM AI 37",22,Ui.GREEN,true);
        TextView lab = Ui.text(this,"  INTEGRATED",11,Ui.AMBER,true);
        liveBadge = Ui.text(this,"● AGUARDANDO INÍCIO",11,Ui.AMBER,true);
        top.addView(brand); top.addView(lab,new LinearLayout.LayoutParams(0,-2,1)); top.addView(liveBadge);
        root.addView(top);

        LinearLayout address = new LinearLayout(this);
        address.setPadding(Ui.dp(this,10),0,Ui.dp(this,10),Ui.dp(this,6));
        urlInput = new EditText(this);
        urlInput.setHint("https://..."); urlInput.setSingleLine(true); urlInput.setTextColor(Ui.TEXT); urlInput.setHintTextColor(Ui.MUTED);
        urlInput.setTextSize(12); urlInput.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        Button open = Ui.button(this,"Abrir",Ui.AMBER,Color.BLACK);
        Button reload = Ui.button(this,"↻",Ui.SURFACE,Ui.TEXT);
        address.addView(urlInput,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));
        address.addView(open,new LinearLayout.LayoutParams(Ui.dp(this,76),Ui.dp(this,44)));
        address.addView(reload,new LinearLayout.LayoutParams(Ui.dp(this,50),Ui.dp(this,44)));
        root.addView(address);
        pageProgress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        pageProgress.setMax(100); pageProgress.setVisibility(View.GONE);
        root.addView(pageProgress,new LinearLayout.LayoutParams(-1,Ui.dp(this,2)));

        webView = new WebView(this); webView.setBackgroundColor(Color.BLACK);
        root.addView(webView,new LinearLayout.LayoutParams(-1,Ui.dp(this,350)));

        ScrollView lowerScroll = new ScrollView(this); lowerScroll.setFillViewport(true);
        LinearLayout lower = new LinearLayout(this); lower.setOrientation(LinearLayout.VERTICAL);
        lower.setPadding(Ui.dp(this,12),Ui.dp(this,10),Ui.dp(this,12),Ui.dp(this,18));
        lowerScroll.addView(lower);

        // 1) Controle operacional imediatamente abaixo da roleta.
        LinearLayout controls = Ui.card(this);
        controls.addView(Ui.text(this,"CONTROLE DE LEITURA",13,Ui.MUTED,true));
        startReadingButton = Ui.button(this,"▶ INICIAR LEITURA",Ui.GREEN,Color.BLACK);
        finishButton = Ui.button(this,"■ FINALIZAR SESSÃO",Ui.SURFACE,Ui.TEXT); finishButton.setEnabled(false);
        newSessionButton = Ui.button(this,"NOVA SESSÃO",Ui.AMBER,Color.BLACK); newSessionButton.setVisibility(View.GONE);
        LinearLayout actionRow = new LinearLayout(this); actionRow.setOrientation(LinearLayout.HORIZONTAL);
        Button clear = Ui.button(this,"↻ LIMPAR",Ui.SURFACE,Ui.TEXT);
        Button correct = Ui.button(this,"✎ CORRIGIR",Ui.SURFACE,Ui.TEXT);
        Button manual = Ui.button(this,"+ GIRO MANUAL",Ui.SURFACE,Ui.TEXT);
        actionRow.addView(clear,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));
        actionRow.addView(correct,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));
        actionRow.addView(manual,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));
        controls.addView(startReadingButton,Ui.margins(-1,Ui.dp(this,52),this,0,8,0,0));
        controls.addView(finishButton,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        controls.addView(newSessionButton,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        controls.addView(actionRow,Ui.margins(-1,Ui.dp(this,46),this,0,6,0,0));
        lower.addView(controls,Ui.margins(-1,-2,this,0,0,0,10));

        // 2) Telemetria verificável.
        LinearLayout statusCard = Ui.card(this);
        LinearLayout statusHeader = new LinearLayout(this); statusHeader.setOrientation(LinearLayout.HORIZONTAL); statusHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView statusTitle = Ui.text(this,"STATUS OPERACIONAL",14,Ui.CYAN,true);
        activityText = Ui.text(this,"AGUARDANDO INÍCIO",11,Ui.MUTED,false); activityText.setGravity(Gravity.RIGHT);
        statusHeader.addView(statusTitle,new LinearLayout.LayoutParams(0,-2,1)); statusHeader.addView(activityText,new LinearLayout.LayoutParams(0,-2,1));
        statusCard.addView(statusHeader);
        pipelineText = Ui.text(this,"CAPTURA — → VALIDAÇÃO — → HISTÓRICO — → CORE — → ANÁLISE —",12,Ui.TEXT,true);
        scannerText = Ui.text(this,"DOM: DISCOVERY\nOCR: STANDBY\nCORE: 0",12,Ui.TEXT,false);
        captureStatusText = Ui.text(this,"OCR • STANDBY",12,Ui.MUTED,false);
        contextText = Ui.text(this,"CONTEXTO: —",11,Ui.MUTED,false);
        statusCard.addView(pipelineText,Ui.margins(-1,-2,this,0,8,0,0));
        statusCard.addView(scannerText,Ui.margins(-1,-2,this,0,6,0,0));
        statusCard.addView(captureStatusText,Ui.margins(-1,-2,this,0,4,0,0));
        statusCard.addView(contextText,Ui.margins(-1,-2,this,0,4,0,0));
        lower.addView(statusCard,Ui.margins(-1,-2,this,0,0,0,10));

        // 3) Radar imediatamente antes do sinal.
        LinearLayout radar = Ui.card(this);
        radar.addView(Ui.text(this,"RADAR DE CONFLUÊNCIA",14,Ui.CYAN,true));
        confluenceBar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        confluenceBar.setMax(FAMILY_COUNT); confluenceBar.setProgress(0);
        confluenceText = Ui.text(this,"LENDO • 0/"+FAMILY_COUNT+" famílias",13,Ui.CYAN,true);
        radar.addView(confluenceBar,Ui.margins(-1,Ui.dp(this,10),this,0,8,0,0));
        radar.addView(confluenceText,Ui.margins(-1,-2,this,0,6,0,0));
        lower.addView(radar,Ui.margins(-1,-2,this,0,0,0,10));

        // 4) Sinal grande e evidente.
        LinearLayout hero = Ui.card(this);
        signalTitle = Ui.text(this,"SINAL • PRECISION",13,Ui.CYAN,true);
        signalTarget = Ui.text(this,"AGUARDANDO INÍCIO",30,Ui.TEXT,true);
        signalMeta = Ui.text(this,"Nenhum resultado entra no CORE antes de iniciar a leitura.",13,Ui.MUTED,false);
        secondaryText = Ui.text(this,"",12,Ui.AMBER,true); secondaryText.setVisibility(View.GONE);
        hero.addView(signalTitle); hero.addView(signalTarget); hero.addView(signalMeta); hero.addView(secondaryText);
        lower.addView(hero,Ui.margins(-1,-2,this,0,0,0,10));

        // 5) Histórico confirmado.
        LinearLayout historyCard=Ui.card(this);
        historyCard.addView(Ui.text(this,"HISTÓRICO CONFIRMADO",13,Ui.MUTED,true));
        historyPreviewText=Ui.text(this,"Últimos: —",12,Ui.TEXT,false);
        historyCard.addView(historyPreviewText,Ui.margins(-1,-2,this,0,6,0,0));
        lower.addView(historyCard,Ui.margins(-1,-2,this,0,0,0,10));

        // 6) Sessão.
        LinearLayout sessionCard=Ui.card(this);
        sessionCard.addView(Ui.text(this,"SESSÃO",14,Ui.AMBER,true));
        sessionText=Ui.text(this,"Sinais 0 • STRIKE 0 • LOSS 0",13,Ui.TEXT,true);
        sessionCard.addView(sessionText,Ui.margins(-1,-2,this,0,6,0,0));
        lower.addView(sessionCard,Ui.margins(-1,-2,this,0,0,0,10));

        // 7) Ferramentas secundárias.
        LinearLayout tools = Ui.card(this);
        tools.addView(Ui.text(this,"FERRAMENTAS / DIAGNÓSTICO",12,Ui.MUTED,true));
        balancedSwitch = new Switch(this); balancedSwitch.setText("Balanced calibrado"); balancedSwitch.setTextColor(Ui.TEXT);
        scanToggle = Ui.button(this,"DOM scanner: ATIVO",Ui.CYAN,Color.BLACK);
        Button visualCaptureButton = Ui.button(this,"Ativar OCR fallback",Ui.GREEN,Color.BLACK);
        Button calibrateButton = Ui.button(this,"Calibrar ROI dos resultados",Ui.AMBER,Color.BLACK);
        Button rayOpen = Ui.button(this,"Abrir Raio-X completo",Ui.SURFACE,Ui.TEXT);
        Button stableTools = Ui.button(this,"Abrir ferramentas Stable",Ui.SURFACE,Ui.TEXT);
        sourceText=Ui.text(this,"FONTE: nenhuma confirmada",11,Ui.MUTED,false);
        rayText=Ui.text(this,"Raio-X aguardando análise.",11,Ui.MUTED,false);
        tools.addView(balancedSwitch); tools.addView(scanToggle,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(visualCaptureButton,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(calibrateButton,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(rayOpen,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(stableTools,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(sourceText,Ui.margins(-1,-2,this,0,6,0,0)); tools.addView(rayText,Ui.margins(-1,-2,this,0,4,0,0));
        lower.addView(tools);

        TextView footer=Ui.text(this,"Aurum Integrated • DOM principal • OCR fallback • CORE preservado",11,Ui.MUTED,true);
        footer.setGravity(Gravity.CENTER); lower.addView(footer,Ui.margins(-1,-2,this,0,14,0,0));
        root.addView(lowerScroll,new LinearLayout.LayoutParams(-1,0,1));

        open.setOnClickListener(v -> openEnteredUrl());
        reload.setOnClickListener(v -> webView.reload());
        startReadingButton.setOnClickListener(v -> startReading());
        finishButton.setOnClickListener(v -> finishSession());
        newSessionButton.setOnClickListener(v -> newSession());
        clear.setOnClickListener(v -> clearOperationalHistory());
        correct.setOnClickListener(v -> showCorrectionDialog());
        manual.setOnClickListener(v -> showNumberDialog("GIRO MANUAL", -1, n -> addManualSpin(n)));
        balancedSwitch.setOnCheckedChangeListener((b,checked) -> { bridge.setPrecision(!checked); signalTitle.setText("SINAL • "+(checked?"BALANCED":"PRECISION")); });
        scanToggle.setOnClickListener(v -> { scannerRunning=!scannerRunning; scanToggle.setText(scannerRunning?"DOM scanner: ATIVO":"DOM scanner: PAUSADO"); if(scannerRunning)discoverPage(); });
        visualCaptureButton.setOnClickListener(v -> requestVisualCapture());
        calibrateButton.setOnClickListener(v -> openCalibration());
        rayOpen.setOnClickListener(v -> showFullRayX());
        stableTools.setOnClickListener(v -> startActivity(new Intent(this,MainActivity.class)));
        return root;
    }

    private void configureWebView() {
        BrowserSecurityPolicy.apply(webView);
        CookieManager cm=CookieManager.getInstance(); cm.setAcceptCookie(true); cm.setAcceptThirdPartyCookies(webView,true);
        webView.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView view,int newProgress){pageProgress.setProgress(newProgress);pageProgress.setVisibility(newProgress>=100?View.GONE:View.VISIBLE);}});
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){Uri u=req.getUrl();if(!BrowserSecurityPolicy.isAllowed(u)){Toast.makeText(IntegratedActivity.this,"Link externo bloqueado.",Toast.LENGTH_SHORT).show();return true;}return false;}
            @Override public void onPageFinished(WebView view,String url){
                if(url==null)return; urlInput.setText(BrowserSecurityPolicy.sanitize(url)); persistLastUrl(url); CookieManager.getInstance().flush();
                String host=hostOf(url); if(!host.equals(currentHost)){currentHost=host;lockedDomSignature=DomSourceMemory.load(IntegratedActivity.this,host);domState=lockedDomSignature.isEmpty()?DomState.DISCOVERY:DomState.LOCKED;domLockFailures=0;domDiscoveryFailures=0;lastDomFingerprint="";lastDomObserved=new ArrayList<>();domOrderTracker.reset();}
                discoverPage();
            }
        });
        String saved=browserPrefs().getString(LAST_URL,"");
        if(saved!=null&&!saved.trim().isEmpty()&&BrowserSecurityPolicy.isAllowed(Uri.parse(saved))){urlInput.setText(BrowserSecurityPolicy.sanitize(saved));webView.loadUrl(saved);}else webView.loadUrl("about:blank");
    }

    private SharedPreferences browserPrefs(){return getSharedPreferences(BROWSER_PREFS,MODE_PRIVATE);}
    private void persistLastUrl(String raw){try{Uri u=Uri.parse(raw);if(!BrowserSecurityPolicy.isAllowed(u)||"about".equalsIgnoreCase(u.getScheme()))return;String safe=BrowserSecurityPolicy.sanitize(raw);if(safe.startsWith("http://")||safe.startsWith("https://"))browserPrefs().edit().putString(LAST_URL,safe).apply();}catch(RuntimeException ignored){}}
    private static String hostOf(String raw){try{String h=Uri.parse(raw).getHost();return h==null?"":h;}catch(RuntimeException e){return "";}}

    private void openEnteredUrl(){String raw=urlInput.getText().toString().trim();if(raw.isEmpty())return;if(!raw.contains("://"))raw="https://"+raw;Uri u=Uri.parse(raw);if(!BrowserSecurityPolicy.isAllowed(u)){Toast.makeText(this,"Use endereço http/https.",Toast.LENGTH_SHORT).show();return;}persistLastUrl(raw);webView.loadUrl(raw);}

    private void startReading(){
        if(readingActive)return;
        if(IntegratedSessionStore.startedAt(this)<=0||IntegratedSessionStore.finished(this))IntegratedSessionStore.startNew(this,webView==null?"":webView.getUrl());
        readingActive=true; scannerRunning=true; startReadingButton.setText("✓ LEITURA ATIVA"); startReadingButton.setEnabled(false); finishButton.setEnabled(true); newSessionButton.setVisibility(View.GONE);
        List<Integer> saved=IntegratedSessionStore.loadOperationalHistory(this);
        if(bridge.historySize()==0&&!saved.isEmpty()){renderBridge(bridge.replaceBootstrap(saved),"SESSÃO RESTAURADA");initialBootstrapPending=false;incrementalSourceMode=true;}
        else if(bridge.historySize()==0&&domState==DomState.TRACKING&&lastDomObserved.size()>=8&&!incrementalSourceMode){renderBridge(bridge.replaceBootstrap(lastDomObserved),"DOM");initialBootstrapPending=false;}
        else if(bridge.historySize()==0&&ocrFallbackEligible()&&lastOcrObserved.size()>=8&&!incrementalSourceMode){renderBridge(bridge.replaceBootstrap(lastOcrObserved),"OCR FALLBACK");initialBootstrapPending=false;}
        refreshTelemetryClock();
    }

    private void finishSession(){
        if(!readingActive&&IntegratedSessionStore.finished(this))return;
        readingActive=false; scannerRunning=false; ocrFallbackActive=false;
        String summary=IntegratedSessionStore.finish(this,bridge.historySize());
        startReadingButton.setText("SESSÃO FINALIZADA"); startReadingButton.setEnabled(false); finishButton.setEnabled(false); newSessionButton.setVisibility(View.VISIBLE);
        Toast.makeText(this,summary,Toast.LENGTH_LONG).show(); refreshSession(); refreshTelemetryClock();
    }

    private void newSession(){
        bridge.clearOperational(); manualEchoReconciler.clear(); lastVerdict=null; IntegratedSessionStore.startNew(this,webView==null?"":webView.getUrl()); IntegratedSessionStore.saveOperationalHistory(this,Collections.emptyList());
        readingActive=false; scannerRunning=true; incrementalSourceMode=true; initialBootstrapPending=false; lastAcceptedSource="—"; lastDataAt=0;
        startReadingButton.setText("▶ INICIAR LEITURA"); startReadingButton.setEnabled(true); finishButton.setEnabled(true); newSessionButton.setVisibility(View.GONE);
        resetSignalUi("AGUARDANDO INÍCIO","Nova sessão criada. O histórico operacional está limpo e somente giros futuros serão adicionados.");
        refreshSession(); refreshTelemetryClock();
    }

    private void clearOperationalHistory(){
        if(!readingActive){Toast.makeText(this,"Inicie a leitura para limpar a sessão operacional.",Toast.LENGTH_SHORT).show();return;}
        renderBridge(bridge.clearOperational(),"CONTROLE"); manualEchoReconciler.clear(); IntegratedSessionStore.saveOperationalHistory(this,Collections.emptyList());
        incrementalSourceMode=true; initialBootstrapPending=false; lastVerdict=null; lastDataAt=0;
        resetSignalUi("SEM SINAL ATIVO","Histórico operacional zerado. A análise recomeça somente com giros novos a partir deste ponto."); refreshSession();
    }

    private void showCorrectionDialog(){
        if(!readingActive){Toast.makeText(this,"Inicie a leitura antes de corrigir giros.",Toast.LENGTH_SHORT).show();return;}
        if(bridge.historySize()==0){Toast.makeText(this,"Histórico vazio.",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(this).setTitle("CORRIGIR GIRO").setItems(new String[]{"Substituir último giro","Remover último giro"},(d,which)->{
            int before=bridge.historySize();
            if(which==0)showNumberDialog("SUBSTITUIR ÚLTIMO GIRO",bridge.historySnapshot().get(0),n->{IntegratedSessionStore.rollbackLatestResolutionIfAtSpin(this,before);renderBridge(bridge.replaceLatest(n),"CORREÇÃO");afterManualOrCorrection();});
            else {IntegratedSessionStore.rollbackLatestResolutionIfAtSpin(this,before);renderBridge(bridge.removeLatest(),"CORREÇÃO");afterManualOrCorrection();}
        }).setNegativeButton("Cancelar",null).show();
    }

    private interface NumberConsumer{void accept(int number);}
    private void showNumberDialog(String title,int current,NumberConsumer consumer){
        EditText input=new EditText(this); input.setInputType(InputType.TYPE_CLASS_NUMBER); input.setHint("0–36"); if(current>=0)input.setText(String.valueOf(current));
        new AlertDialog.Builder(this).setTitle(title).setView(input).setPositiveButton("Confirmar",(d,w)->{try{int n=Integer.parseInt(input.getText().toString().trim());if(n<0||n>36)throw new NumberFormatException();consumer.accept(n);}catch(NumberFormatException e){Toast.makeText(this,"Digite um número de 0 a 36.",Toast.LENGTH_SHORT).show();}}).setNegativeButton("Cancelar",null).show();
    }

    private void addManualSpin(int n){if(!readingActive){Toast.makeText(this,"Inicie a leitura antes de inserir giro manual.",Toast.LENGTH_SHORT).show();return;}manualEchoReconciler.record(n);renderBridge(bridge.prependManual(n),"MANUAL");afterManualOrCorrection();}
    private void afterManualOrCorrection(){incrementalSourceMode=true;initialBootstrapPending=false;IntegratedSessionStore.saveOperationalHistory(this,bridge.historySnapshot());refreshHistoryPreview();refreshSession();}

    @SuppressWarnings("deprecation") private void requestVisualCapture(){MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(manager.createScreenCaptureIntent(),REQUEST_CAPTURE);}
    private void openCalibration(){if(!CaptureRepository.hasLatest()){Toast.makeText(this,"Ative primeiro a captura visual e depois calibre somente o histórico.",Toast.LENGTH_LONG).show();requestVisualCapture();return;}startActivity(new Intent(this,CalibrationActivity.class));}
    private void registerStateReceiver(){IntentFilter filter=new IntentFilter(MainActivity.ACTION_STATE_UPDATED);if(Build.VERSION.SDK_INT>=33)registerReceiver(stateReceiver,filter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(stateReceiver,filter);receiverRegistered=true;}

    private void discoverPage(){
        if(webView==null)return; lastScanAttemptAt=System.currentTimeMillis();scanAttempts++;
        webView.evaluateJavascript(SourceHunter.discoveryScript(lockedDomSignature),value->{
            try{
                JSONObject o=new JSONObject(decodeJsString(value)); JSONArray a=o.optJSONArray("history"); List<Integer> raw=new ArrayList<>(); if(a!=null)for(int i=0;i<a.length();i++)raw.add(a.optInt(i,-1));
                SourceOrderTracker.Order beforeOrder=domOrderTracker.order();
                SourceOrderTracker.Order learnedOrder=domOrderTracker.observe(raw);
                List<Integer> history=normalizer.normalize(domOrderTracker.normalize(raw),true); domHistoryCount=history.size();
                boolean orderJustLearned=beforeOrder==SourceOrderTracker.Order.UNKNOWN&&learnedOrder!=SourceOrderTracker.Order.UNKNOWN; accessibleFrames=o.optInt("accessibleFrames",0);blockedFrames=o.optInt("blockedFrames",0);domConfidence=o.optInt("confidence",0);currentResult=o.optInt("currentResult",-1);domHint=o.optString("hint","");
                String pageUrl=o.optString("url",webView.getUrl());String title=o.optString("title","");String signature=o.optString("signature","");String classification=o.optString("classification","");boolean lockMatched=o.optBoolean("lockMatched",false);int iframes=o.optInt("iframes",0);
                String host=hostOf(pageUrl);if(!host.equals(currentHost)){currentHost=host;lockedDomSignature=DomSourceMemory.load(this,host);domState=lockedDomSignature.isEmpty()?DomState.DISCOVERY:DomState.LOCKED;domLockFailures=0;domDiscoveryFailures=0;lastDomFingerprint="";lastDomObserved=new ArrayList<>();domOrderTracker.reset();}
                parseContext(o.optJSONObject("context"));
                EnvironmentScanner.Snapshot env=environmentScanner.inspect(pageUrl,title,iframes,history.size(),domHint,accessibleFrames,blockedFrames);
                updateDomState(history,signature,classification,lockMatched,host,env.provider);
                renderEnvironment(env);
                if(orderJustLearned&&readingActive&&bridge.historySize()>0&&!incrementalSourceMode&&domState==DomState.TRACKING){lastDomObserved=new ArrayList<>(history);lastDomFingerprint=normalizer.fingerprint(history);renderBridge(bridge.replaceBootstrap(history),"DOM • ORDEM APRENDIDA");initialBootstrapPending=false;}
                else if(domState==DomState.TRACKING&&history.size()>=8)processDomHistory(history);
                else {lastDomObserved=new ArrayList<>(history); lastDomFingerprint=normalizer.fingerprint(history);}
                updateOcrFallbackState(); refreshTelemetryClock();
            }catch(Exception error){domDiscoveryFailures++;if(domDiscoveryFailures>=3&&blockedFrames>0)domState=DomState.BLOCKED;updateOcrFallbackState();refreshTelemetryClock();}
        });
    }

    private void updateDomState(List<Integer> history,String signature,String classification,boolean lockMatched,String host,String provider){
        boolean semantic="HISTORY".equals(classification)&&history.size()>=8;
        if(lockedDomSignature.isEmpty()){
            if(semantic&&domConfidence>=DOM_LOCK_CONFIDENCE&&!signature.isEmpty()){
                lockedDomSignature=signature;DomSourceMemory.save(this,host,provider,signature);domState=DomState.LOCKED;domLockFailures=0;domDiscoveryFailures=0;
            }else{domDiscoveryFailures++;domState=(domDiscoveryFailures>=3&&blockedFrames>0)?DomState.BLOCKED:DomState.DISCOVERY;}
            return;
        }
        if(lockMatched&&semantic&&domConfidence>=DOM_TRACK_CONFIDENCE&&signature.equals(lockedDomSignature)){
            domLockFailures=0;domDiscoveryFailures=0;domState=DomState.TRACKING;evidenceGraph.upsert("dom-history","DOM_HISTORY",domConfidence/100.0,normalizer.fingerprint(history),"current-history");
        }else{
            domLockFailures++;if(domLockFailures>=2){DomSourceMemory.invalidate(this,host,provider);lockedDomSignature="";domState=DomState.DISCOVERY;domLockFailures=0;domDiscoveryFailures=0;lastDomFingerprint="";}
            else domState=DomState.LOCKED;
        }
    }

    private void processDomHistory(List<Integer> history){
        String fingerprint=normalizer.fingerprint(history);List<Integer> previous=new ArrayList<>(lastDomObserved);lastDomObserved=new ArrayList<>(history);
        if(fingerprint.equals(lastDomFingerprint)&&!(readingActive&&initialBootstrapPending&&bridge.historySize()==0))return;lastDomFingerprint=fingerprint;
        if(!readingActive)return;
        ocrFallbackActive=false;
        if(bridge.historySize()==0&&initialBootstrapPending&&!incrementalSourceMode){renderBridge(bridge.replaceBootstrap(history),"DOM");initialBootstrapPending=false;return;}
        if(incrementalSourceMode){SourceDelta.Result d=SourceDelta.between(history,previous);if(d.valid&&!d.newestFirst.isEmpty()){List<Integer> fresh=manualEchoReconciler.suppress(d.newestFirst);if(!fresh.isEmpty())renderBridge(bridge.acceptIncremental(fresh),"DOM");}return;}
        renderBridge(bridge.acceptScan(history),"DOM");
    }

    private void syncFromVisualHistory(){
        List<Integer> visual=AppStateStore.loadHistory(this);ocrHistoryCount=visual.size();List<Integer> previous=new ArrayList<>(lastOcrObserved);lastOcrObserved=new ArrayList<>(visual);String fp=normalizer.fingerprint(visual);updateOcrFallbackState();
        if(!readingActive||!ocrFallbackActive||visual.size()<8){lastOcrFingerprint=fp;refreshSourceLine();refreshHistoryPreview();refreshTelemetryClock();return;}
        if(fp.equals(lastOcrFingerprint)&&!(initialBootstrapPending&&bridge.historySize()==0))return;lastOcrFingerprint=fp;evidenceGraph.upsert("ocr-history","VISUAL_OCR",0.90,fp,"current-history");
        if(bridge.historySize()==0&&initialBootstrapPending&&!incrementalSourceMode){renderBridge(bridge.replaceBootstrap(visual),"OCR FALLBACK");initialBootstrapPending=false;return;}
        if(incrementalSourceMode){SourceDelta.Result d=SourceDelta.between(visual,previous);if(d.valid&&!d.newestFirst.isEmpty()){List<Integer> fresh=manualEchoReconciler.suppress(d.newestFirst);if(!fresh.isEmpty())renderBridge(bridge.acceptIncremental(fresh),"OCR FALLBACK");}return;}
        renderBridge(bridge.acceptScan(visual),"OCR FALLBACK");
    }

    private void updateOcrFallbackState(){ocrFallbackActive=ocrFallbackEligible();refreshCaptureStatus();}
    private boolean ocrFallbackEligible(){boolean domUnavailable=domState!=DomState.TRACKING&&(domState==DomState.BLOCKED||blockedFrames>0||domDiscoveryFailures>=3);return readingActive&&domUnavailable&&AppStateStore.isCalibrated(this)&&ocrHistoryCount>=8;}

    private void renderEnvironment(EnvironmentScanner.Snapshot s){if(s!=null&&!"Não definido".equals(s.provider))AppStateStore.setProvider(this,s.provider);refreshSourceLine();}

    private void renderBridge(IntegratedSignalBridge.Result r,String source){
        if(!r.accepted){signalMeta.setText(source+" • "+r.message+" • histórico preservado");refreshTelemetryClock();return;}
        lastAcceptedSource=source;lastDataAt=System.currentTimeMillis();SignalUpdate u=r.update;lastVerdict=r.verdict;IntegratedSessionStore.saveOperationalHistory(this,r.history);
        if(u!=null){int accent=accent(u.kind);signalTitle.setText("SINAL • "+(bridge.isPrecision()?"PRECISION":"BALANCED"));signalTitle.setTextColor(accent);signalTarget.setText(u.target>=0?(u.playLabel.isEmpty()?u.target+" + VIZINHOS":u.playLabel):u.headline);String score=lastVerdict==null?"—":String.valueOf(lastVerdict.aurumScore);String families=lastVerdict==null?"0":String.valueOf(lastVerdict.independentFamilies);signalMeta.setText("Fonte "+source+" • score interno "+score+"/100 • "+families+" famílias • "+r.message+" • "+r.history.size()+" giros");
            if(u.secondaryTarget>=0&&!u.secondaryCoverage.isEmpty()){secondaryText.setVisibility(View.VISIBLE);secondaryText.setText("SECONDARY • "+u.secondaryPlayLabel+" • score "+u.secondaryStrength);}else secondaryText.setVisibility(View.GONE);
            updateConfluence(lastVerdict);renderRayX(lastVerdict,u);trackSessionOutcome(u,r.history.size());}
        refreshHistoryPreview();refreshSession();refreshTelemetryClock();
    }

    private void trackSessionOutcome(SignalUpdate u,int coreSize){if(u==null)return;if(u.kind==SignalUpdate.Kind.ENTRY)IntegratedSessionStore.recordSignal(this);else if(u.kind==SignalUpdate.Kind.HIT||u.kind==SignalUpdate.Kind.SECONDARY_HIT)IntegratedSessionStore.recordStrike(this,coreSize);else if(u.kind==SignalUpdate.Kind.EXPIRED)IntegratedSessionStore.recordLoss(this,coreSize);}

    private void updateConfluence(ConfluenceVerdict v){
        if(v==null){confluenceBar.setProgress(0);confluenceText.setText("LENDO • 0/"+FAMILY_COUNT+" famílias");confluenceText.setTextColor(Ui.CYAN);return;}int families=Math.min(FAMILY_COUNT,v.independentFamilies);confluenceBar.setProgress(families);String phase;int color;
        switch(v.decision){case ENTRY:phase="SINAL";color=Ui.GREEN;break;case PREPARE:phase="PREPARAR";color=Ui.AMBER;break;case OBSERVE:phase="CONFLUÊNCIA";color=Ui.AMBER;break;default:phase="LENDO";color=Ui.CYAN;break;}confluenceText.setText(phase+" • "+families+"/"+FAMILY_COUNT+" famílias alinhadas");confluenceText.setTextColor(color);
    }

    private void refreshHistoryPreview(){List<Integer> h=bridge.historySnapshot();if(h.isEmpty()){historyPreviewText.setText("Últimos: —");return;}StringBuilder b=new StringBuilder("Últimos: ");int n=Math.min(12,h.size());for(int i=0;i<n;i++){if(i>0)b.append(" • ");b.append(h.get(i));}historyPreviewText.setText(b.toString());}

    private void refreshTelemetryClock(){
        long now=System.currentTimeMillis();String age=lastDataAt<=0?"—":String.format(Locale.US,"%.1fs",(now-lastDataAt)/1000.0);String domLabel=domState.name();String ocr=ocrFallbackActive?"FALLBACK ATIVO":"STANDBY";int last=bridge.historySnapshot().isEmpty()?-1:bridge.historySnapshot().get(0);
        if(!readingActive){liveBadge.setText(IntegratedSessionStore.finished(this)?"● SESSÃO FINALIZADA":"● AGUARDANDO INÍCIO");liveBadge.setTextColor(Ui.AMBER);activityText.setText("AGUARDANDO INÍCIO");pipelineText.setText("CAPTURA "+(domState==DomState.TRACKING?"✓":"…")+" → VALIDAÇÃO "+(domState==DomState.TRACKING?"✓":"…")+" → HISTÓRICO BLOQUEADO → CORE "+bridge.historySize()+" → ANÁLISE EM ESPERA");}
        else{liveBadge.setText("● LEITURA ATIVA");liveBadge.setTextColor(Ui.GREEN);activityText.setText("última atualização "+age);boolean cap=domState==DomState.TRACKING||ocrFallbackActive;pipelineText.setText("CAPTURA "+(cap?"✓":"…")+" → VALIDAÇÃO "+(cap?"✓":"…")+" → HISTÓRICO "+(bridge.historySize()>0?"✓":"…")+" → CORE "+bridge.historySize()+" → ANÁLISE "+(bridge.historySize()>0?"✓":"…"));}
        scannerText.setText("DOM: "+domLabel+(domConfidence>0?" • confidence "+domConfidence+"%":"")+" • ordem "+domOrderTracker.order()+"\nOCR: "+ocr+"\nCORE: "+bridge.historySize()+"\nÚLTIMO GIRO: "+(last>=0?last+" ✓":"—")+"\nÚLTIMA ATUALIZAÇÃO: "+age+"\nHISTÓRICO IDENTIFICADO: "+(domState==DomState.TRACKING?"✓":"—"));
        contextText.setText("CONTEXTO: "+tableContext+(currentResult>=0?" • resultado destacado "+currentResult:""));refreshSourceLine();refreshSession();
    }

    private void refreshSourceLine(){sourceText.setText("Fonte aceita: "+lastAcceptedSource+" • DOM "+domState.name()+" • confidence "+domConfidence+"% • OCR "+(ocrFallbackActive?"FALLBACK":"STANDBY")+" • varreduras "+scanAttempts+(blockedFrames>0?" • iframe bloqueado "+blockedFrames:""));}

    private void refreshCaptureStatus(){if(ocrFallbackActive){captureStatusText.setText("DOM BLOQUEADO/INDISPONÍVEL → OCR FALLBACK • ROI calibrada");captureStatusText.setTextColor(Ui.AMBER);}else if(AppStateStore.isCalibrated(this)){captureStatusText.setText("OCR: STANDBY • ROI calibrada • DOM tem prioridade");captureStatusText.setTextColor(Ui.MUTED);}else{captureStatusText.setText("OCR: STANDBY • ROI ainda não calibrada");captureStatusText.setTextColor(Ui.MUTED);}}

    private void parseContext(JSONObject c){if(c==null){tableContext="—";return;}List<String> parts=new ArrayList<>();if(c.optInt("race",0)>0)parts.add("racetrack reconhecida");if(c.optInt("timeline",0)>0)parts.add("timeline");if(c.optInt("stats",0)>0)parts.add("estatísticas");if(c.optInt("current",0)>0)parts.add("resultado atual");if(c.optInt("bet",0)>0)parts.add("tabela de apostas isolada");if(c.optInt("balance",0)>0)parts.add("saldo isolado");tableContext=parts.isEmpty()?"sem contexto auxiliar confirmado":join(parts," • ");}
    private static String join(List<String> xs,String sep){StringBuilder b=new StringBuilder();for(String x:xs){if(b.length()>0)b.append(sep);b.append(x);}return b.toString();}

    private void renderRayX(ConfluenceVerdict v,SignalUpdate u){if(v==null){rayText.setText("Aguardando dados suficientes para leitura profunda.");return;}String mode=bridge.isPrecision()?"Precision":"Balanced";rayText.setText("GATE • "+mode+" • "+v.decision+" • famílias "+v.independentFamilies+"/"+FAMILY_COUNT+" • regime "+v.spatialRegime+" • "+v.signalShape);}
    private void showFullRayX(){if(lastVerdict==null){Toast.makeText(this,"Raio-X ainda sem veredito.",Toast.LENGTH_SHORT).show();return;}StringBuilder b=new StringBuilder();ConfluenceVerdict v=lastVerdict;b.append("FONTE: ").append(lastAcceptedSource).append("\nDECISÃO: ").append(v.decision).append("\nALVO: ").append(v.target).append("\nAURUM SCORE: ").append(v.aurumScore).append("/100\nFAMÍLIAS: ").append(v.independentFamilies).append('/').append(FAMILY_COUNT).append("\nREGIME: ").append(v.spatialRegime).append("\nSHAPE: ").append(v.signalShape).append("\n\nFAMÍLIAS ALINHADAS:\n");for(EvidenceFamily f:v.supportingFamilies)b.append("• ").append(f.name()).append('\n');b.append("\nRAZÕES:\n");for(String s:v.reasons)b.append("• ").append(s).append('\n');TextView t=Ui.text(this,b.toString(),13,Ui.TEXT,false);t.setPadding(Ui.dp(this,16),Ui.dp(this,10),Ui.dp(this,16),Ui.dp(this,20));ScrollView sv=new ScrollView(this);sv.setBackgroundColor(Ui.BG);sv.addView(t);new AlertDialog.Builder(this).setTitle("RAIO-X • INTEGRATED").setView(sv).setPositiveButton("Fechar",null).show();}

    private void refreshSession(){long start=IntegratedSessionStore.startedAt(this);long end=IntegratedSessionStore.endedAt(this);long stop=end>0?end:System.currentTimeMillis();long mins=start<=0?0:Math.max(0,(stop-start)/60000L);sessionText.setText("Sinais "+IntegratedSessionStore.signals(this)+" • STRIKE "+IntegratedSessionStore.strikes(this)+" • LOSS "+IntegratedSessionStore.losses(this)+" • "+bridge.historySize()+" giros • "+mins+" min");}

    private void resetSignalUi(String target,String meta){signalTitle.setText("SINAL • "+(bridge.isPrecision()?"PRECISION":"BALANCED"));signalTitle.setTextColor(Ui.CYAN);signalTarget.setText(target);signalMeta.setText(meta);secondaryText.setVisibility(View.GONE);updateConfluence(null);refreshHistoryPreview();}

    private static String decodeJsString(String value)throws Exception{if(value==null||"null".equals(value))return "{}";if(value.startsWith("\"")&&value.endsWith("\""))return new JSONArray("["+value+"]").getString(0);return value;}
    private static int accent(SignalUpdate.Kind k){if(k==SignalUpdate.Kind.ENTRY||k==SignalUpdate.Kind.ACTIVE||k==SignalUpdate.Kind.HIT||k==SignalUpdate.Kind.SECONDARY_HIT)return Ui.GREEN;if(k==SignalUpdate.Kind.PREPARE||k==SignalUpdate.Kind.OBSERVE||k==SignalUpdate.Kind.BUILDING)return Ui.AMBER;if(k==SignalUpdate.Kind.INVALIDATED||k==SignalUpdate.Kind.EXPIRED)return Ui.RED;return Ui.CYAN;}
}
