package com.xspaceart.radar30;

import android.graphics.Bitmap;

public final class CaptureRepository {
    private static Bitmap latest;

    private CaptureRepository() {}

    public static synchronized void setLatest(Bitmap bitmap) {
        Bitmap previous = latest;
        latest = bitmap;
        if (previous != null && previous != bitmap && !previous.isRecycled()) previous.recycle();
    }

    public static synchronized Bitmap getLatestCopy() {
        if (latest == null || latest.isRecycled()) return null;
        return latest.copy(Bitmap.Config.ARGB_8888, false);
    }

    public static synchronized boolean hasLatest() {
        return latest != null && !latest.isRecycled();
    }

    public static synchronized void clear() {
        if (latest != null && !latest.isRecycled()) latest.recycle();
        latest = null;
    }
}
