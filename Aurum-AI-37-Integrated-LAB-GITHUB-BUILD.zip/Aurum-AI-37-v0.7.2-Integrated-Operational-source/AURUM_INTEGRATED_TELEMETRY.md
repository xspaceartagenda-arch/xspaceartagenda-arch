# Aurum Integrated Operational Telemetry — v0.7.2

- DOM é a fonte principal e opera em DISCOVERY → LOCKED → TRACKING.
- Regiões da página são classificadas semanticamente antes de qualquer 0–36 ser aceito.
- Histórico confirmado é separado de racetrack, timeline, estatísticas, saldo, controles e tabela de apostas.
- OCR permanece STANDBY enquanto DOM está válida; assume somente como fallback com ROI calibrada.
- SourceDelta impede snapshot velho de repovoar o CORE após limpar/corrigir/manual.
- Telemetria mostra DOM confidence, OCR state, CORE, último giro, idade do dado e pipeline.
- Radar de confluência fica imediatamente antes do Signal Hero.
- Sessão registra sinais, STRIKE e LOSS sem contar Secondary + Primary duas vezes.
- Última URL e cookies/WebView storage são preservados; login/senha não é salvo em texto puro.
- CORE estratégico permanece byte a byte idêntico à v0.7.1 Integrated Telemetry.
