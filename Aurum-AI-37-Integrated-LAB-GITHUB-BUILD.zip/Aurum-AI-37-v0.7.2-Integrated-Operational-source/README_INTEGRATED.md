# Aurum AI 37 — Integrated Operational v0.7.2

Continuação direta da v0.7.1 Integrated Telemetry.

A v0.7.2 adiciona controle explícito de leitura, Semantic DOM Intelligence com lock/tracking, memória estrutural, OCR somente como fallback, telemetria verificável, Radar imediatamente antes do Signal Hero, histórico corrigível/manual e placar de sessão STRIKE/LOSS.

O CORE estratégico v0.6.3 permanece preservado byte a byte.

Consulte `AURUM_CHECKPOINT.md` antes de qualquer nova alteração.
