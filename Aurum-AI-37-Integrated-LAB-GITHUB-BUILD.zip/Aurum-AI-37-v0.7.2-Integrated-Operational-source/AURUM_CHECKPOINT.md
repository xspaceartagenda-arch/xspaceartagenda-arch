# AURUM AI 37 — CHECKPOINT AUTORITATIVO

Atualizado em: 2026-08-27 — America/Sao_Paulo

## 1. Base oficial confirmada

- Base de continuidade: **Aurum AI 37 v0.7.1 Integrated Telemetry**.
- Artefato físico conhecido como funcional no Samsung: `Aurum-AI-37-v0.7.1-STABLE.apk`.
- A v0.7.1 abre fisicamente no Samsung e abre a roleta no WebView, conforme checkpoint operacional fornecido pelo operador.
- Linha de atualização instalada: `com.xspaceart.aurumai37.integratedlab.debug` (build debug da Integrated).
- v0.7.1: `versionCode 2`, `versionName 0.7.1-integrated-telemetry-debug`.
- Certificado SHA-256 da v0.7.1 STABLE:
  `663a96b89181b13c759512229e465ebc895136545f36d1cbd29f7d7e1ad561c4`.
- A keystore de continuidade foi comparada com o APK v0.7.1 e possui o mesmo certificado SHA-256.
- **Não trocar applicationId, suffix `.debug`, alias ou keystore nas próximas builds destinadas a atualização por cima.**

## 2. Próxima versão preparada

- Nome: **Aurum AI 37 v0.7.2 Integrated Operational**.
- `applicationId` base: `com.xspaceart.aurumai37.integratedlab`.
- build instalada/atualizável: `com.xspaceart.aurumai37.integratedlab.debug`.
- `versionCode 3`.
- `versionName 0.7.2-integrated-operational` (`-debug` no APK do workflow).
- CORE estratégico: **preservado byte a byte — 17/17 hashes PASS**.

## 3. IMPLEMENTADO

### Controle de leitura

- Estado inicial `AGUARDANDO INÍCIO`.
- `▶ INICIAR LEITURA`: antes do toque, DOM/OCR podem diagnosticar a página, mas nenhum resultado novo entra no CORE.
- `■ FINALIZAR SESSÃO`: desativa leitura, congela o histórico operacional e salva resumo.
- `NOVA SESSÃO`: cria sessão independente com histórico operacional limpo.
- `↻ LIMPAR`: zera somente o histórico operacional e coloca a captura em modo incremental, impedindo o snapshot antigo da página de repovoar o CORE.
- `✎ CORRIGIR`: permite substituir ou remover o último giro e reconstrói o estado da bridge/core a partir do histórico corrigido.
- `+ GIRO MANUAL`: insere 0–36 como fallback e mantém os snapshots automáticos em modo incremental para não apagar o giro manual.

### Semantic DOM Intelligence

- DOM é a fonte principal.
- O scanner não aceita números 0–36 apenas por existirem na página.
- Classificações implementadas: `HISTORY`, `CURRENT_RESULT`, `RACETRACK`, `TIMELINE`, `STATISTICS`, `BETTING_TABLE`, `BALANCE_VALUES`, `CONTROLS`, `IGNORE`.
- Metadados usados: id, class, aria-label, data-testid, data-number, data-value, data-name, data-type, role, title, pai, shadow DOM aberto e iframe same-origin.
- Contextos negativos como racetrack, estatísticas, saldo, apostas, timer e controles não podem ser escolhidos como histórico.
- Bug encontrado em teste e corrigido: números de dois dígitos no JavaScript eram reduzidos ao primeiro dígito; agora `23`, `31`, `35` etc. permanecem íntegros.

### DOM DISCOVERY → LOCKED → TRACKING

- `DISCOVERY`: procura somente candidatos semânticos a histórico.
- `LOCKED`: grava a assinatura estrutural quando a confiança passa a régua.
- `TRACKING`: aceita somente a mesma assinatura validada e processa mudanças incrementais.
- Duas falhas consecutivas da assinatura invalidam o lock e retornam para `DISCOVERY`.
- Assinaturas são persistidas localmente por host/provedor; nunca contêm senha/login.

### Separação histórico x contexto

- Somente histórico confirmado alimenta `IntegratedSignalBridge`/CORE.
- Resultado atual destacado, racetrack, timeline, estatísticas, tabela de apostas e saldo ficam em contexto/telemetria e não viram giros.

### OCR fallback

- OCR fica `STANDBY` quando DOM está `TRACKING`.
- OCR só pode assumir quando DOM está bloqueado/indisponível, existe ROI calibrada e há histórico visual suficiente.
- DOM e OCR não alimentam o CORE simultaneamente.
- Após limpar/corrigir/manual, a camada `SourceDelta` aceita apenas o prefixo temporal realmente novo da fonte.

### Telemetria

- Estados visíveis: leitura ativa/aguardando, DOM state, DOM confidence, OCR standby/fallback, CORE, último giro, idade da última atualização e histórico identificado.
- Pipeline visual: `CAPTURA → VALIDAÇÃO → HISTÓRICO → CORE → ANÁLISE`.
- Contexto auxiliar reconhecido é exibido separadamente.

### Radar e sinal

- Ordem visual: WebView → controles → telemetria → **RADAR DE CONFLUÊNCIA** → **SINAL** → histórico → sessão.
- Barra do radar usa quantidade de famílias independentes; não é porcentagem de acerto.
- Precision/Balanced, Dual Target, Raio-X, Shadow, Missed Opportunity, change point e motor de confluência não foram alterados.

### Sessão

- Placar persistido: sinais, STRIKE, LOSS, giros e tempo.
- ENTRY abre um sinal no placar.
- HIT ou SECONDARY_HIT resolve o sinal como STRIKE uma única vez.
- EXPIRED resolve como LOSS somente se o mesmo sinal ainda não tiver sido resolvido como STRIKE.
- Correção do giro que acabou de resolver um sinal possui rollback do último desfecho antes da reconstrução.
- Histórico operacional da sessão é persistido localmente.

### URL/login

- Última URL http/https válida é persistida e reaberta automaticamente.
- Query, fragmento e user-info são removidos da URL persistida para não gravar credenciais/tokens em texto puro.
- `CookieManager`, cookies de terceiros e DOM storage permanecem habilitados; cookies são `flush()` no pause/page finished.
- Nenhuma senha de login é armazenada pelo código da Integrated.

## 4. TESTES EXECUTADOS E APROVADOS NESTE AMBIENTE

- `CORE_PRESERVATION`: **PASS 17/17**.
- `PrecisionCoreTest`: **PASS**.
- `DualTargetCoreTest`: **PASS A–H**.
- `V063BalancedCalibrationTest`: **PASS** (`precision=0`, `balanced=5`, vetor conhecido).
- `IntegratedOperationalTest`: **PASS** para bootstrap, novo giro, manual, substituir, remover, limpar, ignorar snapshot antigo e aceitar somente giro futuro.
- `SourceOrderTrackerTest`: **PASS**; aprende automaticamente `NEWEST_FIRST` e `OLDEST_FIRST` pela sequência temporal.
- `ManualEchoReconcilerTest`: **PASS**; giro manual reproduzido depois pela DOM/OCR é suprimido como eco sem remover um giro automático diferente.
- Compilação estática da `IntegratedActivity` contra stubs Android/API usados: **PASS**.
- Sintaxe do JavaScript `SourceHunter`: **PASS** via Node.
- Filtro DOM sintético: **PASS**; histórico correto escolhido, estatística/tabela/saldo isolados, confiança 95.
- DOM lock sintético: **PASS**; assinatura reencontrada e novo giro incremental identificado.
- Certificado da keystore de continuidade = certificado do APK v0.7.1 STABLE: **PASS**.

## 5. COMPILAÇÃO ANDROID — ESTADO REAL

**NÃO CLASSIFICAR COMO COMPILADO AINDA.**

Tentativa local:

```text
./gradlew --no-daemon --version
→ tenta baixar https://services.gradle.org/distributions/gradle-8.9-bin.zip
→ java.net.UnknownHostException: services.gradle.org
```

O ambiente atual não possui Gradle 8.9 nem Android SDK 35 local e não consegue baixar a distribuição. Portanto:

- IMPLEMENTADO: **SIM**.
- TESTES JAVA/HOST: **PASS**.
- CORE PRESERVADO: **PASS**.
- ASSINATURA DE CONTINUIDADE VALIDADA: **PASS**.
- COMPILADO ANDROID: **PENDENTE GitHub Actions**.
- APK v0.7.2: **NÃO GERADO NESTE AMBIENTE**.
- INSTALADO NO S25 FE: **NÃO**.
- TESTADO FISICAMENTE: **NÃO**.

## 6. Workflow GitHub preparado

`build-integrated.yml` foi atualizado para:

1. instalar SDK 35/build-tools 35.0.0;
2. extrair `Aurum-AI-37-Integrated-LAB-GITHUB-BUILD.zip`;
3. verificar os 17 hashes do CORE;
4. executar testes Precision, Dual Target, Balanced e Integrated Operational;
5. executar `assembleDebug` assinado com a identidade estável;
6. auditar package `com.xspaceart.aurumai37.integratedlab.debug`;
7. auditar `versionCode 3` e `versionName 0.7.2-integrated-operational-debug`;
8. comparar o certificado com a identidade da v0.7.1 STABLE;
9. verificar zipalign 16 KiB e integridade ZIP;
10. publicar APK + BADGING + SIGNATURE + SHA256 + BUILD_STATUS.

## 7. Git

A árvore materializada desta continuidade **não possui diretório `.git`**. `git status`/`git diff` não estão disponíveis localmente. O pacote GitHub contém somente a árvore de fonte/workflow e deve ser versionado no repositório externo do operador.

## 8. Arquivos alterados/adicionados

Principais:

- `app/build.gradle`
- `app/src/main/java/com/xspaceart/radar30/integrated/IntegratedActivity.java`
- `app/src/main/java/com/xspaceart/radar30/integrated/IntegratedSignalBridge.java`
- `app/src/main/java/com/xspaceart/radar30/integrated/BrowserSecurityPolicy.java`
- `app/src/main/java/com/xspaceart/radar30/integrated/scanner/SourceHunter.java`
- `app/src/main/java/com/xspaceart/radar30/integrated/scanner/DomSourceMemory.java` (novo)
- `app/src/main/java/com/xspaceart/radar30/integrated/normalize/SourceDelta.java` (novo)
- `app/src/main/java/com/xspaceart/radar30/integrated/normalize/SourceOrderTracker.java` (novo)
- `app/src/main/java/com/xspaceart/radar30/integrated/normalize/ManualEchoReconciler.java` (novo)
- `app/src/main/java/com/xspaceart/radar30/integrated/session/IntegratedSessionStore.java`
- `tools/IntegratedOperationalTest.java` (novo)
- `tools/SourceOrderTrackerTest.java` (novo)
- `tools/ManualEchoReconcilerTest.java` (novo)
- `build-integrated.yml`
- `AURUM_CHECKPOINT.md`
- `AURUM_INTEGRATED_CHECKPOINT.md`
- `INTEGRATED_PREFLIGHT_REPORT.md`

Nenhum arquivo em `app/src/main/java/com/xspaceart/radar30/core/` foi alterado.

## 9. Próxima tarefa EXATA

1. Colocar o BUILD ZIP no workflow GitHub existente com o nome esperado.
2. Executar `Build Aurum Integrated Operational`.
3. Só se `BUILD_STATUS.txt` mostrar `COMPILED=PASS`, baixar o APK v0.7.2.
4. No Samsung S25 FE, **não desinstalar** a v0.7.1 e **não limpar dados**.
5. Instalar a v0.7.2 como atualização por cima.
6. Confirmar startup, WebView e login/cookies preservados.
7. Antes de tocar `INICIAR LEITURA`, confirmar `CORE 0`/sem entrada nova.
8. Tocar `INICIAR LEITURA` e validar DOM `DISCOVERY → LOCKED → TRACKING` na roleta real.
9. Comparar histórico mostrado com 10–20 giros reais, incluindo números de dois dígitos.
10. Validar que racetrack, saldo, estatísticas e tabela não viram giros.
11. Testar `LIMPAR`, `CORRIGIR`, `GIRO MANUAL` e confirmar ausência de duplicação.
12. Testar OCR somente em cenário de DOM bloqueada e confirmar `DOM BLOQUEADO → OCR FALLBACK`.
13. Confirmar placar de sinais/STRIKE/LOSS com pelo menos um ciclo completo.
14. Finalizar sessão, criar `NOVA SESSÃO` e confirmar histórico operacional limpo.
15. Atualizar este checkpoint com o resultado físico.

**A v0.7.2 só poderá ser declarada validada após essa etapa física no Samsung.**
