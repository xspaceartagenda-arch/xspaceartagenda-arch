package com.xspaceart.radar30.integrated.pipeline;

/**
 * Arbitra a fonte operacional sem tocar no motor estratégico.
 * A fonte ativa é sticky: só muda quando perde saúde por tempo suficiente.
 */
public final class ReadingPipelineController {
    public enum Phase { IDLE, BOOTSTRAP, TRACKING, RECOVERING, FINISHED }
    public enum Source { NONE, DOM, OCR }

    public static final long HEALTH_STALE_MS = 5_500L;
    public static final int MIN_HISTORY = 8;

    private Phase phase = Phase.IDLE;
    private Source activeSource = Source.NONE;
    private long domHealthyAt;
    private long ocrHealthyAt;
    private int domCount;
    private int ocrCount;
    private long startedAt;
    private long lastSwitchAt;
    private int sourceSwitches;
    private int recoveries;

    public void start(long now) {
        startedAt = now;
        phase = Phase.BOOTSTRAP;
        activeSource = Source.NONE;
        lastSwitchAt = now;
        sourceSwitches = 0;
        recoveries = 0;
    }

    public void finish() {
        phase = Phase.FINISHED;
        activeSource = Source.NONE;
    }

    public void idle() {
        phase = Phase.IDLE;
        activeSource = Source.NONE;
    }

    public void resetToBootstrap(long now) {
        phase = Phase.BOOTSTRAP;
        activeSource = Source.NONE;
        startedAt = now;
        lastSwitchAt = now;
    }

    public void observeDom(boolean healthy, int count, long now) {
        domCount = Math.max(0, count);
        if (healthy && count >= MIN_HISTORY) domHealthyAt = now;
    }

    public void observeOcr(boolean healthy, int count, long now) {
        ocrCount = Math.max(0, count);
        if (healthy && count >= MIN_HISTORY) ocrHealthyAt = now;
    }

    public Source chooseBootstrap(long now) {
        boolean dom = domHealthy(now);
        boolean ocr = ocrHealthy(now);
        if (!dom && !ocr) return Source.NONE;
        if (dom && !ocr) return Source.DOM;
        if (ocr && !dom) return Source.OCR;

        // Em WebViews de cassino a DOM pode continuar "viva" mesmo quando o widget real
        // deixa de expor o histórico. Quando a captura visual já está estável, ela é a
        // fonte operacional preferida em empate/quase empate; a DOM continua disponível
        // como contexto e failover. Uma DOM claramente mais completa ainda pode vencer.
        return domCount > ocrCount + 2 ? Source.DOM : Source.OCR;
    }

    public void confirmBootstrap(Source source, long now) {
        confirmSource(source, now);
    }

    /** Confirma uma fonte somente depois que o snapshot foi reconciliado com o CORE. */
    public void confirmSource(Source source, long now) {
        if (source == null || source == Source.NONE) return;
        if (activeSource != Source.NONE && activeSource != source) sourceSwitches++;
        activeSource = source;
        phase = Phase.TRACKING;
        lastSwitchAt = now;
    }

    /**
     * Retorna a fonte que deve assumir agora. NONE significa manter/aguardar.
     */
    public Source watchdog(long now) {
        if (phase == Phase.IDLE || phase == Phase.FINISHED) return Source.NONE;
        if (phase == Phase.BOOTSTRAP) return chooseBootstrap(now);

        if (activeSource == Source.DOM) {
            if (domHealthy(now)) {
                phase = Phase.TRACKING;
                return Source.NONE;
            }
            enterRecovery();
            return ocrHealthy(now) ? Source.OCR : Source.NONE;
        }

        if (activeSource == Source.OCR) {
            if (ocrHealthy(now)) {
                phase = Phase.TRACKING;
                return Source.NONE;
            }
            enterRecovery();
            return domHealthy(now) ? Source.DOM : Source.NONE;
        }

        Source candidate = chooseBootstrap(now);
        if (candidate != Source.NONE) return candidate;
        enterRecovery();
        return Source.NONE;
    }

    public boolean domHealthy(long now) {
        return domCount >= MIN_HISTORY && domHealthyAt > 0 && now - domHealthyAt <= HEALTH_STALE_MS;
    }

    public boolean ocrHealthy(long now) {
        return ocrCount >= MIN_HISTORY && ocrHealthyAt > 0 && now - ocrHealthyAt <= HEALTH_STALE_MS;
    }

    public Phase phase() { return phase; }
    public Source activeSource() { return activeSource; }
    public long domHealthyAt() { return domHealthyAt; }
    public long ocrHealthyAt() { return ocrHealthyAt; }
    public int domCount() { return domCount; }
    public int ocrCount() { return ocrCount; }
    public long startedAt() { return startedAt; }
    public long lastSwitchAt() { return lastSwitchAt; }
    public int sourceSwitches() { return sourceSwitches; }
    public int recoveries() { return recoveries; }

    private void enterRecovery() {
        if (phase != Phase.RECOVERING) recoveries++;
        phase = Phase.RECOVERING;
    }
}
