package com.xspaceart.radar30.lock;

/** Classifica a curva estrutural depois do Q; não produz evidência nem altera o Q. */
public final class StructuralRegimeDetector {
    private StructuralRegimeDetector() {}

    public static AurumLockSnapshot.Regime detect(int q,
                                                   int previousQ,
                                                   int recentPeakQ,
                                                   int target,
                                                   int previousTarget,
                                                   int stableTargetUpdates,
                                                   int independentFamilies,
                                                   int margin,
                                                   int qTrend,
                                                   int concentrationQ,
                                                   int convergenceQ,
                                                   int peakQ) {
        if (target < 0 || q < Math.max(20, concentrationQ - 16)) {
            return AurumLockSnapshot.Regime.DISPERSION;
        }

        boolean exceptional = q >= peakQ && independentFamilies >= 3 && margin >= 9;
        if (exceptional) return AurumLockSnapshot.Regime.PEAK;

        boolean changed = previousTarget >= 0 && target != previousTarget;
        if (changed && q < peakQ) return AurumLockSnapshot.Regime.TRANSITION;

        boolean decaying = previousQ - q >= 8
                || (recentPeakQ - q >= 12 && qTrend <= -4);
        if (decaying) return AurumLockSnapshot.Regime.DECAY;

        boolean saturated = stableTargetUpdates >= 6
                && recentPeakQ >= 78
                && q <= recentPeakQ
                && qTrend <= 1;
        if (saturated) return AurumLockSnapshot.Regime.SATURATION;

        if (q >= convergenceQ && independentFamilies >= 3 && margin >= 5) {
            return AurumLockSnapshot.Regime.CONVERGENCE;
        }
        if (q >= concentrationQ && independentFamilies >= 2) {
            return AurumLockSnapshot.Regime.CONCENTRATION;
        }
        return AurumLockSnapshot.Regime.DISPERSION;
    }
}
