package com.xspaceart.radar30.lock;

/** Decisão final simples: gate + audit + Q + Readiness + ausência de veto. */
public final class AurumLockPolicy {
    private AurumLockPolicy() {}

    public static AurumLockSnapshot apply(AurumLockSnapshot input,
                                          AurumLockConfig config,
                                          boolean publicationAllowed) {
        AurumLockSnapshot.Builder out = input.toBuilder()
                .lockMode(AurumLockSnapshot.LockMode.NONE);

        if (!input.dataQualityValid) {
            return out.readinessState(AurumLockSnapshot.ReadinessState.INVALIDATED).build();
        }
        if (input.target < 0 || input.q < 40) {
            return out.readinessState(AurumLockSnapshot.ReadinessState.IDLE).build();
        }
        if (input.regime == AurumLockSnapshot.Regime.DECAY) {
            return out.readinessState(AurumLockSnapshot.ReadinessState.DECAY).build();
        }
        if (input.regime == AurumLockSnapshot.Regime.SATURATION) {
            return out.readinessState(AurumLockSnapshot.ReadinessState.SATURATED).build();
        }
        if (input.regime == AurumLockSnapshot.Regime.TRANSITION) {
            return out.readinessState(AurumLockSnapshot.ReadinessState.FORMING).build();
        }

        boolean diverse = input.independentFamilies >= config.minimumIndependentFamilies;
        boolean armed = input.fastAuditPassed && diverse
                && input.q >= config.confirmedQ
                && input.readiness >= config.armedReadiness;

        if (publicationAllowed && armed
                && input.q >= config.instantQ
                && (input.regime == AurumLockSnapshot.Regime.PEAK
                || input.regime == AurumLockSnapshot.Regime.CONVERGENCE)) {
            return out.readinessState(AurumLockSnapshot.ReadinessState.LOCKED)
                    .lockMode(AurumLockSnapshot.LockMode.INSTANT_LOCK).build();
        }

        if (publicationAllowed && armed
                && input.stableTargetUpdates >= 2
                && (input.regime == AurumLockSnapshot.Regime.CONVERGENCE
                || input.regime == AurumLockSnapshot.Regime.PEAK
                || input.regime == AurumLockSnapshot.Regime.CONCENTRATION)) {
            return out.readinessState(AurumLockSnapshot.ReadinessState.LOCKED)
                    .lockMode(AurumLockSnapshot.LockMode.CONFIRMED_LOCK).build();
        }

        if (armed) return out.readinessState(AurumLockSnapshot.ReadinessState.ARMED).build();
        if (input.q >= config.preLockQ && input.readiness >= config.preLockQ) {
            return out.readinessState(AurumLockSnapshot.ReadinessState.PRE_LOCK).build();
        }
        return out.readinessState(AurumLockSnapshot.ReadinessState.FORMING).build();
    }
}
