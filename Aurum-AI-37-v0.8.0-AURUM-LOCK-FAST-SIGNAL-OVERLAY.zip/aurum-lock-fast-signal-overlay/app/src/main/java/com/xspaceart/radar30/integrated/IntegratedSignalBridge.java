package com.xspaceart.radar30.integrated;

import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.ScanSynchronizer;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.lock.AurumLockSession;
import com.xspaceart.radar30.lock.AurumLockSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Ponte fina: a camada operacional reconcilia fontes, mas o cérebro permanece o core existente. */
public final class IntegratedSignalBridge {
    private ScanSynchronizer sync = new ScanSynchronizer();
    private RadarSession session = new RadarSession();
    private AurumLockSession lockSession = new AurumLockSession();
    private boolean precision = true;
    // Default false preserves host tests and the legacy bridge unless the Android UI
    // explicitly enables the versioned feature flag.
    private boolean aurumLockEnabled;

    public void setPrecision(boolean precision) { this.precision = precision; }
    public boolean isPrecision() { return precision; }

    public void setAurumLockEnabled(boolean enabled) {
        if (aurumLockEnabled == enabled) return;
        aurumLockEnabled = enabled;
        if (enabled) {
            lockSession = new AurumLockSession();
            lockSession.replaceHistory(historySnapshot(), "HISTÓRICO INTEGRADO");
        } else {
            session = new RadarSession();
            session.update(historySnapshot(), Collections.emptyList(), LearningModel.empty(), precision);
        }
    }

    public boolean isAurumLockEnabled() { return aurumLockEnabled; }

    public Result acceptScan(List<Integer> newestFirst) {
        ScanSynchronizer.MergeResult merge = sync.merge(newestFirst);
        if (!merge.accepted) {
            if (aurumLockEnabled) {
                AurumLockSession.Outcome blocked = lockSession.blockDataQuality(merge.message);
                return new Result(false, merge.message, blocked.update, null,
                        merge.history, blocked.snapshot);
            }
            return new Result(false, merge.message, null, session.lastVerdict(), merge.history, null);
        }
        if (aurumLockEnabled) {
            AurumLockSession.Outcome outcome = lockSession.update(merge.history,
                    merge.newNumbers, true, "CAPTURA INTEGRADA CONFIRMADA");
            return new Result(true, merge.message, outcome.update, null,
                    merge.history, outcome.snapshot);
        }
        SignalUpdate u = session.update(merge.history, merge.newNumbers, LearningModel.empty(), precision);
        return new Result(true, merge.message, u, session.lastVerdict(), merge.history, null);
    }

    /** Aceita somente o prefixo realmente novo detectado desde o snapshot anterior da fonte. */
    public Result acceptIncremental(List<Integer> newestFirstNewNumbers) {
        List<Integer> clean = new ArrayList<>();
        if (newestFirstNewNumbers != null) {
            for (Integer n : newestFirstNewNumbers) if (n != null && Wheel.valid(n)) clean.add(n);
        }
        if (clean.isEmpty()) return new Result(true, "Sem resultado novo", null,
                aurumLockEnabled ? null : session.lastVerdict(), historySnapshot(),
                aurumLockEnabled ? lockSession.snapshot() : null);
        List<Integer> next = new ArrayList<>(clean);
        next.addAll(sync.current());
        sync.restore(next);
        String message = clean.size() + (clean.size()==1 ? " resultado novo" : " resultados novos");
        if (aurumLockEnabled) {
            AurumLockSession.Outcome outcome = lockSession.update(sync.current(), clean,
                    true, "CAPTURA INTEGRADA CONFIRMADA");
            return new Result(true, message, outcome.update, null,
                    historySnapshot(), outcome.snapshot);
        }
        SignalUpdate u = session.update(sync.current(), clean, LearningModel.empty(), precision);
        return new Result(true, message, u, session.lastVerdict(), historySnapshot(), null);
    }

    public Result replaceBootstrap(List<Integer> newestFirst) {
        sync.restore(newestFirst == null ? Collections.emptyList() : newestFirst);
        session = new RadarSession();
        lockSession = new AurumLockSession();
        if (aurumLockEnabled) {
            AurumLockSession.Outcome outcome = lockSession.replaceHistory(
                    sync.current(), "HISTÓRICO INTEGRADO");
            return new Result(true, "Histórico sincronizado", outcome.update, null,
                    historySnapshot(), outcome.snapshot);
        }
        SignalUpdate u = session.update(sync.current(), Collections.emptyList(), LearningModel.empty(), precision);
        return new Result(true, "Histórico sincronizado", u, session.lastVerdict(), historySnapshot(), null);
    }

    public Result prependManual(int number) {
        if (!Wheel.valid(number)) return new Result(false, "Número inválido", null,
                aurumLockEnabled ? null : session.lastVerdict(), historySnapshot(),
                aurumLockEnabled ? lockSession.snapshot() : null);
        return acceptIncremental(Collections.singletonList(number));
    }

    public Result removeLatest() {
        List<Integer> h = historySnapshot();
        if (h.isEmpty()) return new Result(false, "Histórico vazio", null,
                aurumLockEnabled ? null : session.lastVerdict(), h,
                aurumLockEnabled ? lockSession.snapshot() : null);
        h.remove(0);
        return rebuild(h, "Último giro removido");
    }

    public Result replaceLatest(int number) {
        if (!Wheel.valid(number)) return new Result(false, "Número inválido", null,
                aurumLockEnabled ? null : session.lastVerdict(), historySnapshot(),
                aurumLockEnabled ? lockSession.snapshot() : null);
        List<Integer> h = historySnapshot();
        if (h.isEmpty()) h.add(number); else h.set(0, number);
        return rebuild(h, "Último giro corrigido para " + number);
    }

    public Result clearOperational() { return rebuild(Collections.emptyList(), "Histórico operacional limpo"); }

    public Result blockDataQuality(String reason) {
        String message = reason == null || reason.trim().isEmpty()
                ? "Leitura em verificação" : reason.trim();
        if (!aurumLockEnabled) {
            return new Result(false, message, null, session.lastVerdict(),
                    historySnapshot(), null);
        }
        AurumLockSession.Outcome blocked = lockSession.blockDataQuality(message);
        return new Result(false, message, blocked.update, null,
                historySnapshot(), blocked.snapshot);
    }

    private Result rebuild(List<Integer> history, String message) {
        sync = new ScanSynchronizer();
        sync.restore(history);
        session = new RadarSession();
        lockSession = new AurumLockSession();
        if (aurumLockEnabled) {
            AurumLockSession.Outcome outcome = lockSession.replaceHistory(
                    sync.current(), "CORREÇÃO INTEGRADA CONFIRMADA");
            return new Result(true, message, outcome.update, null,
                    historySnapshot(), outcome.snapshot);
        }
        SignalUpdate u = session.update(sync.current(), Collections.emptyList(), LearningModel.empty(), precision);
        return new Result(true, message, u, session.lastVerdict(), historySnapshot(), null);
    }

    public int historySize() { return sync.current().size(); }
    public List<Integer> historySnapshot() { return new ArrayList<>(sync.current()); }

    public static final class Result {
        public final boolean accepted; public final String message; public final SignalUpdate update;
        public final ConfluenceVerdict verdict; public final List<Integer> history;
        public final AurumLockSnapshot lock;
        Result(boolean accepted, String message, SignalUpdate update, ConfluenceVerdict verdict,
               List<Integer> history, AurumLockSnapshot lock) {
            this.accepted=accepted; this.message=message; this.update=update; this.verdict=verdict;
            this.history=Collections.unmodifiableList(new ArrayList<>(history));
            this.lock=lock;
        }
    }
}
