package com.xspaceart.radar30.lock;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Resultado imutável de um ciclo do Aurum Lock. */
public final class AurumLockSnapshot {
    public enum Regime {
        DISPERSION, CONCENTRATION, CONVERGENCE, PEAK,
        SATURATION, DECAY, TRANSITION
    }

    public enum ReadinessState {
        IDLE, FORMING, PRE_LOCK, ARMED, LOCKED,
        SATURATED, DECAY, INVALIDATED
    }

    public enum LockMode {
        NONE("—"),
        INSTANT_LOCK("INSTANT LOCK"),
        CONFIRMED_LOCK("CONFIRMED LOCK");

        public final String label;
        LockMode(String label) { this.label = label; }
    }

    public enum SignalType {
        SECTOR_STRONG("SETOR FORTE"),
        TERMINAL_STRONG("TERMINAL FORTE"),
        MICRO_TARGET("MICROALVO"),
        HYBRID_CONFLUENCE("CONFLUÊNCIA HÍBRIDA");

        public final String label;
        SignalType(String label) { this.label = label; }
    }

    public final int q;
    public final int readiness;
    public final Regime regime;
    public final ReadinessState readinessState;
    public final LockMode lockMode;
    public final SignalType signalType;
    public final int target;
    public final int runnerUp;
    public final int margin;
    public final int windowConsistency;
    public final int contradiction;
    public final int independentFamilies;
    public final int stableTargetUpdates;
    public final int qTrend;
    public final int activeRemaining;
    public final boolean dataQualityValid;
    public final boolean fastAuditPassed;
    public final String captureLabel;
    public final List<Integer> nucleus;
    public final List<Integer> coverage;
    public final List<String> familyLabels;
    public final List<String> reasons;
    public final List<AurumEvidence.Provenance> provenance;
    public final long historyFingerprint;

    private AurumLockSnapshot(Builder b) {
        q = clampScore(b.q);
        readiness = clampScore(b.readiness);
        regime = b.regime == null ? Regime.DISPERSION : b.regime;
        readinessState = b.readinessState == null ? ReadinessState.IDLE : b.readinessState;
        lockMode = b.lockMode == null ? LockMode.NONE : b.lockMode;
        signalType = b.signalType == null ? SignalType.SECTOR_STRONG : b.signalType;
        target = validTarget(b.target) ? b.target : -1;
        runnerUp = validTarget(b.runnerUp) ? b.runnerUp : -1;
        margin = clampScore(b.margin);
        windowConsistency = clampScore(b.windowConsistency);
        contradiction = clampScore(b.contradiction);
        independentFamilies = Math.max(0, Math.min(4, b.independentFamilies));
        stableTargetUpdates = Math.max(0, b.stableTargetUpdates);
        qTrend = Math.max(-100, Math.min(100, b.qTrend));
        activeRemaining = Math.max(0, Math.min(3, b.activeRemaining));
        dataQualityValid = b.dataQualityValid;
        fastAuditPassed = b.fastAuditPassed;
        captureLabel = b.captureLabel == null ? "—" : b.captureLabel;
        nucleus = immutableInts(b.nucleus);
        coverage = immutableInts(b.coverage);
        familyLabels = immutableStrings(b.familyLabels);
        reasons = immutableStrings(b.reasons);
        provenance = b.provenance == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(b.provenance));
        historyFingerprint = b.historyFingerprint;
    }

    public Builder toBuilder() { return new Builder(this); }

    public String playLabel() {
        if (target < 0) return "";
        if (signalType == SignalType.MICRO_TARGET && !nucleus.isEmpty()) {
            return "MICROALVO " + join(nucleus);
        }
        return "NÚCLEO " + target + " • SETOR +2";
    }

    public String familySummary() {
        if (familyLabels.isEmpty()) return "—";
        StringBuilder out = new StringBuilder();
        for (String label : familyLabels) {
            if (out.length() > 0) out.append(" + ");
            out.append(label);
        }
        return out.toString();
    }

    public String coverageLabel() { return join(coverage); }

    public static final class Builder {
        int q;
        int readiness;
        Regime regime = Regime.DISPERSION;
        ReadinessState readinessState = ReadinessState.IDLE;
        LockMode lockMode = LockMode.NONE;
        SignalType signalType = SignalType.SECTOR_STRONG;
        int target = -1;
        int runnerUp = -1;
        int margin;
        int windowConsistency;
        int contradiction;
        int independentFamilies;
        int stableTargetUpdates;
        int qTrend;
        int activeRemaining;
        boolean dataQualityValid = true;
        boolean fastAuditPassed;
        String captureLabel = "—";
        List<Integer> nucleus = Collections.emptyList();
        List<Integer> coverage = Collections.emptyList();
        List<String> familyLabels = Collections.emptyList();
        List<String> reasons = Collections.emptyList();
        List<AurumEvidence.Provenance> provenance = Collections.emptyList();
        long historyFingerprint;

        public Builder() {}

        Builder(AurumLockSnapshot source) {
            q = source.q; readiness = source.readiness; regime = source.regime;
            readinessState = source.readinessState; lockMode = source.lockMode;
            signalType = source.signalType; target = source.target; runnerUp = source.runnerUp;
            margin = source.margin; windowConsistency = source.windowConsistency;
            contradiction = source.contradiction;
            independentFamilies = source.independentFamilies;
            stableTargetUpdates = source.stableTargetUpdates; qTrend = source.qTrend;
            activeRemaining = source.activeRemaining; dataQualityValid = source.dataQualityValid;
            fastAuditPassed = source.fastAuditPassed; captureLabel = source.captureLabel;
            nucleus = source.nucleus; coverage = source.coverage;
            familyLabels = source.familyLabels; reasons = source.reasons;
            provenance = source.provenance; historyFingerprint = source.historyFingerprint;
        }

        public Builder q(int value) { q = value; return this; }
        public Builder readiness(int value) { readiness = value; return this; }
        public Builder regime(Regime value) { regime = value; return this; }
        public Builder readinessState(ReadinessState value) { readinessState = value; return this; }
        public Builder lockMode(LockMode value) { lockMode = value; return this; }
        public Builder signalType(SignalType value) { signalType = value; return this; }
        public Builder target(int value) { target = value; return this; }
        public Builder runnerUp(int value) { runnerUp = value; return this; }
        public Builder margin(int value) { margin = value; return this; }
        public Builder windowConsistency(int value) { windowConsistency = value; return this; }
        public Builder contradiction(int value) { contradiction = value; return this; }
        public Builder independentFamilies(int value) { independentFamilies = value; return this; }
        public Builder stableTargetUpdates(int value) { stableTargetUpdates = value; return this; }
        public Builder qTrend(int value) { qTrend = value; return this; }
        public Builder activeRemaining(int value) { activeRemaining = value; return this; }
        public Builder dataQualityValid(boolean value) { dataQualityValid = value; return this; }
        public Builder fastAuditPassed(boolean value) { fastAuditPassed = value; return this; }
        public Builder captureLabel(String value) { captureLabel = value; return this; }
        public Builder nucleus(List<Integer> value) { nucleus = value; return this; }
        public Builder coverage(List<Integer> value) { coverage = value; return this; }
        public Builder familyLabels(List<String> value) { familyLabels = value; return this; }
        public Builder reasons(List<String> value) { reasons = value; return this; }
        public Builder provenance(List<AurumEvidence.Provenance> value) { provenance = value; return this; }
        public Builder historyFingerprint(long value) { historyFingerprint = value; return this; }
        public AurumLockSnapshot build() { return new AurumLockSnapshot(this); }
    }

    private static List<Integer> immutableInts(List<Integer> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        List<Integer> out = new ArrayList<>();
        for (Integer value : values) {
            if (value != null && validTarget(value) && !out.contains(value)) out.add(value);
        }
        return Collections.unmodifiableList(out);
    }

    private static List<String> immutableStrings(List<String> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        List<String> out = new ArrayList<>();
        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) out.add(value.trim());
        }
        return Collections.unmodifiableList(out);
    }

    private static String join(List<Integer> values) {
        if (values == null || values.isEmpty()) return "—";
        StringBuilder out = new StringBuilder();
        for (Integer value : values) {
            if (out.length() > 0) out.append(" • ");
            out.append(value);
        }
        return out.toString();
    }

    private static boolean validTarget(int value) { return value >= 0 && value <= 36; }
    private static int clampScore(int value) { return Math.max(0, Math.min(100, value)); }
}
