package com.xspaceart.radar30.lock;

import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Estado vivo do Pré-Lock, Lock e validade dinâmica de até três giros. */
public final class AurumLockSession {
    private final AurumLockConfig config;
    private final IncrementalAurumIndex index;
    private final AurumLockEngine engine;
    private AurumLockEngine.TemporalContext temporal = AurumLockEngine.TemporalContext.empty();
    private AurumLockSnapshot current = new AurumLockSnapshot.Builder().build();
    private Active active;
    private boolean initialized;

    public AurumLockSession() { this(AurumLockConfig.defaults()); }

    public AurumLockSession(AurumLockConfig config) {
        this.config = config == null ? AurumLockConfig.defaults() : config;
        this.index = new IncrementalAurumIndex(this.config.historyCapacity);
        this.engine = new AurumLockEngine(this.config);
    }

    public Outcome replaceHistory(List<Integer> newestFirst, String captureLabel) {
        reset();
        try {
            index.rebuildNewestFirst(newestFirst);
            initialized = true;
            current = engine.analyze(index, temporal, true, captureLabel, false);
            temporal = temporal.advance(current);
            return new Outcome(current, passiveUpdate(current, "Histórico sincronizado."));
        } catch (IllegalArgumentException invalid) {
            return blockDataQuality("histórico inválido");
        }
    }

    public Outcome update(List<Integer> fullHistoryNewestFirst,
                          List<Integer> newNumbersNewestFirst,
                          boolean dataQualityValid,
                          String captureLabel) {
        if (!dataQualityValid) return blockDataQuality(captureLabel);
        List<Integer> delta = newNumbersNewestFirst == null
                ? Collections.emptyList() : newNumbersNewestFirst;
        try {
            if (!initialized) {
                index.rebuildNewestFirst(fullHistoryNewestFirst);
                initialized = true;
            } else if (!delta.isEmpty()) {
                index.appendNewestFirst(delta);
                if (!matchesHead(fullHistoryNewestFirst)) {
                    // Correção ou troca de sessão: rebuild explícito, nunca um delta ambíguo.
                    index.rebuildNewestFirst(fullHistoryNewestFirst);
                    temporal = AurumLockEngine.TemporalContext.empty();
                    active = null;
                }
            } else if (!matchesHead(fullHistoryNewestFirst)) {
                index.rebuildNewestFirst(fullHistoryNewestFirst);
                temporal = AurumLockEngine.TemporalContext.empty();
                active = null;
            } else if (current.historyFingerprint == index.deterministicFingerprint()) {
                return new Outcome(current, passiveUpdate(current, "Sem resultado novo."));
            }
        } catch (IllegalArgumentException invalid) {
            return blockDataQuality("valor fora de 0–36");
        }

        boolean publicationAllowed = !delta.isEmpty();
        AurumLockSnapshot analyzed = engine.analyze(index, temporal, true,
                captureLabel, publicationAllowed);
        temporal = temporal.advance(analyzed);
        current = analyzed;

        if (active != null && !delta.isEmpty()) {
            SignalUpdate resolution = resolveActive(delta, analyzed);
            if (resolution != null) {
                current = analyzed.toBuilder()
                        .lockMode(AurumLockSnapshot.LockMode.NONE)
                        .activeRemaining(0)
                        .build();
                return new Outcome(current, resolution);
            }
            if (mustCancel(active, analyzed)) {
                Active cancelled = active;
                active = null;
                current = analyzed.toBuilder()
                        .lockMode(AurumLockSnapshot.LockMode.NONE)
                        .activeRemaining(0)
                        .build();
                return new Outcome(current, signalUpdate(
                        SignalUpdate.Kind.INVALIDATED,
                        "CANCELAR AURUM LOCK",
                        cancelled.playLabel() + " perdeu maturidade estrutural.\n"
                                + "Q" + analyzed.q + " • Readiness " + analyzed.readiness
                                + " • Regime " + analyzed.regime + ".\n"
                                + "Entrada encerrada; não perseguir.",
                        cancelled, analyzed, 0, "", -1, cancelled.misses,
                        "DYNAMIC_CANCEL"));
            }
            current = activeSnapshot(analyzed, active);
            return new Outcome(current, signalUpdate(
                    SignalUpdate.Kind.ACTIVE,
                    "AURUM LOCK ATIVO — Q" + analyzed.q,
                    activeDetail(active, analyzed), active, current,
                    active.misses + 1, "", -1, active.misses, "ACTIVE"));
        }

        if (active != null) {
            current = activeSnapshot(analyzed, active);
            return new Outcome(current, signalUpdate(
                    SignalUpdate.Kind.ACTIVE,
                    "AURUM LOCK ATIVO — Q" + analyzed.q,
                    activeDetail(active, analyzed), active, current,
                    active.misses + 1, "", -1, active.misses, "ACTIVE"));
        }

        if (analyzed.lockMode != AurumLockSnapshot.LockMode.NONE) {
            active = new Active(analyzed, config.maxValiditySpins);
            current = activeSnapshot(analyzed, active);
            return new Outcome(current, signalUpdate(
                    SignalUpdate.Kind.ENTRY,
                    "AURUM LOCK — Q" + analyzed.q,
                    entryDetail(active, analyzed), active, current, 1,
                    "Aurum Lock. " + active.playLabel()
                            + ". Válido para o próximo giro.",
                    -1, 0, analyzed.lockMode.name()));
        }

        return new Outcome(current, passiveUpdate(analyzed, "Análise incremental atualizada."));
    }

    public Outcome blockDataQuality(String reason) {
        String label = reason == null || reason.trim().isEmpty()
                ? "leitura em verificação" : reason.trim();
        Active cancelled = active;
        active = null;
        current = engine.analyze(index, temporal, false, label, false);
        SignalUpdate update;
        if (cancelled != null) {
            update = signalUpdate(SignalUpdate.Kind.INVALIDATED,
                    "LOCK BLOCKED — DATA QUALITY",
                    "Leitura em verificação. O sinal ativo foi cancelado por segurança.\n"
                            + label + ".", cancelled, current, 0,
                    "", -1, cancelled.misses, "DATA_QUALITY_CANCEL");
        } else {
            update = new SignalUpdate(SignalUpdate.Kind.WAITING,
                    "LEITURA EM VERIFICAÇÃO",
                    "SINAL TEMPORARIAMENTE BLOQUEADO • " + label,
                    -1, Collections.emptyList(), 0, 0, "");
        }
        return new Outcome(current, update);
    }

    public void reset() {
        index.clear();
        temporal = AurumLockEngine.TemporalContext.empty();
        current = new AurumLockSnapshot.Builder().build();
        active = null;
        initialized = false;
    }

    public AurumLockSnapshot snapshot() { return current; }
    public int historySize() { return index.size(); }
    public long deltaUpdates() { return index.deltaUpdates(); }
    public int rebuildCount() { return index.rebuildCount(); }

    private SignalUpdate resolveActive(List<Integer> newestFirstDelta,
                                       AurumLockSnapshot analyzed) {
        for (int i = newestFirstDelta.size() - 1; i >= 0; i--) {
            int result = newestFirstDelta.get(i);
            int round = active.misses + 1;
            if (active.coverage.contains(result)) {
                Active hit = active;
                active = null;
                return signalUpdate(SignalUpdate.Kind.HIT,
                        "STRYKE • " + result,
                        hit.playLabel() + " confirmado no giro " + round + "/"
                                + hit.validitySpins + ".\nSinal encerrado; sem recuperação.",
                        hit, analyzed, 0, "Aurum Lock confirmado.",
                        result, round, "PRIMARY_HIT");
            }
            active.misses++;
            if (active.misses >= active.validitySpins) {
                Active expired = active;
                active = null;
                return signalUpdate(SignalUpdate.Kind.EXPIRED,
                        "AURUM LOCK EXPIRADO",
                        expired.playLabel() + " não apareceu em "
                                + expired.validitySpins + " giros.\n"
                                + "Sinal encerrado; ausência não aumenta confiança.",
                        expired, analyzed, 0, "Sinal expirado. Não perseguir.",
                        result, expired.validitySpins, "EXPIRED");
            }
        }
        return null;
    }

    private boolean mustCancel(Active signal, AurumLockSnapshot analyzed) {
        if (!analyzed.dataQualityValid || !analyzed.fastAuditPassed) return true;
        if (analyzed.regime == AurumLockSnapshot.Regime.DECAY
                || analyzed.regime == AurumLockSnapshot.Regime.TRANSITION
                || analyzed.regime == AurumLockSnapshot.Regime.SATURATION) return true;
        if (analyzed.q < Math.max(40, config.preLockQ - 8)
                || analyzed.readiness < Math.max(35, config.preLockQ - 10)) return true;
        return overlap(signal.coverage, analyzed.coverage) < 3;
    }

    private SignalUpdate passiveUpdate(AurumLockSnapshot snapshot, String suffix) {
        if (!snapshot.dataQualityValid) {
            return new SignalUpdate(SignalUpdate.Kind.WAITING,
                    "LEITURA EM VERIFICAÇÃO", suffix,
                    -1, Collections.emptyList(), 0, 0, "");
        }
        if (snapshot.readinessState == AurumLockSnapshot.ReadinessState.PRE_LOCK
                || snapshot.readinessState == AurumLockSnapshot.ReadinessState.ARMED) {
            return new SignalUpdate(SignalUpdate.Kind.PREPARE,
                    "FORMAÇÃO EM ACOMPANHAMENTO",
                    "Q" + snapshot.q + " • Readiness " + snapshot.readiness
                            + " • Regime " + snapshot.regime + ".\n"
                            + "Pré-Lock discreto: ainda não entrar. " + suffix,
                    snapshot.target, snapshot.coverage, snapshot.q, 0, "",
                    snapshot.familyLabels, snapshot.independentFamilies,
                    -1, 0, snapshot.playLabel());
        }
        SignalUpdate.Kind kind = snapshot.readinessState == AurumLockSnapshot.ReadinessState.DECAY
                || snapshot.readinessState == AurumLockSnapshot.ReadinessState.SATURATED
                ? SignalUpdate.Kind.OBSERVE : SignalUpdate.Kind.BUILDING;
        return new SignalUpdate(kind,
                snapshot.target < 0 ? "ANALISANDO" : "AURUM EM FORMAÇÃO — Q" + snapshot.q,
                "Readiness " + snapshot.readiness + " • Regime " + snapshot.regime
                        + ". " + suffix,
                snapshot.target, snapshot.coverage, snapshot.q, 0, "",
                snapshot.familyLabels, snapshot.independentFamilies,
                -1, 0, snapshot.playLabel());
    }

    private SignalUpdate signalUpdate(SignalUpdate.Kind kind, String headline,
                                      String detail, Active signal,
                                      AurumLockSnapshot snapshot, int nextRound,
                                      String speech, int eventResult,
                                      int resolvedRound, String resultType) {
        List<String> families = snapshot == null
                ? Collections.emptyList() : snapshot.familyLabels;
        int q = snapshot == null ? signal.entryQ : snapshot.q;
        int independent = snapshot == null
                ? signal.independentFamilies : snapshot.independentFamilies;
        String regime = snapshot == null ? "" : snapshot.regime.name();
        int velocity = snapshot == null ? 0 : snapshot.qTrend;
        return new SignalUpdate(kind, headline, detail, signal.target,
                signal.coverage, "", Collections.emptyList(), signal.coverage,
                q, nextRound, speech, families, independent,
                eventResult, resolvedRound, signal.playLabel(),
                -1, "", Collections.emptyList(), 0,
                "AURUM_LOCK", resultType, regime, velocity,
                "", false);
    }

    private static AurumLockSnapshot activeSnapshot(AurumLockSnapshot analyzed, Active active) {
        return analyzed.toBuilder()
                .lockMode(active.mode)
                .readinessState(AurumLockSnapshot.ReadinessState.LOCKED)
                .target(active.target)
                .coverage(active.coverage)
                .nucleus(active.nucleus)
                .signalType(active.signalType)
                .activeRemaining(active.validitySpins - active.misses)
                .build();
    }

    private static String entryDetail(Active active, AurumLockSnapshot snapshot) {
        return "Readiness: " + snapshot.readiness + "/100\n"
                + "Regime: " + snapshot.regime + "\n"
                + "Tipo: " + active.signalType.label + "\n"
                + "Núcleo: " + join(active.nucleus) + "\n"
                + "Cobertura: " + join(active.coverage) + "\n"
                + "Validade: próximo giro, renovável somente enquanto persistir; máximo "
                + active.validitySpins + "\n"
                + "Famílias independentes: " + snapshot.familySummary() + "\n"
                + "Rival: " + (snapshot.runnerUp < 0 ? "—" : snapshot.runnerUp)
                + " • margem " + snapshot.margin + "/100\n"
                + "Captura: " + snapshot.captureLabel + "\n"
                + "Modo: " + active.mode.label + "\n"
                + "Q" + snapshot.q + " = QUALIDADE ESTRUTURAL, não probabilidade.";
    }

    private static String activeDetail(Active active, AurumLockSnapshot snapshot) {
        int remaining = active.validitySpins - active.misses;
        return active.playLabel() + " • Q" + snapshot.q
                + " • Readiness " + snapshot.readiness
                + " • Regime " + snapshot.regime + ".\n"
                + "Restam no máximo " + remaining
                + (remaining == 1 ? " giro" : " giros")
                + "; validade recalculada agora.";
    }

    private boolean matchesHead(List<Integer> fullHistoryNewestFirst) {
        if (fullHistoryNewestFirst == null) return index.size() == 0;
        int expectedSize = Math.min(config.historyCapacity, fullHistoryNewestFirst.size());
        if (index.size() != expectedSize) return false;
        int compare = Math.min(4, expectedSize);
        for (int i = 0; i < compare; i++) {
            Integer value = fullHistoryNewestFirst.get(i);
            if (value == null || !Wheel.valid(value) || index.recent(i) != value) return false;
        }
        return true;
    }

    private static int overlap(List<Integer> a, List<Integer> b) {
        int count = 0;
        for (Integer value : a) if (b.contains(value)) count++;
        return count;
    }

    private static String join(List<Integer> values) {
        if (values == null || values.isEmpty()) return "—";
        StringBuilder out = new StringBuilder();
        for (Integer value : values) {
            if (out.length() > 0) out.append(" • ");
            out.append(value);
        }
        return out.toString();
    }

    public static final class Outcome {
        public final AurumLockSnapshot snapshot;
        public final SignalUpdate update;
        Outcome(AurumLockSnapshot snapshot, SignalUpdate update) {
            this.snapshot = snapshot;
            this.update = update;
        }
    }

    private static final class Active {
        final int target;
        final List<Integer> nucleus;
        final List<Integer> coverage;
        final int entryQ;
        final int independentFamilies;
        final int validitySpins;
        final AurumLockSnapshot.LockMode mode;
        final AurumLockSnapshot.SignalType signalType;
        int misses;

        Active(AurumLockSnapshot snapshot, int validitySpins) {
            target = snapshot.target;
            nucleus = Collections.unmodifiableList(new ArrayList<>(snapshot.nucleus));
            coverage = Collections.unmodifiableList(new ArrayList<>(snapshot.coverage));
            entryQ = snapshot.q;
            independentFamilies = snapshot.independentFamilies;
            this.validitySpins = Math.min(3, Math.max(1, validitySpins));
            mode = snapshot.lockMode;
            signalType = snapshot.signalType;
        }

        String playLabel() { return "NÚCLEO " + target + " • " + join(coverage); }
    }
}
