package com.xspaceart.radar30.lock;

import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Índice single-writer de tamanho fixo. Um giro novo altera apenas contadores
 * de janela e uma célula da matriz de transição.
 */
public final class IncrementalAurumIndex {
    private static final int[] WINDOWS = {5, 10, 30};

    private final int capacity;
    private final int[] ring;
    private final int[] allCounts = new int[37];
    private final int[][] recentCounts = new int[WINDOWS.length][37];
    private final int[][] transitions = new int[37][37];
    private int head;
    private int size;
    private long deltaUpdates;
    private int rebuildCount;

    public IncrementalAurumIndex(int capacity) {
        if (capacity < 30) throw new IllegalArgumentException("capacity must be >= 30");
        this.capacity = capacity;
        this.ring = new int[capacity];
    }

    public void rebuildNewestFirst(List<Integer> newestFirst) {
        validate(newestFirst);
        clearInternal();
        int limit = Math.min(capacity, newestFirst == null ? 0 : newestFirst.size());
        for (int i = limit - 1; i >= 0; i--) appendChronological(newestFirst.get(i));
        rebuildCount++;
    }

    public void appendNewestFirst(List<Integer> newestFirstDelta) {
        validate(newestFirstDelta);
        if (newestFirstDelta == null) return;
        for (int i = newestFirstDelta.size() - 1; i >= 0; i--) {
            appendChronological(newestFirstDelta.get(i));
        }
    }

    public void clear() {
        clearInternal();
        rebuildCount++;
    }

    private void appendChronological(int number) {
        if (!Wheel.valid(number)) throw new IllegalArgumentException("number must be 0..36");

        if (size == capacity) {
            int oldest = atChronological(0);
            if (size > 1) {
                int next = atChronological(1);
                transitions[oldest][next] = Math.max(0, transitions[oldest][next] - 1);
            }
            allCounts[oldest] = Math.max(0, allCounts[oldest] - 1);
            head = (head + 1) % capacity;
            size--;
        }

        for (int w = 0; w < WINDOWS.length; w++) {
            int window = WINDOWS[w];
            if (size >= window) {
                int falling = atChronological(size - window);
                recentCounts[w][falling] = Math.max(0, recentCounts[w][falling] - 1);
            }
            recentCounts[w][number]++;
        }

        int previous = size == 0 ? -1 : atChronological(size - 1);
        ring[(head + size) % capacity] = number;
        size++;
        allCounts[number]++;
        if (previous >= 0) transitions[previous][number]++;
        deltaUpdates++;
    }

    public int size() { return size; }
    public int capacity() { return capacity; }
    public long deltaUpdates() { return deltaUpdates; }
    public int rebuildCount() { return rebuildCount; }

    /** offset 0 = giro mais recente. */
    public int recent(int offset) {
        if (offset < 0 || offset >= size) throw new IndexOutOfBoundsException("recent offset");
        return atChronological(size - 1 - offset);
    }

    public int count(int number) {
        return Wheel.valid(number) ? allCounts[number] : 0;
    }

    public int windowCount(int window, int number) {
        if (!Wheel.valid(number)) return 0;
        for (int i = 0; i < WINDOWS.length; i++) {
            if (WINDOWS[i] == window) return recentCounts[i][number];
        }
        throw new IllegalArgumentException("supported windows: 5, 10, 30");
    }

    public int windowSize(int window) {
        for (int value : WINDOWS) if (value == window) return Math.min(value, size);
        throw new IllegalArgumentException("supported windows: 5, 10, 30");
    }

    public int transitionCount(int from, int to) {
        return Wheel.valid(from) && Wheel.valid(to) ? transitions[from][to] : 0;
    }

    public int transitionSamples(int from) {
        if (!Wheel.valid(from)) return 0;
        int total = 0;
        for (int to = 0; to < 37; to++) total += transitions[from][to];
        return total;
    }

    public List<Integer> newestFirst(int limit) {
        if (size == 0 || limit <= 0) return Collections.emptyList();
        int count = Math.min(size, limit);
        List<Integer> out = new ArrayList<>(count);
        for (int i = 0; i < count; i++) out.add(recent(i));
        return Collections.unmodifiableList(out);
    }

    public List<Integer> chronological(int limit) {
        if (size == 0 || limit <= 0) return Collections.emptyList();
        int count = Math.min(size, limit);
        int start = size - count;
        List<Integer> out = new ArrayList<>(count);
        for (int i = start; i < size; i++) out.add(atChronological(i));
        return Collections.unmodifiableList(out);
    }

    public long deterministicFingerprint() {
        long hash = 0xcbf29ce484222325L;
        for (int i = 0; i < size; i++) {
            hash ^= atChronological(i) + 1L;
            hash *= 0x100000001b3L;
        }
        return hash;
    }

    public boolean invariantHolds() {
        int all = 0;
        for (int value : allCounts) all += value;
        if (all != size) return false;
        for (int w = 0; w < WINDOWS.length; w++) {
            int total = 0;
            for (int value : recentCounts[w]) total += value;
            if (total != Math.min(WINDOWS[w], size)) return false;
        }
        int transitionTotal = 0;
        for (int from = 0; from < 37; from++) {
            for (int to = 0; to < 37; to++) transitionTotal += transitions[from][to];
        }
        return transitionTotal == Math.max(0, size - 1);
    }

    private int atChronological(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("chronological index");
        return ring[(head + index) % capacity];
    }

    private void clearInternal() {
        head = 0;
        size = 0;
        deltaUpdates = 0L;
        java.util.Arrays.fill(allCounts, 0);
        for (int[] counts : recentCounts) java.util.Arrays.fill(counts, 0);
        for (int[] row : transitions) java.util.Arrays.fill(row, 0);
    }

    private static void validate(List<Integer> values) {
        if (values == null) return;
        for (Integer value : values) {
            if (value == null || !Wheel.valid(value)) {
                throw new IllegalArgumentException("history contains invalid roulette value");
            }
        }
    }
}
