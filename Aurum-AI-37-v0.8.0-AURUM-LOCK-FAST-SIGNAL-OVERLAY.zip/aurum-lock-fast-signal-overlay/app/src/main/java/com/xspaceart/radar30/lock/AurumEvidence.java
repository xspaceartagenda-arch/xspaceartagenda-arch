package com.xspaceart.radar30.lock;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Vetores de 37 posições com provenance compacto e deduplicação por dependência. */
public final class AurumEvidence {
    public static final int NUMBER_COUNT = 37;

    public enum Family {
        PHYSICAL("física"),
        NUMERIC("numérica"),
        SEQUENTIAL("sequencial"),
        PATTERN_ECHO("Pattern Echo");

        public final String label;
        Family(String label) { this.label = label; }
    }

    public static final class Provenance {
        public final Family family;
        public final String moduleId;
        public final long sourceSpinsMask;
        public final String sourcePatternId;
        public final int target;
        public final double contribution;
        public final String dependencyGroup;
        public final long timestamp;
        public final double confidence;

        Provenance(Family family, String moduleId, long sourceSpinsMask,
                   String sourcePatternId, int target, double contribution,
                   String dependencyGroup, long timestamp, double confidence) {
            this.family = family;
            this.moduleId = moduleId;
            this.sourceSpinsMask = sourceSpinsMask;
            this.sourcePatternId = sourcePatternId == null ? "" : sourcePatternId;
            this.target = target;
            this.contribution = clamp01(contribution);
            this.dependencyGroup = dependencyGroup;
            this.timestamp = timestamp;
            this.confidence = clamp01(confidence);
        }
    }

    public static final class FamilyVector {
        public final Family family;
        private final double[] mass;
        public final double confidence;
        public final List<Provenance> provenance;
        private final double peak;

        FamilyVector(Family family, double[] mass, double confidence,
                     List<Provenance> provenance) {
            this.family = family;
            this.mass = mass;
            this.confidence = clamp01(confidence);
            this.provenance = Collections.unmodifiableList(new ArrayList<>(provenance));
            double max = 0.0;
            for (double value : mass) max = Math.max(max, value);
            this.peak = max;
        }

        public double at(int number) {
            return number >= 0 && number < NUMBER_COUNT ? mass[number] : 0.0;
        }

        public double relativeAt(int number) {
            return peak <= 0.0 ? 0.0 : at(number) / peak;
        }

        public double strongestRelative(List<Integer> coverage) {
            double best = 0.0;
            if (coverage != null) {
                for (Integer number : coverage) {
                    if (number != null) best = Math.max(best, relativeAt(number));
                }
            }
            return best;
        }

        public double totalMass() {
            double total = 0.0;
            for (double value : mass) total += value;
            return total;
        }

        public boolean isEmpty() { return peak <= 0.0; }

        public double[] copyMass() { return mass.clone(); }
    }

    /**
     * Um dependencyGroup produz no máximo uma contribuição. Se dois módulos
     * descrevem a mesma observação, apenas o de maior confiança permanece.
     */
    public static final class Builder {
        private final Family family;
        private final Map<String, Module> modules = new LinkedHashMap<>();

        public Builder(Family family) {
            if (family == null) throw new IllegalArgumentException("family required");
            this.family = family;
        }

        public Builder add(String moduleId, String dependencyGroup, double[] raw,
                           double confidence, long sourceSpinsMask,
                           String sourcePatternId) {
            if (raw == null || raw.length != NUMBER_COUNT) {
                throw new IllegalArgumentException("family vector must have 37 positions");
            }
            String module = clean(moduleId, "module");
            String dependency = clean(dependencyGroup, module);
            double[] safe = new double[NUMBER_COUNT];
            double total = 0.0;
            for (int i = 0; i < NUMBER_COUNT; i++) {
                double value = Double.isFinite(raw[i]) ? Math.max(0.0, raw[i]) : 0.0;
                safe[i] = value;
                total += value;
            }
            if (total <= 0.0) return this;
            Module candidate = new Module(module, dependency, safe, clamp01(confidence),
                    sourceSpinsMask, sourcePatternId);
            Module current = modules.get(dependency);
            if (current == null
                    || candidate.confidence > current.confidence + 1e-12
                    || (Math.abs(candidate.confidence - current.confidence) <= 1e-12
                    && candidate.moduleId.compareTo(current.moduleId) < 0)) {
                modules.put(dependency, candidate);
            }
            return this;
        }

        public FamilyVector build(long timestamp) {
            if (modules.isEmpty()) return empty(family);
            double[] combined = new double[NUMBER_COUNT];
            double confidenceTotal = 0.0;
            List<Provenance> provenance = new ArrayList<>();
            for (Module module : modules.values()) {
                double total = sum(module.raw);
                if (total <= 0.0) continue;
                for (int i = 0; i < NUMBER_COUNT; i++) {
                    combined[i] += (module.raw[i] / total) * module.confidence;
                }
                confidenceTotal += module.confidence;
                provenance.add(new Provenance(family, module.moduleId,
                        module.sourceSpinsMask, module.sourcePatternId,
                        argMax(module.raw), module.confidence,
                        module.dependencyGroup, timestamp, module.confidence));
            }
            normalizeInPlace(combined);
            double confidence = confidenceTotal / Math.max(1, modules.size());
            return new FamilyVector(family, combined, confidence, provenance);
        }
    }

    public static FamilyVector empty(Family family) {
        return new FamilyVector(family, new double[NUMBER_COUNT], 0.0,
                Collections.emptyList());
    }

    public static long recentMask(int count) {
        if (count <= 0) return 0L;
        if (count >= Long.SIZE) return -1L;
        return (1L << count) - 1L;
    }

    public static void normalizeInPlace(double[] values) {
        double total = sum(values);
        if (total <= 0.0) return;
        for (int i = 0; i < values.length; i++) values[i] /= total;
    }

    private static final class Module {
        final String moduleId;
        final String dependencyGroup;
        final double[] raw;
        final double confidence;
        final long sourceSpinsMask;
        final String sourcePatternId;

        Module(String moduleId, String dependencyGroup, double[] raw,
               double confidence, long sourceSpinsMask, String sourcePatternId) {
            this.moduleId = moduleId;
            this.dependencyGroup = dependencyGroup;
            this.raw = raw;
            this.confidence = confidence;
            this.sourceSpinsMask = sourceSpinsMask;
            this.sourcePatternId = sourcePatternId;
        }
    }

    private static String clean(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private static int argMax(double[] values) {
        int best = -1;
        double score = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < values.length; i++) {
            if (values[i] > score) { score = values[i]; best = i; }
        }
        return best;
    }

    private static double sum(double[] values) {
        double total = 0.0;
        for (double value : values) total += value;
        return total;
    }

    private static double clamp01(double value) {
        if (!Double.isFinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }
}
