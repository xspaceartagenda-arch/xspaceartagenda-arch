import com.xspaceart.radar30.lock.AurumLockSession;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Host-JVM budget check. This is not a physical-device benchmark. */
public final class AurumLockPerformanceTest {
    public static void main(String[] args) {
        AurumLockSession session = new AurumLockSession();
        List<Integer> history = history(500);
        session.replaceHistory(history, "HOST PERF");
        int bootstrapRebuilds = session.rebuildCount();

        for (int i = 0; i < 200; i++) {
            int n = Math.floorMod(i * 19 + 11, 37);
            history.add(0, n);
            history.remove(history.size() - 1);
            session.update(history, Collections.singletonList(n), true, "HOST PERF");
        }

        long[] nanos = new long[500];
        for (int i = 0; i < nanos.length; i++) {
            int n = Math.floorMod(i * 23 + (i / 7) * 5 + 3, 37);
            history.add(0, n);
            history.remove(history.size() - 1);
            long start = System.nanoTime();
            session.update(history, Collections.singletonList(n), true, "HOST PERF");
            nanos[i] = System.nanoTime() - start;
        }
        Arrays.sort(nanos);
        double p50Ms = nanos[nanos.length / 2] / 1_000_000.0;
        double p95Ms = nanos[(int) Math.ceil(nanos.length * 0.95) - 1] / 1_000_000.0;
        require(session.historySize() == 500, "history capacity changed during benchmark");
        require(session.rebuildCount() == bootstrapRebuilds,
                "live delta path unexpectedly rebuilt history");
        require(p95Ms < 100.0, "host p95 exceeded Fast Fusion budget: " + p95Ms + "ms");
        System.out.printf(java.util.Locale.ROOT,
                "AURUM_LOCK_HOST_PERF=PASS p50_ms=%.3f p95_ms=%.3f samples=%d%n",
                p50Ms, p95Ms, nanos.length);
        System.out.println("PHYSICAL_S25FE=PENDING");
    }

    private static List<Integer> history(int size) {
        List<Integer> chronological = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            chronological.add(Math.floorMod(i * 13 + (i / 9) * 7 + 5, 37));
        }
        Collections.reverse(chronological);
        return chronological;
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
