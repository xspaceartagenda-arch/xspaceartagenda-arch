import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.integrated.IntegratedSignalBridge;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class AurumLockBridgeTest {
    public static void main(String[] args) {
        IntegratedSignalBridge bridge = new IntegratedSignalBridge();
        bridge.setAurumLockEnabled(true);

        List<Integer> history = new ArrayList<>(Arrays.asList(
                25,7,32,14,2,21,9,18,34,5,
                27,11,30,16,3,22,8,29,12,35,
                1,24,6,33,15,20,4,31,17,10));
        IntegratedSignalBridge.Result bootstrap = bridge.acceptScan(history);
        require(bootstrap.accepted, "bootstrap rejected");
        require(bootstrap.lock != null, "feature flag did not select Aurum Lock");
        require(bootstrap.update.kind != SignalUpdate.Kind.ENTRY,
                "bootstrap may not publish an official lock");

        IntegratedSignalBridge.Result unchanged = bridge.acceptScan(history);
        require(unchanged.accepted && unchanged.lock != null, "unchanged snapshot lost lock state");

        history.add(0, 19);
        IntegratedSignalBridge.Result delta = bridge.acceptScan(history);
        require(delta.accepted, "valid one-spin delta rejected");
        require(delta.history.get(0) == 19 && delta.history.get(1) == 25,
                "delta order corrupted");
        require(delta.lock != null && delta.lock.dataQualityValid,
                "validated capture must reach lock core");

        IntegratedSignalBridge.Result blocked = bridge.acceptScan(Arrays.asList(1,2,3));
        require(!blocked.accepted, "short invalid capture should be rejected");
        require(blocked.lock != null && !blocked.lock.dataQualityValid,
                "rejected capture must hard-block lock");
        require(blocked.update.kind == SignalUpdate.Kind.WAITING
                        || blocked.update.kind == SignalUpdate.Kind.INVALIDATED,
                "data quality state was not surfaced");

        IntegratedSignalBridge.Result corrected = bridge.replaceLatest(26);
        require(corrected.accepted && corrected.lock != null,
                "correction did not rebuild Aurum index");
        require(corrected.history.get(0) == 26, "correction not reflected in history");
        require(corrected.lock.dataQualityValid, "valid correction did not unblock gate");

        System.out.println("AURUM_LOCK_BRIDGE=PASS");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
