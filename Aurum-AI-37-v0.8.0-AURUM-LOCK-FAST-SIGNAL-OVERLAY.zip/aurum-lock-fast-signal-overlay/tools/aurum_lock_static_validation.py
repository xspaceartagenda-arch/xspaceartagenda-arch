#!/usr/bin/env python3
from pathlib import Path
import re

root = Path.cwd()
files = {
    "config": root / "app/src/main/java/com/xspaceart/radar30/lock/AurumLockConfig.java",
    "engine": root / "app/src/main/java/com/xspaceart/radar30/lock/AurumLockEngine.java",
    "session": root / "app/src/main/java/com/xspaceart/radar30/lock/AurumLockSession.java",
    "service": root / "app/src/main/java/com/xspaceart/radar30/ScreenCaptureService.java",
    "integrated": root / "app/src/main/java/com/xspaceart/radar30/integrated/IntegratedActivity.java",
    "bridge": root / "app/src/main/java/com/xspaceart/radar30/integrated/IntegratedSignalBridge.java",
    "standalone": root / "app/src/main/java/com/xspaceart/radar30/StandaloneActivity.java",
    "store": root / "app/src/main/java/com/xspaceart/radar30/AppStateStore.java",
    "echo": root / "app/src/main/java/com/xspaceart/radar30/echo/PatternEchoEngine.java",
    "manifest": root / "app/src/main/AndroidManifest.xml",
    "gradle": root / "app/build.gradle",
}
for name, path in files.items():
    assert path.is_file(), f"missing {name}: {path}"

text = {name: path.read_text(encoding="utf-8") for name, path in files.items()}
assert 'FEATURE_FLAG_NAME = "aurum_lock_fast_signal_v1"' in text["config"]
assert "ENABLED_BY_DEFAULT = true" in text["config"]
assert re.search(r"\b3,\s*3,\s*\n\s*180", text["config"]), "default max validity must be 3"
assert "validity must be 1..3" in text["config"]
assert "StructuralRegimeDetector.detect" in text["engine"]
assert text["engine"].index("int q = structuralQ") < text["engine"].index("StructuralRegimeDetector.detect")
assert "não é probabilidade de vitória" in text["engine"]
assert "blockDataQuality" in text["session"] and "INVALIDATED" in text["session"]
assert "AurumLockSession" in text["service"] and "presentAurum" in text["service"]
assert "AurumLockSession" in text["bridge"] and "blockDataQuality" in text["bridge"]
assert "renderBridge" in text["integrated"] and "lock.readiness" in text["integrated"]
assert "PatternEchoActivity" in text["standalone"], "Echo must remain reachable in-app"
assert "aurumLockEnabled" in text["store"]
assert "weightedSupport).reversed()" in text["echo"]
assert "bestCompatibility).reversed())" in text["echo"]
assert ".thenComparingDouble((Aggregate a) -> a.bestCompatibility)\n                .reversed()" not in text["echo"], \
    "known Echo whole-comparator reversal returned"
assert text["manifest"].count("android.intent.category.LAUNCHER") == 1
assert re.search(r'PatternEchoActivity"\s+android:exported="false"', text["manifest"])
assert re.search(r"versionCode\s+14\b", text["gradle"])
assert re.search(r'versionName\s+["\']0\.8\.0-aurum-lock["\']', text["gradle"])
assert "applicationId 'com.xspaceart.aurumai37.integratedlab'" in text["gradle"]
print("AURUM_LOCK_STATIC_VALIDATION=PASS")
