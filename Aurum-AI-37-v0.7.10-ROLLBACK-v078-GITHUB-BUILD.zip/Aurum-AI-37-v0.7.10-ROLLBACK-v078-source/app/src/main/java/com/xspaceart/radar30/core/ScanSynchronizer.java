package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Reconcilia uma grade OCR nova com o histórico anterior sem eliminar repetições legítimas. */
public final class ScanSynchronizer {
    private List<Integer> current = new ArrayList<>();

    public void restore(List<Integer> history) {
        current = trim(history, CurrentTableHistory.MAX_RESULTS);
    }

    public MergeResult merge(List<Integer> scan) {
        List<Integer> clean = trim(scan, CurrentTableHistory.MAX_RESULTS);
        if (clean.size() < 8) return MergeResult.rejected(current, "Poucos números reconhecidos");
        if (current.isEmpty()) {
            current = clean;
            return new MergeResult(true, true, Collections.emptyList(), current, "Histórico inicial carregado");
        }

        int bestOffset = -1;
        double bestRatio = -1.0;
        int bestCompared = 0;
        int maxOffset = Math.min(5, clean.size() - 1);
        for (int offset = 0; offset <= maxOffset; offset++) {
            int compared = Math.min(20, Math.min(clean.size() - offset, current.size()));
            if (compared < 6) continue;
            int equal = 0;
            for (int i = 0; i < compared; i++) {
                if (clean.get(offset + i).equals(current.get(i))) equal++;
            }
            double ratio = equal / (double) compared;
            if (ratio > bestRatio || (ratio == bestRatio && offset < bestOffset)) {
                bestRatio = ratio;
                bestOffset = offset;
                bestCompared = compared;
            }
        }

        if (bestOffset < 0 || bestCompared < 6 || bestRatio < 0.85) {
            return MergeResult.rejected(current, "Mudança grande no OCR; conferir área");
        }

        if (bestOffset == 0) {
            // Um recorte menor pode mostrar só as linhas mais recentes. Não
            // descarte a cauda já confirmada da sessão atual.
            if (clean.size() >= current.size()) current = clean;
            return new MergeResult(true, false, Collections.emptyList(), current, "Sem resultado novo");
        }

        List<Integer> newNumbers = new ArrayList<>(clean.subList(0, bestOffset));
        List<Integer> next = new ArrayList<>(newNumbers);
        next.addAll(current);
        current = trim(next, CurrentTableHistory.MAX_RESULTS);
        return new MergeResult(true, false, newNumbers, current,
                bestOffset + (bestOffset == 1 ? " resultado novo" : " resultados novos"));
    }

    public MergeResult prependManual(int number) {
        if (!Wheel.valid(number)) return MergeResult.rejected(current, "Número inválido");
        List<Integer> next = new ArrayList<>();
        next.add(number);
        next.addAll(current);
        current = trim(next, CurrentTableHistory.MAX_RESULTS);
        return new MergeResult(true, false, Collections.singletonList(number), current, "Resultado manual");
    }

    public List<Integer> current() {
        return Collections.unmodifiableList(current);
    }

    private static List<Integer> trim(List<Integer> source, int limit) {
        List<Integer> result = new ArrayList<>();
        if (source == null) return result;
        for (Integer n : source) {
            if (n != null && Wheel.valid(n)) result.add(n);
            if (result.size() == limit) break;
        }
        return result;
    }

    public static final class MergeResult {
        public final boolean accepted;
        public final boolean bootstrap;
        public final List<Integer> newNumbers;
        public final List<Integer> history;
        public final String message;

        MergeResult(boolean accepted, boolean bootstrap, List<Integer> newNumbers,
                    List<Integer> history, String message) {
            this.accepted = accepted;
            this.bootstrap = bootstrap;
            this.newNumbers = Collections.unmodifiableList(new ArrayList<>(newNumbers));
            this.history = Collections.unmodifiableList(new ArrayList<>(history));
            this.message = message;
        }

        static MergeResult rejected(List<Integer> history, String message) {
            return new MergeResult(false, false, Collections.emptyList(), history, message);
        }
    }
}
