package com.xspaceart.radar30;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import java.util.Collections;
import java.util.List;

/** Intensidade diagnóstica das quatro famílias; não participa da decisão do motor. */
public final class AurumFamilyBarsView extends View {
    private static final String[] LABELS = {"FÍSICA", "NUMÉRICA", "SEQUENCIAL", "PATTERN ECHO"};
    private static final int[] COLORS = {Ui.GREEN, Ui.CYAN, Ui.PURPLE, Ui.GOLD};
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int[] strengths = new int[4];

    public AurumFamilyBarsView(Context context) { super(context); }
    public AurumFamilyBarsView(Context context, AttributeSet attrs) { super(context, attrs); }

    public void setStrengths(List<Integer> values) {
        strengths = new int[4];
        List<Integer> safe = values == null ? Collections.emptyList() : values;
        for (int i = 0; i < strengths.length && i < safe.size(); i++) {
            Integer value = safe.get(i);
            strengths[i] = value == null ? 0 : Math.max(0, Math.min(100, value));
        }
        invalidate();
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(resolveSize(Ui.dp(getContext(), 300), widthMeasureSpec),
                resolveSize(Ui.dp(getContext(), 154), heightMeasureSpec));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left = Ui.dp(getContext(), 8);
        float right = getWidth() - Ui.dp(getContext(), 8);
        float barLeft = left + Ui.dp(getContext(), 92);
        float valueWidth = Ui.dp(getContext(), 31);
        float barRight = right - valueWidth;
        float firstY = Ui.dp(getContext(), 24);
        float gap = Ui.dp(getContext(), 34);
        boolean hasValue = false;
        for (int value : strengths) if (value > 0) hasValue = true;

        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        for (int i = 0; i < 4; i++) {
            float y = firstY + gap * i;
            paint.setStyle(Paint.Style.FILL);
            paint.setTextAlign(Paint.Align.LEFT);
            paint.setTextSize(Ui.dp(getContext(), 9));
            paint.setColor(hasValue ? Ui.MUTED : Ui.withAlpha(Ui.MUTED, 120));
            canvas.drawText(LABELS[i], left, y + Ui.dp(getContext(), 3), paint);

            paint.setColor(Ui.withAlpha(Ui.BORDER, 190));
            canvas.drawRoundRect(barLeft, y - Ui.dp(getContext(), 6), barRight,
                    y + Ui.dp(getContext(), 6), Ui.dp(getContext(), 7), Ui.dp(getContext(), 7), paint);
            if (strengths[i] > 0) {
                paint.setColor(COLORS[i]);
                float end = barLeft + (barRight - barLeft) * strengths[i] / 100f;
                canvas.drawRoundRect(barLeft, y - Ui.dp(getContext(), 6), end,
                        y + Ui.dp(getContext(), 6), Ui.dp(getContext(), 7), Ui.dp(getContext(), 7), paint);
            }
            paint.setTextAlign(Paint.Align.RIGHT);
            paint.setTextSize(Ui.dp(getContext(), 10));
            paint.setColor(strengths[i] > 0 ? COLORS[i] : Ui.MUTED);
            canvas.drawText(strengths[i] > 0 ? strengths[i] + "%" : "—",
                    right, y + Ui.dp(getContext(), 3), paint);
        }
    }
}
