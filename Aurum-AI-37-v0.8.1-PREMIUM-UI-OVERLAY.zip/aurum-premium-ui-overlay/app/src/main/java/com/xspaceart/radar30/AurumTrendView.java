package com.xspaceart.radar30;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Curva real de Q e Readiness; não desenha valores artificiais quando ainda não há série. */
public final class AurumTrendView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private List<Integer> qValues = Collections.emptyList();
    private List<Integer> readinessValues = Collections.emptyList();

    public AurumTrendView(Context context) { super(context); }
    public AurumTrendView(Context context, AttributeSet attrs) { super(context, attrs); }

    public void setSeries(List<Integer> qValues, List<Integer> readinessValues) {
        this.qValues = sanitized(qValues);
        this.readinessValues = sanitized(readinessValues);
        setContentDescription("Curva com " + this.qValues.size() + " atualizações do Aurum Lock");
        invalidate();
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(resolveSize(Ui.dp(getContext(), 300), widthMeasureSpec),
                resolveSize(Ui.dp(getContext(), 150), heightMeasureSpec));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float left = Ui.dp(getContext(), 30);
        float right = getWidth() - Ui.dp(getContext(), 10);
        float top = Ui.dp(getContext(), 14);
        float bottom = getHeight() - Ui.dp(getContext(), 26);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Ui.dp(getContext(), 1));
        paint.setColor(Ui.withAlpha(Ui.BORDER, 180));
        for (int value : new int[]{25, 50, 75, 100}) {
            float y = yFor(value, top, bottom);
            canvas.drawLine(left, y, right, y, paint);
        }

        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(Ui.dp(getContext(), 9));
        paint.setTypeface(Typeface.DEFAULT);
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setColor(Ui.MUTED);
        canvas.drawText("100", left - Ui.dp(getContext(), 5), top + Ui.dp(getContext(), 3), paint);
        canvas.drawText("50", left - Ui.dp(getContext(), 5), yFor(50, top, bottom) + Ui.dp(getContext(), 3), paint);
        canvas.drawText("0", left - Ui.dp(getContext(), 5), bottom + Ui.dp(getContext(), 3), paint);

        int count = Math.max(qValues.size(), readinessValues.size());
        if (count < 2) {
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(Ui.dp(getContext(), 11));
            paint.setColor(Ui.MUTED);
            canvas.drawText("A curva aparecerá após duas leituras validadas",
                    (left + right) / 2f, (top + bottom) / 2f, paint);
            drawLegend(canvas, left, bottom);
            return;
        }

        drawSeries(canvas, qValues, count, left, right, top, bottom, Ui.GREEN, Ui.dp(getContext(), 3));
        drawSeries(canvas, readinessValues, count, left, right, top, bottom, Ui.PURPLE, Ui.dp(getContext(), 2));
        drawLegend(canvas, left, bottom);
    }

    private void drawSeries(Canvas canvas, List<Integer> values, int count, float left, float right,
                            float top, float bottom, int color, float stroke) {
        if (values.size() < 2) return;
        path.reset();
        int start = count - values.size();
        for (int i = 0; i < values.size(); i++) {
            float x = left + (right - left) * (start + i) / Math.max(1, count - 1f);
            float y = yFor(values.get(i), top, bottom);
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(stroke);
        paint.setColor(color);
        canvas.drawPath(path, paint);
        int last = values.get(values.size() - 1);
        float x = right;
        float y = yFor(last, top, bottom);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(x, y, Ui.dp(getContext(), 4), paint);
    }

    private void drawLegend(Canvas canvas, float left, float bottom) {
        float y = bottom + Ui.dp(getContext(), 18);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(Ui.dp(getContext(), 9));
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setColor(Ui.GREEN);
        canvas.drawText("● Q ESTRUTURAL", left, y, paint);
        paint.setColor(Ui.PURPLE);
        canvas.drawText("● READINESS", left + Ui.dp(getContext(), 105), y, paint);
    }

    private static float yFor(int value, float top, float bottom) {
        return bottom - (bottom - top) * Math.max(0, Math.min(100, value)) / 100f;
    }

    private static List<Integer> sanitized(List<Integer> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        List<Integer> out = new ArrayList<>();
        for (Integer value : values) {
            if (value != null) out.add(Math.max(0, Math.min(100, value)));
        }
        return Collections.unmodifiableList(out);
    }
}
