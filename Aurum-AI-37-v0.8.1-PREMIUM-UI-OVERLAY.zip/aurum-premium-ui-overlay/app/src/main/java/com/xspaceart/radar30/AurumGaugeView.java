package com.xspaceart.radar30;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/** Gauge leve, desenhado no Canvas, alimentado somente pelo snapshot real do Aurum Lock. */
public final class AurumGaugeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arc = new RectF();
    private int q;
    private int readiness;
    private String state = "IDLE";

    public AurumGaugeView(Context context) { super(context); init(); }
    public AurumGaugeView(Context context, AttributeSet attrs) { super(context, attrs); init(); }

    private void init() {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setContentDescription("Qualidade estrutural Aurum");
    }

    public void setValues(int q, int readiness, String state) {
        this.q = clamp(q);
        this.readiness = clamp(readiness);
        this.state = state == null || state.trim().isEmpty() ? "IDLE" : state.trim();
        setContentDescription("Qualidade estrutural " + this.q
                + " de 100, readiness " + this.readiness + " de 100, estado " + this.state);
        invalidate();
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int desired = Ui.dp(getContext(), 194);
        int width = resolveSize(desired, widthMeasureSpec);
        int height = resolveSize(desired, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float width = getWidth();
        float height = getHeight();
        float size = Math.min(width, height);
        float cx = width / 2f;
        float cy = height / 2f;
        float inset = Ui.dp(getContext(), 18);
        arc.set(cx - size / 2f + inset, cy - size / 2f + inset,
                cx + size / 2f - inset, cy + size / 2f - inset);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(Ui.dp(getContext(), 13));
        paint.setColor(Ui.BORDER);
        paint.clearShadowLayer();
        canvas.drawArc(arc, 135f, 270f, false, paint);

        int qColor = q >= 80 ? Ui.GREEN : q >= 70 ? Ui.GOLD : Ui.CYAN;
        paint.setColor(qColor);
        paint.setShadowLayer(Ui.dp(getContext(), 9), 0, 0, Ui.withAlpha(qColor, 115));
        canvas.drawArc(arc, 135f, 270f * q / 100f, false, paint);
        paint.clearShadowLayer();

        float readinessInset = Ui.dp(getContext(), 38);
        arc.set(cx - size / 2f + readinessInset, cy - size / 2f + readinessInset,
                cx + size / 2f - readinessInset, cy + size / 2f - readinessInset);
        paint.setStrokeWidth(Ui.dp(getContext(), 4));
        paint.setColor(Ui.withAlpha(Ui.PURPLE, 48));
        canvas.drawArc(arc, 135f, 270f, false, paint);
        paint.setColor(Ui.PURPLE);
        canvas.drawArc(arc, 135f, 270f * readiness / 100f, false, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setColor(Ui.TEXT);
        paint.setTextSize(Ui.dp(getContext(), 43));
        canvas.drawText(String.valueOf(q), cx, cy + Ui.dp(getContext(), 8), paint);

        paint.setTextSize(Ui.dp(getContext(), 10));
        paint.setLetterSpacing(0.08f);
        paint.setColor(Ui.MUTED);
        canvas.drawText("STRUCTURAL Q", cx, cy - Ui.dp(getContext(), 31), paint);
        paint.setLetterSpacing(0f);
        paint.setTextSize(Ui.dp(getContext(), 11));
        paint.setColor(Ui.PURPLE);
        canvas.drawText("READINESS " + readiness, cx, cy + Ui.dp(getContext(), 30), paint);
        paint.setTextSize(Ui.dp(getContext(), 10));
        paint.setColor(q >= 80 ? Ui.GREEN : Ui.MUTED);
        canvas.drawText(state, cx, cy + Ui.dp(getContext(), 48), paint);
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }
}
