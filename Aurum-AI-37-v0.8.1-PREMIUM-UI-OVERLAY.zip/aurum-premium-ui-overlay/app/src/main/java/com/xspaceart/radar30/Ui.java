package com.xspaceart.radar30;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public final class Ui {
    public static final int BG = Color.rgb(6, 10, 17);
    public static final int SURFACE = Color.rgb(15, 22, 33);
    public static final int SURFACE_ALT = Color.rgb(20, 29, 43);
    public static final int BORDER = Color.rgb(43, 57, 75);
    public static final int GREEN = Color.rgb(58, 224, 157);
    public static final int GREEN_DARK = Color.rgb(20, 91, 67);
    public static final int AMBER = Color.rgb(246, 190, 74);
    public static final int GOLD = Color.rgb(255, 207, 92);
    public static final int CYAN = Color.rgb(73, 199, 240);
    public static final int PURPLE = Color.rgb(157, 123, 255);
    public static final int RED = Color.rgb(255, 100, 111);
    public static final int TEXT = Color.rgb(246, 248, 252);
    public static final int MUTED = Color.rgb(151, 164, 181);

    private Ui() {}

    public static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    public static TextView text(Context context, String value, float sizeSp, int color, boolean bold) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setLineSpacing(0, 1.12f);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    public static Button button(Context context, String value, int background, int foreground) {
        Button button = new Button(context);
        button.setText(value);
        button.setTextColor(foreground);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setBackground(roundedStroke(background, background == SURFACE ? BORDER : background,
                1, 13, context));
        button.setPadding(dp(context, 14), dp(context, 10), dp(context, 14), dp(context, 10));
        button.setElevation(dp(context, 2));
        return button;
    }

    public static LinearLayout card(Context context) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(context, 16), dp(context, 15), dp(context, 16), dp(context, 15));
        card.setBackground(roundedStroke(SURFACE, BORDER, 1, 18, context));
        card.setElevation(dp(context, 2));
        return card;
    }

    public static TextView pill(Context context, String value, int color) {
        TextView pill = text(context, value, 10, color, true);
        pill.setGravity(android.view.Gravity.CENTER);
        pill.setPadding(dp(context, 10), dp(context, 5), dp(context, 10), dp(context, 5));
        pill.setBackground(roundedStroke(withAlpha(color, 32), withAlpha(color, 128),
                1, 999, context));
        return pill;
    }

    public static TextView sectionLabel(Context context, String value) {
        TextView label = text(context, value, 11, MUTED, true);
        label.setLetterSpacing(0.08f);
        return label;
    }

    public static LinearLayout metric(Context context, String label, String value, int accent) {
        LinearLayout metric = new LinearLayout(context);
        metric.setOrientation(LinearLayout.VERTICAL);
        metric.setPadding(dp(context, 12), dp(context, 10), dp(context, 12), dp(context, 10));
        metric.setBackground(roundedStroke(SURFACE_ALT, BORDER, 1, 14, context));
        metric.addView(text(context, label, 10, MUTED, true));
        metric.addView(text(context, value, 18, accent, true),
                margins(-1, -2, context, 0, 3, 0, 0));
        return metric;
    }

    public static GradientDrawable rounded(int color, int radiusDp, Context context) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(context, radiusDp));
        return drawable;
    }

    public static GradientDrawable roundedStroke(int color, int strokeColor, int strokeDp,
                                                  int radiusDp, Context context) {
        GradientDrawable drawable = rounded(color, radiusDp, context);
        if (strokeDp > 0) drawable.setStroke(dp(context, strokeDp), strokeColor);
        return drawable;
    }

    public static GradientDrawable verticalGradient(int top, int bottom, int strokeColor,
                                                    int radiusDp, Context context) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        drawable.setCornerRadius(dp(context, radiusDp));
        drawable.setStroke(dp(context, 1), strokeColor);
        return drawable;
    }

    public static void tintProgress(ProgressBar bar, int progress, int track) {
        if (bar == null) return;
        bar.setProgressTintList(ColorStateList.valueOf(progress));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(track));
        bar.setIndeterminateTintList(ColorStateList.valueOf(progress));
    }

    public static int withAlpha(int color, int alpha) {
        return Color.argb(Math.max(0, Math.min(255, alpha)), Color.red(color),
                Color.green(color), Color.blue(color));
    }

    public static LinearLayout.LayoutParams margins(int width, int height, Context context,
                                                     int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
        params.setMargins(dp(context, left), dp(context, top), dp(context, right), dp(context, bottom));
        return params;
    }

    public static void setVisible(View view, boolean visible) {
        view.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    public static View spacer(Context context, int heightDp) {
        View view = new View(context);
        view.setLayoutParams(new ViewGroup.LayoutParams(1, dp(context, heightDp)));
        return view;
    }
}
