from pathlib import Path

root = Path(__file__).resolve().parents[1]

gradle = (root / "app/build.gradle").read_text(encoding="utf-8")
state = (root / "app/src/main/java/com/xspaceart/radar30/AppStateStore.java").read_text(encoding="utf-8")
overlay = (root / "app/src/main/java/com/xspaceart/radar30/OverlayController.java").read_text(encoding="utf-8")
service = (root / "app/src/main/java/com/xspaceart/radar30/ScreenCaptureService.java").read_text(encoding="utf-8")
standalone = (root / "app/src/main/java/com/xspaceart/radar30/StandaloneActivity.java").read_text(encoding="utf-8")
integrated = (root / "app/src/main/java/com/xspaceart/radar30/integrated/IntegratedActivity.java").read_text(encoding="utf-8")
snapshot = (root / "app/src/main/java/com/xspaceart/radar30/lock/AurumLockSnapshot.java").read_text(encoding="utf-8")

assert "versionCode 15" in gradle
assert 'versionName "0.8.1-premium-ui"' in gradle
assert 'AURUM_PREMIUM_UI_FLAG = "aurum_premium_ui_v1"' in state
assert "AURUM_VISUAL_FINGERPRINT" in state and "appendSeries" in state
assert "familyStrengths" in snapshot
assert "showAurum" in overlay and "hideByUser" in overlay and '"±2"' in overlay
assert "saveOverlayPosition" in overlay and "showStoredAurum" in overlay
assert "ACTION_TOGGLE_OVERLAY" in service
assert "overlay.showAurum(update, snapshot, accent)" in service
assert "kind == SignalUpdate.Kind.ENTRY\n                || kind == SignalUpdate.Kind.ACTIVE" in service
assert "AurumGaugeView" in standalone and "AurumTrendView" in standalone
assert "AurumFamilyBarsView" in standalone and "buildLegacyUi" in standalone
assert "AurumGaugeView" in integrated and "saveAurumVisualSnapshot" in integrated

manifest = (root / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
assert manifest.count("android.intent.category.LAUNCHER") == 1

print("AURUM_PREMIUM_UI_STATIC=PASS")
print("MINI_BUBBLE=COMPACT_EXPAND_DRAG_HIDE_RESTORE")
print("VISUAL_DATA=REAL_SNAPSHOT_ONLY")
print("PHYSICAL_S25FE=PENDING")
