# AURUM AI 37 v0.9.1 — checkpoint de trabalho

Atualizado em: 2026-09-21

## Objetivo consolidado

Aplicar, juntos e sem alterar contratos ou fórmulas preexistentes:

1. pacote de performance (OCR single-flight, throttle, cache do Hard Expert, UI adaptativa, debounce de estado e Thermal Guard);
2. pacote quantitativo (kernel espacial físico, filtro de entropia/confluência e projeção de 2–3 giros).

## Base de trabalho

- Projeto editável: `aurum-v091-optimized`
- Package Java preservado: `com.xspaceart.radar30`
- Versão de origem: `0.9.1-master-hard-expert-startup-fix`

## Concluído

- Auditoria dos arquivos e contratos principais.
- `ScreenCaptureService.java`:
  - barreira atômica single-flight preservada;
  - throttle mínimo de OCR de 380 ms;
  - `Bitmap` da ROI reciclado em `addOnCompleteListener`;
  - proteção para falha síncrona ao iniciar ML Kit;
  - dois arrays fixos reutilizados na amostragem visual.
- `HardExpertSession.java` e `HardExpertEngine.java`:
  - cache por fingerprint do histórico nos dois níveis;
  - árvore pesada ignorada quando o histórico não muda;
  - sobrecarga explícita `forceRefresh`;
  - correções antigas também são detectadas pelo hash completo.
- `StandaloneActivity.java`:
  - `stateHasChanged` + assinatura semântica do estado;
  - renderização somente após mudança real;
  - loop de 250 ms durante mudança ativa e 600–1000 ms em idle.
- `AppStateStore.java`:
  - lote/debounce de 1200 ms em telemetria de alta frequência;
  - `apply()` mantido em todas as gravações;
  - executor serial daemon e shadow state do OCR para não adicionar latência visual.
- `ThermalPolicy.java` / `ThermalPerformanceController.java`:
  - intervalos normais 350 / 450 / 700 ms para none / moderate / severe+.
- Inteligência quantitativa:
  - kernel físico exponencial e hot clusters de 5–7 bolsões com z-score;
  - entropia/dispersão de 12–18 giros e veto de forte confluência ruidosa;
  - concordância física + terminal/dezena + motor auxiliar;
  - projeção de 2–3 giros, setor prioritário, dois terminais e confiança normalizada.
- Validação estática aprovada.
- Compilação Java 17 de todos os fontes Android contra API 35 aprovada.
- Testes host relevantes e `V091DeepOptimizationTest` aprovados.
- A única falha da suíte ampla (`V075OperationalGateTest`) foi reproduzida sem alterações na base original e não é regressão.

## Próxima ação exata

Trabalho implementado e validado. Para entrega/retomada, usar:

1. `AURUM_V091_ENGINEERING_REPORT.md` — decisões e locais de substituição;
2. `AURUM_V091_PERFORMANCE_AND_QUANT.patch` — patch validado com `patch --dry-run -p1`;
3. `Aurum-AI-37-v0.9.1-performance-quant-source.zip` — pacote dos arquivos completos.

O wrapper não conseguiu baixar Gradle 8.9 por restrição de rede do ambiente. Se houver uma continuação com acesso à distribuição, a única etapa pendente é executar `assembleDebug`; a compilação Java Android completa já passou.

## Regra de continuidade

Não reiniciar do zero. Continuar nesta ordem e preservar todos os recursos existentes.
