# AURUM AI 37 v0.9.1 — checkpoint de trabalho

Atualizado em: 2026-09-21

## Objetivo consolidado

Aplicar, juntos e sem alterar contratos ou fórmulas preexistentes:

1. pacote de performance (OCR single-flight, throttle, cache do Hard Expert, UI adaptativa, debounce de estado e Thermal Guard);
2. pacote quantitativo (kernel espacial físico, filtro de entropia/confluência e projeção de 2–3 giros).

## Base de trabalho

- Projeto editável: `aurum-v091-optimized`
- Package Java preservado: `com.xspaceart.radar30`
- Versão de origem: `0.9.1-master-hard-expert-startup-fix`

## Concluído

- Auditoria dos arquivos e contratos principais.
- `ScreenCaptureService.java`:
  - barreira atômica single-flight preservada;
  - throttle mínimo de OCR de 380 ms;
  - `Bitmap` da ROI reciclado em `addOnCompleteListener`;
  - proteção para falha síncrona ao iniciar ML Kit;
  - dois arrays fixos reutilizados na amostragem visual.
- `HardExpertSession.java` e `HardExpertEngine.java`:
  - cache por fingerprint do histórico nos dois níveis;
  - árvore pesada ignorada quando o histórico não muda;
  - sobrecarga explícita `forceRefresh`;
  - correções antigas também são detectadas pelo hash completo.
- `StandaloneActivity.java`:
  - `stateHasChanged` + assinatura semântica do estado;
  - renderização somente após mudança real;
  - loop de 250 ms durante mudança ativa e 600–1000 ms em idle.
- `AppStateStore.java`:
  - lote/debounce de 1200 ms em telemetria de alta frequência;
  - `apply()` mantido em todas as gravações;
  - executor serial daemon e shadow state do OCR para não adicionar latência visual.
- `ThermalPolicy.java` / `ThermalPerformanceController.java`:
  - intervalos normais 350 / 450 / 700 ms para none / moderate / severe+.
- Inteligência quantitativa:
  - kernel físico exponencial e hot clusters de 5–7 bolsões com z-score;
  - entropia/dispersão de 12–18 giros e veto de forte confluência ruidosa;
  - concordância física + terminal/dezena + motor auxiliar;
  - projeção de 2–3 giros, setor prioritário, dois terminais e confiança normalizada.
- Gates de segurança endurecidos:
  - `FORTE`/`EXTREME` exigem qualidade `>= 80` e confiança `>= 85`;
  - setor rival `>= 45` veta alerta forte e força `OBSERVAÇÃO / DISPERSÃO BIPOLAR`;
  - o status registra `Rival ativo (>45%) - Risco de dispersão oposta`;
  - rival `> 40` limita a projeção recomendada a 2 giros e a validade interna a no máximo 3;
  - divergência entre setor dominante e migração aplica penalidade de 14 pontos;
  - veto de entropia severa permanece obrigatório.
- Validação estática aprovada.
- Compilação Java 17 de todos os fontes Android contra API 35 aprovada.
- Testes host relevantes e `V091DeepOptimizationTest` aprovados.
- A única falha da suíte ampla (`V075OperationalGateTest`) foi reproduzida sem alterações na base original e não é regressão.

## Próxima ação exata

Empacotar a árvore completa, publicar no GitHub e aguardar o workflow Java 17/API 35.
Commit obrigatório desta etapa:

`fix(safety): harden signal fusion gates, require quality>=80, and add rival sector veto`

## Regra de continuidade

Não reiniciar do zero. Continuar nesta ordem e preservar todos os recursos existentes.
