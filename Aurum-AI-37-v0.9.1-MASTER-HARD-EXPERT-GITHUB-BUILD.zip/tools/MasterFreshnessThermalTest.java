import com.xspaceart.radar30.master.SignalFreshnessGate;
import com.xspaceart.radar30.master.ThermalPolicy;

public final class MasterFreshnessThermalTest {
    public static void main(String[] args) {
        staleDataGate();
        unsafeOcrGate();
        thermalGuardPriorities();
        System.out.println("MASTER_FRESHNESS_THERMAL=PASS");
    }

    private static void staleDataGate() {
        long now = 100_000L;
        SignalFreshnessGate.Result fresh = SignalFreshnessGate.evaluate(
                now, now - 200L, now - 30L, true, true, 0.99, "LIVE");
        SignalFreshnessGate.Result stale = SignalFreshnessGate.evaluate(
                now, now - 5_000L, now - 30L, true, true, 0.99, "LIVE");
        require(fresh.fresh, "dados atuais foram bloqueados");
        require(!stale.fresh && stale.label.contains("DESATUALIZADOS"),
                "dado atrasado não bloqueou alerta");
    }

    private static void unsafeOcrGate() {
        long now = 100_000L;
        require(!SignalFreshnessGate.evaluate(now, now, now,
                true, true, 0.40, "LIVE").fresh, "OCR inseguro passou pelo gate");
        require(!SignalFreshnessGate.evaluate(now, now, now,
                true, true, 0.99, "RESYNC").fresh, "resync publicou alerta");
        require(!SignalFreshnessGate.evaluate(now, now, now,
                true, false, 0.99, "LIVE").fresh, "histórico incompleto publicou alerta");
    }

    private static void thermalGuardPriorities() {
        ThermalPolicy normal = ThermalPolicy.forStatus(0);
        ThermalPolicy moderate = ThermalPolicy.forStatus(2);
        ThermalPolicy severe = ThermalPolicy.forStatus(4);
        require(normal.mode == ThermalPolicy.Mode.MAXIMUM && normal.allowAnimations,
                "modo térmico normal incorreto");
        require(moderate.mode == ThermalPolicy.Mode.CONSERVATIVE
                        && moderate.fastFrameIntervalMs < moderate.ocrHeartbeatMs,
                "modo moderado atrasou caminho crítico");
        require(severe.mode == ThermalPolicy.Mode.PROTECTED
                        && !severe.allowAnimations && !severe.allowSecondaryWork,
                "modo quente não cortou trabalho secundário");
        require(severe.fastFrameIntervalMs < severe.normalFrameIntervalMs,
                "captura crítica perdeu prioridade térmica");
    }

    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
