import com.xspaceart.radar30.core.ScanStabilizer;
import com.xspaceart.radar30.core.ScanSynchronizer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class V085CaptureContinuityTest {
    public static void main(String[] args) {
        testJitterConfirmation();
        testRepeatSpin();
        testSingleSpinGuard();
        System.out.println("V085_CAPTURE_CONTINUITY=PASS");
    }

    private static void testJitterConfirmation() {
        ScanStabilizer s = new ScanStabilizer();
        List<Integer> a = list(9,31,5,8,22,14,3,17,20,1,32,6,11,24,35);
        List<Integer> b = new ArrayList<>(a);
        b.set(9, 2); // jitter em célula antiga não pode congelar a atualização.
        require(!s.accept(a), "first frame must wait");
        require(s.accept(b), "second near-identical frame should confirm");
        require(!s.accept(a), "same grid must not emit twice");
    }

    private static void testRepeatSpin() {
        ScanStabilizer s = new ScanStabilizer();
        List<Integer> base = list(9,31,5,8,22,14,3,17,20,1,32,6,11,24,35);
        require(!s.accept(base), "base first");
        require(s.accept(base), "base second");
        // Novo giro também é 9: desloca toda a sequência e precisa ser reconhecido.
        List<Integer> repeat = list(9,9,31,5,8,22,14,3,17,20,1,32,6,11,24);
        require(!s.accept(repeat), "repeat first");
        require(s.accept(repeat), "repeat spin should emit");
    }

    private static void testSingleSpinGuard() {
        ScanSynchronizer sync = new ScanSynchronizer();
        List<Integer> current = list(31,5,8,22,14,3,17,20,1,32,6,11,24,35,7,13,2,28,10,4);
        sync.restore(current);

        List<Integer> rogue = new ArrayList<>();
        rogue.add(9);
        rogue.add(14); // contador espúrio antes do histórico real.
        rogue.addAll(current);
        ScanSynchronizer.MergeResult guarded = sync.merge(rogue, 1);
        require(!guarded.accepted, "LIVE must not accept two apparent new spins");
        require(sync.current().equals(current), "rejected scan mutated history");

        List<Integer> normal = new ArrayList<>();
        normal.add(9);
        normal.addAll(current);
        ScanSynchronizer.MergeResult one = sync.merge(normal, 1);
        require(one.accepted && one.newNumbers.equals(Arrays.asList(9)), "one spin should merge");

        ScanSynchronizer recovery = new ScanSynchronizer();
        recovery.restore(current);
        ScanSynchronizer.MergeResult catchup = recovery.merge(rogue, 12);
        require(catchup.accepted && catchup.newNumbers.size() == 2, "recovery catch-up should stay available");
    }

    private static List<Integer> list(Integer... n) { return Arrays.asList(n); }
    private static void require(boolean c, String m) { if (!c) throw new AssertionError(m); }
}
