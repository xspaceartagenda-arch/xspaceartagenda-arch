import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.master.HardExpertSession;
import com.xspaceart.radar30.master.MasterEvidence;
import com.xspaceart.radar30.master.MasterHistoryIndex;
import com.xspaceart.radar30.master.MasterSignalFusion;
import com.xspaceart.radar30.master.SectorClusterEngine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class V091DeepOptimizationTest {
    public static void main(String[] args) {
        wheelKernelFindsSignificantHotCluster();
        entropyBlocksUniformNoise();
        unchangedHistorySkipsHeavyTreeUnlessForced();
        System.out.println("V091_DEEP_OPTIMIZATION=PASS");
    }

    private static void wheelKernelFindsSignificantHotCluster() {
        MasterHistoryIndex index = indexOf(Arrays.asList(
                21, 4, 19, 15, 32, 21, 4, 19, 15, 32,
                21, 4, 19, 15, 32, 21, 4, 19));
        double[] neutral = new double[37];
        Arrays.fill(neutral, 0.20);
        SectorClusterEngine.Result result = SectorClusterEngine.cluster(neutral, 2, index);
        require(result.wheelKernelApplied, "kernel físico não foi aplicado");
        require(result.primary.members.size() >= 5 && result.primary.members.size() <= 7,
                "hot cluster não possui 5–7 bolsões");
        require(result.primary.statisticallyHot && result.primary.zScore >= 1.35,
                "cluster concentrado não superou a hipótese uniforme");
    }

    private static void entropyBlocksUniformNoise() {
        List<Integer> dispersed = new ArrayList<>();
        for (int i = 0; i < 18; i++) {
            dispersed.add(Wheel.EUROPEAN.get((i * 13) % 37));
        }
        MasterHistoryIndex index = indexOf(dispersed);
        double[] flat = new double[37];
        Arrays.fill(flat, 1.0);
        List<MasterEvidence> evidence = Arrays.asList(
                new MasterEvidence(MasterEvidence.Family.PHYSICAL,
                        "physical", "físico", flat, 0.90, true),
                new MasterEvidence(MasterEvidence.Family.SEQUENTIAL,
                        "sequential", "sequencial", flat, 0.90, true),
                new MasterEvidence(MasterEvidence.Family.NUMERIC,
                        "numeric", "terminal/dezena", flat, 0.90, true));
        MasterSignalFusion.Result result = MasterSignalFusion.fuse(evidence, index);
        require(result.recentEntropy >= 70, "entropia dispersa subestimada");
        require(result.noisePenalty > 0, "ruído uniforme não recebeu penalidade");
        require(!result.strongConfluenceEligible,
                "ruído uniforme liberou forte confluência");
        require(result.protectionTerminals.size() == 2
                        && result.recommendedSpins >= 2 && result.recommendedSpins <= 3,
                "projeção temporal/terminais não foi estruturada");
    }

    private static void unchangedHistorySkipsHeavyTreeUnlessForced() {
        List<Integer> history = Arrays.asList(
                21, 4, 19, 15, 32, 21, 4, 19, 15, 32,
                21, 4, 19, 15, 32, 21, 4, 19, 15, 32);
        HardExpertSession session = new HardExpertSession();
        session.replaceHistory(history);
        int evaluated = session.evaluationCount();
        long now = System.currentTimeMillis();
        session.update(history, Collections.emptyList(), true,
                now, 1.0, "LIVE", null);
        require(session.evaluationCount() == evaluated,
                "histórico idêntico recalculou a árvore pesada");
        session.update(history, Collections.emptyList(), true,
                now, 1.0, "LIVE", null, true);
        require(session.evaluationCount() == evaluated + 1,
                "forceRefresh explícito não reavaliou a árvore");
    }

    private static MasterHistoryIndex indexOf(List<Integer> newestFirst) {
        MasterHistoryIndex index = new MasterHistoryIndex();
        index.rebuildNewestFirst(newestFirst);
        return index;
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
