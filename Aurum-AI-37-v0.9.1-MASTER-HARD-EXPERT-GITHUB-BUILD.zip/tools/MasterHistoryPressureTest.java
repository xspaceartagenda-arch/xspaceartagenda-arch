import com.xspaceart.radar30.master.HardExpertSession;
import com.xspaceart.radar30.master.MasterHistoryIndex;
import com.xspaceart.radar30.master.MasterSignalFusion;
import com.xspaceart.radar30.master.MasterSignalSnapshot;
import com.xspaceart.radar30.master.MicroPressureEngine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class MasterHistoryPressureTest {
    public static void main(String[] args) {
        microWindowThreeSpins();
        risingAndFallingPressure();
        incrementalProcessingAndNoDuplication();
        alertAgeExpires();
        System.out.println("MASTER_HISTORY_PRESSURE=PASS");
    }

    private static void microWindowThreeSpins() {
        MasterHistoryIndex index = new MasterHistoryIndex();
        index.rebuildNewestFirst(list(15, 32, 19));
        MicroPressureEngine.Result micro = MicroPressureEngine.analyze(index);
        require(micro.pressure[15] > 0.60, "microjanela não concentrou no setor recente");
        require(index.windowSize(3) == 3, "janela especial precisa conter três giros");
    }

    private static void risingAndFallingPressure() {
        MasterHistoryIndex rising = new MasterHistoryIndex();
        rising.rebuildNewestFirst(list(15, 32, 19, 24, 16, 33));
        MicroPressureEngine.Result up = MicroPressureEngine.analyze(rising);
        require(up.acceleration >= 58 && "CRESCENTE".equals(up.trend),
                "pressão crescente não detectada: " + up.acceleration);

        MasterHistoryIndex falling = new MasterHistoryIndex();
        falling.rebuildNewestFirst(list(15, 24, 7, 32, 19, 4));
        MicroPressureEngine.Result down = MicroPressureEngine.analyze(falling);
        require(down.acceleration <= 42 && "DECRESCENTE".equals(down.trend),
                "pressão decrescente não detectada: " + down.acceleration);
        require(MasterSignalFusion.temporalAcceleration(80, 60, 35) < 50,
                "fusão temporal deve penalizar queda");
    }

    private static void incrementalProcessingAndNoDuplication() {
        List<Integer> history = new ArrayList<>();
        for (int i = 0; i < 500; i++) history.add(i % 37);
        MasterHistoryIndex index = new MasterHistoryIndex();
        index.rebuildNewestFirst(history);
        require(index.invariantHolds(), "índice inválido após rebuild de 500");
        index.appendNewestFirst(Collections.singletonList(9));
        require(index.size() == 500 && index.invariantHolds(),
                "anel incremental de 500 perdeu invariantes");
        require(index.deltaUpdates() == 1L, "um giro deve gerar exatamente um delta");

        HardExpertSession session = new HardExpertSession();
        List<Integer> base = list(3, 35, 12, 28, 7, 29, 18, 22, 9, 31, 14, 20);
        session.replaceHistory(base);
        int echoCount = session.patternEchoComputationCount();
        MasterSignalSnapshot before = session.snapshot();
        MasterSignalSnapshot unchanged = session.update(base, Collections.emptyList(),
                true, System.currentTimeMillis(), 1.0, "LIVE", null);
        require(before.historyFingerprint == unchanged.historyFingerprint
                        && before.pressure == unchanged.pressure,
                "heartbeat sem giro alterou a análise");
        require(!unchanged.shouldAlert && !unchanged.newEvent,
                "heartbeat sem giro duplicou alerta");
        require(session.patternEchoComputationCount() == echoCount,
                "poll sem giro recalculou Pattern Echo");

        List<Integer> next = new ArrayList<>(base);
        next.add(0, 26);
        session.update(next, Collections.singletonList(26), true,
                System.currentTimeMillis(), 1.0, "LIVE", null);
        require(session.historySize() == base.size() + 1, "delta não entrou no histórico");
        require(session.deltaUpdates() == 1L, "delta duplicado no processamento incremental");
    }

    private static void alertAgeExpires() {
        MasterSignalSnapshot young = snapshotWithAge(4, 1);
        MasterSignalSnapshot old = snapshotWithAge(4, 5);
        require(young.remainingSpins == 3, "idade jovem calculada incorretamente");
        require(old.remainingSpins == 0, "sinal antigo deveria expirar");
    }

    private static MasterSignalSnapshot snapshotWithAge(int validity, int age) {
        return new MasterSignalSnapshot(MasterSignalSnapshot.State.STRONG, 15,
                82, 78, 80, 21, 70, 12, 4, 3, 70,
                validity, age, false, false, false, true, true,
                "CONVERGÊNCIA", "DADOS ATUALIZADOS", "",
                list(32, 15, 19, 4, 21), Collections.emptyList(), 0,
                list(15, 19), list(82, 76), list(60, 70, 82),
                Collections.singletonList("teste"), null,
                1L, 2L, 1L, 3L);
    }

    private static List<Integer> list(Integer... values) { return Arrays.asList(values); }
    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
