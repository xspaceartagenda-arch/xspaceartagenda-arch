import com.xspaceart.radar30.master.ConfigurationQualityEngine;
import com.xspaceart.radar30.master.MasterHistoryIndex;
import com.xspaceart.radar30.master.PatternEchoSnapshot;
import com.xspaceart.radar30.master.PatternEchoSnapshotCache;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class MasterPatternQualityTest {
    public static void main(String[] args) {
        patternEchoOrientation();
        patternEchoCache();
        configurationQualityAndLeakageGuard();
        System.out.println("MASTER_PATTERN_QUALITY=PASS");
    }

    private static void patternEchoOrientation() {
        MasterHistoryIndex index = repeatedPatternIndex();
        List<Integer> chronological = index.chronological(500);
        require(chronological.subList(chronological.size() - 3, chronological.size())
                        .equals(Arrays.asList(1, 2, 3)),
                "orientação cronológica do Pattern Echo invertida");
        PatternEchoSnapshot snapshot = new PatternEchoSnapshotCache().update(index);
        require(snapshot.active, "Pattern Echo deveria estar ativo");
        require(snapshot.primaryProjection == 15 || snapshot.pressureAt(15) > 0.70,
                "follower histórico correto não foi projetado");
    }

    private static void patternEchoCache() {
        MasterHistoryIndex index = repeatedPatternIndex();
        PatternEchoSnapshotCache cache = new PatternEchoSnapshotCache();
        PatternEchoSnapshot first = cache.update(index);
        PatternEchoSnapshot same = cache.update(index);
        require(first == same && cache.computationCount() == 1,
                "cache recalculou sem mudança de histórico");
        index.appendNewestFirst(Collections.singletonList(4));
        cache.update(index);
        require(cache.computationCount() == 2,
                "cache não recalculou após novo giro");
    }

    private static void configurationQualityAndLeakageGuard() {
        MasterHistoryIndex index = repeatedPatternIndex();
        ConfigurationQualityEngine.Result good = ConfigurationQualityEngine.evaluate(
                index, Collections.singletonList(15), 4, 4, 90, 0);
        ConfigurationQualityEngine.Result bad = ConfigurationQualityEngine.evaluate(
                index, Collections.singletonList(24), 4, 4, 90, 0);
        require(good.historicalSamples >= 5 && good.outOfSampleReady,
                "amostra histórica fora da amostra não preparada");
        require(good.score > bad.score,
                "qualidade não distinguiu configuração historicamente coerente");
        require(good.matchingFollowers <= good.historicalSamples,
                "leakage futuro contaminou seguidores");
    }

    private static MasterHistoryIndex repeatedPatternIndex() {
        List<Integer> chronological = new ArrayList<>();
        for (int i = 0; i < 18; i++) {
            chronological.add(1); chronological.add(2); chronological.add(3); chronological.add(15);
        }
        chronological.add(1); chronological.add(2); chronological.add(3);
        List<Integer> newest = new ArrayList<>();
        for (int i = chronological.size() - 1; i >= 0; i--) newest.add(chronological.get(i));
        MasterHistoryIndex index = new MasterHistoryIndex();
        index.rebuildNewestFirst(newest);
        return index;
    }

    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
