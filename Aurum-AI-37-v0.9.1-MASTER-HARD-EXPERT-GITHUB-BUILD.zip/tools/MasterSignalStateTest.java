import com.xspaceart.radar30.master.HardExpertSession;
import com.xspaceart.radar30.master.MasterSignalSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class MasterSignalStateTest {
    public static void main(String[] args) {
        selectiveStateProgression();
        staleSignalCannotAlert();
        System.out.println("MASTER_SIGNAL_STATES=PASS");
    }

    private static void selectiveStateProgression() {
        List<Integer> chronological = new ArrayList<>();
        int[] learned = {32, 15, 19, 4, 21, 15, 19, 4};
        for (int cycle = 0; cycle < 55; cycle++) {
            for (int number : learned) chronological.add(number);
        }
        List<Integer> newest = reverse(chronological);
        HardExpertSession session = new HardExpertSession();
        MasterSignalSnapshot snapshot = session.replaceHistory(newest);
        boolean sawHeating = snapshot.state == MasterSignalSnapshot.State.HEATING
                || snapshot.state == MasterSignalSnapshot.State.MODERATE
                || snapshot.strongOrExtreme();
        boolean sawStrong = snapshot.strongOrExtreme();
        int[] continuation = {21, 4, 19, 15, 32, 21, 4, 19, 15, 32, 21, 4};
        for (int number : continuation) {
            newest.add(0, number);
            snapshot = session.update(newest, Collections.singletonList(number),
                    true, System.currentTimeMillis(), 1.0, "LIVE", null);
            sawHeating |= snapshot.state == MasterSignalSnapshot.State.HEATING
                    || snapshot.state == MasterSignalSnapshot.State.MODERATE
                    || snapshot.strongOrExtreme();
            sawStrong |= snapshot.strongOrExtreme();
        }
        require(sawHeating, "histórico convergente não iniciou aquecimento");
        require(sawStrong, "histórico convergente persistente nunca atingiu FORTE");
        require(snapshot.pressureSeries.size() <= 5, "curva antecipada excedeu cinco giros");
    }

    private static void staleSignalCannotAlert() {
        HardExpertSession session = new HardExpertSession();
        List<Integer> history = new ArrayList<>();
        for (int i = 0; i < 90; i++) history.add(i % 5 == 0 ? 15 : (i * 7) % 37);
        session.replaceHistory(history);
        MasterSignalSnapshot blocked = session.blockDataQuality("captura atrasada");
        require(blocked.state == MasterSignalSnapshot.State.BLOCKED,
                "dado atrasado não entrou em BLOQUEADA");
        require(blocked.stale && !blocked.shouldAlert,
                "alerta forte sobreviveu ao veto de frescor");
    }

    private static List<Integer> reverse(List<Integer> chronological) {
        List<Integer> newest = new ArrayList<>();
        for (int i = chronological.size() - 1; i >= 0; i--) newest.add(chronological.get(i));
        return newest;
    }

    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
