#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def read(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        raise AssertionError(f"missing: {relative}")
    return path.read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


build = read("app/build.gradle")
service = read("app/src/main/java/com/xspaceart/radar30/ScreenCaptureService.java")
activity = read("app/src/main/java/com/xspaceart/radar30/StandaloneActivity.java")
state = read("app/src/main/java/com/xspaceart/radar30/AppStateStore.java")
session = read("app/src/main/java/com/xspaceart/radar30/master/HardExpertSession.java")
index = read("app/src/main/java/com/xspaceart/radar30/master/MasterHistoryIndex.java")
engine = read("app/src/main/java/com/xspaceart/radar30/master/HardExpertEngine.java")
echo = read("app/src/main/java/com/xspaceart/radar30/master/PatternEchoSnapshotCache.java")
ledger = read("app/src/main/java/com/xspaceart/radar30/MasterAlertLedger.java")

require("applicationId 'com.xspaceart.aurumai37.integratedlab'" in build,
        "package continuity broken")
require("versionCode 22" in build and 'versionName "0.9.1-master-hard-expert-startup-fix"' in build,
        "master version missing")
require((ROOT / "keystore/aurum-integrated.jks").is_file(), "stable keystore missing")

for name in (
    "HardExpertEngine", "MicroPressureEngine", "SpatialPressureEngine",
    "SectorClusterEngine", "PressureMigrationTracker", "DualPressureDetector",
    "ConfigurationQualityEngine", "SignalFreshnessGate", "PatternEchoSnapshot",
    "ThermalPolicy", "MasterSignalFusion", "MasterHistoryIndex",
):
    require((ROOT / f"app/src/main/java/com/xspaceart/radar30/master/{name}.java").is_file(),
            f"architecture class missing: {name}")

for window in ("3", "5", "10", "30", "60", "150", "500"):
    require(window in index, f"history window missing: {window}")
require("CAPACITY = 500" in index and "appendNewestFirst" in index,
        "incremental 500-spin index missing")
require("newest-first" in index and "oldest-first" in index,
        "history orientation contract missing")
require("index.chronological" in echo and "cachedFingerprint" in echo,
        "Pattern Echo orientation/cache missing")
require("if (fingerprint == cachedFingerprint) return cached" in echo,
        "Pattern Echo recalculates unchanged history")

require("imageRoiToBitmap(image, roi)" in service,
        "OCR hot path does not use direct ROI")
hot = service[service.index("// Caminho quente"):service.index("private void requestAutomaticResync")]
require("imageToBitmap(image)" not in hot,
        "full-screen bitmap present in OCR hot path")
require("ACTION_CAPTURE_PREVIEW" in service and "capturePreviewRequested" in service,
        "explicit full-screen calibration preview missing")
require("ThermalPerformanceController" in service and "thermal.ocrHeartbeatMs" in service,
        "thermal adaptive capture missing")
require("ocrBusy.compareAndSet(false, true)" in service,
        "OCR anti-backlog guard missing")

for token in ("SILENCE", "HEATING", "MODERATE", "STRONG", "EXTREME", "BLOCKED"):
    require(token in read("app/src/main/java/com/xspaceart/radar30/master/MasterSignalSnapshot.java"),
            f"pressure state missing: {token}")
require("quality.score < 45" in engine and "dual.dual" in engine,
        "configuration quality/rival veto missing")
require("dependencyGroup" in read("app/src/main/java/com/xspaceart/radar30/master/MasterSignalFusion.java"),
        "evidence deduplication missing")
require("PRESSÃO MIGRANDO" in service and "DUPLA PRESSÃO" in service,
        "migration/dual presentation missing")
require("Score interno; não representa probabilidade matemática" in service,
        "probability disclaimer missing")

for token in ("PATTERN ECHO", "DADOS DESATUALIZADOS", "NÃO CONSIDERAR ALERTA",
              "Último giro detectado", "idade da análise", "THERMAL GUARD"):
    require(token in activity, f"main UI field missing: {token}")
require("playMaster" in service and "PRESSÃO EXTREMA" in activity,
        "strong/extreme alert path missing")
require("masterSoundEnabled" in state and "thermalUiRefreshMs" in state,
        "master preferences missing")

for round_number in range(1, 6):
    require('"result_after_" + round' in ledger,
            f"result tracking missing for round {round_number}")
require('event.put("closed", round >= 5)' in ledger,
        "alert ledger does not retain five-spin outcome")
require("outOfSampleReady" in engine and "history_fingerprint" in ledger,
        "out-of-sample calibration preparation missing")

required_tests = (
    "MasterHistoryPressureTest.java", "MasterSpatialFusionTest.java",
    "MasterPatternQualityTest.java", "MasterFreshnessThermalTest.java",
    "MasterSignalStateTest.java",
    "V085CaptureContinuityTest.java", "V085CpeActiveFusionTest.java",
    "AurumLockCoreTest.java", "V0712PatternEchoTest.java",
)
for test in required_tests:
    require((ROOT / "tools" / test).is_file(), f"test missing: {test}")

require("lastEvaluatedHistoryHash" in session and "forceRefresh" in session
        and "!forceRefresh && !historyChanged" in session,
        "unchanged history cache/forceRefresh contract missing")
require("MIN_OCR_DISPATCH_INTERVAL_MS = 380L" in service
        and "addOnCompleteListener" in service
        and "VISUAL_SAMPLE_COUNT" in service,
        "OCR throttle/recycle/reusable visual buffers missing")
fusion = read("app/src/main/java/com/xspaceart/radar30/master/MasterSignalFusion.java")
sector = read("app/src/main/java/com/xspaceart/radar30/master/SectorClusterEngine.java")
require("NoiseProfile" in fusion and "strongConfluenceEligible" in fusion,
        "entropy/confluence gate missing")
require("HOT_Z_THRESHOLD" in sector and "RECENCY_HALF_LIFE" in sector,
        "wheel spatial kernel/significance missing")
require("projeção temporal" in engine and "índice normalizado de confluência" in engine,
        "multi-round projection/confidence output missing")
require("MIN_STRONG_QUALITY = 80" in fusion
        and "MIN_STRONG_CONFIDENCE = 85" in fusion,
        "strict quality/confidence gates missing")
require("RIVAL_STRONG_VETO = 45" in fusion
        and "Rival ativo (>45%) - Risco de dispersão oposta" in fusion
        and "OBSERVAÇÃO / DISPERSÃO BIPOLAR" in fusion,
        "bipolar rival veto/status missing")
require("rivalVetoActive" in fusion and "entropyBlocked" in fusion
        and "evaluateStrongGate" in fusion,
        "centralized strong safety gate missing")
require("migrationDivergencePenalty" in engine
        and "migrationDivergesFromDominantSector" in engine,
        "dominant-sector/migration divergence penalty missing")
require("RIVAL_PROJECTION_LIMIT" in engine and "Math.min(validity, 3)" in engine,
        "rival-aware validity cap missing")

print("MASTER_HARD_EXPERT_STATIC=PASS")
print("PACKAGE_CONTINUITY=PASS")
print("DIRECT_ROI_CAPTURE=PASS")
print("PATTERN_ECHO_ORIENTATION_CACHE=PASS")
print("THERMAL_GUARD=PASS")
print("ANDROID16_BASE_GUARDS=PRESERVED")
