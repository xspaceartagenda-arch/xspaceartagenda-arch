import com.xspaceart.radar30.cpe.ConditionalPredictionEngine;
import com.xspaceart.radar30.cpe.ConditionalPredictionSnapshot;
import com.xspaceart.radar30.lock.IncrementalAurumIndex;

import java.util.ArrayList;
import java.util.List;

public final class V084ConditionalPredictionTest {
    public static void main(String[] args) {
        List<Integer> chronological = new ArrayList<>();
        int[] seed = {8,5,31,14,21,2,17,11,25,4,32,8,5,1,20,21,17,31,25,2};
        for (int i = 0; i < 18; i++) {
            for (int v : seed) chronological.add(v);
            chronological.add((i * 7) % 37);
        }
        // termina em família terminal 1 para exercitar terminal->próximo.
        chronological.add(8); chronological.add(5); chronological.add(1);

        IncrementalAurumIndex index = new IncrementalAurumIndex(500);
        List<Integer> newest = new ArrayList<>();
        for (int i = chronological.size() - 1; i >= 0; i--) newest.add(chronological.get(i));
        index.rebuildNewestFirst(newest);
        long fp = index.deterministicFingerprint();

        ConditionalPredictionSnapshot a = ConditionalPredictionEngine.analyze(index);
        ConditionalPredictionSnapshot b = ConditionalPredictionEngine.analyze(index);
        require(a.available(), "CPE unavailable");
        require(a.topNumbers.size() == 5 && a.topScores.size() == 5, "top5 missing");
        require(a.primarySector.size() == 5 && a.secondarySector.size() == 5, "sector size");
        require(a.primaryTerminal >= 0 && a.primaryTerminal <= 9, "terminal invalid");
        require(a.sampleQuality > 0, "sample quality missing");
        for (int i = 1; i < a.topScores.size(); i++) {
            require(a.topScores.get(i - 1) >= a.topScores.get(i), "ranking not sorted");
        }
        require(a.topNumbers.equals(b.topNumbers) && a.topScores.equals(b.topScores), "not deterministic");
        require(index.deterministicFingerprint() == fp, "CPE mutated history");
        require(a.available(), "CPE compatibility snapshot unavailable");
        System.out.println("V084_CPE=PASS top=" + a.topNumbers + " scores=" + a.topScores
                + " sector=" + a.primarySector + " T" + a.primaryTerminal
                + " sample=" + a.sampleQuality);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
