import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.master.DualPressureDetector;
import com.xspaceart.radar30.master.MasterEvidence;
import com.xspaceart.radar30.master.MasterSignalFusion;
import com.xspaceart.radar30.master.PressureMigrationTracker;
import com.xspaceart.radar30.master.SectorClusterEngine;
import com.xspaceart.radar30.master.SpatialPressureEngine;

import java.util.Arrays;

public final class MasterSpatialFusionTest {
    public static void main(String[] args) {
        spatialDensityAndSectorGrouping();
        dualPressureAndRivalVeto();
        sameSectorMigration();
        evidenceDeduplication();
        System.out.println("MASTER_SPATIAL_FUSION=PASS");
    }

    private static void spatialDensityAndSectorGrouping() {
        double[] raw = new double[37];
        raw[15] = 0.72; raw[21] = 0.70; raw[2] = 0.68; raw[4] = 0.66;
        SpatialPressureEngine.Result spread = SpatialPressureEngine.spread(raw);
        SectorClusterEngine.Result sectors = SectorClusterEngine.cluster(
                spread.pressure, spread.adaptiveRadius);
        require(sectors.primary.members.contains(15), "setor não contém 15");
        require(sectors.primary.members.contains(21) || sectors.primary.members.contains(4),
                "densidade física próxima não foi agrupada");
        require(sectors.primary.score >= 60, "pressão regional ficou fraca demais");
    }

    private static void dualPressureAndRivalVeto() {
        double[] twoPoles = new double[37];
        addPole(twoPoles, 15, 1.00);
        addPole(twoPoles, 24, 0.98);
        SectorClusterEngine.Result sectors = SectorClusterEngine.cluster(twoPoles, 2);
        DualPressureDetector.Result dual = DualPressureDetector.detect(
                sectors.primary, sectors.secondary);
        require(dual.dual, "dois polos separados e equivalentes não detectados");
        require(dual.conflict >= 40, "veto rival não elevou conflito");
        require(dual.gap <= 10, "polos equivalentes produziram gap excessivo");
    }

    private static void sameSectorMigration() {
        PressureMigrationTracker tracker = new PressureMigrationTracker();
        SectorClusterEngine.Cluster a = clusterAt(21);
        SectorClusterEngine.Cluster b = clusterAt(15);
        SectorClusterEngine.Cluster c = clusterAt(32);
        require(!tracker.update(a).migrating, "primeira leitura não pode migrar");
        PressureMigrationTracker.Result second = tracker.update(b);
        PressureMigrationTracker.Result third = tracker.update(c);
        require(second.migrating && third.migrating,
                "migração dentro da mesma região reiniciou leitura");
        require(third.persistence == 3, "persistência regional não foi mantida");
    }

    private static void evidenceDeduplication() {
        double[] p = new double[37]; p[15] = 1.0;
        double[] q = new double[37]; q[15] = 0.8; q[24] = 0.2;
        MasterEvidence weakDuplicate = new MasterEvidence(MasterEvidence.Family.PHYSICAL,
                "same-source", "duplicada fraca", q, 0.40, true);
        MasterEvidence strongDuplicate = new MasterEvidence(MasterEvidence.Family.PHYSICAL,
                "same-source", "duplicada forte", p, 0.90, true);
        MasterEvidence independent = new MasterEvidence(MasterEvidence.Family.SEQUENTIAL,
                "transition", "transição", p, 0.90, true);
        MasterSignalFusion.Result result = MasterSignalFusion.fuse(
                Arrays.asList(weakDuplicate, strongDuplicate, independent));
        require(result.deduplicatedEvidenceCount == 2,
                "mesma evidência foi contada duas vezes");
        require(result.independentReadings == 2,
                "leituras independentes incorretas após deduplicação");
    }

    private static SectorClusterEngine.Cluster clusterAt(int number) {
        double[] pressure = new double[37];
        addPole(pressure, number, 1.0);
        return SectorClusterEngine.cluster(pressure, 2).primary;
    }

    private static void addPole(double[] pressure, int center, double strength) {
        for (int n : Wheel.coverage(center, 2)) {
            int d = Wheel.distance(center, n);
            pressure[n] = Math.max(pressure[n], strength * (d == 0 ? 1.0 : d == 1 ? 0.88 : 0.72));
        }
    }

    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
