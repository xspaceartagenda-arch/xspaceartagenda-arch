import com.xspaceart.radar30.cpe.ConditionalPredictionEngine;
import com.xspaceart.radar30.cpe.ConditionalPredictionSnapshot;
import com.xspaceart.radar30.lock.AurumLockConfig;
import com.xspaceart.radar30.lock.AurumLockEngine;
import com.xspaceart.radar30.lock.AurumLockSnapshot;
import com.xspaceart.radar30.lock.IncrementalAurumIndex;
import com.xspaceart.radar30.lock.AurumLockEngine.TemporalContext;

import java.util.ArrayList;
import java.util.List;

public final class V085CpeActiveFusionTest {
    public static void main(String[] args) {
        List<Integer> chronological = new ArrayList<>();
        int[] seed = {8,5,31,14,21,2,17,11,25,4,32,8,5,1,20,21,17,31,25,2};
        for (int i = 0; i < 18; i++) {
            for (int v : seed) chronological.add(v);
            chronological.add((i * 7) % 37);
        }
        chronological.add(8); chronological.add(5); chronological.add(1);
        List<Integer> newest = new ArrayList<>();
        for (int i = chronological.size() - 1; i >= 0; i--) newest.add(chronological.get(i));

        IncrementalAurumIndex index = new IncrementalAurumIndex(500);
        index.rebuildNewestFirst(newest);
        ConditionalPredictionSnapshot cpe = ConditionalPredictionEngine.analyze(index);
        require(cpe.available(), "CPE unavailable");
        require(!cpe.shadow, "CPE must be active in v0.8.5");
        double max = 0.0;
        for (int n = 0; n < 37; n++) max = Math.max(max, cpe.pressureAt(n));
        require(max > 0.99, "full pressure vector missing");

        AurumLockEngine engine = new AurumLockEngine(AurumLockConfig.defaults());
        AurumLockSnapshot snap = engine.analyze(index, TemporalContext.empty(), true, "TEST", true);
        boolean activeReason = false;
        for (String r : snap.reasons) if (r.contains("CPE ATIVO")) activeReason = true;
        require(activeReason, "active CPE provenance missing");
        require(snap.conditionalPrediction.available() && !snap.conditionalPrediction.shadow,
                "snapshot did not preserve active CPE");
        System.out.println("V085_CPE_ACTIVE=PASS target=" + snap.target
                + " cpe=" + cpe.topNumbers + " sample=" + cpe.sampleQuality);
    }

    private static void require(boolean c, String m) { if (!c) throw new AssertionError(m); }
}
