# Aurum AI 37 v0.9.1 — pacote consolidado

## Resultado

Foram aplicados conjuntamente o pacote de eficiência térmica/latência e o pacote quantitativo de confluência. Os contratos existentes de CPE, Aurum Lock, Pattern Echo, Hard Expert, entrada manual, histórico e UI foram mantidos.

Importante: o campo `modelConfidence` continua sendo um índice normalizado de concordância interna (0–100), não uma probabilidade de vitória. Uma roleta fisicamente independente não se torna previsível por observar resultados anteriores.

## Arquivos alterados e local exato

Substitua os arquivos completos nos mesmos caminhos ou aplique `AURUM_V091_PERFORMANCE_AND_QUANT.patch` na raiz do projeto.

| Arquivo | Alteração |
| --- | --- |
| `app/src/main/java/com/xspaceart/radar30/ScreenCaptureService.java` | OCR single-flight, throttle de 380 ms, recycle único em `addOnCompleteListener`, buffers visuais fixos |
| `app/src/main/java/com/xspaceart/radar30/master/HardExpertSession.java` | cache de fingerprint e sobrecarga `forceRefresh` |
| `app/src/main/java/com/xspaceart/radar30/master/HardExpertEngine.java` | cache defensivo, gate de ruído, confiança normalizada e projeção 2–3 giros |
| `app/src/main/java/com/xspaceart/radar30/StandaloneActivity.java` | `stateHasChanged`, assinatura semântica e ticker 250/600–1000 ms |
| `app/src/main/java/com/xspaceart/radar30/AppStateStore.java` | debounce de 1200 ms, executor serial e somente `apply()` |
| `app/src/main/java/com/xspaceart/radar30/ThermalPerformanceController.java` | política térmica aplicada dinamicamente pelo listener |
| `app/src/main/java/com/xspaceart/radar30/master/ThermalPolicy.java` | captura normal em 350/450/700 ms |
| `app/src/main/java/com/xspaceart/radar30/master/SectorClusterEngine.java` | Wheel Spatial Kernel e hot clusters significativos de 5–7 bolsões |
| `app/src/main/java/com/xspaceart/radar30/master/MasterSignalFusion.java` | entropia/dispersão, concordância tripla e terminais de proteção |

Também foram adicionados `tools/V091DeepOptimizationTest.java` e verificações estáticas correspondentes.

## Modelo quantitativo acrescentado

Para o giro de offset `t`, o peso de recência é:

`w(t) = 2^(-t/6)`

A densidade sobre a distância física `d` no cilindro europeu usa:

`K(d) = exp(-d/1.55)`

Para um cluster de `k` bolsões, a hipótese uniforme usa `p = k/37`. A significância é calculada com erro-padrão ponderado pelos pesos de recência; o cluster é marcado como quente quando possui amostra efetiva mínima e `z >= 1.35`.

O filtro de ruído combina entropia de Shannon normalizada em 12 setores angulares e distância física média nos últimos 12–18 giros. Uma leitura FORTE/EXTREMA exige simultaneamente:

1. densidade física coerente;
2. alinhamento de terminal/dezena ou sequência;
3. suporte do motor físico auxiliar;
4. ausência de dispersão aleatória elevada.

A saída enriquecida inclui setor prioritário, dois terminais de proteção, janela recomendada de 2–3 giros e índice normalizado de confluência.

## Verificação executada

- Compilação Java 17 de todos os fontes Android contra Android API 35: aprovada.
- Validação estática Master Hard Expert: aprovada.
- 30 testes host executados; todos os testes ligados às alterações passaram.
- Novo `V091DeepOptimizationTest`: aprovado.
- `V075OperationalGateTest` continua falhando de forma idêntica na base original, portanto não é regressão deste pacote.
- O `assembleDebug` pelo wrapper não pôde baixar a distribuição Gradle 8.9 no ambiente sem acesso a `services.gradle.org`; a compilação integral dos fontes Java Android foi realizada como verificação substituta.

## Checkpoint

`AURUM_V091_WORK_CHECKPOINT.md` contém o estado de retomada e deve ser atualizado se houver uma nova rodada de trabalho.
