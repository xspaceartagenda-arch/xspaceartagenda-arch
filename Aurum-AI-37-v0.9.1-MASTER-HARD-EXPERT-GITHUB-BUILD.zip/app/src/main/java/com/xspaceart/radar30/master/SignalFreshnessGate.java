package com.xspaceart.radar30.master;

/** Bloqueio absoluto de alerta forte quando captura ou análise já estão atrasadas. */
public final class SignalFreshnessGate {
    public static final long MAX_CAPTURE_AGE_MS = 4_500L;
    public static final long MAX_ANALYSIS_AGE_MS = 2_500L;

    private SignalFreshnessGate() {}

    public static Result evaluate(long nowMs, long capturedAtMs, long analyzedAtMs,
                                  boolean dataQualityValid, boolean historyComplete,
                                  double ocrConfidence, String captureStatus) {
        long captureAge = capturedAtMs <= 0L ? Long.MAX_VALUE : Math.max(0L, nowMs - capturedAtMs);
        long analysisAge = analyzedAtMs <= 0L ? Long.MAX_VALUE : Math.max(0L, nowMs - analyzedAtMs);
        String status = captureStatus == null ? "" : captureStatus.trim().toUpperCase();
        String reason = "";
        if (!dataQualityValid) reason = "qualidade de dados rejeitada";
        else if (!historyComplete) reason = "histórico incompleto";
        else if (ocrConfidence < 0.55) reason = "OCR inseguro";
        else if (captureAge > MAX_CAPTURE_AGE_MS) reason = "captura atrasada";
        else if (analysisAge > MAX_ANALYSIS_AGE_MS) reason = "análise antiga";
        else if (status.contains("ERRO") || status.contains("RESYNC")
                || status.contains("PARADO")) reason = "captura fora de LIVE";
        boolean fresh = reason.isEmpty();
        return new Result(fresh, captureAge, analysisAge,
                fresh ? "DADOS ATUALIZADOS" : "DADOS DESATUALIZADOS • " + reason);
    }

    public static final class Result {
        public final boolean fresh;
        public final long captureAgeMs;
        public final long analysisAgeMs;
        public final String label;

        Result(boolean fresh, long captureAgeMs, long analysisAgeMs, String label) {
            this.fresh = fresh;
            this.captureAgeMs = captureAgeMs;
            this.analysisAgeMs = analysisAgeMs;
            this.label = label;
        }
    }
}
