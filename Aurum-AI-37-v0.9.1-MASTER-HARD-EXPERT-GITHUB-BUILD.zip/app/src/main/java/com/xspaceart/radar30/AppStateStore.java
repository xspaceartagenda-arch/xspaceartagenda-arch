package com.xspaceart.radar30;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.RectF;

import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.core.CurrentTableHistory;
import com.xspaceart.radar30.lock.AurumLockConfig;
import com.xspaceart.radar30.lock.AurumLockSnapshot;
import com.xspaceart.radar30.master.MasterSignalSnapshot;
import com.xspaceart.radar30.master.ThermalPolicy;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public final class AppStateStore {
    private static final String PREFS = "radar30_state";
    private static final String CALIBRATED = "calibrated";
    private static final String ROI_LEFT = "roi_left";
    private static final String ROI_TOP = "roi_top";
    private static final String ROI_RIGHT = "roi_right";
    private static final String ROI_BOTTOM = "roi_bottom";
    private static final String ROI_REVISION = "roi_revision";
    private static final String HISTORY = "history";
    private static final String HISTORY_SESSION = "history_session";
    private static final String STATUS = "status";
    private static final String SIGNAL = "signal";
    private static final String VOICE = "voice";
    private static final String CONSERVATIVE = "conservative";
    private static final String PROVIDER = "provider";
    private static final String DEALER = "dealer";
    private static final String OCR_SNAPSHOT = "ocr_snapshot";
    private static final String OCR_SNAPSHOT_AT = "ocr_snapshot_at";
    private static final String OCR_SCAN_COUNT = "ocr_scan_count";
    private static final String CAPTURE_ACTIVE = "capture_active";
    private static final String CAPTURE_HEALTH = "capture_health";
    private static final String CAPTURE_HEALTH_DETAIL = "capture_health_detail";
    private static final String CAPTURE_HEALTH_AT = "capture_health_at";
    private static final String CAPTURE_RECOVERED = "capture_recovered_spins";
    private static final String RADAR_SCORE = "radar_score";
    private static final String RADAR_FAMILIES = "radar_families";
    private static final String RADAR_DECISION = "radar_decision";
    private static final String RADAR_TARGET = "radar_target";
    private static final String RADAR_PLAY_LABEL = "radar_play_label";
    private static final String RADAR_HEADLINE = "radar_headline";
    private static final String RADAR_DETAIL = "radar_detail";
    private static final String RADAR_REASONS = "radar_reasons";
    private static final String RADAR_UPDATED_AT = "radar_updated_at";
    private static final String RADAR_FOCUS = "radar_focus";
    private static final String RADAR_SECTORS = "radar_sectors";
    private static final String RADAR_HEAT = "radar_heat";
    private static final String RADAR_FAMILY_DETAIL = "radar_family_detail";
    private static final String RADAR_GATE = "radar_gate";
    private static final String RADAR_EARLY_TOUCH = "radar_early_touch";
    private static final String RADAR_EARLY_TOUCH_AT = "radar_early_touch_at";
    private static final String AURUM_READINESS = "aurum_readiness";
    private static final String AURUM_REGIME = "aurum_regime";
    private static final String AURUM_STATE = "aurum_readiness_state";
    private static final String AURUM_LOCK_MODE = "aurum_lock_mode";
    private static final String AURUM_RUNNER = "aurum_runner";
    private static final String AURUM_MARGIN = "aurum_margin";
    private static final String AURUM_ACTIVE_REMAINING = "aurum_active_remaining";
    private static final String AURUM_COVERAGE = "aurum_coverage";
    private static final String AURUM_FAMILY_STRENGTHS = "aurum_family_strengths";
    private static final String AURUM_Q_SERIES = "aurum_q_series";
    private static final String AURUM_READINESS_SERIES = "aurum_readiness_series";
    private static final String AURUM_VISUAL_FINGERPRINT = "aurum_visual_fingerprint";
    private static final String AURUM_CPE_TOP_NUMBERS = "aurum_cpe_top_numbers";
    private static final String AURUM_CPE_TOP_SCORES = "aurum_cpe_top_scores";
    private static final String AURUM_CPE_PRIMARY_SECTOR = "aurum_cpe_primary_sector";
    private static final String AURUM_CPE_PRIMARY_SECTOR_SCORE = "aurum_cpe_primary_sector_score";
    private static final String AURUM_CPE_SECONDARY_SECTOR = "aurum_cpe_secondary_sector";
    private static final String AURUM_CPE_SECONDARY_SECTOR_SCORE = "aurum_cpe_secondary_sector_score";
    private static final String AURUM_CPE_PRIMARY_TERMINAL = "aurum_cpe_primary_terminal";
    private static final String AURUM_CPE_PRIMARY_TERMINAL_SCORE = "aurum_cpe_primary_terminal_score";
    private static final String AURUM_CPE_SECONDARY_TERMINAL = "aurum_cpe_secondary_terminal";
    private static final String AURUM_CPE_SECONDARY_TERMINAL_SCORE = "aurum_cpe_secondary_terminal_score";
    private static final String AURUM_CPE_GAP = "aurum_cpe_gap";
    private static final String AURUM_CPE_SAMPLE = "aurum_cpe_sample";
    private static final String AURUM_CPE_DRIVERS = "aurum_cpe_drivers";
    private static final String MASTER_STATE = "master_state";
    private static final String MASTER_PRESSURE = "master_pressure";
    private static final String MASTER_QUALITY = "master_configuration_quality";
    private static final String MASTER_CONFIDENCE = "master_model_confidence";
    private static final String MASTER_TARGET = "master_target";
    private static final String MASTER_RIVAL = "master_rival";
    private static final String MASTER_RIVAL_PRESSURE = "master_rival_pressure";
    private static final String MASTER_GAP = "master_gap";
    private static final String MASTER_INDEPENDENT = "master_independent";
    private static final String MASTER_PERSISTENCE = "master_persistence";
    private static final String MASTER_ACCELERATION = "master_acceleration";
    private static final String MASTER_VALIDITY = "master_validity";
    private static final String MASTER_AGE = "master_age";
    private static final String MASTER_REMAINING = "master_remaining";
    private static final String MASTER_DUAL = "master_dual";
    private static final String MASTER_MIGRATING = "master_migrating";
    private static final String MASTER_STALE = "master_stale";
    private static final String MASTER_REGIME = "master_regime";
    private static final String MASTER_FRESHNESS = "master_freshness";
    private static final String MASTER_BLOCK_REASON = "master_block_reason";
    private static final String MASTER_SECTOR = "master_sector";
    private static final String MASTER_SECONDARY_SECTOR = "master_secondary_sector";
    private static final String MASTER_SECONDARY_PRESSURE = "master_secondary_pressure";
    private static final String MASTER_RANK_NUMBERS = "master_rank_numbers";
    private static final String MASTER_RANK_SCORES = "master_rank_scores";
    private static final String MASTER_PRESSURE_SERIES = "master_pressure_series";
    private static final String MASTER_EVIDENCE = "master_evidence";
    private static final String MASTER_ECHO_ACTIVE = "master_echo_active";
    private static final String MASTER_ECHO_STRENGTH = "master_echo_strength";
    private static final String MASTER_ECHO_CORRESPONDENCE = "master_echo_correspondence";
    private static final String MASTER_ECHO_TYPE = "master_echo_type";
    private static final String MASTER_ECHO_AGE = "master_echo_age";
    private static final String MASTER_ECHO_MATCHES = "master_echo_matches";
    private static final String MASTER_ECHO_PRIMARY = "master_echo_primary";
    private static final String MASTER_CAPTURED_AT = "master_captured_at";
    private static final String MASTER_ANALYZED_AT = "master_analyzed_at";
    private static final String MASTER_PROCESSING_MS = "master_processing_ms";
    private static final String MASTER_FINGERPRINT = "master_fingerprint";
    private static final String MASTER_SOUND = "master_alert_sound";
    private static final String THERMAL_MODE = "thermal_mode";
    private static final String THERMAL_STATUS = "thermal_status";
    private static final String THERMAL_ANIMATIONS = "thermal_animations";
    private static final String AURUM_PREMIUM_UI_FLAG = "aurum_premium_ui_v1";
    private static final String OVERLAY_HIDDEN = "aurum_overlay_hidden";
    private static final String OVERLAY_X = "aurum_overlay_x";
    private static final String OVERLAY_Y = "aurum_overlay_y";
    private static final int VISUAL_SERIES_LIMIT = 18;
    private static final String STANDALONE_DEFAULTS = "standalone_defaults_v075";
    private static final long SAVE_DEBOUNCE_MS = 1_200L;
    private static final Object SAVE_LOCK = new Object();
    private static final ScheduledExecutorService SAVE_EXECUTOR =
            Executors.newSingleThreadScheduledExecutor(runnable -> {
                Thread thread = new Thread(runnable, "aurum-state-writer");
                thread.setDaemon(true);
                return thread;
            });
    private static SharedPreferences.Editor pendingEditor;
    private static SharedPreferences pendingPreferences;
    private static ScheduledFuture<?> pendingFlush;
    private static long pendingOcrScanCount = Long.MIN_VALUE;
    private static volatile String latestOcrSnapshot;
    private static volatile long latestOcrObservedAt;
    private static volatile long latestOcrScans = -1L;

    private AppStateStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isCalibrated(Context context) {
        SharedPreferences p = prefs(context);
        String suffix = providerSuffix(context);
        if (p.getBoolean(CALIBRATED + "_" + suffix, false)) return true;
        return isLegacyProvider(context) && p.getBoolean(CALIBRATED, false);
    }

    public static RectF getRoi(Context context) {
        SharedPreferences p = prefs(context);
        String suffix = providerSuffix(context);
        boolean providerCalibrated = p.getBoolean(CALIBRATED + "_" + suffix, false);
        String keyPrefix = providerCalibrated ? suffix + "_" : "";
        return new RectF(
                p.getFloat(keyPrefix + ROI_LEFT, 0.05f),
                p.getFloat(keyPrefix + ROI_TOP, 0.25f),
                p.getFloat(keyPrefix + ROI_RIGHT, 0.95f),
                p.getFloat(keyPrefix + ROI_BOTTOM, 0.75f));
    }

    public static void saveRoi(Context context, RectF normalized) {
        String suffix = providerSuffix(context);
        prefs(context).edit()
                .putBoolean(CALIBRATED + "_" + suffix, true)
                .putFloat(suffix + "_" + ROI_LEFT, normalized.left)
                .putFloat(suffix + "_" + ROI_TOP, normalized.top)
                .putFloat(suffix + "_" + ROI_RIGHT, normalized.right)
                .putFloat(suffix + "_" + ROI_BOTTOM, normalized.bottom)
                .putLong(ROI_REVISION, System.currentTimeMillis())
                .apply();
    }

    public static void saveHistory(Context context, List<Integer> history) {
        StringBuilder out = new StringBuilder();
        int end = Math.min(CurrentTableHistory.MAX_RESULTS, history.size());
        for (int i = 0; i < end; i++) {
            if (i > 0) out.append(',');
            out.append(history.get(i));
        }
        prefs(context).edit()
                .putString(HISTORY, out.toString())
                .putLong(HISTORY_SESSION, SessionLedger.activeSessionId(context))
                .apply();
    }

    public static List<Integer> loadHistory(Context context) {
        List<Integer> result = new ArrayList<>();
        long activeSession = SessionLedger.activeSessionId(context);
        long storedSession = prefs(context).getLong(HISTORY_SESSION, Long.MIN_VALUE);
        if (activeSession < 0L || storedSession != activeSession) return result;
        String value = prefs(context).getString(HISTORY, "");
        if (value == null || value.trim().isEmpty()) return result;
        for (String token : value.split(",")) {
            try {
                int number = Integer.parseInt(token.trim());
                if (Wheel.valid(number)) result.add(number);
            } catch (NumberFormatException ignored) {
                // Ignora valor persistido inválido.
            }
        }
        return result;
    }

    public static void saveStatus(Context context, String status, String signal) {
        debouncedApply(context, edit -> edit
                .putString(STATUS, status == null ? "" : status)
                .putString(SIGNAL, signal == null ? "" : signal));
    }

    public static String getStatus(Context context) {
        return prefs(context).getString(STATUS, "Leitura parada");
    }

    public static String getSignal(Context context) {
        return prefs(context).getString(SIGNAL, "SCANNING • sem sinal ativo");
    }

    public static boolean voiceEnabled(Context context) {
        return prefs(context).getBoolean(VOICE, true);
    }

    public static void setVoiceEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(VOICE, enabled).apply();
    }

    public static boolean masterSoundEnabled(Context context) {
        return prefs(context).getBoolean(MASTER_SOUND, false);
    }

    public static void setMasterSoundEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(MASTER_SOUND, enabled).apply();
    }

    public static boolean conservativeMode(Context context) {
        return prefs(context).getBoolean(CONSERVATIVE, true);
    }

    public static void setConservativeMode(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(CONSERVATIVE, enabled).apply();
    }

    public static boolean aurumLockEnabled(Context context) {
        return prefs(context).getBoolean(AurumLockConfig.FEATURE_FLAG_NAME,
                AurumLockConfig.ENABLED_BY_DEFAULT);
    }

    public static void setAurumLockEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(AurumLockConfig.FEATURE_FLAG_NAME, enabled).apply();
    }

    public static boolean premiumUiEnabled(Context context) {
        return prefs(context).getBoolean(AURUM_PREMIUM_UI_FLAG, true);
    }

    public static void setPremiumUiEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(AURUM_PREMIUM_UI_FLAG, enabled).apply();
    }

    public static String provider(Context context) {
        SharedPreferences p = prefs(context);
        String stored = p.getString(PROVIDER, null);
        if (stored != null && !stored.trim().isEmpty()) return stored;
        // Migração da v0.1: o único recorte antigo conhecido era Betão / Roleta Brasil.
        String migrated = p.getBoolean(CALIBRATED, false)
                ? "Betão / Roleta Brasil" : "Roleta ao vivo";
        p.edit().putString(PROVIDER, migrated).apply();
        return migrated;
    }

    public static void setProvider(Context context, String provider) {
        String value = provider == null || provider.trim().isEmpty()
                ? "Roleta ao vivo" : provider.trim();
        prefs(context).edit().putString(PROVIDER, value).apply();
    }


    /** Snapshot visual bruto mais recente, independente do motor Stable. */
    public static void saveOcrSnapshot(Context context, List<Integer> history, long observedAt) {
        StringBuilder out = new StringBuilder();
        int end = Math.min(CurrentTableHistory.MAX_RESULTS, history == null ? 0 : history.size());
        for (int i = 0; i < end; i++) {
            Integer value = history.get(i);
            if (value == null || !Wheel.valid(value)) continue;
            if (out.length() > 0) out.append(',');
            out.append(value);
        }
        String encoded = out.toString();
        synchronized (SAVE_LOCK) {
            ensurePendingEditorLocked(context);
            if (pendingOcrScanCount == Long.MIN_VALUE) {
                pendingOcrScanCount = pendingPreferences.getLong(OCR_SCAN_COUNT, 0L);
            }
            pendingOcrScanCount++;
            latestOcrSnapshot = encoded;
            latestOcrObservedAt = observedAt;
            latestOcrScans = pendingOcrScanCount;
            pendingEditor.putString(OCR_SNAPSHOT, encoded)
                    .putLong(OCR_SNAPSHOT_AT, observedAt)
                    .putLong(OCR_SCAN_COUNT, pendingOcrScanCount);
            scheduleFlushLocked();
        }
    }

    public static List<Integer> loadOcrSnapshot(Context context) {
        List<Integer> result = new ArrayList<>();
        String memory = latestOcrSnapshot;
        String value = memory == null ? prefs(context).getString(OCR_SNAPSHOT, "") : memory;
        if (value == null || value.trim().isEmpty()) return result;
        for (String token : value.split(",")) {
            try {
                int number = Integer.parseInt(token.trim());
                if (Wheel.valid(number)) result.add(number);
            } catch (NumberFormatException ignored) {
                // Snapshot inválido não contamina a leitura.
            }
        }
        return result;
    }

    public static long ocrSnapshotAt(Context context) {
        if (latestOcrObservedAt > 0L) return latestOcrObservedAt;
        return prefs(context).getLong(OCR_SNAPSHOT_AT, 0L);
    }

    public static long ocrScanCount(Context context) {
        if (latestOcrScans >= 0L) return latestOcrScans;
        synchronized (SAVE_LOCK) {
            if (pendingOcrScanCount != Long.MIN_VALUE) return pendingOcrScanCount;
        }
        return prefs(context).getLong(OCR_SCAN_COUNT, 0L);
    }

    public static void setCaptureActive(Context context, boolean active) {
        prefs(context).edit().putBoolean(CAPTURE_ACTIVE, active).apply();
    }

    public static boolean captureActive(Context context) {
        return prefs(context).getBoolean(CAPTURE_ACTIVE, false);
    }

    public static void saveCaptureHealth(Context context, String state,
                                         String detail, int recoveredSpins) {
        prefs(context).edit()
                .putString(CAPTURE_HEALTH, state == null ? "—" : state)
                .putString(CAPTURE_HEALTH_DETAIL, detail == null ? "" : detail)
                .putLong(CAPTURE_HEALTH_AT, System.currentTimeMillis())
                .putInt(CAPTURE_RECOVERED, Math.max(0, recoveredSpins))
                .apply();
    }

    public static String captureHealth(Context context) {
        return prefs(context).getString(CAPTURE_HEALTH,
                captureActive(context) ? "LIVE" : "PARADO");
    }

    public static String captureHealthDetail(Context context) {
        return prefs(context).getString(CAPTURE_HEALTH_DETAIL, "");
    }

    public static long captureHealthAt(Context context) {
        return prefs(context).getLong(CAPTURE_HEALTH_AT, 0L);
    }

    public static int captureRecoveredSpins(Context context) {
        return prefs(context).getInt(CAPTURE_RECOVERED, 0);
    }

    public static void clearOcrSnapshot(Context context) {
        flushPendingWrites(context);
        latestOcrSnapshot = null;
        latestOcrObservedAt = 0L;
        latestOcrScans = -1L;
        prefs(context).edit().remove(OCR_SNAPSHOT).remove(OCR_SNAPSHOT_AT).apply();
    }

    public static String dealer(Context context) {
        return prefs(context).getString(DEALER, "");
    }

    public static void setDealer(Context context, String dealer) {
        prefs(context).edit().putString(DEALER,
                dealer == null ? "" : dealer.trim()).apply();
    }


    public static void ensureStandaloneDefaults(Context context) {
        SharedPreferences p = prefs(context);
        if (p.getBoolean(STANDALONE_DEFAULTS, false)) return;
        p.edit()
                .putBoolean(CONSERVATIVE, false)
                .putBoolean(VOICE, true)
                .putBoolean(STANDALONE_DEFAULTS, true)
                .apply();
    }

    public static void saveRadarSnapshot(Context context,
                                         int score, int families, String decision,
                                         int target, String playLabel,
                                         String headline, String detail,
                                         List<String> reasons) {
        StringBuilder reasonText = new StringBuilder();
        int end = Math.min(5, reasons == null ? 0 : reasons.size());
        for (int i = 0; i < end; i++) {
            String value = reasons.get(i);
            if (value == null || value.trim().isEmpty()) continue;
            if (reasonText.length() > 0) reasonText.append("\n");
            reasonText.append("• ").append(value.trim());
        }
        debouncedApply(context, edit -> edit
                .putInt(RADAR_SCORE, Math.max(0, Math.min(100, score)))
                .putInt(RADAR_FAMILIES, Math.max(0, families))
                .putString(RADAR_DECISION, decision == null ? "" : decision)
                .putInt(RADAR_TARGET, target)
                .putString(RADAR_PLAY_LABEL, playLabel == null ? "" : playLabel)
                .putString(RADAR_HEADLINE, headline == null ? "" : headline)
                .putString(RADAR_DETAIL, detail == null ? "" : detail)
                .putString(RADAR_REASONS, reasonText.toString())
                .putLong(RADAR_UPDATED_AT, System.currentTimeMillis()));
    }

    public static void saveRadarBackstage(Context context, String focus, String sectors,
                                           String heat, String familyDetail, String gate) {
        debouncedApply(context, edit -> edit
                .putString(RADAR_FOCUS, focus == null ? "" : focus)
                .putString(RADAR_SECTORS, sectors == null ? "" : sectors)
                .putString(RADAR_HEAT, heat == null ? "" : heat)
                .putString(RADAR_FAMILY_DETAIL, familyDetail == null ? "" : familyDetail)
                .putString(RADAR_GATE, gate == null ? "" : gate));
    }

    /**
     * Persiste somente dados visuais derivados do snapshot real. A série avança uma vez
     * por fingerprint do histórico, impedindo polling da interface de inventar pontos.
     */
    public static void saveAurumVisualSnapshot(Context context, AurumLockSnapshot snapshot) {
        if (snapshot == null) return;
        SharedPreferences p = prefs(context);
        SharedPreferences.Editor edit = p.edit()
                .putInt(AURUM_READINESS, snapshot.readiness)
                .putString(AURUM_REGIME, snapshot.regime.name())
                .putString(AURUM_STATE, snapshot.readinessState.name())
                .putString(AURUM_LOCK_MODE, snapshot.lockMode.label)
                .putInt(AURUM_RUNNER, snapshot.runnerUp)
                .putInt(AURUM_MARGIN, snapshot.margin)
                .putInt(AURUM_ACTIVE_REMAINING, snapshot.activeRemaining)
                .putString(AURUM_COVERAGE, encodeInts(snapshot.coverage))
                .putString(AURUM_FAMILY_STRENGTHS, encodeInts(snapshot.familyStrengths))
                .putString(AURUM_CPE_TOP_NUMBERS, encodeInts(snapshot.conditionalPrediction.topNumbers))
                .putString(AURUM_CPE_TOP_SCORES, encodeInts(snapshot.conditionalPrediction.topScores))
                .putString(AURUM_CPE_PRIMARY_SECTOR, encodeInts(snapshot.conditionalPrediction.primarySector))
                .putInt(AURUM_CPE_PRIMARY_SECTOR_SCORE, snapshot.conditionalPrediction.primarySectorScore)
                .putString(AURUM_CPE_SECONDARY_SECTOR, encodeInts(snapshot.conditionalPrediction.secondarySector))
                .putInt(AURUM_CPE_SECONDARY_SECTOR_SCORE, snapshot.conditionalPrediction.secondarySectorScore)
                .putInt(AURUM_CPE_PRIMARY_TERMINAL, snapshot.conditionalPrediction.primaryTerminal)
                .putInt(AURUM_CPE_PRIMARY_TERMINAL_SCORE, snapshot.conditionalPrediction.primaryTerminalScore)
                .putInt(AURUM_CPE_SECONDARY_TERMINAL, snapshot.conditionalPrediction.secondaryTerminal)
                .putInt(AURUM_CPE_SECONDARY_TERMINAL_SCORE, snapshot.conditionalPrediction.secondaryTerminalScore)
                .putInt(AURUM_CPE_GAP, snapshot.conditionalPrediction.leaderGap)
                .putInt(AURUM_CPE_SAMPLE, snapshot.conditionalPrediction.sampleQuality)
                .putString(AURUM_CPE_DRIVERS, encodeStrings(snapshot.conditionalPrediction.drivers));
        long prior = p.getLong(AURUM_VISUAL_FINGERPRINT, Long.MIN_VALUE);
        if (snapshot.historyFingerprint != prior && snapshot.dataQualityValid) {
            edit.putString(AURUM_Q_SERIES,
                            appendSeries(p.getString(AURUM_Q_SERIES, ""), snapshot.q))
                    .putString(AURUM_READINESS_SERIES,
                            appendSeries(p.getString(AURUM_READINESS_SERIES, ""), snapshot.readiness))
                    .putLong(AURUM_VISUAL_FINGERPRINT, snapshot.historyFingerprint);
        }
        edit.apply();
    }

    /** Snapshot visual completo do Hard Expert, persistido uma vez por giro validado. */
    public static void saveMasterSnapshot(Context context, MasterSignalSnapshot snapshot) {
        if (snapshot == null) return;
        prefs(context).edit()
                .putString(MASTER_STATE, snapshot.state.name())
                .putInt(MASTER_PRESSURE, snapshot.pressure)
                .putInt(MASTER_QUALITY, snapshot.configurationQuality)
                .putInt(MASTER_CONFIDENCE, snapshot.modelConfidence)
                .putInt(MASTER_TARGET, snapshot.target)
                .putInt(MASTER_RIVAL, snapshot.rival)
                .putInt(MASTER_RIVAL_PRESSURE, snapshot.rivalPressure)
                .putInt(MASTER_GAP, snapshot.gap)
                .putInt(MASTER_INDEPENDENT, snapshot.independentReadings)
                .putInt(MASTER_PERSISTENCE, snapshot.persistence)
                .putInt(MASTER_ACCELERATION, snapshot.acceleration)
                .putInt(MASTER_VALIDITY, snapshot.validitySpins)
                .putInt(MASTER_AGE, snapshot.signalAgeSpins)
                .putInt(MASTER_REMAINING, snapshot.remainingSpins)
                .putBoolean(MASTER_DUAL, snapshot.dualPressure)
                .putBoolean(MASTER_MIGRATING, snapshot.migrating)
                .putBoolean(MASTER_STALE, snapshot.stale)
                .putString(MASTER_REGIME, snapshot.regime)
                .putString(MASTER_FRESHNESS, snapshot.freshnessLabel)
                .putString(MASTER_BLOCK_REASON, snapshot.blockReason)
                .putString(MASTER_SECTOR, encodeInts(snapshot.sector))
                .putString(MASTER_SECONDARY_SECTOR, encodeInts(snapshot.secondarySector))
                .putInt(MASTER_SECONDARY_PRESSURE, snapshot.secondarySectorPressure)
                .putString(MASTER_RANK_NUMBERS, encodeInts(snapshot.rankingNumbers))
                .putString(MASTER_RANK_SCORES, encodeInts(snapshot.rankingScores))
                .putString(MASTER_PRESSURE_SERIES, encodeInts(snapshot.pressureSeries))
                .putString(MASTER_EVIDENCE, encodeStrings(snapshot.evidenceLabels))
                .putBoolean(MASTER_ECHO_ACTIVE, snapshot.patternEcho.active)
                .putInt(MASTER_ECHO_STRENGTH, snapshot.patternEcho.strength)
                .putString(MASTER_ECHO_CORRESPONDENCE, snapshot.patternEcho.correspondence)
                .putString(MASTER_ECHO_TYPE, snapshot.patternEcho.patternType)
                .putInt(MASTER_ECHO_AGE, snapshot.patternEcho.ageSpins)
                .putInt(MASTER_ECHO_MATCHES, snapshot.patternEcho.matchCount)
                .putInt(MASTER_ECHO_PRIMARY, snapshot.patternEcho.primaryProjection)
                .putLong(MASTER_CAPTURED_AT, snapshot.capturedAtMs)
                .putLong(MASTER_ANALYZED_AT, snapshot.analyzedAtMs)
                .putLong(MASTER_PROCESSING_MS, snapshot.processingMs)
                .putLong(MASTER_FINGERPRINT, snapshot.historyFingerprint)
                .apply();
    }

    public static void saveThermalPolicy(Context context, ThermalPolicy policy, int status) {
        ThermalPolicy safe = policy == null ? ThermalPolicy.forStatus(0) : policy;
        prefs(context).edit()
                .putString(THERMAL_MODE, safe.mode.name())
                .putInt(THERMAL_STATUS, Math.max(0, status))
                .putBoolean(THERMAL_ANIMATIONS, safe.allowAnimations)
                .apply();
    }

    public static void saveEarlyTouch(Context context, String value) {
        prefs(context).edit()
                .putString(RADAR_EARLY_TOUCH, value == null ? "" : value)
                .putLong(RADAR_EARLY_TOUCH_AT, System.currentTimeMillis())
                .apply();
    }

    public static void clearRadarSnapshot(Context context) {
        flushPendingWrites(context);
        prefs(context).edit()
                .remove(RADAR_SCORE).remove(RADAR_FAMILIES)
                .remove(RADAR_DECISION).remove(RADAR_TARGET)
                .remove(RADAR_PLAY_LABEL).remove(RADAR_HEADLINE)
                .remove(RADAR_DETAIL).remove(RADAR_REASONS)
                .remove(RADAR_UPDATED_AT)
                .remove(RADAR_FOCUS).remove(RADAR_SECTORS)
                .remove(RADAR_HEAT).remove(RADAR_FAMILY_DETAIL)
                .remove(RADAR_GATE).remove(RADAR_EARLY_TOUCH)
                .remove(RADAR_EARLY_TOUCH_AT)
                .remove(AURUM_READINESS).remove(AURUM_REGIME)
                .remove(AURUM_STATE).remove(AURUM_LOCK_MODE)
                .remove(AURUM_RUNNER).remove(AURUM_MARGIN)
                .remove(AURUM_ACTIVE_REMAINING).remove(AURUM_COVERAGE)
                .remove(AURUM_FAMILY_STRENGTHS).remove(AURUM_Q_SERIES)
                .remove(AURUM_READINESS_SERIES).remove(AURUM_VISUAL_FINGERPRINT)
                .remove(AURUM_CPE_TOP_NUMBERS).remove(AURUM_CPE_TOP_SCORES)
                .remove(AURUM_CPE_PRIMARY_SECTOR).remove(AURUM_CPE_PRIMARY_SECTOR_SCORE)
                .remove(AURUM_CPE_SECONDARY_SECTOR).remove(AURUM_CPE_SECONDARY_SECTOR_SCORE)
                .remove(AURUM_CPE_PRIMARY_TERMINAL).remove(AURUM_CPE_PRIMARY_TERMINAL_SCORE)
                .remove(AURUM_CPE_SECONDARY_TERMINAL).remove(AURUM_CPE_SECONDARY_TERMINAL_SCORE)
                .remove(AURUM_CPE_GAP).remove(AURUM_CPE_SAMPLE).remove(AURUM_CPE_DRIVERS)
                .remove(MASTER_STATE).remove(MASTER_PRESSURE).remove(MASTER_QUALITY)
                .remove(MASTER_CONFIDENCE).remove(MASTER_TARGET).remove(MASTER_RIVAL)
                .remove(MASTER_RIVAL_PRESSURE).remove(MASTER_GAP).remove(MASTER_INDEPENDENT)
                .remove(MASTER_PERSISTENCE).remove(MASTER_ACCELERATION).remove(MASTER_VALIDITY)
                .remove(MASTER_AGE).remove(MASTER_REMAINING).remove(MASTER_DUAL)
                .remove(MASTER_MIGRATING).remove(MASTER_STALE).remove(MASTER_REGIME)
                .remove(MASTER_FRESHNESS).remove(MASTER_BLOCK_REASON).remove(MASTER_SECTOR)
                .remove(MASTER_SECONDARY_SECTOR).remove(MASTER_SECONDARY_PRESSURE)
                .remove(MASTER_RANK_NUMBERS).remove(MASTER_RANK_SCORES)
                .remove(MASTER_PRESSURE_SERIES).remove(MASTER_EVIDENCE)
                .remove(MASTER_ECHO_ACTIVE).remove(MASTER_ECHO_STRENGTH)
                .remove(MASTER_ECHO_CORRESPONDENCE).remove(MASTER_ECHO_TYPE)
                .remove(MASTER_ECHO_AGE).remove(MASTER_ECHO_MATCHES).remove(MASTER_ECHO_PRIMARY)
                .remove(MASTER_CAPTURED_AT).remove(MASTER_ANALYZED_AT)
                .remove(MASTER_PROCESSING_MS).remove(MASTER_FINGERPRINT)
                .apply();
    }

    public static int radarScore(Context context) { return prefs(context).getInt(RADAR_SCORE, 0); }
    public static int radarFamilies(Context context) { return prefs(context).getInt(RADAR_FAMILIES, 0); }
    public static String radarDecision(Context context) { return prefs(context).getString(RADAR_DECISION, ""); }
    public static int radarTarget(Context context) { return prefs(context).getInt(RADAR_TARGET, -1); }
    public static String radarPlayLabel(Context context) { return prefs(context).getString(RADAR_PLAY_LABEL, ""); }
    public static String radarHeadline(Context context) { return prefs(context).getString(RADAR_HEADLINE, "ANALISANDO"); }
    public static String radarDetail(Context context) { return prefs(context).getString(RADAR_DETAIL, "Aguardando leitura OCR."); }
    public static String radarReasons(Context context) { return prefs(context).getString(RADAR_REASONS, ""); }
    public static long radarUpdatedAt(Context context) { return prefs(context).getLong(RADAR_UPDATED_AT, 0L); }
    public static String radarFocus(Context context) { return prefs(context).getString(RADAR_FOCUS, ""); }
    public static String radarSectors(Context context) { return prefs(context).getString(RADAR_SECTORS, ""); }
    public static String radarHeat(Context context) { return prefs(context).getString(RADAR_HEAT, ""); }
    public static String radarFamilyDetail(Context context) { return prefs(context).getString(RADAR_FAMILY_DETAIL, ""); }
    public static String radarGate(Context context) { return prefs(context).getString(RADAR_GATE, ""); }
    public static String radarEarlyTouch(Context context) {
        long at = prefs(context).getLong(RADAR_EARLY_TOUCH_AT, 0L);
        if (at <= 0L || System.currentTimeMillis() - at > 180000L) return "";
        return prefs(context).getString(RADAR_EARLY_TOUCH, "");
    }

    public static int aurumReadiness(Context context) {
        return prefs(context).getInt(AURUM_READINESS, 0);
    }

    public static String aurumRegime(Context context) {
        return prefs(context).getString(AURUM_REGIME, "DISPERSION");
    }

    public static String aurumReadinessState(Context context) {
        return prefs(context).getString(AURUM_STATE, "IDLE");
    }

    public static String aurumLockMode(Context context) {
        return prefs(context).getString(AURUM_LOCK_MODE, "—");
    }

    public static int aurumRunner(Context context) {
        return prefs(context).getInt(AURUM_RUNNER, -1);
    }

    public static int aurumMargin(Context context) {
        return prefs(context).getInt(AURUM_MARGIN, 0);
    }

    public static int aurumActiveRemaining(Context context) {
        return prefs(context).getInt(AURUM_ACTIVE_REMAINING, 0);
    }

    public static List<Integer> aurumCoverage(Context context) {
        return decodeInts(prefs(context).getString(AURUM_COVERAGE, ""));
    }

    public static List<Integer> aurumFamilyStrengths(Context context) {
        return decodeInts(prefs(context).getString(AURUM_FAMILY_STRENGTHS, ""));
    }

    public static List<Integer> aurumQSeries(Context context) {
        return decodeInts(prefs(context).getString(AURUM_Q_SERIES, ""));
    }

    public static List<Integer> aurumReadinessSeries(Context context) {
        return decodeInts(prefs(context).getString(AURUM_READINESS_SERIES, ""));
    }

    public static List<Integer> aurumCpeTopNumbers(Context context) { return decodeInts(prefs(context).getString(AURUM_CPE_TOP_NUMBERS, "")); }
    public static List<Integer> aurumCpeTopScores(Context context) { return decodeInts(prefs(context).getString(AURUM_CPE_TOP_SCORES, "")); }
    public static List<Integer> aurumCpePrimarySector(Context context) { return decodeInts(prefs(context).getString(AURUM_CPE_PRIMARY_SECTOR, "")); }
    public static int aurumCpePrimarySectorScore(Context context) { return prefs(context).getInt(AURUM_CPE_PRIMARY_SECTOR_SCORE, 0); }
    public static List<Integer> aurumCpeSecondarySector(Context context) { return decodeInts(prefs(context).getString(AURUM_CPE_SECONDARY_SECTOR, "")); }
    public static int aurumCpeSecondarySectorScore(Context context) { return prefs(context).getInt(AURUM_CPE_SECONDARY_SECTOR_SCORE, 0); }
    public static int aurumCpePrimaryTerminal(Context context) { return prefs(context).getInt(AURUM_CPE_PRIMARY_TERMINAL, -1); }
    public static int aurumCpePrimaryTerminalScore(Context context) { return prefs(context).getInt(AURUM_CPE_PRIMARY_TERMINAL_SCORE, 0); }
    public static int aurumCpeSecondaryTerminal(Context context) { return prefs(context).getInt(AURUM_CPE_SECONDARY_TERMINAL, -1); }
    public static int aurumCpeSecondaryTerminalScore(Context context) { return prefs(context).getInt(AURUM_CPE_SECONDARY_TERMINAL_SCORE, 0); }
    public static int aurumCpeGap(Context context) { return prefs(context).getInt(AURUM_CPE_GAP, 0); }
    public static int aurumCpeSample(Context context) { return prefs(context).getInt(AURUM_CPE_SAMPLE, 0); }
    public static String aurumCpeDrivers(Context context) { return prefs(context).getString(AURUM_CPE_DRIVERS, ""); }

    public static String masterState(Context context) { return prefs(context).getString(MASTER_STATE, "SILENCE"); }
    public static int masterPressure(Context context) { return prefs(context).getInt(MASTER_PRESSURE, 0); }
    public static int masterQuality(Context context) { return prefs(context).getInt(MASTER_QUALITY, 0); }
    public static int masterConfidence(Context context) { return prefs(context).getInt(MASTER_CONFIDENCE, 0); }
    public static int masterTarget(Context context) { return prefs(context).getInt(MASTER_TARGET, -1); }
    public static int masterRival(Context context) { return prefs(context).getInt(MASTER_RIVAL, -1); }
    public static int masterRivalPressure(Context context) { return prefs(context).getInt(MASTER_RIVAL_PRESSURE, 0); }
    public static int masterGap(Context context) { return prefs(context).getInt(MASTER_GAP, 0); }
    public static int masterIndependent(Context context) { return prefs(context).getInt(MASTER_INDEPENDENT, 0); }
    public static int masterPersistence(Context context) { return prefs(context).getInt(MASTER_PERSISTENCE, 0); }
    public static int masterAcceleration(Context context) { return prefs(context).getInt(MASTER_ACCELERATION, 50); }
    public static int masterValidity(Context context) { return prefs(context).getInt(MASTER_VALIDITY, 0); }
    public static int masterAge(Context context) { return prefs(context).getInt(MASTER_AGE, 0); }
    public static int masterRemaining(Context context) { return prefs(context).getInt(MASTER_REMAINING, 0); }
    public static boolean masterDual(Context context) { return prefs(context).getBoolean(MASTER_DUAL, false); }
    public static boolean masterMigrating(Context context) { return prefs(context).getBoolean(MASTER_MIGRATING, false); }
    public static boolean masterStale(Context context) { return prefs(context).getBoolean(MASTER_STALE, false); }
    public static String masterRegime(Context context) { return prefs(context).getString(MASTER_REGIME, "DISPERSÃO"); }
    public static String masterFreshness(Context context) { return prefs(context).getString(MASTER_FRESHNESS, "AGUARDANDO DADOS"); }
    public static String masterBlockReason(Context context) { return prefs(context).getString(MASTER_BLOCK_REASON, ""); }
    public static List<Integer> masterSector(Context context) { return decodeInts(prefs(context).getString(MASTER_SECTOR, "")); }
    public static List<Integer> masterSecondarySector(Context context) { return decodeInts(prefs(context).getString(MASTER_SECONDARY_SECTOR, "")); }
    public static int masterSecondaryPressure(Context context) { return prefs(context).getInt(MASTER_SECONDARY_PRESSURE, 0); }
    public static List<Integer> masterRankNumbers(Context context) { return decodeInts(prefs(context).getString(MASTER_RANK_NUMBERS, "")); }
    public static List<Integer> masterRankScores(Context context) { return decodeInts(prefs(context).getString(MASTER_RANK_SCORES, "")); }
    public static List<Integer> masterPressureSeries(Context context) { return decodeInts(prefs(context).getString(MASTER_PRESSURE_SERIES, "")); }
    public static String masterEvidence(Context context) { return prefs(context).getString(MASTER_EVIDENCE, ""); }
    public static boolean masterEchoActive(Context context) { return prefs(context).getBoolean(MASTER_ECHO_ACTIVE, false); }
    public static int masterEchoStrength(Context context) { return prefs(context).getInt(MASTER_ECHO_STRENGTH, 0); }
    public static String masterEchoCorrespondence(Context context) { return prefs(context).getString(MASTER_ECHO_CORRESPONDENCE, "SEM ECO"); }
    public static String masterEchoType(Context context) { return prefs(context).getString(MASTER_ECHO_TYPE, "—"); }
    public static int masterEchoAge(Context context) { return prefs(context).getInt(MASTER_ECHO_AGE, 0); }
    public static int masterEchoMatches(Context context) { return prefs(context).getInt(MASTER_ECHO_MATCHES, 0); }
    public static int masterEchoPrimary(Context context) { return prefs(context).getInt(MASTER_ECHO_PRIMARY, -1); }
    public static long masterCapturedAt(Context context) { return prefs(context).getLong(MASTER_CAPTURED_AT, 0L); }
    public static long masterAnalyzedAt(Context context) { return prefs(context).getLong(MASTER_ANALYZED_AT, 0L); }
    public static long masterProcessingMs(Context context) { return prefs(context).getLong(MASTER_PROCESSING_MS, 0L); }
    public static long masterFingerprint(Context context) { return prefs(context).getLong(MASTER_FINGERPRINT, 0L); }
    public static String thermalMode(Context context) { return prefs(context).getString(THERMAL_MODE, ThermalPolicy.Mode.MAXIMUM.name()); }
    public static int thermalStatus(Context context) { return prefs(context).getInt(THERMAL_STATUS, 0); }
    public static boolean thermalAnimationsAllowed(Context context) { return prefs(context).getBoolean(THERMAL_ANIMATIONS, true); }
    public static long thermalUiRefreshMs(Context context) {
        return ThermalPolicy.forStatus(thermalStatus(context)).uiRefreshMs;
    }

    /** Assinatura barata para impedir reconstrução da UI quando nada visível mudou. */
    public static long uiStateToken(Context context, long nowMs) {
        SharedPreferences p = prefs(context);
        long hash = 0xcbf29ce484222325L;
        boolean capture = p.getBoolean(CAPTURE_ACTIVE, false);
        String memoryOcr = latestOcrSnapshot;
        long ocrAt = latestOcrObservedAt > 0L
                ? latestOcrObservedAt : p.getLong(OCR_SNAPSHOT_AT, 0L);
        hash = mix(hash, capture ? 1L : 0L);
        hash = mix(hash, hashOf(p.getString(PROVIDER, "")));
        hash = mix(hash, p.getLong(ROI_REVISION, 0L));
        hash = mix(hash, hashOf(p.getString(HISTORY, "")));
        hash = mix(hash, p.getLong(HISTORY_SESSION, Long.MIN_VALUE));
        hash = mix(hash, hashOf(memoryOcr == null
                ? p.getString(OCR_SNAPSHOT, "") : memoryOcr));
        hash = mix(hash, capture && ocrAt > 0L && nowMs - ocrAt <= 4_500L ? 1L : 0L);
        hash = mix(hash, hashOf(p.getString(CAPTURE_HEALTH, "")));
        hash = mix(hash, hashOf(p.getString(CAPTURE_HEALTH_DETAIL, "")));
        hash = mix(hash, p.getInt(CAPTURE_RECOVERED, 0));
        hash = mix(hash, p.getLong(MASTER_FINGERPRINT, 0L));
        hash = mix(hash, hashOf(p.getString(MASTER_STATE, "")));
        hash = mix(hash, p.getInt(MASTER_PRESSURE, 0));
        hash = mix(hash, p.getInt(MASTER_QUALITY, 0));
        hash = mix(hash, p.getInt(MASTER_CONFIDENCE, 0));
        hash = mix(hash, p.getInt(MASTER_TARGET, -1));
        hash = mix(hash, p.getInt(MASTER_RIVAL, -1));
        hash = mix(hash, p.getInt(MASTER_RIVAL_PRESSURE, 0));
        hash = mix(hash, p.getInt(MASTER_GAP, 0));
        hash = mix(hash, p.getInt(MASTER_INDEPENDENT, 0));
        hash = mix(hash, p.getInt(MASTER_PERSISTENCE, 0));
        hash = mix(hash, p.getInt(MASTER_ACCELERATION, 50));
        hash = mix(hash, p.getInt(MASTER_REMAINING, 0));
        hash = mix(hash, p.getBoolean(MASTER_DUAL, false) ? 1L : 0L);
        hash = mix(hash, p.getBoolean(MASTER_MIGRATING, false) ? 1L : 0L);
        hash = mix(hash, p.getBoolean(MASTER_STALE, false) ? 1L : 0L);
        hash = mix(hash, hashOf(p.getString(MASTER_REGIME, "")));
        hash = mix(hash, hashOf(p.getString(MASTER_SECTOR, "")));
        hash = mix(hash, hashOf(p.getString(MASTER_SECONDARY_SECTOR, "")));
        hash = mix(hash, hashOf(p.getString(MASTER_RANK_NUMBERS, "")));
        hash = mix(hash, hashOf(p.getString(MASTER_RANK_SCORES, "")));
        hash = mix(hash, hashOf(p.getString(MASTER_EVIDENCE, "")));
        hash = mix(hash, hashOf(p.getString(RADAR_REASONS, "")));
        hash = mix(hash, hashOf(p.getString(RADAR_FOCUS, "")));
        hash = mix(hash, hashOf(p.getString(RADAR_SECTORS, "")));
        hash = mix(hash, hashOf(p.getString(RADAR_HEAT, "")));
        hash = mix(hash, hashOf(p.getString(RADAR_FAMILY_DETAIL, "")));
        hash = mix(hash, hashOf(p.getString(RADAR_GATE, "")));
        hash = mix(hash, hashOf(p.getString(RADAR_EARLY_TOUCH, "")));
        hash = mix(hash, p.getInt(THERMAL_STATUS, 0));
        hash = mix(hash, p.getBoolean(OVERLAY_HIDDEN, false) ? 1L : 0L);
        hash = mix(hash, p.getBoolean(CONSERVATIVE, true) ? 1L : 0L);
        hash = mix(hash, p.getBoolean(VOICE, true) ? 1L : 0L);
        hash = mix(hash, p.getBoolean(MASTER_SOUND, false) ? 1L : 0L);
        return hash;
    }

    public static boolean overlayHidden(Context context) {
        return prefs(context).getBoolean(OVERLAY_HIDDEN, false);
    }

    public static void setOverlayHidden(Context context, boolean hidden) {
        prefs(context).edit().putBoolean(OVERLAY_HIDDEN, hidden).apply();
    }

    public static int overlayX(Context context, int fallback) {
        return prefs(context).getInt(OVERLAY_X, fallback);
    }

    public static int overlayY(Context context, int fallback) {
        return prefs(context).getInt(OVERLAY_Y, fallback);
    }

    public static void saveOverlayPosition(Context context, int x, int y) {
        prefs(context).edit().putInt(OVERLAY_X, Math.max(0, x))
                .putInt(OVERLAY_Y, Math.max(0, y)).apply();
    }

    public static void clearHistory(Context context) {
        flushPendingWrites(context);
        prefs(context).edit().remove(HISTORY).remove(HISTORY_SESSION)
                .remove(SIGNAL).apply();
    }

    /** Força apenas a publicação em memória; o I/O de disco continua assíncrono via apply(). */
    public static void flushPendingWrites(Context context) {
        SharedPreferences.Editor editor;
        synchronized (SAVE_LOCK) {
            editor = detachPendingEditorLocked();
        }
        if (editor != null) editor.apply();
    }

    private static void debouncedApply(Context context, EditorAction action) {
        synchronized (SAVE_LOCK) {
            ensurePendingEditorLocked(context);
            action.apply(pendingEditor);
            scheduleFlushLocked();
        }
    }

    private static void ensurePendingEditorLocked(Context context) {
        if (pendingEditor != null) return;
        Context app = context.getApplicationContext();
        pendingPreferences = prefs(app == null ? context : app);
        pendingEditor = pendingPreferences.edit();
    }

    private static void scheduleFlushLocked() {
        if (pendingFlush != null && !pendingFlush.isDone()) return;
        pendingFlush = SAVE_EXECUTOR.schedule(() -> {
            SharedPreferences.Editor editor;
            synchronized (SAVE_LOCK) {
                editor = detachPendingEditorLocked();
            }
            if (editor != null) editor.apply();
        }, SAVE_DEBOUNCE_MS, TimeUnit.MILLISECONDS);
    }

    private static SharedPreferences.Editor detachPendingEditorLocked() {
        SharedPreferences.Editor editor = pendingEditor;
        pendingEditor = null;
        pendingPreferences = null;
        pendingOcrScanCount = Long.MIN_VALUE;
        if (pendingFlush != null) pendingFlush.cancel(false);
        pendingFlush = null;
        return editor;
    }

    private static long mix(long hash, long value) {
        hash ^= value;
        return hash * 0x100000001b3L;
    }

    private static int hashOf(String value) { return value == null ? 0 : value.hashCode(); }

    private interface EditorAction { void apply(SharedPreferences.Editor editor); }

    private static String providerSuffix(Context context) {
        return provider(context).toLowerCase()
                .replaceAll("[^a-z0-9]+", "_")
                .replaceAll("^_+|_+$", "");
    }

    private static boolean isLegacyProvider(Context context) {
        return "Betão / Roleta Brasil".equals(provider(context));
    }

    private static String encodeStrings(List<String> values) {
        if (values == null || values.isEmpty()) return "";
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (value == null || value.trim().isEmpty()) continue;
            if (out.length() > 0) out.append(" • ");
            out.append(value.trim().replace("•", "/"));
        }
        return out.toString();
    }

    private static String encodeInts(List<Integer> values) {
        if (values == null || values.isEmpty()) return "";
        StringBuilder out = new StringBuilder();
        for (Integer value : values) {
            if (value == null) continue;
            if (out.length() > 0) out.append(',');
            out.append(value);
        }
        return out.toString();
    }

    private static List<Integer> decodeInts(String value) {
        List<Integer> out = new ArrayList<>();
        if (value == null || value.trim().isEmpty()) return out;
        for (String token : value.split(",")) {
            try { out.add(Integer.parseInt(token.trim())); }
            catch (NumberFormatException ignored) { /* dado visual inválido é descartado */ }
        }
        return out;
    }

    private static String appendSeries(String encoded, int value) {
        List<Integer> values = decodeInts(encoded);
        values.add(Math.max(0, Math.min(100, value)));
        while (values.size() > VISUAL_SERIES_LIMIT) values.remove(0);
        return encodeInts(values);
    }
}
