package com.xspaceart.radar30.master;

import java.util.Arrays;

/** Snapshot compacto, sempre exibível, do Pattern Echo. */
public final class PatternEchoSnapshot {
    public final boolean active;
    public final int strength;
    public final String correspondence;
    public final String patternType;
    public final int ageSpins;
    public final int matchCount;
    public final int primaryProjection;
    public final long historyFingerprint;
    private final double[] pressure;

    public PatternEchoSnapshot(boolean active, int strength, String correspondence,
                               String patternType, int ageSpins, int matchCount,
                               int primaryProjection, long historyFingerprint,
                               double[] pressure) {
        this.active = active;
        this.strength = clamp(strength);
        this.correspondence = clean(correspondence, active ? "ATIVA" : "SEM ECO");
        this.patternType = clean(patternType, "—");
        this.ageSpins = Math.max(0, ageSpins);
        this.matchCount = Math.max(0, matchCount);
        this.primaryProjection = primaryProjection >= 0 && primaryProjection <= 36
                ? primaryProjection : -1;
        this.historyFingerprint = historyFingerprint;
        this.pressure = sanitize(pressure);
    }

    public static PatternEchoSnapshot empty(long fingerprint) {
        return new PatternEchoSnapshot(false, 0, "SEM ECO", "—", 0, 0,
                -1, fingerprint, new double[37]);
    }

    public double pressureAt(int number) {
        return number >= 0 && number < 37 ? pressure[number] : 0.0;
    }

    public double[] copyPressure() { return pressure.clone(); }

    public String statusLabel() { return active ? "ATIVO" : "INATIVO"; }

    private static double[] sanitize(double[] values) {
        double[] out = values == null ? new double[37] : Arrays.copyOf(values, 37);
        double max = 0.0;
        for (int i = 0; i < out.length; i++) {
            if (!Double.isFinite(out[i]) || out[i] < 0.0) out[i] = 0.0;
            max = Math.max(max, out[i]);
        }
        if (max > 1e-12) for (int i = 0; i < out.length; i++) out[i] /= max;
        return out;
    }

    private static String clean(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }
}
