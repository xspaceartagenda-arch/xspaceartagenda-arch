package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;

/** Detecta dois polos separados e aplica o veto de falsa dominância. */
public final class DualPressureDetector {
    private DualPressureDetector() {}

    public static Result detect(SectorClusterEngine.Cluster primary,
                                SectorClusterEngine.Cluster secondary) {
        if (primary == null || secondary == null
                || !primary.available() || !secondary.available()) return Result.none();
        int gap = Math.max(0, primary.score - secondary.score);
        int separation = Wheel.distance(primary.center, secondary.center);
        boolean separated = separation > primary.radius + secondary.radius + 1;
        boolean dual = separated && secondary.score >= 58 && gap <= 10;
        int conflict = dual ? clamp(82 - gap * 4)
                : separated && gap <= 16 ? clamp(48 - gap) : 0;
        return new Result(dual, conflict, gap, separation);
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }

    public static final class Result {
        public final boolean dual;
        public final int conflict;
        public final int gap;
        public final int separation;

        Result(boolean dual, int conflict, int gap, int separation) {
            this.dual = dual;
            this.conflict = clamp(conflict);
            this.gap = Math.max(0, gap);
            this.separation = Math.max(0, separation);
        }

        static Result none() { return new Result(false, 0, 100, 0); }
    }
}
