package com.xspaceart.radar30;

import android.graphics.Rect;

import com.google.mlkit.vision.text.Text;
import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.core.CurrentTableHistory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Converte caixas de texto do ML Kit em uma grade: topo primeiro, esquerda para direita. */
public final class OcrHistoryParser {
    private static final Pattern NUMBER = Pattern.compile("(?<!\\d)(?:[0-9]|[12][0-9]|3[0-6])(?!\\d)");

    public List<Integer> parse(Text result) {
        List<Token> tokens = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element element : line.getElements()) {
                    Rect box = element.getBoundingBox();
                    if (box == null) continue;
                    addTokens(tokens, normalize(element.getText()), box);
                }
            }
        }
        if (tokens.isEmpty()) return new ArrayList<>();

        float medianHeight = medianHeight(tokens);
        float tolerance = Math.max(10f, medianHeight * 0.72f);
        tokens.sort(Comparator.comparingDouble(t -> t.cy));

        List<Row> rows = new ArrayList<>();
        for (Token token : tokens) {
            Row best = null;
            float bestDistance = Float.MAX_VALUE;
            for (Row row : rows) {
                float distance = Math.abs(row.meanY - token.cy);
                if (distance <= tolerance && distance < bestDistance) {
                    best = row;
                    bestDistance = distance;
                }
            }
            if (best == null) rows.add(new Row(token));
            else best.add(token);
        }

        rows.sort(Comparator.comparingDouble(r -> r.meanY));
        rows = keepGridLikeRows(rows);
        List<Integer> values = new ArrayList<>();
        for (Row row : rows) {
            row.tokens.sort(Comparator.comparingDouble(t -> t.cx));
            for (Token token : row.tokens) {
                if (Wheel.valid(token.value)) values.add(token.value);
                if (values.size() == CurrentTableHistory.MAX_RESULTS) return values;
            }
        }
        return values;
    }

    private static void addTokens(List<Token> output, String text, Rect box) {
        if (looksLikeClockOrUiCounter(text)) return;
        Matcher matcher = NUMBER.matcher(text);
        List<Integer> found = new ArrayList<>();
        while (matcher.find()) {
            try {
                int value = Integer.parseInt(matcher.group());
                if (Wheel.valid(value)) found.add(value);
            } catch (NumberFormatException ignored) {
                // O regex já restringe, mas preserva o pipeline se houver anomalia.
            }
        }
        if (found.isEmpty()) return;
        // Um único Element do ML Kit com vários números pode representar células
        // vizinhas coladas. Só preservamos isso quando o texto não contém pontuação
        // típica de relógio/placar; "9:31", por exemplo, nunca pode virar 9 + 31.
        float segmentWidth = box.width() / (float) found.size();
        for (int i = 0; i < found.size(); i++) {
            float x = box.left + segmentWidth * (i + 0.5f);
            output.add(new Token(found.get(i), x, box.exactCenterY(), box.height()));
        }
    }


    /**
     * Remove cabeçalhos/placares que eventualmente entram na ROI. A grade real
     * costuma ter várias linhas com quantidade parecida de células; uma linha
     * esparsa como "9:31" ou um contador de mesa não deve virar histórico.
     */
    private static List<Row> keepGridLikeRows(List<Row> source) {
        if (source == null || source.size() < 3) return source;
        java.util.Map<Integer, Integer> frequency = new java.util.HashMap<>();
        for (Row row : source) {
            int size = row.tokens.size();
            if (size >= 4) frequency.put(size, frequency.getOrDefault(size, 0) + 1);
        }
        int expected = -1;
        int bestCount = 0;
        for (java.util.Map.Entry<Integer, Integer> entry : frequency.entrySet()) {
            int count = entry.getValue();
            int size = entry.getKey();
            if (count > bestCount || (count == bestCount && size > expected)) {
                bestCount = count;
                expected = size;
            }
        }
        // Só filtra quando há evidência de grade repetida; caso contrário mantém
        // o comportamento permissivo para layouts de cassino diferentes.
        if (expected < 4 || bestCount < 2) return source;
        int min = Math.max(4, expected - 2);
        int max = expected + 2;
        List<Row> filtered = new ArrayList<>();
        for (Row row : source) {
            int size = row.tokens.size();
            if (size >= min && size <= max) filtered.add(row);
        }
        return filtered.size() >= 2 ? filtered : source;
    }

    private static boolean looksLikeClockOrUiCounter(String text) {
        if (text == null) return false;
        String value = text.trim();
        if (value.isEmpty()) return false;
        // Horário/cronômetro e placares são a principal fonte de falsos números
        // dentro de uma ROI um pouco larga. Não rejeita hífen/espaço para não
        // quebrar células que o ML Kit eventualmente agrupe.
        if (value.indexOf(':') >= 0 || value.indexOf('/') >= 0 || value.indexOf('%') >= 0) return true;
        // "09.31" / "09,31" também é tratado como contador, mas um número
        // isolado continua válido.
        if ((value.indexOf('.') >= 0 || value.indexOf(',') >= 0)) {
            Matcher matcher = NUMBER.matcher(value);
            int count = 0;
            while (matcher.find()) count++;
            if (count >= 2) return true;
        }
        return false;
    }

    private static String normalize(String raw) {
        if (raw == null) return "";
        String value = raw.trim().toUpperCase(Locale.ROOT);
        if (value.length() <= 2) {
            value = value.replace('O', '0')
                    .replace('I', '1')
                    .replace('L', '1')
                    .replace('S', '5');
        }
        return value;
    }

    private static float medianHeight(List<Token> tokens) {
        List<Float> heights = new ArrayList<>();
        for (Token token : tokens) heights.add(token.height);
        heights.sort(Float::compareTo);
        return heights.get(heights.size() / 2);
    }

    private static final class Token {
        final int value;
        final float cx;
        final float cy;
        final float height;

        Token(int value, float cx, float cy, float height) {
            this.value = value;
            this.cx = cx;
            this.cy = cy;
            this.height = height;
        }
    }

    private static final class Row {
        final List<Token> tokens = new ArrayList<>();
        float meanY;

        Row(Token first) {
            add(first);
        }

        void add(Token token) {
            tokens.add(token);
            float total = 0;
            for (Token value : tokens) total += value.cy;
            meanY = total / tokens.size();
        }
    }
}
