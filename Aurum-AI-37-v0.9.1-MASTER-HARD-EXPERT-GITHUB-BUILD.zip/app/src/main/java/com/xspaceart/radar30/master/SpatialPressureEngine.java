package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;

/** Pressão multijanela e propagação física na ordem real da roleta europeia. */
public final class SpatialPressureEngine {
    private SpatialPressureEngine() {}

    public static double[] multiWindow(MasterHistoryIndex index) {
        double[] raw = new double[37];
        if (index == null || index.size() == 0) return raw;

        addBand(index, raw, 0, 2, 0.26);
        addBand(index, raw, 3, 4, 0.20);
        addBand(index, raw, 5, 9, 0.18);
        addBand(index, raw, 10, 29, 0.14);
        addBand(index, raw, 30, 59, 0.09);
        addBand(index, raw, 60, 149, 0.07);
        addBand(index, raw, 150, 499, 0.06);
        normalize(raw);
        return raw;
    }

    public static Result spread(double[] source) {
        double[] safe = source == null ? new double[37] : source.clone();
        normalize(safe);
        double concentration = concentration(safe);
        int radius = concentration >= 0.72 ? 2 : concentration >= 0.48 ? 3 : 4;
        double[] out = new double[37];
        for (int number = 0; number < 37; number++) {
            if (safe[number] <= 0.0) continue;
            int center = Wheel.EUROPEAN.indexOf(number);
            for (int offset = -radius; offset <= radius; offset++) {
                int p = (center + offset) % 37;
                if (p < 0) p += 37;
                int distance = Math.abs(offset);
                double kernel = distance == 0 ? 1.0
                        : distance == 1 ? 0.68
                        : distance == 2 ? 0.42
                        : distance == 3 ? 0.24 : 0.13;
                out[Wheel.EUROPEAN.get(p)] += safe[number] * kernel;
            }
        }
        normalize(out);
        return new Result(out, radius, clamp((int) Math.round(100.0 * concentration)));
    }

    private static void addBand(MasterHistoryIndex index, double[] out,
                                int start, int end, double totalWeight) {
        int available = Math.max(0, Math.min(index.size() - 1, end) - start + 1);
        if (available <= 0) return;
        // Diferença entre contadores incrementais das janelas: custo fixo 37,
        // sem varrer novamente os até 500 giros a cada entrada.
        int outerWindow = end + 1;
        for (int number = 0; number < 37; number++) {
            int hits = index.windowCount(outerWindow, number)
                    - (start == 0 ? 0 : index.windowCount(start, number));
            if (hits > 0) {
                MicroPressureEngine.addKernel(out, number,
                        totalWeight * hits / available);
            }
        }
    }

    private static double concentration(double[] values) {
        double max = 0.0, total = 0.0;
        for (double value : values) { max = Math.max(max, value); total += value; }
        return total <= 1e-12 ? 0.0 : Math.min(1.0, max * 4.0 / total);
    }

    static void normalize(double[] values) {
        double max = 0.0;
        for (double value : values) max = Math.max(max, value);
        if (max <= 1e-12) return;
        for (int i = 0; i < values.length; i++) values[i] = Math.max(0.0, values[i] / max);
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }

    public static final class Result {
        public final double[] pressure;
        public final int adaptiveRadius;
        public final int concentration;

        Result(double[] pressure, int adaptiveRadius, int concentration) {
            this.pressure = pressure.clone();
            this.adaptiveRadius = adaptiveRadius;
            this.concentration = concentration;
        }
    }
}
