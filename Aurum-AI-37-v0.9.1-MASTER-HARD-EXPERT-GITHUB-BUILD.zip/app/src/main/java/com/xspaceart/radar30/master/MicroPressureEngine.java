package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;

/** Leitura especial dos últimos três giros, sem substituir as janelas maiores. */
public final class MicroPressureEngine {
    private MicroPressureEngine() {}

    public static Result analyze(MasterHistoryIndex index) {
        double[] pressure = new double[37];
        if (index == null || index.size() == 0) return new Result(pressure, 0, "SEM DADOS");

        int count = Math.min(3, index.size());
        double[] recency = {1.0, 0.74, 0.52};
        for (int offset = 0; offset < count; offset++) {
            int source = index.recent(offset);
            addKernel(pressure, source, recency[offset]);

            int samples = index.transitionSamples(source);
            if (samples >= 3) {
                for (int to = 0; to < 37; to++) {
                    double observed = index.transitionCount(source, to) / (double) samples;
                    if (observed > 1.0 / 37.0) {
                        pressure[to] += recency[offset] * 0.85
                                * reliability(samples, 16.0) * observed * 8.0;
                    }
                }
            }
        }

        if (index.size() >= 3) {
            int latestStep = signedStep(index.recent(1), index.recent(0));
            int priorStep = signedStep(index.recent(2), index.recent(1));
            if (Math.abs(latestStep - priorStep) <= 2) {
                addKernel(pressure, shift(index.recent(0), latestStep), 0.72);
            }
        }

        normalize(pressure);
        int center = argMax(pressure);
        double current = density(index, center, 0, Math.min(3, index.size()));
        double previous = index.size() <= 3 ? current
                : density(index, center, 3, Math.min(3, index.size() - 3));
        int acceleration = clamp((int) Math.round(50.0 + 85.0 * (current - previous)));
        String trend = acceleration >= 58 ? "CRESCENTE"
                : acceleration <= 42 ? "DECRESCENTE" : "ESTÁVEL";
        return new Result(pressure, acceleration, trend);
    }

    private static double density(MasterHistoryIndex index, int center, int start, int count) {
        if (center < 0 || count <= 0) return 0.0;
        int hits = 0;
        for (int i = start; i < start + count && i < index.size(); i++) {
            if (Wheel.distance(center, index.recent(i)) <= 3) hits++;
        }
        return hits / (double) count;
    }

    static void addKernel(double[] out, int center, double weight) {
        int centerIndex = Wheel.EUROPEAN.indexOf(center);
        int[] offsets = {0, -1, 1, -2, 2, -3, 3};
        double[] kernel = {1.0, 0.76, 0.76, 0.48, 0.48, 0.25, 0.25};
        for (int i = 0; i < offsets.length; i++) {
            int p = (centerIndex + offsets[i]) % 37;
            if (p < 0) p += 37;
            out[Wheel.EUROPEAN.get(p)] += weight * kernel[i];
        }
    }

    private static int signedStep(int from, int to) {
        int d = Wheel.EUROPEAN.indexOf(to) - Wheel.EUROPEAN.indexOf(from);
        if (d > 18) d -= 37;
        if (d < -18) d += 37;
        return d;
    }

    private static int shift(int number, int step) {
        int p = (Wheel.EUROPEAN.indexOf(number) + step) % 37;
        if (p < 0) p += 37;
        return Wheel.EUROPEAN.get(p);
    }

    private static double reliability(int samples, double half) {
        return samples <= 0 ? 0.0 : samples / (samples + half);
    }

    private static int argMax(double[] values) {
        int best = -1;
        double score = 0.0;
        for (int i = 0; i < values.length; i++) if (values[i] > score) { score = values[i]; best = i; }
        return best;
    }

    private static void normalize(double[] values) {
        double max = 0.0;
        for (double value : values) max = Math.max(max, value);
        if (max <= 1e-12) return;
        for (int i = 0; i < values.length; i++) values[i] /= max;
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }

    public static final class Result {
        public final double[] pressure;
        public final int acceleration;
        public final String trend;

        Result(double[] pressure, int acceleration, String trend) {
            this.pressure = pressure.clone();
            this.acceleration = clamp(acceleration);
            this.trend = trend;
        }
    }
}
