package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Índice incremental single-writer do Hard Expert.
 *
 * <p>A entrada pública é sempre newest-first, como o histórico OCR da Aurum.
 * Internamente o anel é cronológico para que transições e Pattern Echo nunca
 * sejam avaliados ao contrário. Um giro novo atualiza contadores fixos; rebuild
 * completo ocorre somente em correção, resync ou troca de sessão.</p>
 */
public final class MasterHistoryIndex {
    public static final int CAPACITY = 500;
    private static final int[] WINDOWS = {3, 5, 10, 30, 60, 150, 500};

    private final int[] ring = new int[CAPACITY];
    private final int[][] windowCounts = new int[WINDOWS.length][37];
    private final int[][] transitions = new int[37][37];
    private final int[][] terminalTransitions = new int[10][37];
    private int head;
    private int size;
    private long deltaUpdates;
    private int rebuildCount;

    public void rebuildNewestFirst(List<Integer> newestFirst) {
        validate(newestFirst);
        clearInternal();
        int limit = Math.min(CAPACITY, newestFirst == null ? 0 : newestFirst.size());
        for (int i = limit - 1; i >= 0; i--) appendChronological(newestFirst.get(i));
        // Rebuild é uma operação de recuperação, não uma atualização incremental.
        deltaUpdates = 0L;
        rebuildCount++;
    }

    public void appendNewestFirst(List<Integer> newestFirstDelta) {
        validate(newestFirstDelta);
        if (newestFirstDelta == null) return;
        for (int i = newestFirstDelta.size() - 1; i >= 0; i--) {
            appendChronological(newestFirstDelta.get(i));
        }
    }

    public void clear() {
        clearInternal();
        rebuildCount++;
    }

    private void appendChronological(int number) {
        if (!Wheel.valid(number)) throw new IllegalArgumentException("number must be 0..36");

        if (size == CAPACITY) {
            int oldest = chronologicalAt(0);
            if (size > 1) {
                int next = chronologicalAt(1);
                transitions[oldest][next] = Math.max(0, transitions[oldest][next] - 1);
                terminalTransitions[oldest % 10][next] =
                        Math.max(0, terminalTransitions[oldest % 10][next] - 1);
            }
            // A janela 500 contém o item que sai do anel; as demais janelas
            // contêm apenas a cauda recente e são ajustadas abaixo.
            windowCounts[windowIndex(500)][oldest] =
                    Math.max(0, windowCounts[windowIndex(500)][oldest] - 1);
            head = (head + 1) % CAPACITY;
            size--;
        }

        for (int w = 0; w < WINDOWS.length; w++) {
            int window = WINDOWS[w];
            if (size >= window) {
                int falling = chronologicalAt(size - window);
                windowCounts[w][falling] = Math.max(0, windowCounts[w][falling] - 1);
            }
            windowCounts[w][number]++;
        }

        int previous = size == 0 ? -1 : chronologicalAt(size - 1);
        ring[(head + size) % CAPACITY] = number;
        size++;
        if (previous >= 0) {
            transitions[previous][number]++;
            terminalTransitions[previous % 10][number]++;
        }
        deltaUpdates++;
    }

    public int size() { return size; }
    public long deltaUpdates() { return deltaUpdates; }
    public int rebuildCount() { return rebuildCount; }

    /** offset 0 = giro mais recente. */
    public int recent(int offset) {
        if (offset < 0 || offset >= size) throw new IndexOutOfBoundsException("recent offset");
        return chronologicalAt(size - 1 - offset);
    }

    public int windowCount(int window, int number) {
        if (!Wheel.valid(number)) return 0;
        int index = windowIndex(window);
        return windowCounts[index][number];
    }

    public int windowSize(int window) {
        windowIndex(window);
        return Math.min(window, size);
    }

    /** Faixa de offsets newest-first, inclusive. Ex.: 30..59 = giros 31–60. */
    public int bandCount(int offsetStart, int offsetEnd, int number) {
        if (!Wheel.valid(number) || size == 0) return 0;
        int start = Math.max(0, offsetStart);
        int end = Math.min(size - 1, Math.max(start, offsetEnd));
        int count = 0;
        for (int offset = start; offset <= end; offset++) if (recent(offset) == number) count++;
        return count;
    }

    public int transitionCount(int from, int to) {
        return Wheel.valid(from) && Wheel.valid(to) ? transitions[from][to] : 0;
    }

    public int transitionSamples(int from) {
        if (!Wheel.valid(from)) return 0;
        int total = 0;
        for (int value : transitions[from]) total += value;
        return total;
    }

    public int terminalTransitionCount(int terminal, int to) {
        return terminal >= 0 && terminal <= 9 && Wheel.valid(to)
                ? terminalTransitions[terminal][to] : 0;
    }

    public int terminalTransitionSamples(int terminal) {
        if (terminal < 0 || terminal > 9) return 0;
        int total = 0;
        for (int value : terminalTransitions[terminal]) total += value;
        return total;
    }

    public List<Integer> newestFirst(int limit) {
        if (limit <= 0 || size == 0) return Collections.emptyList();
        int count = Math.min(limit, size);
        List<Integer> out = new ArrayList<>(count);
        for (int i = 0; i < count; i++) out.add(recent(i));
        return Collections.unmodifiableList(out);
    }

    /** Retorna oldest-first; é a única orientação aceita pelo Pattern Echo. */
    public List<Integer> chronological(int limit) {
        if (limit <= 0 || size == 0) return Collections.emptyList();
        int count = Math.min(limit, size);
        int start = size - count;
        List<Integer> out = new ArrayList<>(count);
        for (int i = start; i < size; i++) out.add(chronologicalAt(i));
        return Collections.unmodifiableList(out);
    }

    public boolean matchesNewest(List<Integer> newestFirst) {
        if (newestFirst == null) return size == 0;
        int expected = Math.min(CAPACITY, newestFirst.size());
        if (expected != size) return false;
        int compare = Math.min(8, expected);
        for (int i = 0; i < compare; i++) {
            Integer value = newestFirst.get(i);
            if (value == null || !Wheel.valid(value) || recent(i) != value) return false;
        }
        return true;
    }

    public long fingerprint() {
        long hash = 0xcbf29ce484222325L;
        for (int i = 0; i < size; i++) {
            hash ^= chronologicalAt(i) + 1L;
            hash *= 0x100000001b3L;
        }
        return hash;
    }

    public boolean invariantHolds() {
        for (int w = 0; w < WINDOWS.length; w++) {
            int total = 0;
            for (int value : windowCounts[w]) total += value;
            if (total != Math.min(WINDOWS[w], size)) return false;
        }
        int transitionTotal = 0;
        int terminalTotal = 0;
        for (int from = 0; from < 37; from++) {
            for (int to = 0; to < 37; to++) transitionTotal += transitions[from][to];
        }
        for (int terminal = 0; terminal < 10; terminal++) {
            for (int to = 0; to < 37; to++) terminalTotal += terminalTransitions[terminal][to];
        }
        int expected = Math.max(0, size - 1);
        return transitionTotal == expected && terminalTotal == expected;
    }

    private int chronologicalAt(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("chronological index");
        return ring[(head + index) % CAPACITY];
    }

    private static int windowIndex(int window) {
        for (int i = 0; i < WINDOWS.length; i++) if (WINDOWS[i] == window) return i;
        throw new IllegalArgumentException("supported windows: " + Arrays.toString(WINDOWS));
    }

    private void clearInternal() {
        head = 0;
        size = 0;
        deltaUpdates = 0L;
        for (int[] counts : windowCounts) Arrays.fill(counts, 0);
        for (int[] row : transitions) Arrays.fill(row, 0);
        for (int[] row : terminalTransitions) Arrays.fill(row, 0);
    }

    private static void validate(List<Integer> values) {
        if (values == null) return;
        for (Integer value : values) {
            if (value == null || !Wheel.valid(value)) {
                throw new IllegalArgumentException("history contains invalid roulette value");
            }
        }
    }
}
