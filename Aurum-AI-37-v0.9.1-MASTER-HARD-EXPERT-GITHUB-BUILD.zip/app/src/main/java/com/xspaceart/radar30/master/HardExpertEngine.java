package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.lock.AurumLockSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Orquestrador puro do AURUM 37 AI MASTER — HARD EXPERT. */
public final class HardExpertEngine {
    private final PatternEchoSnapshotCache echoCache = new PatternEchoSnapshotCache();
    private final PressureMigrationTracker migrationTracker = new PressureMigrationTracker();
    private long lastEvaluatedHistoryHash = Long.MIN_VALUE;
    private MasterSignalSnapshot lastEvaluation;
    private int evaluationCount;

    public MasterSignalSnapshot analyze(MasterHistoryIndex index,
                                        MasterSignalSnapshot previous,
                                        AurumLockSnapshot legacy,
                                        CaptureContext capture,
                                        boolean publicationAllowed,
                                        int spinsAdded) {
        return analyze(index, previous, legacy, capture,
                publicationAllowed, spinsAdded, false);
    }

    public MasterSignalSnapshot analyze(MasterHistoryIndex index,
                                        MasterSignalSnapshot previous,
                                        AurumLockSnapshot legacy,
                                        CaptureContext capture,
                                        boolean publicationAllowed,
                                        int spinsAdded,
                                        boolean forceRefresh) {
        long startedNanos = System.nanoTime();
        long now = capture == null || capture.nowMs <= 0L
                ? System.currentTimeMillis() : capture.nowMs;
        CaptureContext safeCapture = capture == null ? CaptureContext.restored(now) : capture;
        MasterSignalSnapshot prior = previous == null ? MasterSignalSnapshot.empty() : previous;

        if (index == null || index.size() == 0) {
            return MasterSignalSnapshot.empty();
        }
        long historyHash = index.fingerprint();
        boolean sameHistory = historyHash == lastEvaluatedHistoryHash;
        if (!forceRefresh && sameHistory && lastEvaluation != null) {
            return lastEvaluation;
        }
        evaluationCount++;

        MicroPressureEngine.Result micro = MicroPressureEngine.analyze(index);
        double[] spatial = SpatialPressureEngine.multiWindow(index);
        double[] physical = combine(spatial, 0.62, micro.pressure, 0.38);
        List<MasterEvidence> evidence = new ArrayList<>();
        evidence.add(new MasterEvidence(MasterEvidence.Family.PHYSICAL,
                "physical:recent-multiscale", "radar físico 3/5/10/30/60/150/500",
                physical, physicalConfidence(index), true));

        double[] sequential = sequentialPressure(index);
        evidence.add(new MasterEvidence(MasterEvidence.Family.SEQUENTIAL,
                "sequential:transition-jump", "transições e jumps",
                sequential, sequentialConfidence(index), true));

        double[] numeric = numericPressure(index);
        evidence.add(new MasterEvidence(MasterEvidence.Family.NUMERIC,
                "numeric:terminal-arithmetic", "terminais / soma / subtração",
                numeric, numericConfidence(index), true));

        PatternEchoSnapshot echo = echoCache.update(index);
        if (echo.active) {
            evidence.add(new MasterEvidence(MasterEvidence.Family.PATTERN_ECHO,
                    "echo:historical-pattern", "Pattern Echo",
                    echo.copyPressure(), echo.strength / 100.0, true));
        }

        if (legacy != null && legacy.conditionalPrediction != null
                && legacy.conditionalPrediction.available()) {
            evidence.add(new MasterEvidence(MasterEvidence.Family.LEGACY_FUSION,
                    "legacy:cpe-lock", "CPE + Aurum Lock",
                    legacy.conditionalPrediction.copyPressure(),
                    Math.max(0.25, legacy.conditionalPrediction.sampleQuality / 100.0), false));
        }

        MasterSignalFusion.Result fusion = MasterSignalFusion.fuse(evidence, index);
        PressureMigrationTracker.Result migration = sameHistory && forceRefresh
                && prior.historyFingerprint == historyHash
                ? new PressureMigrationTracker.Result(prior.migrating,
                Math.max(1, prior.persistence), prior.target)
                : migrationTracker.update(fusion.primary);
        DualPressureDetector.Result dual = DualPressureDetector.detect(
                fusion.primary, fusion.secondary);
        boolean migrationDivergence = migrationDivergesFromDominantSector(
                migration, fusion.primary);
        int migrationDivergencePenalty = migrationDivergence ? 14 : 0;
        Regime regime = regime(index, fusion.primary);
        boolean regimeChanged = prior.historyFingerprint != 0L
                && !prior.regime.equals(regime.label);
        int inheritedAge = migration.persistence > 1
                ? prior.signalAgeSpins + Math.max(1, spinsAdded) : 0;
        int agePenalty = prior.validitySpins > 0 && inheritedAge >= prior.validitySpins
                ? Math.min(24, 6 * (inheritedAge - prior.validitySpins + 1)) : 0;

        int persistenceScore = clamp(18 + 21 * Math.min(4, migration.persistence));
        int preliminary = clamp((int) Math.round(
                0.29 * fusion.primary.score
                        + 0.12 * fusion.targetScore
                        + 0.18 * (25 * fusion.independentReadings)
                        + 0.10 * micro.acceleration
                        + 0.08 * echo.strength
                        + 0.08 * persistenceScore
                        + 0.08 * regime.strength
                        + 0.07 * fusion.gap
                        - 0.10 * dual.conflict
                        + (regimeChanged ? 4.0 : 0.0)
                        - agePenalty
                        - fusion.noisePenalty
                        - migrationDivergencePenalty));
        int acceleration = prior.historyFingerprint == 0L ? micro.acceleration
                : MasterSignalFusion.temporalAcceleration(prior.pressure, preliminary,
                micro.acceleration);
        int pressure = clamp((int) Math.round(0.88 * preliminary + 0.12 * acceleration));

        int contradiction = clamp(dual.conflict
                + Math.max(0, 3 - fusion.independentReadings) * 9
                + (fusion.deduplicatedEvidenceCount < 3 ? 12 : 0));
        ConfigurationQualityEngine.Result quality = ConfigurationQualityEngine.evaluate(
                index, fusion.primary.members, fusion.independentReadings,
                migration.persistence, echo.strength, contradiction);

        long analyzedAt = System.currentTimeMillis();
        SignalFreshnessGate.Result freshness = SignalFreshnessGate.evaluate(
                analyzedAt, safeCapture.capturedAtMs, analyzedAt,
                safeCapture.dataQualityValid, index.size() >= 3,
                safeCapture.ocrConfidence, safeCapture.captureStatus);
        int legacyConfidence = clamp((int) Math.round(
                0.55 * pressure + 0.45 * quality.score));
        int confidence = clamp((int) Math.round(
                0.65 * legacyConfidence + 0.35 * fusion.confluenceConfidence
                        - 0.50 * fusion.noisePenalty));
        MasterSignalFusion.StrongGate strongGate = MasterSignalFusion.evaluateStrongGate(
                quality.score, confidence, fusion.rivalScore, fusion.entropyBlocked);
        MasterSignalSnapshot.State state = classify(pressure, quality.score,
                fusion.independentReadings, migration.persistence, acceleration,
                contradiction, dual.dual, freshness.fresh,
                fusion.strongConfluenceEligible, fusion.noisePenalty, strongGate);

        boolean sameRegion = migration.persistence > 1;
        int signalAge = sameRegion && prior.state == state
                ? prior.signalAgeSpins + Math.max(1, spinsAdded) : 0;
        int validity = state == MasterSignalSnapshot.State.EXTREME ? 5
                : state == MasterSignalSnapshot.State.STRONG ? 4
                : state == MasterSignalSnapshot.State.MODERATE ? 3 : 0;
        if (fusion.rivalScore > MasterSignalFusion.RIVAL_PROJECTION_LIMIT) {
            validity = Math.min(validity, 3);
        }
        boolean newEvent = publicationAllowed && (prior.state != state
                || !sameRegion || prior.dualPressure != dual.dual
                || pressure >= prior.pressure + 12);
        boolean shouldAlert = publicationAllowed && freshness.fresh
                && (state == MasterSignalSnapshot.State.STRONG
                || state == MasterSignalSnapshot.State.EXTREME)
                && signalAge < Math.max(1, validity)
                && (newEvent || pressure >= prior.pressure + 6);

        List<Integer> series = new ArrayList<>(prior.pressureSeries);
        if (prior.historyFingerprint != index.fingerprint()) series.add(pressure);
        while (series.size() > 5) series.remove(0);
        List<String> labels = new ArrayList<>(fusion.evidenceLabels);
        if (legacy != null && legacy.conditionalPrediction != null
                && legacy.conditionalPrediction.available()) {
            labels.add("CPE ativo (fusão auxiliar deduplicada)");
        }
        if (migration.migrating) labels.add("pressão migrando no mesmo setor");
        if (migrationDivergence) {
            labels.add("divergência entre setor dominante e migração de pressão"
                    + " • score -" + migrationDivergencePenalty);
        }
        if (dual.dual) labels.add("dupla pressão separada");
        if (regimeChanged) labels.add("mudança de regime: " + prior.regime + " → " + regime.label);
        if (agePenalty > 0) labels.add("penalidade por idade do sinal: " + agePenalty);
        if (quality.outOfSampleReady) labels.add("estrutura pronta para validação fora da amostra");
        if (!strongGate.allowStrong && !strongGate.reason.isEmpty()
                && !labels.contains(strongGate.reason)) {
            labels.add(strongGate.reason);
        }
        if (fusion.recommendedSpins > 0 && fusion.primary.available()) {
            String protection = fusion.protectionTerminals.size() >= 2
                    ? "T" + fusion.protectionTerminals.get(0)
                    + " / T" + fusion.protectionTerminals.get(1) : "—";
            labels.add("projeção temporal " + fusion.recommendedSpins
                    + " giros • setor " + fusion.primary.members
                    + " • terminais de proteção " + protection);
        }
        labels.add("índice normalizado de confluência " + confidence
                + "% • não é probabilidade de acerto");

        String statusReason = strongGate.rivalVeto ? strongGate.reason
                : state == MasterSignalSnapshot.State.BLOCKED
                ? (!freshness.fresh ? freshness.label
                : quality.score < 45 ? "qualidade da configuração insuficiente"
                : "conflito excessivo entre leituras")
                : !strongGate.allowStrong && pressure >= 63 ? strongGate.reason : "";
        String effectiveRegime = strongGate.rivalVeto
                ? MasterSignalFusion.BIPOLAR_OBSERVATION_STATUS : regime.label;
        long engineMs = Math.max(0L, (System.nanoTime() - startedNanos) / 1_000_000L);
        long processingMs = safeCapture.capturedAtMs > 0L
                ? Math.max(engineMs, analyzedAt - safeCapture.capturedAtMs) : engineMs;
        MasterSignalSnapshot result = new MasterSignalSnapshot(state, fusion.target, pressure,
                quality.score, confidence, fusion.rival, fusion.rivalScore,
                fusion.gap, fusion.independentReadings, migration.persistence,
                acceleration, validity, signalAge, dual.dual,
                migration.migrating, !freshness.fresh, shouldAlert, newEvent,
                effectiveRegime, freshness.label, statusReason,
                fusion.primary.members,
                dual.dual ? fusion.secondary.members : Collections.emptyList(),
                dual.dual ? fusion.secondary.score : 0,
                fusion.rankingNumbers, fusion.rankingScores, series, labels,
                echo, safeCapture.capturedAtMs, analyzedAt, processingMs,
                historyHash);
        lastEvaluatedHistoryHash = historyHash;
        lastEvaluation = result;
        return result;
    }

    public void reset() {
        echoCache.reset();
        migrationTracker.reset();
        lastEvaluatedHistoryHash = Long.MIN_VALUE;
        lastEvaluation = null;
        evaluationCount = 0;
    }

    public int patternEchoComputationCount() { return echoCache.computationCount(); }
    public int evaluationCount() { return evaluationCount; }

    private static MasterSignalSnapshot.State classify(int pressure, int quality,
                                                        int independent, int persistence,
                                                        int acceleration, int contradiction,
                                                        boolean dual, boolean fresh,
                                                        boolean strongConfluenceEligible,
                                                        int noisePenalty,
                                                        MasterSignalFusion.StrongGate strongGate) {
        if (!fresh) return MasterSignalSnapshot.State.BLOCKED;
        if (pressure >= 63 && quality < 45) return MasterSignalSnapshot.State.BLOCKED;
        if (contradiction >= 78 && pressure >= 55) return MasterSignalSnapshot.State.BLOCKED;
        if (strongGate.rivalVeto) return MasterSignalSnapshot.State.HEATING;
        if (strongGate.entropyVeto
                || (noisePenalty >= 12 && !strongConfluenceEligible)) {
            return pressure >= 48 ? MasterSignalSnapshot.State.HEATING
                    : MasterSignalSnapshot.State.SILENCE;
        }
        if (pressure >= 90 && quality >= 82 && independent >= 4
                && persistence >= 3 && contradiction < 30 && !dual
                && strongConfluenceEligible && strongGate.allowStrong) {
            return MasterSignalSnapshot.State.EXTREME;
        }
        if (pressure >= 76 && quality >= MasterSignalFusion.MIN_STRONG_QUALITY
                && independent >= 3
                && (persistence >= 2 || acceleration >= 66) && contradiction < 70
                && strongConfluenceEligible && strongGate.allowStrong) {
            return MasterSignalSnapshot.State.STRONG;
        }
        if (pressure >= 63 && quality >= 48 && independent >= 2) {
            return MasterSignalSnapshot.State.MODERATE;
        }
        if (pressure >= 48 || (acceleration >= 62 && pressure >= 42)) {
            return MasterSignalSnapshot.State.HEATING;
        }
        return MasterSignalSnapshot.State.SILENCE;
    }

    private static boolean migrationDivergesFromDominantSector(
            PressureMigrationTracker.Result migration,
            SectorClusterEngine.Cluster dominant) {
        if (migration == null || migration.previousCenter < 0
                || dominant == null || !dominant.available()) return false;
        int safeRadius = Math.max(3, dominant.radius + 2);
        return Wheel.distance(migration.previousCenter, dominant.center) > safeRadius;
    }

    private static double[] sequentialPressure(MasterHistoryIndex index) {
        double[] out = new double[37];
        if (index.size() == 0) return out;
        int latest = index.recent(0);
        int samples = index.transitionSamples(latest);
        if (samples > 0) for (int to = 0; to < 37; to++) {
            out[to] += 1.25 * reliability(samples, 18.0)
                    * index.transitionCount(latest, to) / samples;
        }
        int terminal = latest % 10;
        int terminalSamples = index.terminalTransitionSamples(terminal);
        if (terminalSamples > 0) for (int to = 0; to < 37; to++) {
            out[to] += 0.72 * reliability(terminalSamples, 36.0)
                    * index.terminalTransitionCount(terminal, to) / terminalSamples;
        }
        if (index.size() >= 3) {
            int a = signedStep(index.recent(2), index.recent(1));
            int b = signedStep(index.recent(1), index.recent(0));
            if (Math.abs(a - b) <= 3) {
                MicroPressureEngine.addKernel(out, shift(index.recent(0), b), 0.50);
            }
            List<Integer> h = index.chronological(Math.min(500, index.size()));
            for (int i = 2; i + 1 < h.size() - 2; i++) {
                int x = signedStep(h.get(i - 2), h.get(i - 1));
                int y = signedStep(h.get(i - 1), h.get(i));
                if (Math.abs(x - a) <= 2 && Math.abs(y - b) <= 2) {
                    MicroPressureEngine.addKernel(out, h.get(i + 1), 0.18);
                }
            }
        }
        SpatialPressureEngine.normalize(out);
        return out;
    }

    private static double[] numericPressure(MasterHistoryIndex index) {
        double[] out = new double[37];
        int[] windows = {5, 10, 30, 60, 150, 500};
        double[] weights = {0.24, 0.23, 0.20, 0.14, 0.11, 0.08};
        for (int terminal = 0; terminal < 10; terminal++) {
            double value = 0.0;
            for (int i = 0; i < windows.length; i++) {
                int size = index.windowSize(windows[i]);
                if (size <= 0) continue;
                int hits = 0;
                for (int n = terminal; n <= 36; n += 10) hits += index.windowCount(windows[i], n);
                value += weights[i] * hits / size;
            }
            for (int n = terminal; n <= 36; n += 10) out[n] += value;
        }

        if (index.size() >= 3) {
            int a = index.recent(0), b = index.recent(1), c = index.recent(2);
            addValidatedArithmetic(index, out, 0, Math.abs(a - b));
            addValidatedArithmetic(index, out, 1, (a + b) % 37);
            addValidatedArithmetic(index, out, 2, Math.abs(a - b - c));
            addValidatedArithmetic(index, out, 3, (a + b + c) % 37);
            int d1 = a - b, d2 = b - c;
            if (Integer.signum(d1) == Integer.signum(d2) && Math.abs(d1 - d2) <= 3) {
                int projected = a + d1;
                if (Wheel.valid(projected)) MicroPressureEngine.addKernel(out, projected, 0.32);
            }
        }

        if (index.size() >= 30) {
            for (int n = 0; n < 37; n++) {
                if (index.windowCount(30, n) == 0) out[n] += 0.045;
                if (index.windowCount(5, n) >= 2) out[n] += 0.10;
            }
        }
        SpatialPressureEngine.normalize(out);
        return out;
    }

    private static void addValidatedArithmetic(MasterHistoryIndex index, double[] out,
                                                int rule, int currentCandidate) {
        if (!Wheel.valid(currentCandidate) || index.size() < 28) return;
        List<Integer> h = index.chronological(Math.min(500, index.size()));
        int samples = 0, hits = 0;
        for (int i = 2; i + 1 < h.size(); i++) {
            int candidate = arithmetic(rule, h.get(i), h.get(i - 1), h.get(i - 2));
            if (!Wheel.valid(candidate)) continue;
            samples++;
            if (candidate == h.get(i + 1)) hits++;
        }
        if (samples < 20) return;
        double rate = (hits + 4.0 / 37.0) / (samples + 4.0);
        double lift = Math.max(0.0, (rate - 1.0 / 37.0) / (1.0 - 1.0 / 37.0));
        if (lift >= 0.02) MicroPressureEngine.addKernel(out, currentCandidate,
                0.20 + 0.65 * Math.min(1.0, lift * 6.0));
    }

    private static int arithmetic(int rule, int a, int b, int c) {
        switch (rule) {
            case 0: return Math.abs(a - b);
            case 1: return (a + b) % 37;
            case 2: return Math.abs(a - b - c);
            case 3: return (a + b + c) % 37;
            default: return -1;
        }
    }

    private static double physicalConfidence(MasterHistoryIndex index) {
        return Math.min(0.94, 0.38 + 0.56 * Math.min(1.0, index.size() / 60.0));
    }

    private static double sequentialConfidence(MasterHistoryIndex index) {
        if (index.size() == 0) return 0.0;
        int samples = index.transitionSamples(index.recent(0));
        return Math.min(0.90, 0.22 + 0.68 * reliability(samples, 18.0));
    }

    private static double numericConfidence(MasterHistoryIndex index) {
        return Math.min(0.88, 0.25 + 0.63 * Math.min(1.0, index.size() / 90.0));
    }

    private static Regime regime(MasterHistoryIndex index, SectorClusterEngine.Cluster cluster) {
        if (cluster == null || !cluster.available() || index.size() < 5) {
            return new Regime("DISPERSÃO", 35);
        }
        double recent = sectorRate(index, cluster.members, 0, Math.min(10, index.size()));
        double prior = index.size() <= 10 ? recent
                : sectorRate(index, cluster.members, 10, Math.min(20, index.size() - 10));
        double change = recent - prior;
        if (recent >= 0.60 && change >= 0.15) return new Regime("CONVERGÊNCIA", 92);
        if (recent >= 0.48) return new Regime("CONCENTRAÇÃO", 76);
        if (Math.abs(change) >= 0.22) return new Regime("MUDANÇA DE REGIME", 62);
        return new Regime("DISPERSÃO", 42);
    }

    private static double sectorRate(MasterHistoryIndex index, List<Integer> sector,
                                     int start, int count) {
        if (count <= 0) return 0.0;
        int hits = 0;
        for (int i = start; i < start + count && i < index.size(); i++) {
            if (sector.contains(index.recent(i))) hits++;
        }
        return hits / (double) count;
    }

    private static double[] combine(double[] a, double wa, double[] b, double wb) {
        double[] out = new double[37];
        for (int i = 0; i < 37; i++) out[i] = a[i] * wa + b[i] * wb;
        SpatialPressureEngine.normalize(out);
        return out;
    }

    private static int signedStep(int from, int to) {
        int d = Wheel.EUROPEAN.indexOf(to) - Wheel.EUROPEAN.indexOf(from);
        if (d > 18) d -= 37;
        if (d < -18) d += 37;
        return d;
    }

    private static int shift(int number, int offset) {
        int p = (Wheel.EUROPEAN.indexOf(number) + offset) % 37;
        if (p < 0) p += 37;
        return Wheel.EUROPEAN.get(p);
    }

    private static double reliability(int samples, double half) {
        return samples <= 0 ? 0.0 : samples / (samples + half);
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }

    private static final class Regime {
        final String label;
        final int strength;
        Regime(String label, int strength) { this.label = label; this.strength = strength; }
    }

    public static final class CaptureContext {
        public final long nowMs;
        public final long capturedAtMs;
        public final boolean dataQualityValid;
        public final double ocrConfidence;
        public final String captureStatus;

        public CaptureContext(long nowMs, long capturedAtMs, boolean dataQualityValid,
                              double ocrConfidence, String captureStatus) {
            this.nowMs = nowMs;
            this.capturedAtMs = capturedAtMs;
            this.dataQualityValid = dataQualityValid;
            this.ocrConfidence = Math.max(0.0, Math.min(1.0, ocrConfidence));
            this.captureStatus = captureStatus == null ? "" : captureStatus;
        }

        public static CaptureContext restored(long nowMs) {
            // Restaura a estrutura sem publicar alerta. A interface ainda veta a
            // exibição enquanto a captura Android estiver parada.
            return new CaptureContext(nowMs, nowMs, true, 1.0, "RESTORED");
        }
    }
}
