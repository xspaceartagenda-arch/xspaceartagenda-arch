package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Agrupa força próxima em setores adaptativos da roda, não em números isolados. */
public final class SectorClusterEngine {
    private static final int RECENT_WINDOW = 18;
    private static final double RECENCY_HALF_LIFE = 6.0;
    private static final double HOT_Z_THRESHOLD = 1.35;
    private static final double MIN_EFFECTIVE_SAMPLE = 8.0;

    private SectorClusterEngine() {}

    public static Result cluster(double[] pressure, int suggestedRadius) {
        return cluster(pressure, suggestedRadius, null);
    }

    /**
     * Kernel espacial contínuo sobre a ordem física da roda europeia. O vetor dos
     * motores continua sendo a fonte principal; o histórico recente acrescenta
     * densidade exponencial e significância contra a hipótese uniforme.
     */
    public static Result cluster(double[] pressure, int suggestedRadius,
                                 MasterHistoryIndex history) {
        double[] safe = pressure == null ? new double[37] : pressure.clone();
        SpatialPressureEngine.normalize(safe);
        KernelProfile kernel = KernelProfile.from(history);
        if (kernel.available) {
            for (int number = 0; number < 37; number++) {
                safe[number] = 0.76 * safe[number] + 0.24 * kernel.density[number];
            }
            SpatialPressureEngine.normalize(safe);
        }
        List<Cluster> candidates = new ArrayList<>();
        for (int center = 0; center < 37; center++) {
            Cluster best = null;
            int minRadius = Math.max(2, suggestedRadius - 1);
            // Hot clusters operacionais têm 5 ou 7 bolsões contíguos.
            int maxRadius = Math.min(3, suggestedRadius + 1);
            if (minRadius > maxRadius) minRadius = maxRadius;
            for (int radius = minRadius; radius <= maxRadius; radius++) {
                List<Integer> members = Wheel.coverage(center, radius);
                double sum = 0.0, peak = 0.0, kernelSum = 0.0;
                for (Integer number : members) {
                    sum += safe[number];
                    peak = Math.max(peak, safe[number]);
                    kernelSum += kernel.density[number];
                }
                double average = sum / Math.max(1, members.size());
                double kernelAverage = kernelSum / Math.max(1, members.size());
                double widthPenalty = 1.0 - 0.045 * Math.max(0, radius - 2);
                HotStats hot = HotStats.evaluate(history, members, kernel);
                double base = kernel.available
                        ? 0.50 * peak + 0.34 * average + 0.16 * kernelAverage
                        : 0.56 * peak + 0.44 * average;
                double significanceBoost = kernel.available
                        ? 0.12 * clamp01((hot.zScore - 0.75) / 2.25) : 0.0;
                int score = clamp((int) Math.round(100.0
                        * (base * widthPenalty + significanceBoost)));
                Cluster candidate = new Cluster(center, radius, members, score, peak,
                        hot.zScore, hot.observedDensity, hot.expectedDensity,
                        hot.effectiveSampleSize, hot.statisticallyHot);
                if (best == null || candidate.score > best.score) best = candidate;
            }
            candidates.add(best);
        }
        candidates.sort((a, b) -> {
            int c = Integer.compare(b.score, a.score);
            return c != 0 ? c : Integer.compare(a.center, b.center);
        });

        Cluster primary = candidates.isEmpty() ? Cluster.empty() : candidates.get(0);
        Cluster secondary = Cluster.empty();
        for (Cluster candidate : candidates) {
            if (candidate.center == primary.center) continue;
            int separation = Wheel.distance(primary.center, candidate.center);
            if (separation > primary.radius + candidate.radius + 1) {
                secondary = candidate;
                break;
            }
        }
        return new Result(primary, secondary, Collections.unmodifiableList(candidates),
                kernel.available, kernel.effectiveSampleSize);
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }
    private static double clamp01(double value) {
        return Double.isFinite(value) ? Math.max(0.0, Math.min(1.0, value)) : 0.0;
    }

    public static final class Cluster {
        public final int center;
        public final int radius;
        public final List<Integer> members;
        public final int score;
        public final double peak;
        public final double zScore;
        public final double observedDensity;
        public final double expectedDensity;
        public final double effectiveSampleSize;
        public final boolean statisticallyHot;

        Cluster(int center, int radius, List<Integer> members, int score, double peak) {
            this(center, radius, members, score, peak, 0.0,
                    0.0, members == null ? 0.0 : members.size() / 37.0,
                    0.0, false);
        }

        Cluster(int center, int radius, List<Integer> members, int score, double peak,
                double zScore, double observedDensity, double expectedDensity,
                double effectiveSampleSize, boolean statisticallyHot) {
            this.center = center;
            this.radius = radius;
            this.members = members == null ? Collections.emptyList()
                    : Collections.unmodifiableList(new ArrayList<>(members));
            this.score = clamp(score);
            this.peak = Math.max(0.0, Math.min(1.0, peak));
            this.zScore = Double.isFinite(zScore) ? zScore : 0.0;
            this.observedDensity = clamp01(observedDensity);
            this.expectedDensity = clamp01(expectedDensity);
            this.effectiveSampleSize = Math.max(0.0, effectiveSampleSize);
            this.statisticallyHot = statisticallyHot;
        }

        public static Cluster empty() {
            return new Cluster(-1, 0, Collections.emptyList(), 0, 0.0);
        }

        public boolean available() { return center >= 0 && !members.isEmpty(); }
    }

    public static final class Result {
        public final Cluster primary;
        public final Cluster secondary;
        public final List<Cluster> candidates;
        public final boolean wheelKernelApplied;
        public final double effectiveSampleSize;

        Result(Cluster primary, Cluster secondary, List<Cluster> candidates) {
            this(primary, secondary, candidates, false, 0.0);
        }

        Result(Cluster primary, Cluster secondary, List<Cluster> candidates,
               boolean wheelKernelApplied, double effectiveSampleSize) {
            this.primary = primary;
            this.secondary = secondary;
            this.candidates = candidates;
            this.wheelKernelApplied = wheelKernelApplied;
            this.effectiveSampleSize = Math.max(0.0, effectiveSampleSize);
        }
    }

    private static final class KernelProfile {
        final double[] density;
        final double totalWeight;
        final double squaredWeight;
        final double effectiveSampleSize;
        final int sampleCount;
        final boolean available;

        KernelProfile(double[] density, double totalWeight, double squaredWeight,
                      int sampleCount) {
            this.density = density;
            this.totalWeight = totalWeight;
            this.squaredWeight = squaredWeight;
            this.effectiveSampleSize = squaredWeight <= 1e-12
                    ? 0.0 : totalWeight * totalWeight / squaredWeight;
            this.sampleCount = sampleCount;
            this.available = sampleCount >= 3 && totalWeight > 1e-12;
        }

        static KernelProfile from(MasterHistoryIndex history) {
            double[] density = new double[37];
            if (history == null || history.size() == 0) {
                return new KernelProfile(density, 0.0, 0.0, 0);
            }
            int count = Math.min(RECENT_WINDOW, history.size());
            double total = 0.0, squared = 0.0;
            for (int offset = 0; offset < count; offset++) {
                int source = history.recent(offset);
                double recency = Math.exp(-Math.log(2.0) * offset / RECENCY_HALF_LIFE);
                total += recency;
                squared += recency * recency;
                for (int number = 0; number < 37; number++) {
                    int distance = Wheel.distance(source, number);
                    density[number] += recency * Math.exp(-distance / 1.55);
                }
            }
            SpatialPressureEngine.normalize(density);
            return new KernelProfile(density, total, squared, count);
        }
    }

    private static final class HotStats {
        final double zScore;
        final double observedDensity;
        final double expectedDensity;
        final double effectiveSampleSize;
        final boolean statisticallyHot;

        HotStats(double zScore, double observedDensity, double expectedDensity,
                 double effectiveSampleSize, boolean statisticallyHot) {
            this.zScore = zScore;
            this.observedDensity = observedDensity;
            this.expectedDensity = expectedDensity;
            this.effectiveSampleSize = effectiveSampleSize;
            this.statisticallyHot = statisticallyHot;
        }

        static HotStats evaluate(MasterHistoryIndex history, List<Integer> members,
                                 KernelProfile kernel) {
            double expected = members == null ? 0.0 : members.size() / 37.0;
            if (history == null || !kernel.available || members == null || members.isEmpty()) {
                return new HotStats(0.0, 0.0, expected,
                        kernel.effectiveSampleSize, false);
            }
            double hits = 0.0;
            int count = Math.min(kernel.sampleCount, history.size());
            for (int offset = 0; offset < count; offset++) {
                double recency = Math.exp(-Math.log(2.0) * offset / RECENCY_HALF_LIFE);
                if (members.contains(history.recent(offset))) hits += recency;
            }
            double observed = hits / kernel.totalWeight;
            double standardError = Math.sqrt(Math.max(1e-12,
                    expected * (1.0 - expected) * kernel.squaredWeight
                            / (kernel.totalWeight * kernel.totalWeight)));
            double z = (observed - expected) / standardError;
            boolean hot = kernel.effectiveSampleSize >= MIN_EFFECTIVE_SAMPLE
                    && z >= HOT_Z_THRESHOLD && observed > expected;
            return new HotStats(z, observed, expected,
                    kernel.effectiveSampleSize, hot);
        }
    }
}
