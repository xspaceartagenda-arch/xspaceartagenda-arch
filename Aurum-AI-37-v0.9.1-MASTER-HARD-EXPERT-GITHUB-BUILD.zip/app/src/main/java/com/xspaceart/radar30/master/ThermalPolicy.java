package com.xspaceart.radar30.master;

/** Política pura e testável do Thermal Guard; não contém dependência Android. */
public final class ThermalPolicy {
    public enum Mode { MAXIMUM, CONSERVATIVE, PROTECTED }

    public final Mode mode;
    public final long normalFrameIntervalMs;
    public final long fastFrameIntervalMs;
    public final long ocrHeartbeatMs;
    public final long uiRefreshMs;
    public final boolean allowAnimations;
    public final boolean allowSecondaryWork;

    private ThermalPolicy(Mode mode, long normalFrameIntervalMs,
                          long fastFrameIntervalMs, long ocrHeartbeatMs,
                          long uiRefreshMs, boolean allowAnimations,
                          boolean allowSecondaryWork) {
        this.mode = mode;
        this.normalFrameIntervalMs = normalFrameIntervalMs;
        this.fastFrameIntervalMs = fastFrameIntervalMs;
        this.ocrHeartbeatMs = ocrHeartbeatMs;
        this.uiRefreshMs = uiRefreshMs;
        this.allowAnimations = allowAnimations;
        this.allowSecondaryWork = allowSecondaryWork;
    }

    /** Android thermal status: 0 none, 1 light, 2 moderate, 3+ severe. */
    public static ThermalPolicy forStatus(int thermalStatus) {
        if (thermalStatus >= 3) {
            return new ThermalPolicy(Mode.PROTECTED, 700L, 600L,
                    2_600L, 1_000L, false, false);
        }
        if (thermalStatus >= 2) {
            return new ThermalPolicy(Mode.CONSERVATIVE, 450L, 350L,
                    1_900L, 900L, false, true);
        }
        return new ThermalPolicy(Mode.MAXIMUM, 350L, 250L,
                1_400L, 800L, true, true);
    }
}
