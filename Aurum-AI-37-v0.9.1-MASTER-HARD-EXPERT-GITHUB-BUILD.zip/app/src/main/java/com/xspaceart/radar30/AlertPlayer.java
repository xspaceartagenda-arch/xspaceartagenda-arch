package com.xspaceart.radar30;

import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;

import com.xspaceart.radar30.core.SignalUpdate;

import java.util.Locale;

public final class AlertPlayer implements TextToSpeech.OnInitListener {
    private final Context context;
    private final Vibrator vibrator;
    private final TextToSpeech speech;
    private ToneGenerator tone;
    private boolean ready;
    private String pending = "";

    public AlertPlayer(Context context) {
        this.context = context.getApplicationContext();
        this.vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        this.speech = new TextToSpeech(this.context, this);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = speech.setLanguage(new Locale("pt", "BR"));
            ready = result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
            speech.setSpeechRate(1.03f);
            if (ready && !pending.isEmpty()) {
                speakNow(pending);
                pending = "";
            }
        }
    }

    public void play(SignalUpdate update) {
        vibrate(update.kind);
        if (!AppStateStore.voiceEnabled(context) || update.speech.isEmpty()) return;
        if (ready) speakNow(update.speech);
        else pending = update.speech;
    }

    /** Alerta sensorial exclusivo do Hard Expert; score é força interna, não chance. */
    public void playMaster(SignalUpdate update, boolean extreme) {
        if (update == null) return;
        vibrateMaster(extreme);
        if (AppStateStore.masterSoundEnabled(context)) {
            try {
                if (tone == null) tone = new ToneGenerator(AudioManager.STREAM_ALARM, 82);
                tone.startTone(extreme
                        ? ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD
                        : ToneGenerator.TONE_PROP_BEEP2, extreme ? 850 : 500);
            } catch (RuntimeException ignored) {
                // Vibração e alerta visual continuam disponíveis.
            }
        }
        if (!AppStateStore.voiceEnabled(context) || update.speech.isEmpty()) return;
        if (ready) speakNow(update.speech);
        else pending = update.speech;
    }

    public void shutdown() {
        speech.stop();
        speech.shutdown();
        if (tone != null) {
            tone.release();
            tone = null;
        }
    }

    private void speakNow(String value) {
        speech.speak(value, TextToSpeech.QUEUE_FLUSH, null, "radar30-alert");
    }

    private void vibrate(SignalUpdate.Kind kind) {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        long[] pattern;
        if (kind == SignalUpdate.Kind.HIT
                || kind == SignalUpdate.Kind.SECONDARY_HIT) {
            pattern = new long[]{0, 100, 80, 100, 80, 220};
        }
        else if (kind == SignalUpdate.Kind.ENTRY) pattern = new long[]{0, 150, 90, 240};
        else if (kind == SignalUpdate.Kind.TRIAL) pattern = new long[]{0, 120};
        else if (kind == SignalUpdate.Kind.EXPIRED) pattern = new long[]{0, 350};
        else return;
        vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
    }

    private void vibrateMaster(boolean extreme) {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        long[] pattern = extreme
                ? new long[]{0, 260, 80, 260, 80, 420}
                : new long[]{0, 180, 90, 180, 90, 280};
        vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
    }
}
