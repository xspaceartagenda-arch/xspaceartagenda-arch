package com.xspaceart.radar30.master;

import com.xspaceart.radar30.lock.AurumLockSnapshot;

import java.util.Collections;
import java.util.List;

/** Estado incremental do Hard Expert; rebuild somente em correção ou resync. */
public final class HardExpertSession {
    private final MasterHistoryIndex index = new MasterHistoryIndex();
    private final HardExpertEngine engine = new HardExpertEngine();
    private MasterSignalSnapshot current = MasterSignalSnapshot.empty();
    private boolean initialized;
    private long lastEvaluatedHistoryHash = Long.MIN_VALUE;

    public MasterSignalSnapshot replaceHistory(List<Integer> newestFirst) {
        reset();
        index.rebuildNewestFirst(newestFirst);
        initialized = true;
        long now = System.currentTimeMillis();
        current = engine.analyze(index, current, null,
                HardExpertEngine.CaptureContext.restored(now), false, 0, true);
        lastEvaluatedHistoryHash = index.fingerprint();
        return current;
    }

    public MasterSignalSnapshot update(List<Integer> fullHistoryNewestFirst,
                                       List<Integer> newNumbersNewestFirst,
                                       boolean dataQualityValid,
                                       long capturedAtMs,
                                       double ocrConfidence,
                                       String captureStatus,
                                       AurumLockSnapshot legacySnapshot) {
        return update(fullHistoryNewestFirst, newNumbersNewestFirst,
                dataQualityValid, capturedAtMs, ocrConfidence,
                captureStatus, legacySnapshot, false);
    }

    /** Reavalia sem mudança de histórico somente quando forceRefresh é explícito. */
    public MasterSignalSnapshot update(List<Integer> fullHistoryNewestFirst,
                                       List<Integer> newNumbersNewestFirst,
                                       boolean dataQualityValid,
                                       long capturedAtMs,
                                       double ocrConfidence,
                                       String captureStatus,
                                       AurumLockSnapshot legacySnapshot,
                                       boolean forceRefresh) {
        if (!dataQualityValid) return blockDataQuality("leitura rejeitada");
        List<Integer> delta = newNumbersNewestFirst == null
                ? Collections.emptyList() : newNumbersNewestFirst;
        try {
            if (!initialized) {
                index.rebuildNewestFirst(fullHistoryNewestFirst);
                engine.reset();
                initialized = true;
            } else if (!delta.isEmpty()) {
                index.appendNewestFirst(delta);
                if (!index.matchesNewest(fullHistoryNewestFirst)
                        || index.fingerprint() != fingerprintNewest(fullHistoryNewestFirst)) {
                    index.rebuildNewestFirst(fullHistoryNewestFirst);
                    engine.reset();
                }
            } else if (!index.matchesNewest(fullHistoryNewestFirst)
                    || index.fingerprint() != fingerprintNewest(fullHistoryNewestFirst)) {
                index.rebuildNewestFirst(fullHistoryNewestFirst);
                engine.reset();
            }
        } catch (IllegalArgumentException error) {
            return blockDataQuality("histórico inválido");
        }
        long historyHash = index.fingerprint();
        boolean historyChanged = historyHash != lastEvaluatedHistoryHash;
        if (!forceRefresh && !historyChanged) {
            return refreshFreshness(capturedAtMs, ocrConfidence, captureStatus);
        }
        long now = System.currentTimeMillis();
        HardExpertEngine.CaptureContext capture = new HardExpertEngine.CaptureContext(
                now, capturedAtMs, true, ocrConfidence, captureStatus);
        current = engine.analyze(index, current, legacySnapshot, capture,
                historyChanged && !delta.isEmpty(), historyChanged ? delta.size() : 0,
                forceRefresh);
        lastEvaluatedHistoryHash = historyHash;
        return current;
    }

    public MasterSignalSnapshot blockDataQuality(String reason) {
        current = MasterSignalSnapshot.blocked(current,
                reason == null ? "qualidade de dados" : reason,
                System.currentTimeMillis());
        return current;
    }

    public void reset() {
        index.clear();
        engine.reset();
        current = MasterSignalSnapshot.empty();
        initialized = false;
        lastEvaluatedHistoryHash = Long.MIN_VALUE;
    }

    public MasterSignalSnapshot snapshot() { return current; }
    public int historySize() { return index.size(); }
    public long deltaUpdates() { return index.deltaUpdates(); }
    public int rebuildCount() { return index.rebuildCount(); }
    public int patternEchoComputationCount() { return engine.patternEchoComputationCount(); }
    public int evaluationCount() { return engine.evaluationCount(); }

    private static long fingerprintNewest(List<Integer> newestFirst) {
        long hash = 0xcbf29ce484222325L;
        int limit = Math.min(MasterHistoryIndex.CAPACITY,
                newestFirst == null ? 0 : newestFirst.size());
        for (int i = limit - 1; i >= 0; i--) {
            Integer value = newestFirst.get(i);
            hash ^= (value == null ? -1L : value.longValue()) + 1L;
            hash *= 0x100000001b3L;
        }
        return hash;
    }

    private MasterSignalSnapshot refreshFreshness(long capturedAtMs,
                                                  double ocrConfidence,
                                                  String captureStatus) {
        long now = System.currentTimeMillis();
        SignalFreshnessGate.Result fresh = SignalFreshnessGate.evaluate(
                now, capturedAtMs, now, true, index.size() >= 3,
                ocrConfidence, captureStatus);
        current = fresh.fresh ? heartbeatSnapshot(current, capturedAtMs, now)
                : MasterSignalSnapshot.blocked(current, fresh.label, now);
        return current;
    }

    private static MasterSignalSnapshot heartbeatSnapshot(MasterSignalSnapshot s,
                                                           long capturedAtMs,
                                                           long analyzedAtMs) {
        return new MasterSignalSnapshot(s.state, s.target, s.pressure,
                s.configurationQuality, s.modelConfidence, s.rival,
                s.rivalPressure, s.gap, s.independentReadings, s.persistence,
                s.acceleration, s.validitySpins, s.signalAgeSpins,
                s.dualPressure, s.migrating, false, false, false,
                s.regime, "DADOS ATUALIZADOS", "", s.sector,
                s.secondarySector, s.secondarySectorPressure,
                s.rankingNumbers, s.rankingScores, s.pressureSeries,
                s.evidenceLabels, s.patternEcho, capturedAtMs, analyzedAtMs,
                0L, s.historyFingerprint);
    }
}
