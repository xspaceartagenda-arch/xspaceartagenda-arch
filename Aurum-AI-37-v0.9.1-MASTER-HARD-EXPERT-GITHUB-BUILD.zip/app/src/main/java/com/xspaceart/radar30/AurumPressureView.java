package com.xspaceart.radar30;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Painel gráfico compacto do CPE. Scores = pressão relativa, não probabilidade. */
public final class AurumPressureView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Integer> numbers = Collections.emptyList();
    private List<Integer> scores = Collections.emptyList();
    private List<Integer> sector1 = Collections.emptyList();
    private List<Integer> sector2 = Collections.emptyList();
    private int sector1Score, sector2Score, terminal = -1, terminalScore;

    public AurumPressureView(Context context) { super(context); }
    public AurumPressureView(Context context, AttributeSet attrs) { super(context, attrs); }

    public void setData(List<Integer> numbers, List<Integer> scores,
                        List<Integer> sector1, int sector1Score,
                        List<Integer> sector2, int sector2Score,
                        int terminal, int terminalScore) {
        this.numbers = copy(numbers);
        this.scores = copy(scores);
        this.sector1 = copy(sector1);
        this.sector2 = copy(sector2);
        this.sector1Score = clamp(sector1Score);
        this.sector2Score = clamp(sector2Score);
        this.terminal = terminal;
        this.terminalScore = clamp(terminalScore);
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth();
        if (w <= 0) return;
        p.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT,
                android.graphics.Typeface.BOLD));
        p.setTextSize(Ui.dp(getContext(), 11));
        p.setColor(Ui.MUTED);
        c.drawText("PRESSÃO CONDICIONAL • CPE ATIVO", 0, Ui.dp(getContext(), 14), p);

        float y = Ui.dp(getContext(), 34);
        p.setTextSize(Ui.dp(getContext(), 12));
        p.setColor(Ui.TEXT);
        c.drawText("SETOR 1  " + join(sector1) + "   " + sector1Score, 0, y, p);
        y += Ui.dp(getContext(), 21);
        p.setColor(Ui.MUTED);
        c.drawText("SETOR 2  " + join(sector2) + "   " + sector2Score, 0, y, p);
        y += Ui.dp(getContext(), 21);
        p.setColor(Ui.GOLD);
        c.drawText("TERMINAL  T" + (terminal < 0 ? "—" : terminal) + "   " + terminalScore, 0, y, p);
        y += Ui.dp(getContext(), 19);

        float labelW = Ui.dp(getContext(), 30);
        float scoreW = Ui.dp(getContext(), 28);
        float barLeft = labelW;
        float barRight = Math.max(barLeft + 1, w - scoreW);
        int rows = Math.min(5, Math.min(numbers.size(), scores.size()));
        for (int i = 0; i < rows; i++) {
            int n = numbers.get(i), score = clamp(scores.get(i));
            y += Ui.dp(getContext(), 20);
            p.setTextSize(Ui.dp(getContext(), 12));
            p.setColor(i == 0 ? Ui.GOLD : Ui.TEXT);
            c.drawText(String.valueOf(n), 0, y, p);

            float top = y - Ui.dp(getContext(), 10);
            float bottom = y + Ui.dp(getContext(), 3);
            p.setColor(Ui.SURFACE_ALT);
            c.drawRoundRect(new RectF(barLeft, top, barRight, bottom),
                    Ui.dp(getContext(), 5), Ui.dp(getContext(), 5), p);
            p.setColor(i == 0 ? Ui.GOLD : Ui.CYAN);
            float filled = barLeft + (barRight - barLeft) * score / 100f;
            c.drawRoundRect(new RectF(barLeft, top, filled, bottom),
                    Ui.dp(getContext(), 5), Ui.dp(getContext(), 5), p);
            p.setTextSize(Ui.dp(getContext(), 10));
            p.setColor(Ui.MUTED);
            c.drawText(String.valueOf(score), barRight + Ui.dp(getContext(), 4), y, p);
        }

        if (rows == 0) {
            p.setTextSize(Ui.dp(getContext(), 12));
            p.setColor(Ui.MUTED);
            c.drawText("Aguardando histórico suficiente para o ranking.", 0,
                    y + Ui.dp(getContext(), 28), p);
        }
    }

    private static List<Integer> copy(List<Integer> in) {
        return in == null ? Collections.emptyList() : new ArrayList<>(in);
    }

    private static String join(List<Integer> values) {
        if (values == null || values.isEmpty()) return "—";
        StringBuilder b = new StringBuilder();
        for (Integer v : values) { if (b.length() > 0) b.append('·'); b.append(v); }
        return b.toString();
    }

    private static int clamp(int v) { return Math.max(0, Math.min(100, v)); }
}
