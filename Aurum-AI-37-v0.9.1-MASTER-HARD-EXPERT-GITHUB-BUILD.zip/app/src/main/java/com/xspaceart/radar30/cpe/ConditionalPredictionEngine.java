package com.xspaceart.radar30.cpe;

import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.echo.PatternEchoEngine;
import com.xspaceart.radar30.lock.IncrementalAurumIndex;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * CPE v2 — Conditional Prediction Engine.
 *
 * Produz um ranking relativo dos 37 números a partir de múltiplas leituras
 * condicionais. Na v0.8.5 a pressão CPE participa da fusão do Aurum Lock com
 * peso limitado e dependente da qualidade amostral; continua sendo score
 * estrutural relativo, nunca porcentagem de chance.
 */
public final class ConditionalPredictionEngine {
    private static final int[] WINDOWS = {5, 10, 30, 60, 150, 500};
    private static final double[] WINDOW_WEIGHTS = {0.24, 0.23, 0.20, 0.15, 0.11, 0.07};
    private static final double BASE_NUMBER = 1.0 / 37.0;

    private ConditionalPredictionEngine() {}

    public static ConditionalPredictionSnapshot analyze(IncrementalAurumIndex index) {
        if (index == null || index.size() < 30) return ConditionalPredictionSnapshot.empty();

        double[] sector = sectorPressure(index);
        double[] terminal = terminalPressure(index);
        double[] acceleration = numberAcceleration(index);
        double[] transition = directTransition(index);
        double[] terminalTransition = terminalTransition(index);
        EchoVector echo = echoPressure(index);
        ArithmeticVector arithmetic = validatedArithmetic(index);

        normalize(sector);
        normalize(terminal);
        normalize(acceleration);
        normalize(transition);
        normalize(terminalTransition);
        normalize(echo.mass);
        normalize(arithmetic.mass);

        double[] fused = new double[37];
        int[] supports = new int[37];
        for (int n = 0; n < 37; n++) {
            double[] c = {sector[n], transition[n], terminalTransition[n], echo.mass[n],
                    terminal[n], acceleration[n], arithmetic.mass[n]};
            double[] w = {0.26, 0.20, 0.13, 0.18, 0.10, 0.08, 0.05};
            double value = 0.0;
            for (int i = 0; i < c.length; i++) {
                value += c[i] * w[i];
                if (c[i] >= 0.58) supports[n]++;
            }
            // Evidência solitária é penalizada; convergência independente é premiada sem explodir score.
            if (supports[n] <= 1) value *= 0.78;
            else if (supports[n] == 2) value *= 0.92;
            else if (supports[n] >= 4) value *= 1.06;
            fused[n] = value;
        }
        normalize(fused);

        List<Integer> ranking = rank(fused);
        List<Integer> topNumbers = new ArrayList<>();
        List<Integer> topScores = new ArrayList<>();
        for (int i = 0; i < Math.min(5, ranking.size()); i++) {
            int n = ranking.get(i);
            topNumbers.add(n);
            topScores.add(score(fused[n]));
        }

        SectorRank sectors = sectorRank(fused);
        TerminalRank terminals = terminalRank(fused);
        int gap = topScores.size() < 2 ? 0 : Math.max(0, topScores.get(0) - topScores.get(1));
        int sampleQuality = sampleQuality(index, echo.matches, arithmetic.validatedRules);

        List<String> drivers = driversFor(topNumbers.isEmpty() ? -1 : topNumbers.get(0),
                sector, transition, terminalTransition, echo.mass, terminal, acceleration,
                arithmetic.mass, index, echo.matches, arithmetic.validatedRules);

        return new ConditionalPredictionSnapshot(topNumbers, topScores,
                sectors.primary, sectors.primaryScore, sectors.secondary, sectors.secondaryScore,
                terminals.primary, terminals.primaryScore, terminals.secondary, terminals.secondaryScore,
                gap, sampleQuality, drivers, false, fused);
    }

    private static double[] sectorPressure(IncrementalAurumIndex index) {
        double[] out = new double[37];
        for (int center = 0; center < 37; center++) {
            List<Integer> coverage = Wheel.coverage(center, 2);
            double total = 0.0;
            double weight = 0.0;
            for (int i = 0; i < WINDOWS.length; i++) {
                int window = WINDOWS[i];
                int size = supportedWindowSize(index, window);
                if (size <= 0) continue;
                int hits = 0;
                for (Integer n : coverage) hits += supportedWindowCount(index, window, n);
                double expected = coverage.size() / 37.0;
                double observed = hits / (double) size;
                total += WINDOW_WEIGHTS[i] * positiveLift(observed, expected);
                weight += WINDOW_WEIGHTS[i];
            }
            out[center] = weight <= 0.0 ? 0.0 : total / weight;
        }
        return out;
    }

    private static double[] terminalPressure(IncrementalAurumIndex index) {
        double[] t = new double[10];
        for (int terminal = 0; terminal < 10; terminal++) {
            int members = terminalMembers(terminal).size();
            double total = 0.0, weight = 0.0;
            for (int i = 0; i < WINDOWS.length; i++) {
                int window = WINDOWS[i];
                int size = supportedWindowSize(index, window);
                if (size <= 0) continue;
                int hits = 0;
                for (Integer n : terminalMembers(terminal)) hits += supportedWindowCount(index, window, n);
                total += WINDOW_WEIGHTS[i] * positiveLift(hits / (double) size, members / 37.0);
                weight += WINDOW_WEIGHTS[i];
            }
            t[terminal] = weight <= 0.0 ? 0.0 : total / weight;
        }
        double[] out = new double[37];
        for (int n = 0; n < 37; n++) out[n] = t[n % 10];
        return out;
    }

    private static double[] numberAcceleration(IncrementalAurumIndex index) {
        double[] out = new double[37];
        for (int n = 0; n < 37; n++) {
            double total = 0.0, weight = 0.0;
            for (int i = 0; i < WINDOWS.length; i++) {
                int size = supportedWindowSize(index, WINDOWS[i]);
                if (size <= 0) continue;
                double observed = supportedWindowCount(index, WINDOWS[i], n) / (double) size;
                total += WINDOW_WEIGHTS[i] * positiveLift(observed, BASE_NUMBER);
                weight += WINDOW_WEIGHTS[i];
            }
            out[n] = weight <= 0.0 ? 0.0 : total / weight;
        }
        return out;
    }

    private static double[] directTransition(IncrementalAurumIndex index) {
        double[] out = new double[37];
        int from = index.recent(0);
        int samples = index.transitionSamples(from);
        double prior = 8.0;
        for (int to = 0; to < 37; to++) {
            double p = (index.transitionCount(from, to) + prior * BASE_NUMBER) / (samples + prior);
            out[to] = samples < 4 ? 0.0 : positiveLift(p, BASE_NUMBER) * sampleReliability(samples, 22.0);
        }
        return out;
    }

    private static double[] terminalTransition(IncrementalAurumIndex index) {
        double[] out = new double[37];
        int terminal = index.recent(0) % 10;
        int samples = 0;
        int[] counts = new int[37];
        for (int from = 0; from < 37; from++) {
            if (from % 10 != terminal) continue;
            samples += index.transitionSamples(from);
            for (int to = 0; to < 37; to++) counts[to] += index.transitionCount(from, to);
        }
        double prior = 12.0;
        for (int to = 0; to < 37; to++) {
            double p = (counts[to] + prior * BASE_NUMBER) / (samples + prior);
            out[to] = samples < 8 ? 0.0 : positiveLift(p, BASE_NUMBER) * sampleReliability(samples, 45.0);
        }
        return out;
    }

    private static EchoVector echoPressure(IncrementalAurumIndex index) {
        double[] out = new double[37];
        int matches = 0;
        List<Integer> history = index.chronological(Math.min(500, index.size()));
        for (int len : new int[]{3, 4, 5}) {
            if (history.size() < len * 2 + 1) continue;
            PatternEchoEngine.Result r = PatternEchoEngine.analyze(history,
                    new PatternEchoEngine.Settings(len, PatternEchoEngine.Mode.AUTO, 16, 2, 80.0));
            for (PatternEchoEngine.Match m : r.matches) {
                matches++;
                double recency = 1.0 / (1.0 + Math.min(180, m.distanceFromCurrent) / 55.0);
                double specificity = m.matchedBy == PatternEchoEngine.Mode.EXACT ? 1.0
                        : m.matchedBy == PatternEchoEngine.Mode.TERMINAL ? 0.88
                        : m.matchedBy == PatternEchoEngine.Mode.NEIGHBOR ? 0.82 : 0.74;
                double support = (m.compatibility / 100.0) * recency * specificity;
                List<Integer> region = m.projectedRegion == null || m.projectedRegion.isEmpty()
                        ? Collections.singletonList(m.projectedPrimary) : m.projectedRegion;
                Set<Integer> unique = new HashSet<>(region);
                for (Integer n : unique) if (n != null && Wheel.valid(n)) out[n] += support / unique.size();
                if (Wheel.valid(m.projectedPrimary)) out[m.projectedPrimary] += support * 0.30;
            }
        }
        return new EchoVector(out, matches);
    }

    /** Relações matemáticas entram somente quando a MESMA regra demonstrou recorrência passada. */
    private static ArithmeticVector validatedArithmetic(IncrementalAurumIndex index) {
        List<Integer> h = index.chronological(Math.min(500, index.size()));
        double[] out = new double[37];
        if (h.size() < 35) return new ArithmeticVector(out, 0);
        int validated = 0;
        for (Rule rule : Rule.values()) {
            int samples = 0, hits = 0;
            for (int i = 2; i + 1 < h.size(); i++) {
                int candidate = rule.apply(h.get(i), h.get(i - 1), h.get(i - 2));
                if (!Wheel.valid(candidate)) continue;
                samples++;
                if (candidate == h.get(i + 1)) hits++;
            }
            if (samples < 25) continue;
            double smoothed = (hits + 4.0 * BASE_NUMBER) / (samples + 4.0);
            double lift = positiveLift(smoothed, BASE_NUMBER);
            if (lift < 0.16) continue;
            int current = rule.apply(index.recent(0), index.recent(1), index.recent(2));
            if (!Wheel.valid(current)) continue;
            out[current] += lift * sampleReliability(samples, 80.0);
            validated++;
        }
        return new ArithmeticVector(out, validated);
    }

    private enum Rule {
        ABS_DIFF_2 { int apply(int a, int b, int c) { return Math.abs(a - b); } },
        ABS_CHAIN_3 { int apply(int a, int b, int c) { return Math.abs(a - b - c); } },
        SUM_2_MOD37 { int apply(int a, int b, int c) { return (a + b) % 37; } },
        SUM_3_MOD37 { int apply(int a, int b, int c) { return (a + b + c) % 37; } };
        abstract int apply(int a, int b, int c);
    }

    private static SectorRank sectorRank(double[] fused) {
        double[] score = new double[37];
        for (int center = 0; center < 37; center++) {
            for (Integer n : Wheel.coverage(center, 2)) score[center] += fused[n];
        }
        List<Integer> centers = rank(score);
        int first = centers.get(0);
        List<Integer> p = Wheel.coverage(first, 2);
        int second = -1;
        for (int c : centers) {
            if (c == first) continue;
            Set<Integer> overlap = new HashSet<>(p);
            overlap.retainAll(Wheel.coverage(c, 2));
            if (overlap.size() <= 2) { second = c; break; }
        }
        if (second < 0) second = centers.size() > 1 ? centers.get(1) : first;
        return new SectorRank(p, score(score[first] / 5.0), Wheel.coverage(second, 2),
                score(score[second] / 5.0));
    }

    private static TerminalRank terminalRank(double[] fused) {
        double[] t = new double[10];
        for (int n = 0; n < 37; n++) t[n % 10] += fused[n];
        List<Integer> order = rank(t);
        int a = order.get(0), b = order.size() > 1 ? order.get(1) : a;
        return new TerminalRank(a, score(t[a] / Math.max(1, terminalMembers(a).size())),
                b, score(t[b] / Math.max(1, terminalMembers(b).size())));
    }

    private static List<String> driversFor(int leader, double[] sector, double[] transition,
                                           double[] terminalTransition, double[] echo, double[] terminal,
                                           double[] acceleration, double[] arithmetic,
                                           IncrementalAurumIndex index, int echoMatches, int validatedRules) {
        if (!Wheel.valid(leader)) return Collections.emptyList();
        List<Driver> drivers = Arrays.asList(
                new Driver("setor físico multijanela", sector[leader]),
                new Driver("transição número→número", transition[leader]),
                new Driver("terminal→próximo", terminalTransition[leader]),
                new Driver("Pattern Echo estrutural", echo[leader]),
                new Driver("pressão de terminal", terminal[leader]),
                new Driver("aceleração 5/10/30/60/150/500", acceleration[leader]),
                new Driver("aritmética validada", arithmetic[leader]));
        List<Driver> sorted = new ArrayList<>(drivers);
        sorted.sort(Comparator.comparingDouble((Driver d) -> d.value).reversed());
        List<String> out = new ArrayList<>();
        for (Driver d : sorted) {
            if (d.value < 0.12 || out.size() >= 4) continue;
            out.add(d.label);
        }
        if (echoMatches > 0 && out.size() < 4) out.add("ecos válidos: " + echoMatches);
        if (validatedRules > 0 && out.size() < 4) out.add("regras matemáticas validadas: " + validatedRules);
        if (out.isEmpty()) out.add("pressão combinada ainda difusa");
        return out;
    }

    private static int sampleQuality(IncrementalAurumIndex index, int echoMatches, int validatedRules) {
        double history = Math.min(1.0, index.size() / 300.0);
        double transition = Math.min(1.0, index.transitionSamples(index.recent(0)) / 18.0);
        double echo = Math.min(1.0, echoMatches / 8.0);
        double arithmetic = Math.min(1.0, validatedRules / 2.0);
        return score(0.50 * history + 0.22 * transition + 0.20 * echo + 0.08 * arithmetic);
    }

    private static int supportedWindowCount(IncrementalAurumIndex index, int window, int n) {
        if (window <= 30) return index.windowCount(window, n);
        int limit = Math.min(window, index.size());
        int count = 0;
        for (int i = 0; i < limit; i++) if (index.recent(i) == n) count++;
        return count;
    }

    private static int supportedWindowSize(IncrementalAurumIndex index, int window) {
        if (window <= 30) return index.windowSize(window);
        return Math.min(window, index.size());
    }

    private static double positiveLift(double observed, double expected) {
        if (expected <= 0.0 || observed <= expected) return 0.0;
        // Compressão robusta: evita que amostra curta domine o ranking.
        double relative = (observed - expected) / expected;
        return relative / (relative + 2.25);
    }

    private static double sampleReliability(int samples, double half) {
        return samples <= 0 ? 0.0 : samples / (samples + half);
    }

    private static void normalize(double[] values) {
        double max = 0.0;
        for (double v : values) max = Math.max(max, v);
        if (max <= 1e-12) return;
        for (int i = 0; i < values.length; i++) values[i] = Math.max(0.0, values[i] / max);
    }

    private static List<Integer> rank(double[] values) {
        List<Integer> out = new ArrayList<>();
        for (int i = 0; i < values.length; i++) out.add(i);
        out.sort((a, b) -> {
            int c = Double.compare(values[b], values[a]);
            return c != 0 ? c : Integer.compare(a, b);
        });
        return out;
    }

    private static List<Integer> terminalMembers(int t) {
        List<Integer> out = new ArrayList<>();
        for (int n = 0; n <= 36; n++) if (n % 10 == t) out.add(n);
        return out;
    }

    private static int score(double normalized) {
        return Math.max(0, Math.min(100, (int) Math.round(100.0 * normalized)));
    }

    private static final class EchoVector { final double[] mass; final int matches; EchoVector(double[] m, int x){mass=m;matches=x;} }
    private static final class ArithmeticVector { final double[] mass; final int validatedRules; ArithmeticVector(double[] m,int r){mass=m;validatedRules=r;} }
    private static final class Driver { final String label; final double value; Driver(String l,double v){label=l;value=v;} }
    private static final class SectorRank {
        final List<Integer> primary, secondary; final int primaryScore, secondaryScore;
        SectorRank(List<Integer> p,int ps,List<Integer>s,int ss){primary=p;primaryScore=ps;secondary=s;secondaryScore=ss;}
    }
    private static final class TerminalRank {
        final int primary, secondary, primaryScore, secondaryScore;
        TerminalRank(int p,int ps,int s,int ss){primary=p;primaryScore=ps;secondary=s;secondaryScore=ss;}
    }
}
