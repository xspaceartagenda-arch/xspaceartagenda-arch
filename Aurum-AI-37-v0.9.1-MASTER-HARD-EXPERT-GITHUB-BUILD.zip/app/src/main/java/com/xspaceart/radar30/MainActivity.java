package com.xspaceart.radar30;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public final class MainActivity extends Activity {
    public static final String ACTION_STATE_UPDATED = "com.xspaceart.radar30.STATE_UPDATED";
    private static final int REQUEST_CAPTURE = 4001;
    private static final int REQUEST_NOTIFICATIONS = 4002;
    private static final String[] PROVIDERS = {
            "Roleta ao vivo", "Playtech", "Evolution", "Pragmatic",
            "Betão / Roleta Brasil", "Outro"
    };

    private TextView capturePermission;
    private TextView overlayPermission;
    private TextView calibrationStatus;
    private TextView operationalStatus;
    private TextView signalStatus;
    private TextView historyView;
    private TextView sessionStatus;
    private TextView sessionHistory;
    private TextView learningStatus;
    private TextView shadowStatus;
    private TextView rayXText;
    private LinearLayout sessionDetails;
    private LinearLayout rayXDetails;
    private Button sessionToggle;
    private Button rayXToggle;
    private EditText manualNumber;
    private EditText dealerInput;
    private EditText bankStartInput;
    private EditText bankEndInput;
    private Spinner providerSpinner;
    private Button startSessionButton;
    private Button finishSessionButton;
    private boolean startupFailed;
    private String startupPhase = "início";

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            refreshState();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            startupPhase = "montagem da tela";
            setContentView(buildContent());
            startupPhase = "permissão de notificações";
            requestNotificationPermission();
            startupPhase = "registro do estado ao vivo";
            registerStateReceiver();
            startupPhase = "leitura dos dados preservados";
            refreshState();
            startupPhase = "concluído";
        } catch (Throwable error) {
            showStartupFailure(error);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!startupFailed) {
            try {
                startupPhase = "retomada da tela";
                refreshState();
                startupPhase = "concluído";
            } catch (Throwable error) {
                showStartupFailure(error);
            }
        }
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(receiver);
        } catch (IllegalArgumentException ignored) {
            // Receiver já removido.
        }
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Compartilhamento não autorizado.", Toast.LENGTH_LONG).show();
            return;
        }
        ensureSessionBeforeCapture();
        Intent service = new Intent(this, ScreenCaptureService.class)
                .setAction(ScreenCaptureService.ACTION_START)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data);
        startForegroundService(service);
        Toast.makeText(this,
                "Precision Mode iniciado. Carregue o histórico disponível e mantenha os últimos resultados visíveis.",
                Toast.LENGTH_LONG).show();
        refreshState();
    }

    private ScrollView buildContent() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 30));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(Ui.text(this, "AURUM AI 37", 30, Ui.GREEN, true));
        root.addView(Ui.text(this,
                "PRECISION / BALANCED • confluência acima de quantidade",
                15, Ui.AMBER, true),
                Ui.margins(-1, -2, this, 0, 4, 0, 18));

        addValidationNotice(root);
        addSessionCard(root);
        addCaptureCard(root);
        addCurrentSignalCard(root);
        addLearningCard(root);
        addRayXCard(root);
        addManualCard(root);
        addHistoryCard(root);

        root.addView(Ui.text(this,
                "Compatível com roleta europeia ao vivo de zero único (0–36). Mesas com 00 não são suportadas. O aplicativo não realiza apostas. Aurum Score mede força de confluência, não probabilidade nem garantia de lucro.",
                12, Ui.MUTED, false),
                Ui.margins(-1, -2, this, 0, 16, 0, 0));
        root.addView(Ui.text(this, "Aurum AI 37 • v0.6.1 • STARTUP REPAIR", 11, Ui.MUTED, false),
                Ui.margins(-1, -2, this, 0, 10, 0, 0));
        return scroll;
    }

    /**
     * Mantém os dados intactos e transforma uma falha de primeiro início em
     * diagnóstico visível. Não limpa preferências, sessão, histórico ou
     * calibração.
     */
    private void showStartupFailure(Throwable error) {
        startupFailed = true;
        try {
            ScrollView scroll = new ScrollView(this);
            scroll.setFillViewport(true);
            scroll.setBackgroundColor(Color.rgb(9, 14, 19));

            TextView diagnostic = new TextView(this);
            diagnostic.setTextColor(Color.WHITE);
            diagnostic.setTextSize(15);
            int padding = Math.max(24,
                    (int) (24 * getResources().getDisplayMetrics().density));
            diagnostic.setPadding(padding, padding, padding, padding);

            String detail = android.util.Log.getStackTraceString(error);
            if (detail == null || detail.trim().isEmpty()) {
                detail = error == null ? "Erro sem detalhe" : error.getClass().getName();
            }
            if (detail.length() > 5000) detail = detail.substring(0, 5000);
            diagnostic.setText("AURUM AI 37 — DIAGNÓSTICO DE INÍCIO\n\n"
                    + "Seus dados continuam preservados. NÃO desinstale e NÃO use Limpar dados.\n\n"
                    + "Falha na etapa: " + startupPhase + "\n\n"
                    + detail);
            scroll.addView(diagnostic, new ScrollView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            setContentView(scroll);
        } catch (Throwable ignored) {
            // Se até a tela mínima falhar, o Android preserva a exceção original.
        }
    }

    private void addValidationNotice(LinearLayout root) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "v0.6.3 • PRECISION / BALANCED CALIBRADO", 16, Ui.CYAN, true));
        card.addView(Ui.text(this,
                "Precision mantém a régua máxima. Balanced agora pode liberar uma entrada "
                        + "moderada quando um PREPARE forte ou persistente mantém famílias "
                        + "independentes alinhadas, sem transformar OBSERVE isolado em sinal.",
                13, Ui.TEXT, false), Ui.margins(-1, -2, this, 0, 6, 0, 0));
        root.addView(card, Ui.margins(-1, -2, this, 0, 0, 0, 12));
    }

    private void addSessionCard(LinearLayout root) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "Sessão e contexto", 17, Ui.TEXT, true));
        card.addView(Ui.text(this,
                "Opcional: registre provedor, crupiê e banca sem ocupar a tela durante o jogo.",
                13, Ui.MUTED, false));

        sessionStatus = Ui.text(this, "Nenhuma sessão iniciada.", 14, Ui.TEXT, true);
        card.addView(sessionStatus, Ui.margins(-1, -2, this, 0, 9, 0, 8));

        sessionToggle = Ui.button(this, "Mostrar detalhes da sessão", Ui.BG, Ui.TEXT);
        card.addView(sessionToggle, new LinearLayout.LayoutParams(-1, -2));

        sessionDetails = new LinearLayout(this);
        sessionDetails.setOrientation(LinearLayout.VERTICAL);
        sessionDetails.setVisibility(View.GONE);
        card.addView(sessionDetails, Ui.margins(-1, -2, this, 0, 10, 0, 0));
        sessionToggle.setOnClickListener(v -> toggleSessionDetails());

        sessionDetails.addView(Ui.text(this, "Provedor", 12, Ui.MUTED, true));
        providerSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, PROVIDERS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        providerSpinner.setAdapter(adapter);
        providerSpinner.setSelection(providerIndex(AppStateStore.provider(this)));
        providerSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!SessionLedger.hasActiveSession(MainActivity.this)) {
                    AppStateStore.setProvider(MainActivity.this, PROVIDERS[position]);
                    refreshCalibrationOnly();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        sessionDetails.addView(providerSpinner, Ui.margins(-1, -2, this, 0, 4, 0, 8));

        dealerInput = textInput("Nome do crupiê (opcional)");
        dealerInput.setText(AppStateStore.dealer(this));
        sessionDetails.addView(dealerInput, new LinearLayout.LayoutParams(-1, -2));

        bankStartInput = moneyInput("Banca inicial — ex.: 300,00");
        startSessionButton = Ui.button(this, "Iniciar nova sessão", Ui.GREEN, Ui.BG);
        LinearLayout startRow = horizontalInputRow(bankStartInput, startSessionButton);
        sessionDetails.addView(startRow, Ui.margins(-1, -2, this, 0, 8, 0, 8));
        startSessionButton.setOnClickListener(v -> startSession());

        bankEndInput = moneyInput("Banca final — ex.: 600,00");
        finishSessionButton = Ui.button(this, "Finalizar sessão", Ui.AMBER, Ui.BG);
        LinearLayout endRow = horizontalInputRow(bankEndInput, finishSessionButton);
        sessionDetails.addView(endRow, Ui.margins(-1, -2, this, 0, 0, 0, 10));
        finishSessionButton.setOnClickListener(v -> finishSession());

        sessionDetails.addView(Ui.text(this, "Sinais desta sessão", 13, Ui.MUTED, true));
        sessionHistory = Ui.text(this, "Nenhum sinal registrado.", 13, Ui.TEXT, false);
        sessionDetails.addView(sessionHistory, Ui.margins(-1, -2, this, 0, 5, 0, 0));
        root.addView(card, Ui.margins(-1, -2, this, 0, 0, 0, 12));
    }

    private void addCaptureCard(LinearLayout root) {
        LinearLayout readiness = Ui.card(this);
        readiness.addView(Ui.text(this, "Leitura automática", 17, Ui.TEXT, true));
        TextView auto = Ui.text(this, "● OCR automático: ativo", 14, Ui.GREEN, true);
        capturePermission = Ui.text(this, "● Captura: parada", 14, Ui.MUTED, false);
        overlayPermission = Ui.text(this, "● Janela flutuante", 14, Ui.MUTED, false);
        calibrationStatus = Ui.text(this, "● Área de leitura", 14, Ui.MUTED, false);
        readiness.addView(auto, Ui.margins(-1, -2, this, 0, 9, 0, 0));
        readiness.addView(capturePermission, Ui.margins(-1, -2, this, 0, 6, 0, 0));
        readiness.addView(overlayPermission, Ui.margins(-1, -2, this, 0, 6, 0, 0));
        readiness.addView(calibrationStatus, Ui.margins(-1, -2, this, 0, 6, 0, 0));

        Button overlay = Ui.button(this, "1. Permitir painel flutuante", Ui.SURFACE, Ui.TEXT);
        Button start = Ui.button(this, "2. Iniciar compartilhamento", Ui.GREEN, Ui.BG);
        Button calibrate = Ui.button(this, "3. Sincronizar histórico inicial", Ui.AMBER, Ui.BG);
        Button stop = Ui.button(this, "Parar leitura", Ui.RED, Color.WHITE);
        readiness.addView(overlay, Ui.margins(-1, -2, this, 0, 12, 0, 0));
        readiness.addView(start, Ui.margins(-1, -2, this, 0, 8, 0, 0));
        readiness.addView(calibrate, Ui.margins(-1, -2, this, 0, 8, 0, 0));
        readiness.addView(stop, Ui.margins(-1, -2, this, 0, 8, 0, 0));
        overlay.setOnClickListener(v -> requestOverlayPermission());
        start.setOnClickListener(v -> requestScreenCapture());
        calibrate.setOnClickListener(v -> openCalibration());
        stop.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_STOP));
        root.addView(readiness, Ui.margins(-1, -2, this, 0, 0, 0, 12));
    }

    private void addCurrentSignalCard(LinearLayout root) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "Bot ao vivo", 17, Ui.TEXT, true));
        operationalStatus = Ui.text(this, "Leitura parada", 14, Ui.MUTED, false);
        signalStatus = Ui.text(this, "SCANNING • sem sinal ativo", 17, Ui.TEXT, true);
        card.addView(operationalStatus, Ui.margins(-1, -2, this, 0, 7, 0, 0));
        card.addView(signalStatus, Ui.margins(-1, -2, this, 0, 10, 0, 0));
        root.addView(card, Ui.margins(-1, -2, this, 0, 0, 0, 12));
    }

    private void addLearningCard(LinearLayout root) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "Desempenho real", 17, Ui.TEXT, true));
        card.addView(Ui.text(this, "● STRYKE/RED registrados prospectivamente", 14,
                Ui.GREEN, true), Ui.margins(-1, -2, this, 0, 7, 0, 0));
        card.addView(Ui.text(this,
                "Cada entrada guarda o contexto da sessão, famílias, Aurum Score e até 500 "
                        + "resultados. Acertos e erros entram na auditoria; o histórico antigo "
                        + "não aquece diretamente a mesa atual.",
                12, Ui.MUTED, false));
        card.addView(Ui.text(this,
                "CIANO: scanning/construção  •  AMARELO: observar/preparar  •  VERDE: entrada/STRYKE  •  VERMELHO: RED",
                12, Ui.MUTED, false), Ui.margins(-1, -2, this, 0, 5, 0, 0));
        learningStatus = Ui.text(this, "Aprendizado local aguardando dados", 13, Ui.AMBER, true);
        card.addView(learningStatus, Ui.margins(-1, -2, this, 0, 9, 0, 0));

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setGravity(Gravity.CENTER_VERTICAL);
        modeRow.addView(Ui.text(this,
                        "Balanced calibrado (forte + moderado persistente)",
                        14, Ui.TEXT, true),
                new LinearLayout.LayoutParams(0, -2, 1f));
        Switch balanced = new Switch(this);
        balanced.setChecked(!AppStateStore.conservativeMode(this));
        balanced.setOnCheckedChangeListener((buttonView, checked) -> {
            AppStateStore.setConservativeMode(this, !checked);
            Toast.makeText(this, checked
                            ? "Balanced ativo: evidência suficiente sem exigir perfeição."
                            : "Precision ativo: régua máxima de seletividade.",
                    Toast.LENGTH_SHORT).show();
        });
        modeRow.addView(balanced);
        card.addView(modeRow, Ui.margins(-1, -2, this, 0, 9, 0, 0));

        LinearLayout voiceRow = new LinearLayout(this);
        voiceRow.setGravity(Gravity.CENTER_VERTICAL);
        voiceRow.addView(Ui.text(this, "Avisar por voz e vibração", 14, Ui.TEXT, true),
                new LinearLayout.LayoutParams(0, -2, 1f));
        Switch voice = new Switch(this);
        voice.setChecked(AppStateStore.voiceEnabled(this));
        voice.setOnCheckedChangeListener((buttonView, checked) ->
                AppStateStore.setVoiceEnabled(this, checked));
        voiceRow.addView(voice);
        card.addView(voiceRow, Ui.margins(-1, -2, this, 0, 9, 0, 0));
        root.addView(card, Ui.margins(-1, -2, this, 0, 0, 0, 12));
    }

    private void addRayXCard(LinearLayout root) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "RAIO-X / SHADOW TEST", 17, Ui.CYAN, true));
        card.addView(Ui.text(this,
                "Painel técnico separado da operação. O motor anterior e o Precision bruto "
                        + "são auditados silenciosamente; nenhum resultado deste painel cria aposta.",
                12, Ui.MUTED, false), Ui.margins(-1, -2, this, 0, 5, 0, 0));
        shadowStatus = Ui.text(this, "Shadow Test: aguardando dados da sessão.",
                13, Ui.TEXT, true);
        card.addView(shadowStatus, Ui.margins(-1, -2, this, 0, 9, 0, 8));

        rayXToggle = Ui.button(this, "Abrir Raio-X", Ui.SURFACE, Ui.TEXT);
        card.addView(rayXToggle, new LinearLayout.LayoutParams(-1, -2));

        rayXDetails = new LinearLayout(this);
        rayXDetails.setOrientation(LinearLayout.VERTICAL);
        rayXDetails.setVisibility(View.GONE);
        rayXText = Ui.text(this, "Aguardando a primeira varredura.", 12, Ui.TEXT, false);
        rayXDetails.addView(rayXText, Ui.margins(-1, -2, this, 0, 10, 0, 0));
        card.addView(rayXDetails, new LinearLayout.LayoutParams(-1, -2));
        rayXToggle.setOnClickListener(v -> toggleRayX());
        root.addView(card, Ui.margins(-1, -2, this, 0, 0, 0, 12));
    }

    private void addManualCard(LinearLayout root) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "Correção manual de emergência", 17, Ui.TEXT, true));
        card.addView(Ui.text(this,
                "O histórico atualiza sozinho. Use somente se o OCR realmente errar o número mais recente.",
                13, Ui.MUTED, false));
        manualNumber = new EditText(this);
        styleInput(manualNumber, "0–36");
        manualNumber.setInputType(InputType.TYPE_CLASS_NUMBER);
        Button add = Ui.button(this, "Corrigir resultado", Ui.AMBER, Ui.BG);
        LinearLayout row = horizontalInputRow(manualNumber, add);
        card.addView(row, Ui.margins(-1, -2, this, 0, 8, 0, 0));
        add.setOnClickListener(v -> addManualResult());
        root.addView(card, Ui.margins(-1, -2, this, 0, 0, 0, 12));
    }

    private void addHistoryCard(LinearLayout root) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "Histórico reconhecido automaticamente", 17, Ui.TEXT, true));
        card.addView(Ui.text(this,
                "O número mais recente fica à esquerda. Não é necessário limpar após cada giro.",
                12, Ui.MUTED, false), Ui.margins(-1, -2, this, 0, 5, 0, 0));
        historyView = Ui.text(this, "Nenhum número carregado", 14, Ui.MUTED, false);
        card.addView(historyView, Ui.margins(-1, -2, this, 0, 7, 0, 0));
        Button clear = Ui.button(this, "Limpar somente o histórico da mesa", Ui.SURFACE, Ui.TEXT);
        card.addView(clear, Ui.margins(-1, -2, this, 0, 10, 0, 0));
        clear.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_RESET));
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));
    }

    private void toggleSessionDetails() {
        if (sessionDetails == null || sessionToggle == null) return;
        boolean show = sessionDetails.getVisibility() != View.VISIBLE;
        sessionDetails.setVisibility(show ? View.VISIBLE : View.GONE);
        sessionToggle.setText(show ? "Ocultar detalhes da sessão" : "Mostrar detalhes da sessão");
    }

    private void toggleRayX() {
        if (rayXDetails == null || rayXToggle == null) return;
        boolean show = rayXDetails.getVisibility() != View.VISIBLE;
        rayXDetails.setVisibility(show ? View.VISIBLE : View.GONE);
        rayXToggle.setText(show ? "Fechar Raio-X" : "Abrir Raio-X");
        if (show && rayXText != null) rayXText.setText(ShadowAuditStore.rayX(this));
    }

    @SuppressWarnings("deprecation")
    private void requestScreenCapture() {
        MediaProjectionManager manager = (MediaProjectionManager)
                getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    private void requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Painel flutuante já está permitido.", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
    }

    private void openCalibration() {
        if (!CaptureRepository.hasLatest()) {
            Toast.makeText(this,
                    "Inicie o compartilhamento, abra a mesa e depois volte pela notificação para calibrar.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(new Intent(this, CalibrationActivity.class));
    }

    private void startSession() {
        if (SessionLedger.hasActiveSession(this)) {
            Toast.makeText(this, "Finalize a sessão atual antes de trocar provedor ou crupiê.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Long bank = parseMoney(bankStartInput, "banca inicial");
        if (bankStartInput.getText().length() > 0 && bank == null) return;
        String provider = PROVIDERS[providerSpinner.getSelectedItemPosition()];
        String dealer = dealerInput.getText().toString().trim();
        AppStateStore.setProvider(this, provider);
        AppStateStore.setDealer(this, dealer);
        if (SessionLedger.startSession(this, provider, dealer, bank)) {
            // Uma nova sessão começa com contexto próprio. Sessões antigas
            // continuam no ledger, mas nunca entram como "calor" da mesa.
            sendServiceAction(ScreenCaptureService.ACTION_RESET);
            bankStartInput.setText("");
            Toast.makeText(this, "Sessão atual isolada e Precision Mode iniciado.", Toast.LENGTH_SHORT).show();
            refreshState();
        } else {
            Toast.makeText(this, "Não foi possível iniciar a sessão.", Toast.LENGTH_LONG).show();
        }
    }

    private void finishSession() {
        Long bank = parseMoney(bankEndInput, "banca final");
        if (bankEndInput.getText().length() > 0 && bank == null) return;
        if (SessionLedger.finishSession(this, bank)) {
            bankEndInput.setText("");
            Toast.makeText(this, "Sessão finalizada e salva.", Toast.LENGTH_LONG).show();
            refreshState();
        } else {
            Toast.makeText(this, "Não existe sessão ativa.", Toast.LENGTH_SHORT).show();
        }
    }

    private void ensureSessionBeforeCapture() {
        if (SessionLedger.hasActiveSession(this)) return;
        String provider = PROVIDERS[providerSpinner.getSelectedItemPosition()];
        String dealer = dealerInput.getText().toString().trim();
        AppStateStore.setProvider(this, provider);
        AppStateStore.setDealer(this, dealer);
        AppStateStore.clearHistory(this);
        SessionLedger.ensureActive(this, provider, dealer);
    }

    private void addManualResult() {
        if (AppStateStore.getStatus(this).toLowerCase().contains("parada")) {
            Toast.makeText(this, "Inicie a leitura antes de usar a correção manual.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        String value = manualNumber.getText().toString().trim();
        try {
            int number = Integer.parseInt(value);
            if (number < 0 || number > 36) throw new NumberFormatException();
            Intent intent = new Intent(this, ScreenCaptureService.class)
                    .setAction(ScreenCaptureService.ACTION_MANUAL)
                    .putExtra(ScreenCaptureService.EXTRA_MANUAL_NUMBER, number);
            startService(intent);
            manualNumber.setText("");
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Digite um número de 0 a 36.", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendServiceAction(String action) {
        startService(new Intent(this, ScreenCaptureService.class).setAction(action));
        refreshState();
    }

    private void refreshState() {
        if (overlayPermission == null) return;
        boolean overlay = Settings.canDrawOverlays(this);
        overlayPermission.setText(overlay
                ? "● Janela flutuante: permitida" : "● Janela flutuante: falta permitir");
        overlayPermission.setTextColor(overlay ? Ui.GREEN : Ui.AMBER);
        refreshCalibrationOnly();

        String status = AppStateStore.getStatus(this);
        boolean stopped = status.toLowerCase().contains("parada");
        capturePermission.setText(stopped ? "● Captura: parada" : "● Captura: em execução");
        capturePermission.setTextColor(stopped ? Ui.MUTED : Ui.GREEN);
        operationalStatus.setText(status);
        String signal = AppStateStore.getSignal(this);
        signalStatus.setText(signal);
        signalStatus.setTextColor(signalColor(signal));

        sessionStatus.setText(SessionLedger.sessionSummary(this));
        sessionHistory.setText(SessionLedger.recentSignals(this, 8));
        learningStatus.setText(SessionLedger.learningSummary(this));
        shadowStatus.setText(ShadowAuditStore.summary(this));
        if (rayXDetails.getVisibility() == View.VISIBLE) {
            rayXText.setText(ShadowAuditStore.rayX(this));
        }

        boolean active = SessionLedger.hasActiveSession(this);
        providerSpinner.setEnabled(!active);
        dealerInput.setEnabled(!active);
        bankStartInput.setEnabled(!active);
        startSessionButton.setEnabled(!active);
        bankEndInput.setEnabled(active);
        finishSessionButton.setEnabled(active);

        List<Integer> history = AppStateStore.loadHistory(this);
        if (history.isEmpty()) historyView.setText("Nenhum número carregado");
        else {
            StringBuilder out = new StringBuilder();
            int end = Math.min(30, history.size());
            for (int i = 0; i < end; i++) {
                if (i > 0) out.append(i % 10 == 0 ? "\n" : " · ");
                out.append(history.get(i));
            }
            historyView.setText(history.size() + "/500 carregados\n" + out);
        }
    }

    private void refreshCalibrationOnly() {
        if (calibrationStatus == null) return;
        boolean calibrated = AppStateStore.isCalibrated(this);
        calibrationStatus.setText(calibrated
                ? "● Área de leitura: calibrada para " + AppStateStore.provider(this)
                : "● Área de leitura: falta calibrar " + AppStateStore.provider(this));
        calibrationStatus.setTextColor(calibrated ? Ui.GREEN : Ui.AMBER);
    }

    private EditText textInput(String hint) {
        EditText input = new EditText(this);
        styleInput(input, hint);
        input.setSingleLine(true);
        return input;
    }

    private EditText moneyInput(String hint) {
        EditText input = textInput(hint);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return input;
    }

    private void styleInput(EditText input, String hint) {
        input.setHint(hint);
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setTextSize(14);
    }

    private LinearLayout horizontalInputRow(EditText input, Button button) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(button, Ui.margins(-2, -2, this, 10, 0, 0, 0));
        return row;
    }

    private Long parseMoney(EditText input, String label) {
        String value = input.getText().toString().trim()
                .replace("R$", "").replace(" ", "");
        if (value.isEmpty()) return null;
        try {
            if (value.contains(",")) value = value.replace(".", "").replace(',', '.');
            BigDecimal amount = new BigDecimal(value);
            if (amount.signum() < 0) throw new NumberFormatException();
            return amount.multiply(new BigDecimal("100"))
                    .setScale(0, RoundingMode.HALF_UP).longValueExact();
        } catch (ArithmeticException | NumberFormatException error) {
            Toast.makeText(this, "Confira a " + label + ". Exemplo: 300,00",
                    Toast.LENGTH_LONG).show();
            return null;
        }
    }

    private int providerIndex(String provider) {
        for (int i = 0; i < PROVIDERS.length; i++) {
            if (PROVIDERS[i].equals(provider)) return i;
        }
        return PROVIDERS.length - 1;
    }

    private int signalColor(String signal) {
        String value = signal == null ? "" : signal.toUpperCase();
        if (value.contains("RED") || value.contains("INVALIDADA")
                || value.contains("EXPIRADO")) return Ui.RED;
        if (value.contains("ENTRADA") || value.contains("STRYKE")
                || value.contains("MANTER SINAL")) return Ui.GREEN;
        if (value.contains("SE PREPARAR") || value.contains("OBSERVANDO")) return Ui.AMBER;
        if (value.contains("SCANNING") || value.contains("CRESCENDO")
                || value.contains("COOLDOWN")) return Ui.CYAN;
        return Ui.TEXT;
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQUEST_NOTIFICATIONS);
        }
    }

    private void registerStateReceiver() {
        IntentFilter filter = new IntentFilter(ACTION_STATE_UPDATED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, filter);
        }
    }
}
