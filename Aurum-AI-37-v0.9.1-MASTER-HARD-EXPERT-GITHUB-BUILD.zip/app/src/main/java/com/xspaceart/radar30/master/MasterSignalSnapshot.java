package com.xspaceart.radar30.master;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Resultado imutável de um ciclo do AURUM 37 AI MASTER — HARD EXPERT. */
public final class MasterSignalSnapshot {
    public enum State {
        SILENCE("SILÊNCIO"),
        HEATING("AQUECENDO"),
        MODERATE("MODERADA"),
        STRONG("FORTE"),
        EXTREME("EXTREMA"),
        BLOCKED("BLOQUEADA");

        public final String label;
        State(String label) { this.label = label; }
    }

    public final State state;
    public final int target;
    public final int pressure;
    public final int configurationQuality;
    public final int modelConfidence;
    public final int rival;
    public final int rivalPressure;
    public final int gap;
    public final int independentReadings;
    public final int persistence;
    public final int acceleration;
    public final int validitySpins;
    public final int signalAgeSpins;
    public final int remainingSpins;
    public final boolean dualPressure;
    public final boolean migrating;
    public final boolean stale;
    public final boolean shouldAlert;
    public final boolean newEvent;
    public final String regime;
    public final String freshnessLabel;
    public final String blockReason;
    public final List<Integer> sector;
    public final List<Integer> secondarySector;
    public final int secondarySectorPressure;
    public final List<Integer> rankingNumbers;
    public final List<Integer> rankingScores;
    public final List<Integer> pressureSeries;
    public final List<String> evidenceLabels;
    public final PatternEchoSnapshot patternEcho;
    public final long capturedAtMs;
    public final long analyzedAtMs;
    public final long processingMs;
    public final long historyFingerprint;

    public MasterSignalSnapshot(State state, int target, int pressure,
                                int configurationQuality, int modelConfidence,
                                int rival, int rivalPressure, int gap,
                                int independentReadings, int persistence,
                                int acceleration, int validitySpins,
                                int signalAgeSpins, boolean dualPressure,
                                boolean migrating, boolean stale,
                                boolean shouldAlert, boolean newEvent,
                                String regime, String freshnessLabel,
                                String blockReason, List<Integer> sector,
                                List<Integer> secondarySector,
                                int secondarySectorPressure,
                                List<Integer> rankingNumbers,
                                List<Integer> rankingScores,
                                List<Integer> pressureSeries,
                                List<String> evidenceLabels,
                                PatternEchoSnapshot patternEcho,
                                long capturedAtMs, long analyzedAtMs,
                                long processingMs, long historyFingerprint) {
        this.state = state == null ? State.SILENCE : state;
        this.target = valid(target) ? target : -1;
        this.pressure = clamp(pressure);
        this.configurationQuality = clamp(configurationQuality);
        this.modelConfidence = clamp(modelConfidence);
        this.rival = valid(rival) ? rival : -1;
        this.rivalPressure = clamp(rivalPressure);
        this.gap = clamp(gap);
        this.independentReadings = Math.max(0, Math.min(5, independentReadings));
        this.persistence = Math.max(0, persistence);
        this.acceleration = clamp(acceleration);
        this.validitySpins = Math.max(0, Math.min(5, validitySpins));
        this.signalAgeSpins = Math.max(0, signalAgeSpins);
        this.remainingSpins = Math.max(0, this.validitySpins - this.signalAgeSpins);
        this.dualPressure = dualPressure;
        this.migrating = migrating;
        this.stale = stale;
        this.shouldAlert = shouldAlert && !stale;
        this.newEvent = newEvent;
        this.regime = clean(regime, "DISPERSÃO");
        this.freshnessLabel = clean(freshnessLabel, "SEM DADOS");
        this.blockReason = blockReason == null ? "" : blockReason.trim();
        this.sector = immutableInts(sector);
        this.secondarySector = immutableInts(secondarySector);
        this.secondarySectorPressure = clamp(secondarySectorPressure);
        this.rankingNumbers = immutableInts(rankingNumbers);
        this.rankingScores = immutableScores(rankingScores);
        this.pressureSeries = immutableScores(pressureSeries);
        this.evidenceLabels = immutableStrings(evidenceLabels);
        this.patternEcho = patternEcho == null ? PatternEchoSnapshot.empty(historyFingerprint) : patternEcho;
        this.capturedAtMs = Math.max(0L, capturedAtMs);
        this.analyzedAtMs = Math.max(0L, analyzedAtMs);
        this.processingMs = Math.max(0L, processingMs);
        this.historyFingerprint = historyFingerprint;
    }

    public static MasterSignalSnapshot empty() {
        return new MasterSignalSnapshot(State.SILENCE, -1, 0, 0, 0,
                -1, 0, 0, 0, 0, 50, 0, 0,
                false, false, false, false, false,
                "DISPERSÃO", "AGUARDANDO DADOS", "",
                Collections.emptyList(), Collections.emptyList(), 0,
                Collections.emptyList(), Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(),
                PatternEchoSnapshot.empty(0L), 0L, 0L, 0L, 0L);
    }

    public static MasterSignalSnapshot blocked(MasterSignalSnapshot previous,
                                               String reason, long nowMs) {
        MasterSignalSnapshot p = previous == null ? empty() : previous;
        return new MasterSignalSnapshot(State.BLOCKED, p.target, p.pressure,
                p.configurationQuality, p.modelConfidence, p.rival,
                p.rivalPressure, p.gap, p.independentReadings, p.persistence,
                p.acceleration, 0, p.signalAgeSpins, p.dualPressure,
                p.migrating, true, false, true, p.regime,
                "DADOS DESATUALIZADOS • NÃO CONSIDERAR ALERTA", reason,
                p.sector, p.secondarySector, p.secondarySectorPressure,
                p.rankingNumbers, p.rankingScores, p.pressureSeries,
                p.evidenceLabels, p.patternEcho, p.capturedAtMs, nowMs, 0L,
                p.historyFingerprint);
    }

    public String headline() {
        if (state == State.BLOCKED) return "DADOS DESATUALIZADOS";
        if (dualPressure) return "DUPLA PRESSÃO";
        if (state == State.EXTREME) return "⚠ PRESSÃO EXTREMA";
        if (state == State.STRONG) return "ALERTA FORTE";
        if (state == State.MODERATE) return "PRESSÃO MODERADA";
        if (state == State.HEATING) return "AQUECENDO";
        return "SILÊNCIO INTELIGENTE";
    }

    public String playLabel() {
        if (target < 0) return state.label;
        return dualPressure && rival >= 0
                ? "SETORES " + target + " / " + rival
                : "SETOR " + target;
    }

    public boolean strongOrExtreme() {
        return state == State.STRONG || state == State.EXTREME;
    }

    private static List<Integer> immutableInts(List<Integer> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        List<Integer> out = new ArrayList<>();
        for (Integer value : values) if (value != null && valid(value) && !out.contains(value)) out.add(value);
        return Collections.unmodifiableList(out);
    }

    private static List<Integer> immutableScores(List<Integer> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        List<Integer> out = new ArrayList<>();
        for (Integer value : values) out.add(clamp(value == null ? 0 : value));
        return Collections.unmodifiableList(out);
    }

    private static List<String> immutableStrings(List<String> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        List<String> out = new ArrayList<>();
        for (String value : values) if (value != null && !value.trim().isEmpty()) out.add(value.trim());
        return Collections.unmodifiableList(out);
    }

    private static String clean(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private static boolean valid(int number) { return number >= 0 && number <= 36; }
    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }
}
