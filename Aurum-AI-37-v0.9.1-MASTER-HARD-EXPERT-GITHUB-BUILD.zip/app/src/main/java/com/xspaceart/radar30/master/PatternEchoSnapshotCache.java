package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.echo.PatternEchoEngine;

import java.util.Collections;
import java.util.List;

/** Recalcula o Pattern Echo somente quando o fingerprint do histórico muda. */
public final class PatternEchoSnapshotCache {
    private long cachedFingerprint = Long.MIN_VALUE;
    private PatternEchoSnapshot cached = PatternEchoSnapshot.empty(0L);
    private String persistentKey = "";
    private int persistentAge;
    private int computationCount;

    public PatternEchoSnapshot update(MasterHistoryIndex index) {
        long fingerprint = index == null ? 0L : index.fingerprint();
        if (fingerprint == cachedFingerprint) return cached;
        cachedFingerprint = fingerprint;
        computationCount++;
        if (index == null || index.size() < 7) {
            cached = PatternEchoSnapshot.empty(fingerprint);
            persistentKey = "";
            persistentAge = 0;
            return cached;
        }

        // Orientação obrigatória: oldest -> newest. O teste de regressão protege isto.
        List<Integer> chronological = index.chronological(Math.min(500, index.size()));
        double[] pressure = new double[37];
        int matches = 0;
        double bestCompatibility = 0.0;
        PatternEchoEngine.Mode bestMode = null;
        int primary = -1;
        double primaryMass = 0.0;

        for (int length : new int[]{3, 4, 5}) {
            PatternEchoEngine.Result result = PatternEchoEngine.analyze(chronological,
                    new PatternEchoEngine.Settings(length, PatternEchoEngine.Mode.AUTO,
                            16, 3, 78.0));
            for (PatternEchoEngine.Match match : result.matches) {
                matches++;
                double recency = 1.0 / (1.0 + Math.min(220, match.distanceFromCurrent) / 62.0);
                double specificity = match.matchedBy == PatternEchoEngine.Mode.EXACT ? 1.0
                        : match.matchedBy == PatternEchoEngine.Mode.TERMINAL ? 0.88
                        : match.matchedBy == PatternEchoEngine.Mode.NEIGHBOR ? 0.82 : 0.74;
                double support = (match.compatibility / 100.0) * recency * specificity;
                List<Integer> region = match.projectedRegion == null || match.projectedRegion.isEmpty()
                        ? Collections.singletonList(match.projectedPrimary) : match.projectedRegion;
                for (Integer number : region) {
                    if (number != null && Wheel.valid(number)) pressure[number] += support / region.size();
                }
                if (Wheel.valid(match.projectedPrimary)) pressure[match.projectedPrimary] += support * 0.34;
                if (support > primaryMass) {
                    primaryMass = support;
                    primary = match.projectedPrimary;
                    bestMode = match.matchedBy;
                }
                bestCompatibility = Math.max(bestCompatibility, match.compatibility);
            }
        }
        SpatialPressureEngine.normalize(pressure);
        boolean active = matches > 0 && primary >= 0;
        int strength = active ? clamp((int) Math.round(
                0.72 * bestCompatibility + 28.0 * Math.min(1.0, matches / 8.0))) : 0;
        String type = bestMode == null ? "—" : bestMode.name();
        String key = active ? type + ":" + primary : "";
        persistentAge = key.equals(persistentKey) && !key.isEmpty() ? persistentAge + 1 : 0;
        persistentKey = key;
        String correspondence = strength >= 82 ? "ALTA" : strength >= 65 ? "MODERADA" : "BAIXA";
        cached = new PatternEchoSnapshot(active, strength, correspondence, type,
                persistentAge, matches, primary, fingerprint, pressure);
        return cached;
    }

    public int computationCount() { return computationCount; }

    public void reset() {
        cachedFingerprint = Long.MIN_VALUE;
        cached = PatternEchoSnapshot.empty(0L);
        persistentKey = "";
        persistentAge = 0;
        computationCount = 0;
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }
}
