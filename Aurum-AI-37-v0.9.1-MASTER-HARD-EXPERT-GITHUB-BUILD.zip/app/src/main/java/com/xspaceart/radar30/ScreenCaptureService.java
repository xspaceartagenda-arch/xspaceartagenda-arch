package com.xspaceart.radar30;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.WindowMetrics;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.ScanStabilizer;
import com.xspaceart.radar30.core.ScanSynchronizer;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.integrated.IntegratedActivity;
import com.xspaceart.radar30.lock.AurumLockFormatter;
import com.xspaceart.radar30.lock.AurumLockSession;
import com.xspaceart.radar30.lock.AurumLockSnapshot;
import com.xspaceart.radar30.master.HardExpertSession;
import com.xspaceart.radar30.master.MasterSignalSnapshot;
import com.xspaceart.radar30.master.ThermalPolicy;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ScreenCaptureService extends Service {
    public static final String ACTION_START = "com.xspaceart.radar30.START";
    public static final String ACTION_STOP = "com.xspaceart.radar30.STOP";
    public static final String ACTION_MANUAL = "com.xspaceart.radar30.MANUAL";
    public static final String ACTION_RESET = "com.xspaceart.radar30.RESET";
    public static final String ACTION_REPLACE_LATEST = "com.xspaceart.radar30.REPLACE_LATEST";
    public static final String ACTION_REMOVE_LATEST = "com.xspaceart.radar30.REMOVE_LATEST";
    public static final String ACTION_FAST_RESYNC = "com.xspaceart.radar30.FAST_RESYNC";
    public static final String ACTION_TOGGLE_OVERLAY = "com.xspaceart.radar30.TOGGLE_OVERLAY";
    public static final String ACTION_CAPTURE_PREVIEW = "com.xspaceart.radar30.CAPTURE_PREVIEW";
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String EXTRA_MANUAL_NUMBER = "manual_number";
    public static final String EXTRA_PIPELINE_MODE = "pipeline_mode";
    public static final String MODE_INTEGRATED_SOURCE_ONLY = "integrated_source_only";
    public static final String MODE_STANDALONE_OCR = "standalone_ocr";

    private static final String CHANNEL_ID = "radar30_capture";
    private static final String SIGNAL_CHANNEL_ID = "aurum_signal_alerts_v076";
    private static final int NOTIFICATION_ID = 3030;
    private static final int SIGNAL_NOTIFICATION_ID = 3031;
    // v0.7.11: captura responsiva sem fila. Frames visuais podem chegar rápido,
    // mas OCR só roda quando a ROI realmente mudou ou precisa confirmar leitura.
    private static final long FRAME_INTERVAL_MS = 320L;
    private static final long FAST_FRAME_INTERVAL_MS = 180L;
    private static final long FAST_RESYNC_WINDOW_MS = 2200L;
    private static final long MIN_OCR_DISPATCH_INTERVAL_MS = 380L;
    // v0.8.3 Capture Integrity: mesmo se o detector visual não perceber uma célula
    // nova, um heartbeat curto força OCR periódico e impede congelamento indefinido.
    private static final long OCR_HEARTBEAT_MS = 1400L;
    private static final long OCR_STALL_TIMEOUT_MS = 4500L;
    private static final long FRAME_STALL_TIMEOUT_MS = 4200L;
    private static final long WATCHDOG_INTERVAL_MS = 900L;
    private static final long DISPLAY_RESTART_COOLDOWN_MS = 6500L;
    private static final long CAPTURE_HEALTH_DEBOUNCE_MS = 700L;
    private static final long RECOVERED_BADGE_TTL_MS = 12_000L;
    private static final int TRANSIENT_GRID_RETRY_LIMIT = 2;
    private static final int VISUAL_SAMPLE_COLS = 26;
    private static final int VISUAL_SAMPLE_ROWS = 14;
    private static final int VISUAL_SAMPLE_COUNT = VISUAL_SAMPLE_COLS * VISUAL_SAMPLE_ROWS;
    private static final int VISUAL_LUMA_DELTA = 20;
    private static final int VISUAL_CHANGED_SAMPLES = 2;

    private final AtomicBoolean ocrBusy = new AtomicBoolean(false);
    private final ScanStabilizer stabilizer = new ScanStabilizer();
    private final ScanSynchronizer synchronizer = new ScanSynchronizer();
    private final RadarSession radarSession = new RadarSession();
    private final AurumLockSession aurumLockSession = new AurumLockSession();
    private final HardExpertSession hardExpertSession = new HardExpertSession();
    private final OcrHistoryParser parser = new OcrHistoryParser();

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private TextRecognizer recognizer;
    private OverlayController overlay;
    private AlertPlayer alerts;
    private ThermalPerformanceController thermalController;
    private int captureWidth;
    private int captureHeight;
    private int captureDensity;
    private long lastFrameAt;
    private long lastWaitingNoticeAt;
    private long lastSessionId = -1L;
    private boolean destroying;
    private boolean integratedSourceOnly;
    private boolean standaloneMode;
    private long lastSnapshotBroadcastAt;
    private long lastSnapshotPersistAt;
    private String lastSnapshotFingerprint = "";
    private int[] lastVisualSamples = new int[VISUAL_SAMPLE_COUNT];
    private int[] currentVisualSamples = new int[VISUAL_SAMPLE_COUNT];
    private boolean visualSamplesInitialized;
    private ByteBuffer packedFrameBuffer;
    private ByteBuffer packedRoiBuffer;
    private boolean capturePreviewRequested;
    private long lastAnalysisCaptureAt;
    private boolean forceNextOcr = true;
    private long fastResyncUntil;
    private long lastValidGridAt;
    private long lastOcrStartedAt;
    private long lastOcrFinishedAt;
    private long lastOcrDispatchAt;
    private long lastCoreFinishedAt;
    private long lastImageAvailableAt;
    private long lastDisplayRestartAt;
    private long ocrRequestSequence;
    private long activeOcrRequestId;
    private int transientGridFailures;
    private int partialOcrFailures;
    private boolean captureRecovering;
    private long lastCaptureHealthSavedAt;
    private String lastCaptureHealthState = "";
    private String lastCaptureHealthDetail = "";
    // Catch-up de 2..12 giros só pode acontecer após uma falha real de captura.
    // Em LIVE normal aceitamos no máximo um resultado novo por atualização.
    private boolean multiSpinCatchupAllowed;

    private final Runnable captureWatchdog = new Runnable() {
        @Override public void run() {
            try {
                runCaptureWatchdog();
            } finally {
                Handler handler = captureHandler;
                if (!destroying && handler != null) {
                    handler.postDelayed(this, WATCHDOG_INTERVAL_MS);
                }
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        createSignalNotificationChannel();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        overlay = new OverlayController(this);
        alerts = new AlertPlayer(this);
        thermalController = new ThermalPerformanceController(this);
        thermalController.start((policy, status) -> {
            AppStateStore.saveThermalPolicy(this, policy, status);
            broadcastState();
        });
        List<Integer> restoredHistory = AppStateStore.loadHistory(this);
        synchronizer.restore(restoredHistory);
        aurumLockSession.replaceHistory(restoredHistory, "HISTÓRICO RESTAURADO");
        MasterSignalSnapshot restoredMaster = hardExpertSession.replaceHistory(restoredHistory);
        saveMasterPresentation(restoredMaster, masterUpdate(restoredMaster));
        lastSessionId = SessionLedger.activeSessionId(this);
        AppStateStore.setCaptureActive(this, false);
        AppStateStore.saveCaptureHealth(this, "PARADO", "Serviço aguardando captura", 0);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();

        if (ACTION_TOGGLE_OVERLAY.equals(action)) {
            if (AppStateStore.overlayHidden(this)) {
                overlay.showStoredAurum();
            } else {
                overlay.hideByUser();
            }
            updateNotification(AppStateStore.overlayHidden(this)
                    ? "Mini Bubble oculta • toque em Mostrar para restaurar"
                    : "Mini Bubble disponível");
            broadcastState();
            if (mediaProjection == null) stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_STOP.equals(action)) {
            SessionLedger.cancelPending(this);
            radarSession.resetSignal();
            aurumLockSession.reset();
            hardExpertSession.reset();
            AppStateStore.saveStatus(this, "Leitura parada", "SCANNING • sem sinal ativo");
            broadcastState();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_RESET.equals(action)) {
            boolean captureWasActive = mediaProjection != null;
            synchronizer.restore(Collections.emptyList());
            radarSession.resetSignal();
            aurumLockSession.reset();
            hardExpertSession.reset();
            SessionLedger.cancelPending(this);
            AppStateStore.clearHistory(this);
            AppStateStore.clearRadarSnapshot(this);
            ShadowAuditStore.clearLive(this);
            AppStateStore.saveStatus(this, mediaProjection == null ? "Leitura parada" : "Histórico limpo; aguardando OCR",
                    "SCANNING • sem sinal ativo");
            if (!standaloneMode) overlay.show("HISTÓRICO LIMPO", "Aguardando nova leitura", Ui.AMBER);
            else overlay.hide();
            updateNotification("Histórico limpo • aguardando OCR");
            broadcastState();
            if (!captureWasActive) stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_MANUAL.equals(action)) {
            int number = intent.getIntExtra(EXTRA_MANUAL_NUMBER, -1);
            lastAnalysisCaptureAt = System.currentTimeMillis();
            handleMerge(synchronizer.prependManual(number));
            if (mediaProjection == null) stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_REPLACE_LATEST.equals(action)) {
            int number = intent.getIntExtra(EXTRA_MANUAL_NUMBER, -1);
            List<Integer> current = new java.util.ArrayList<>(synchronizer.current());
            if (number >= 0 && number <= 36 && !current.isEmpty()) {
                current.set(0, number);
                synchronizer.restore(current);
                radarSession.resetSignal();
                aurumLockSession.replaceHistory(current, "CORREÇÃO MANUAL CONFIRMADA");
                MasterSignalSnapshot corrected = hardExpertSession.replaceHistory(current);
                SessionLedger.cancelPending(this);
                AppStateStore.saveHistory(this, current);
                AppStateStore.clearRadarSnapshot(this);
                saveMasterPresentation(corrected, masterUpdate(corrected));
                AppStateStore.saveStatus(this, "Último giro corrigido para " + number,
                        "ANALISANDO • aguardando próximo giro confirmado");
                overlay.hide();
                updateNotification("Correção aplicada • " + number);
                broadcastState();
            }
            if (mediaProjection == null) stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_REMOVE_LATEST.equals(action)) {
            List<Integer> current = new java.util.ArrayList<>(synchronizer.current());
            if (!current.isEmpty()) {
                current.remove(0);
                synchronizer.restore(current);
                radarSession.resetSignal();
                aurumLockSession.replaceHistory(current, "CORREÇÃO MANUAL CONFIRMADA");
                MasterSignalSnapshot corrected = hardExpertSession.replaceHistory(current);
                SessionLedger.cancelPending(this);
                AppStateStore.saveHistory(this, current);
                AppStateStore.clearRadarSnapshot(this);
                saveMasterPresentation(corrected, masterUpdate(corrected));
                AppStateStore.saveStatus(this, "Último giro removido",
                        "ANALISANDO • aguardando próximo giro confirmado");
                overlay.hide();
                updateNotification("Último giro removido");
                broadcastState();
            }
            if (mediaProjection == null) stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_FAST_RESYNC.equals(action)) {
            // Não zera histórico, hipóteses, momentum nem sessão. Apenas força o próximo
            // frame da ROI a ser lido imediatamente e atualiza a UI com o estado já calculado.
            lastFrameAt = 0L;
            forceNextOcr = true;
            fastResyncUntil = SystemClock.elapsedRealtime() + FAST_RESYNC_WINDOW_MS;
            visualSamplesInitialized = false;
            multiSpinCatchupAllowed = true;
            markCaptureRecovery("RESSINCRONIZAÇÃO MANUAL");
            broadcastState();
            if (mediaProjection != null) {
                updateNotification("Sincronização rápida • aguardando a ROI");
            } else {
                stopSelf();
            }
            return START_NOT_STICKY;
        }
        if (ACTION_CAPTURE_PREVIEW.equals(action)) {
            capturePreviewRequested = true;
            lastFrameAt = 0L;
            forceNextOcr = true;
            if (mediaProjection == null) stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            String pipelineMode = intent.getStringExtra(EXTRA_PIPELINE_MODE);
            integratedSourceOnly = MODE_INTEGRATED_SOURCE_ONLY.equals(pipelineMode);
            standaloneMode = MODE_STANDALONE_OCR.equals(pipelineMode);
            if (standaloneMode) {
                integratedSourceOnly = false;
                AppStateStore.ensureStandaloneDefaults(this);
            }
            if (mediaProjection != null) updateNotification(standaloneMode
                    ? "OCR Standalone ativo • lendo somente a ROI"
                    : integratedSourceOnly
                    ? "Captura integrada • fonte visual ativa"
                    : "Captura Stable ativa");
        }
        if (ACTION_START.equals(action) && mediaProjection == null) {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
            Intent resultData = projectionData(intent);
            if (resultCode != Activity.RESULT_OK || resultData == null) {
                setOperationalStatus("Falha: autorização de captura ausente",
                        "Autorize novamente a leitura da tela");
                stopSelf();
                return START_NOT_STICKY;
            }
            try {
                // Android 14+: a promoção para mediaProjection só é permitida depois
                // do consentimento atual do usuário e antes de getMediaProjection().
                ensureForeground("Preparando leitura");
            } catch (SecurityException error) {
                AppStateStore.saveCaptureHealth(this, "ERRO",
                        "Autorização de captura expirada", 0);
                setOperationalStatus("Falha: autorização de captura expirada",
                        "Autorize novamente a leitura da tela");
                stopSelf();
                return START_NOT_STICKY;
            }
            startProjection(resultCode, resultData);
            return START_NOT_STICKY;
        }
        if (mediaProjection == null) stopSelf();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        destroying = true;
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        if (mediaProjection != null) {
            try {
                mediaProjection.stop();
            } catch (RuntimeException ignored) {
                // Projeção já encerrada pelo sistema.
            }
            mediaProjection = null;
        }
        if (captureHandler != null) captureHandler.removeCallbacks(captureWatchdog);
        if (captureThread != null) {
            captureThread.quitSafely();
            captureThread = null;
        }
        packedFrameBuffer = null;
        packedRoiBuffer = null;
        if (thermalController != null) thermalController.stop();
        if (recognizer != null) recognizer.close();
        if (alerts != null) alerts.shutdown();
        if (overlay != null) overlay.hide();
        CaptureRepository.clear();
        AppStateStore.setCaptureActive(this, false);
        AppStateStore.saveCaptureHealth(this, "PARADO", "Captura encerrada", 0);
        AppStateStore.saveStatus(this, "Leitura parada", "SCANNING • sem sinal ativo");
        AppStateStore.flushPendingWrites(this);
        broadcastState();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private Intent projectionData(Intent source) {
        if (Build.VERSION.SDK_INT >= 33) {
            return source.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        }
        return source.getParcelableExtra(EXTRA_RESULT_DATA);
    }

    private void startProjection(int resultCode, Intent resultData) {
        try {
            MediaProjectionManager manager = (MediaProjectionManager)
                    getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mediaProjection = manager.getMediaProjection(resultCode, resultData);
            AppStateStore.setCaptureActive(this, true);
            if (!integratedSourceOnly) {
                lastSessionId = SessionLedger.ensureActive(this,
                        AppStateStore.provider(this), AppStateStore.dealer(this));
            }
            calculateCaptureSize();

            captureThread = new HandlerThread("radar30-capture");
            captureThread.start();
            captureHandler = new Handler(captureThread.getLooper());
            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    if (!destroying) stopSelf();
                }
            }, captureHandler);

            imageReader = ImageReader.newInstance(captureWidth, captureHeight,
                    PixelFormat.RGBA_8888, 2);
            imageReader.setOnImageAvailableListener(this::onImageAvailable, captureHandler);
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "Radar30Capture",
                    captureWidth,
                    captureHeight,
                    captureDensity,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    captureHandler);
            long captureNow = SystemClock.elapsedRealtime();
            lastImageAvailableAt = captureNow;
            lastDisplayRestartAt = captureNow;
            lastOcrStartedAt = 0L;
            lastOcrFinishedAt = 0L;
            lastOcrDispatchAt = 0L;
            forceNextOcr = true;
            capturePreviewRequested = !AppStateStore.isCalibrated(this);
            lastAnalysisCaptureAt = 0L;
            captureRecovering = false;
            multiSpinCatchupAllowed = false;
            transientGridFailures = 0;
            AppStateStore.saveCaptureHealth(this, "LIVE", "Captura iniciada", 0);
            captureHandler.removeCallbacks(captureWatchdog);
            captureHandler.postDelayed(captureWatchdog, WATCHDOG_INTERVAL_MS);
            setOperationalStatus("Captura ativa • " + AppStateStore.provider(this)
                            + dealerSuffix(),
                    AppStateStore.isCalibrated(this) ? "Aguardando números" : "Toque em Calibrar pela notificação");
            if (!integratedSourceOnly && !standaloneMode) {
                overlay.show(AppStateStore.isCalibrated(this) ? "ANALISANDO" : "CALIBRAR LEITURA",
                        AppStateStore.isCalibrated(this)
                                ? "Painel ativo • aguardando o próximo resultado"
                                : "Abra a notificação e marque a grade de resultados",
                        AppStateStore.isCalibrated(this) ? Ui.GREEN : Ui.AMBER);
            } else if (standaloneMode) {
                // No Standalone a bolha só aparece quando existe PREPARAR/ENTRADA/resultado.
                // Assim ela não cobre a ROI durante a leitura contínua.
                overlay.hide();
            }
            updateNotification(standaloneMode
                    ? "OCR Standalone ativo • mantenha o histórico visível"
                    : "Captura ativa • toque para calibrar");
        } catch (RuntimeException error) {
            AppStateStore.saveCaptureHealth(this, "ERRO",
                    "Falha ao iniciar: " + error.getClass().getSimpleName(), 0);
            setOperationalStatus("Falha ao iniciar captura: " + error.getClass().getSimpleName(),
                    "Autorize novamente");
            stopSelf();
        }
    }

    private void calculateCaptureSize() {
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        captureDensity = metrics.densityDpi;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowMetrics windowMetrics = windowManager.getMaximumWindowMetrics();
            Rect bounds = windowMetrics.getBounds();
            captureWidth = bounds.width();
            captureHeight = bounds.height();
        } else {
            captureWidth = metrics.widthPixels;
            captureHeight = metrics.heightPixels;
        }
    }

    private void onImageAvailable(ImageReader reader) {
        // acquireLatestImage descarta automaticamente frames antigos: nunca criamos backlog.
        Image image = reader.acquireLatestImage();
        if (image == null) return;
        long now = SystemClock.elapsedRealtime();
        final long frameCapturedAtWall = System.currentTimeMillis();
        lastImageAvailableAt = now;
        try {
            ThermalPolicy thermal = thermalController == null
                    ? ThermalPolicy.forStatus(0) : thermalController.policy();
            long interval = now < fastResyncUntil
                    ? thermal.fastFrameIntervalMs : thermal.normalFrameIntervalMs;
            if (now - lastFrameAt < interval) return;
            lastFrameAt = now;

            if (!AppStateStore.isCalibrated(this)) {
                // Uma única imagem completa é suficiente para calibrar. Não copiamos
                // a tela inteira continuamente enquanto a seleção fica aberta.
                if ((capturePreviewRequested || !CaptureRepository.hasLatest())
                        && !ocrBusy.get()) {
                    Bitmap full = imageToBitmap(image);
                    if (full != null) {
                        CaptureRepository.setLatest(full);
                        capturePreviewRequested = false;
                    }
                }
                if (now - lastWaitingNoticeAt > 5000L) {
                    lastWaitingNoticeAt = now;
                    setOperationalStatus("Captura ativa • falta calibrar a área",
                            "Abra a notificação e toque em Calibrar");
                }
                return;
            }

            // Se o OCR anterior ainda estiver trabalhando, o watchdog decide se houve stall.
            // Nunca empilhamos OCRs enquanto uma requisição saudável está em andamento.
            if (ocrBusy.get()) return;

            RectF roi = AppStateStore.getRoi(this);
            if (capturePreviewRequested && !ocrBusy.get()) {
                Bitmap preview = imageToBitmap(image);
                if (preview != null) {
                    CaptureRepository.setLatest(preview);
                    capturePreviewRequested = false;
                }
            }
            boolean confirmationNeeded = stabilizer.needsConfirmation();
            boolean visualChanged = roiVisuallyChanged(image, roi);
            boolean heartbeatDue = lastOcrFinishedAt <= 0L
                    || now - lastOcrFinishedAt >= thermal.ocrHeartbeatMs;
            if (!forceNextOcr && !confirmationNeeded && !visualChanged && !heartbeatDue) return;
            if (now - lastOcrDispatchAt < MIN_OCR_DISPATCH_INTERVAL_MS) return;
            if (!ocrBusy.compareAndSet(false, true)) return;

            forceNextOcr = false;
            lastOcrStartedAt = SystemClock.elapsedRealtime();
            lastOcrDispatchAt = lastOcrStartedAt;
            final long requestId = ++ocrRequestSequence;
            activeOcrRequestId = requestId;
            // Caminho quente: compacta somente a ROI calibrada. A tela inteira é
            // reservada para calibração explícita e nunca para cada ciclo OCR.
            Bitmap crop = imageRoiToBitmap(image, roi);
            if (crop == null) {
                ocrBusy.set(false);
                requestAutomaticResync("ROI INVÁLIDA");
                return;
            }

            // Callbacks no Handler de captura: OCR/CORE não bloqueiam a thread principal/UI.
            java.util.concurrent.Executor callbackExecutor = command -> {
                Handler handler = captureHandler;
                if (handler != null) handler.post(command);
                else command.run();
            };

            try {
                recognizer.process(InputImage.fromBitmap(crop, 0))
                        .addOnSuccessListener(callbackExecutor, text -> {
                            if (requestId != activeOcrRequestId) return;
                            List<Integer> numbers = parser.parse(text);
                            long observedAt = System.currentTimeMillis();

                            if (numbers.size() < 8) {
                                partialOcrFailures++;
                                String reason = "OCR PARCIAL • " + numbers.size() + " números";
                                if (partialOcrFailures <= TRANSIENT_GRID_RETRY_LIMIT) {
                                    requestAutomaticResync(reason);
                                } else {
                                    // Uma sequência de OCR parcial pode esconder giros reais. A partir
                                    // daqui o próximo alinhamento consistente pode recuperar 2..12.
                                    multiSpinCatchupAllowed = true;
                                    // Depois do pequeno burst inicial, evita loop de OCR a cada frame.
                                    // O heartbeat de segurança tenta novamente sem sobrecarregar o aparelho.
                                    markCaptureRecovery(reason + " • aguardando heartbeat");
                                }
                                return;
                            }
                            partialOcrFailures = 0;

                            boolean returnedToGrid = multiSpinCatchupAllowed
                                    || (lastValidGridAt > 0L
                                    && observedAt - lastValidGridAt > 5000L);
                            lastValidGridAt = observedAt;
                            CaptureRepository.setLatestNumbers(numbers, observedAt);
                            String fingerprint = numbers.toString();
                            if (!fingerprint.equals(lastSnapshotFingerprint)
                                    || observedAt - lastSnapshotPersistAt >= 2_000L) {
                                lastSnapshotFingerprint = fingerprint;
                                lastSnapshotPersistAt = observedAt;
                                AppStateStore.saveOcrSnapshot(this, numbers, observedAt);
                            }
                            if (observedAt - lastSnapshotBroadcastAt >= 500L) {
                                lastSnapshotBroadcastAt = observedAt;
                                broadcastState();
                            }

                            if (returnedToGrid) {
                                fastResyncUntil = SystemClock.elapsedRealtime()
                                        + FAST_RESYNC_WINDOW_MS;
                                // Houve um intervalo real sem grade válida: agora faz sentido
                                // permitir catch-up de múltiplos giros, se o alinhamento provar.
                                multiSpinCatchupAllowed = true;
                            }

                            // Na Integrated a captura é SOMENTE uma fonte de dados. Ela não pode
                            // executar ScanSynchronizer/RadarSession/overlay em paralelo.
                            if (!integratedSourceOnly) {
                                boolean accepted = stabilizer.accept(numbers);
                                if (stabilizer.needsConfirmation()) {
                                    fastResyncUntil = SystemClock.elapsedRealtime()
                                            + FAST_RESYNC_WINDOW_MS;
                                    forceNextOcr = true;
                                }
                                if (accepted) {
                                    ScanSynchronizer.MergeResult merge = synchronizer.merge(numbers,
                                            multiSpinCatchupAllowed ? 12 : 1);
                                    if (!merge.accepted
                                            && transientGridFailures < TRANSIENT_GRID_RETRY_LIMIT) {
                                        transientGridFailures++;
                                        requestAutomaticResync("CONFERINDO ALINHAMENTO OCR");
                                    } else {
                                        int recovered = merge.accepted ? merge.newNumbers.size() : 0;
                                        transientGridFailures = 0;
                                        lastAnalysisCaptureAt = frameCapturedAtWall;
                                        handleMerge(merge);
                                        lastCoreFinishedAt = SystemClock.elapsedRealtime();
                                        if (merge.accepted) markCaptureLive(recovered);
                                    }
                                } else if (captureRecovering && !stabilizer.needsConfirmation()) {
                                    // Um heartbeat válido confirma que a grade voltou mesmo quando
                                    // o fingerprint já havia sido emitido antes da recuperação.
                                    markCaptureLive(0);
                                }
                            } else {
                                markCaptureLive(0);
                            }
                        })
                        .addOnFailureListener(callbackExecutor, error -> {
                            if (requestId != activeOcrRequestId) return;
                            partialOcrFailures++;
                            String reason = "OCR " + error.getClass().getSimpleName().toUpperCase();
                            if (partialOcrFailures <= TRANSIENT_GRID_RETRY_LIMIT) {
                                requestAutomaticResync(reason);
                            } else {
                                multiSpinCatchupAllowed = true;
                                markCaptureRecovery(reason + " • aguardando heartbeat");
                            }
                            setOperationalStatus(
                                    "OCR em recuperação: " + error.getClass().getSimpleName(),
                                    "Aurum tenta ressincronizar automaticamente");
                        })
                        .addOnCompleteListener(callbackExecutor, task -> {
                            // Único ponto de liberação: sucesso, falha ou cancelamento.
                            if (!crop.isRecycled()) crop.recycle();
                            if (requestId == activeOcrRequestId) {
                                lastOcrFinishedAt = SystemClock.elapsedRealtime();
                                ocrBusy.set(false);
                            }
                        });
            } catch (RuntimeException error) {
                if (!crop.isRecycled()) crop.recycle();
                if (requestId == activeOcrRequestId) ocrBusy.set(false);
                requestAutomaticResync("OCR NÃO INICIADO");
            }
        } finally {
            image.close();
        }
    }

    private void requestAutomaticResync(String reason) {
        long now = SystemClock.elapsedRealtime();
        forceNextOcr = true;
        lastFrameAt = 0L;
        fastResyncUntil = Math.max(fastResyncUntil, now + FAST_RESYNC_WINDOW_MS);
        markCaptureRecovery(reason);
    }

    private void markCaptureRecovery(String reason) {
        captureRecovering = true;
        String detail = reason == null || reason.trim().isEmpty()
                ? "Conferindo a leitura" : reason.trim();
        long now = SystemClock.elapsedRealtime();
        boolean changed = !"RESYNC".equals(lastCaptureHealthState)
                || !detail.equals(lastCaptureHealthDetail);
        if (changed || now - lastCaptureHealthSavedAt >= CAPTURE_HEALTH_DEBOUNCE_MS) {
            lastCaptureHealthState = "RESYNC";
            lastCaptureHealthDetail = detail;
            lastCaptureHealthSavedAt = now;
            AppStateStore.saveCaptureHealth(this, "RESYNC", detail, 0);
            if (overlay != null) overlay.refreshCaptureState();
            broadcastState();
        }
    }

    private void markCaptureLive(int recovered) {
        boolean wasRecovering = captureRecovering;
        captureRecovering = false;
        multiSpinCatchupAllowed = false;
        transientGridFailures = 0;
        partialOcrFailures = 0;

        // Mantém por alguns segundos a informação de giros recuperados para que o operador
        // consiga enxergar a recuperação; uma confirmação LIVE normal não apaga imediatamente.
        int shownRecovered = recovered;
        String detail;
        if (recovered <= 0 && !wasRecovering
                && "LIVE".equalsIgnoreCase(AppStateStore.captureHealth(this))
                && AppStateStore.captureRecoveredSpins(this) > 0
                && System.currentTimeMillis() - AppStateStore.captureHealthAt(this)
                < RECOVERED_BADGE_TTL_MS) {
            shownRecovered = AppStateStore.captureRecoveredSpins(this);
            detail = AppStateStore.captureHealthDetail(this);
        } else {
            detail = recovered > 0
                    ? recovered + (recovered == 1 ? " giro recuperado" : " giros recuperados")
                    : "ROI confirmada";
        }

        long now = SystemClock.elapsedRealtime();
        boolean changed = !"LIVE".equals(lastCaptureHealthState)
                || !detail.equals(lastCaptureHealthDetail);
        if (changed || now - lastCaptureHealthSavedAt >= CAPTURE_HEALTH_DEBOUNCE_MS) {
            lastCaptureHealthState = "LIVE";
            lastCaptureHealthDetail = detail;
            lastCaptureHealthSavedAt = now;
            AppStateStore.saveCaptureHealth(this, "LIVE", detail, shownRecovered);
            if (overlay != null) overlay.refreshCaptureState();
        }
        if (wasRecovering || recovered > 0) {
            updateNotification(recovered > 0
                    ? "LIVE • " + detail
                    : "LIVE • leitura ressincronizada");
            broadcastState();
        }
    }

    private void runCaptureWatchdog() {
        if (destroying || mediaProjection == null || captureHandler == null) return;
        long now = SystemClock.elapsedRealtime();

        if (ocrBusy.get() && lastOcrStartedAt > 0L
                && now - lastOcrStartedAt >= OCR_STALL_TIMEOUT_MS) {
            // Invalida callbacks atrasados antes de liberar uma nova leitura.
            activeOcrRequestId = ++ocrRequestSequence;
            ocrBusy.set(false);
            try {
                if (recognizer != null) recognizer.close();
            } catch (RuntimeException ignored) {
                // O recognizer antigo já estava encerrando.
            }
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            multiSpinCatchupAllowed = true;
            requestAutomaticResync("WATCHDOG • OCR TRAVADO");
        }

        if (lastImageAvailableAt > 0L
                && now - lastImageAvailableAt >= FRAME_STALL_TIMEOUT_MS
                && now - lastDisplayRestartAt >= DISPLAY_RESTART_COOLDOWN_MS) {
            restartCaptureSurface();
        }
    }

    private void restartCaptureSurface() {
        if (mediaProjection == null || captureHandler == null) return;
        lastDisplayRestartAt = SystemClock.elapsedRealtime();
        multiSpinCatchupAllowed = true;
        markCaptureRecovery("WATCHDOG • SEM FRAMES");
        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            if (imageReader != null) {
                imageReader.setOnImageAvailableListener(null, null);
                imageReader.close();
                imageReader = null;
            }
            imageReader = ImageReader.newInstance(captureWidth, captureHeight,
                    PixelFormat.RGBA_8888, 2);
            imageReader.setOnImageAvailableListener(this::onImageAvailable, captureHandler);
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "Radar30CaptureRecovery",
                    captureWidth,
                    captureHeight,
                    captureDensity,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    captureHandler);
            lastImageAvailableAt = SystemClock.elapsedRealtime();
            forceNextOcr = true;
            visualSamplesInitialized = false;
            fastResyncUntil = SystemClock.elapsedRealtime() + FAST_RESYNC_WINDOW_MS;
        } catch (RuntimeException error) {
            AppStateStore.saveCaptureHealth(this, "ERRO",
                    "Falha no restart: " + error.getClass().getSimpleName(), 0);
            if (overlay != null) overlay.refreshCaptureState();
            setOperationalStatus("Captura precisa ser reautorizada",
                    "Watchdog não conseguiu reiniciar os frames");
        }
    }

    /**
     * Detector visual barato sobre a ROI. Lê poucos pixels diretamente do buffer RGBA,
     * sem criar Bitmap e sem chamar ML Kit. Tela parada = quase zero OCR.
     */
    private boolean roiVisuallyChanged(Image image, RectF roi) {
        if (!sampleRoiLuma(image, roi, currentVisualSamples)) return true;
        if (forceNextOcr || !visualSamplesInitialized) {
            swapVisualSampleBuffers();
            visualSamplesInitialized = true;
            return true;
        }
        int changed = 0;
        for (int i = 0; i < VISUAL_SAMPLE_COUNT; i++) {
            if (Math.abs(currentVisualSamples[i] - lastVisualSamples[i])
                    >= VISUAL_LUMA_DELTA) {
                changed++;
                if (changed >= VISUAL_CHANGED_SAMPLES) break;
            }
        }
        swapVisualSampleBuffers();
        return changed >= VISUAL_CHANGED_SAMPLES;
    }

    private void swapVisualSampleBuffers() {
        int[] swap = lastVisualSamples;
        lastVisualSamples = currentVisualSamples;
        currentVisualSamples = swap;
    }

    private boolean sampleRoiLuma(Image image, RectF roi, int[] samples) {
        if (samples == null || samples.length < VISUAL_SAMPLE_COUNT) return false;
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return false;
        Image.Plane plane = planes[0];
        ByteBuffer buffer = plane.getBuffer().duplicate();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        if (pixelStride < 3 || rowStride <= 0) return false;

        int left = bound(Math.round(roi.left * captureWidth), 0, captureWidth - 1);
        int top = bound(Math.round(roi.top * captureHeight), 0, captureHeight - 1);
        int right = bound(Math.round(roi.right * captureWidth), left + 1, captureWidth);
        int bottom = bound(Math.round(roi.bottom * captureHeight), top + 1, captureHeight);

        int index = 0;
        for (int row = 0; row < VISUAL_SAMPLE_ROWS; row++) {
            int y = top + ((row * 2 + 1) * (bottom - top))
                    / (VISUAL_SAMPLE_ROWS * 2);
            for (int col = 0; col < VISUAL_SAMPLE_COLS; col++) {
                int x = left + ((col * 2 + 1) * (right - left))
                        / (VISUAL_SAMPLE_COLS * 2);
                int offset = y * rowStride + x * pixelStride;
                if (offset < 0 || offset + 2 >= buffer.limit()) {
                    samples[index++] = 0;
                    continue;
                }
                int r = buffer.get(offset) & 0xff;
                int g = buffer.get(offset + 1) & 0xff;
                int b = buffer.get(offset + 2) & 0xff;
                // Luma inteira aproximada; quantização reduz ruído de antialiasing/vídeo.
                int luma = (77 * r + 150 * g + 29 * b) >> 8;
                samples[index++] = (luma >> 4) << 4;
            }
        }
        return true;
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;
        Image.Plane plane = planes[0];
        ByteBuffer source = plane.getBuffer().duplicate();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        if (pixelStride != 4 || captureWidth <= 0 || captureHeight <= 0) return null;

        long tightRowBytesLong = (long) captureWidth * pixelStride;
        long requiredBytesLong = tightRowBytesLong * captureHeight;
        if (tightRowBytesLong > Integer.MAX_VALUE || requiredBytesLong > Integer.MAX_VALUE
                || rowStride < tightRowBytesLong) return null;

        int tightRowBytes = (int) tightRowBytesLong;
        int requiredBytes = (int) requiredBytesLong;
        int sourceBase = source.position();
        int sourceLimit = source.limit();

        // Alguns buffers RGBA da Samsung não incluem o padding depois da última
        // linha. Copiar o plano diretamente para um Bitmap acolchoado faz o HWUI
        // ler além do limite e pode terminar em SIGSEGV. Primeiro compactamos só
        // os pixels válidos em um buffer que pertence ao app.
        if (packedFrameBuffer == null || packedFrameBuffer.capacity() < requiredBytes) {
            packedFrameBuffer = ByteBuffer.allocateDirect(requiredBytes);
        }
        ByteBuffer packed = packedFrameBuffer;
        packed.clear();
        packed.limit(requiredBytes);
        for (int row = 0; row < captureHeight; row++) {
            long rowStartLong = (long) sourceBase + (long) row * rowStride;
            long rowEndLong = rowStartLong + tightRowBytes;
            if (rowStartLong < 0L || rowEndLong > sourceLimit) {
                packed.clear();
                return null;
            }
            ByteBuffer rowPixels = source.duplicate();
            rowPixels.position((int) rowStartLong);
            rowPixels.limit((int) rowEndLong);
            packed.put(rowPixels);
        }
        packed.flip();

        Bitmap exact = Bitmap.createBitmap(captureWidth, captureHeight,
                Bitmap.Config.ARGB_8888);
        try {
            exact.copyPixelsFromBuffer(packed);
            return exact;
        } catch (RuntimeException error) {
            exact.recycle();
            return null;
        }
    }

    /** Copia diretamente a ROI RGBA para um bitmap compacto, sem bitmap da tela inteira. */
    private Bitmap imageRoiToBitmap(Image image, RectF roi) {
        if (image == null || roi == null) return null;
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;
        Image.Plane plane = planes[0];
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();
        if (pixelStride != 4 || imageWidth < 2 || imageHeight < 2) return null;

        int left = bound(Math.round(roi.left * imageWidth), 0, imageWidth - 2);
        int top = bound(Math.round(roi.top * imageHeight), 0, imageHeight - 2);
        int right = bound(Math.round(roi.right * imageWidth), left + 2, imageWidth);
        int bottom = bound(Math.round(roi.bottom * imageHeight), top + 2, imageHeight);
        int width = right - left;
        int height = bottom - top;
        long rowBytesLong = (long) width * pixelStride;
        long requiredLong = rowBytesLong * height;
        if (rowBytesLong > Integer.MAX_VALUE || requiredLong > Integer.MAX_VALUE) return null;

        int rowBytes = (int) rowBytesLong;
        int required = (int) requiredLong;
        ByteBuffer source = plane.getBuffer().duplicate();
        int sourceBase = source.position();
        int sourceLimit = source.limit();
        if (packedRoiBuffer == null || packedRoiBuffer.capacity() < required) {
            packedRoiBuffer = ByteBuffer.allocateDirect(required);
        }
        ByteBuffer packed = packedRoiBuffer;
        packed.clear();
        packed.limit(required);
        for (int row = top; row < bottom; row++) {
            long startLong = (long) sourceBase + (long) row * rowStride
                    + (long) left * pixelStride;
            long endLong = startLong + rowBytes;
            if (startLong < 0L || endLong > sourceLimit) {
                packed.clear();
                return null;
            }
            ByteBuffer pixels = source.duplicate();
            pixels.position((int) startLong);
            pixels.limit((int) endLong);
            packed.put(pixels);
        }
        packed.flip();
        Bitmap crop = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        try {
            crop.copyPixelsFromBuffer(packed);
            return crop;
        } catch (RuntimeException error) {
            crop.recycle();
            return null;
        }
    }

    private Bitmap cropForOcr(Bitmap source, RectF roi) {
        int left = bound(Math.round(roi.left * source.getWidth()), 0, source.getWidth() - 2);
        int top = bound(Math.round(roi.top * source.getHeight()), 0, source.getHeight() - 2);
        int right = bound(Math.round(roi.right * source.getWidth()), left + 2, source.getWidth());
        int bottom = bound(Math.round(roi.bottom * source.getHeight()), top + 2, source.getHeight());
        try {
            Bitmap window = Bitmap.createBitmap(source, left, top, right - left, bottom - top);
            Bitmap copy = window.copy(Bitmap.Config.ARGB_8888, false);
            if (window != source) window.recycle();
            return copy;
        } catch (IllegalArgumentException error) {
            return null;
        }
    }

    private void handleMerge(ScanSynchronizer.MergeResult merge) {
        if (integratedSourceOnly) {
            // Defesa extra: nenhuma ação Stable deve tocar histórico, overlay ou motor
            // enquanto a Integrated for dona da sessão.
            broadcastState();
            return;
        }
        if (!merge.accepted) {
            MasterSignalSnapshot masterBlocked = hardExpertSession.blockDataQuality(merge.message);
            saveMasterPresentation(masterBlocked, masterUpdate(masterBlocked));
            if (AppStateStore.aurumLockEnabled(this)) {
                AurumLockSession.Outcome blocked = aurumLockSession.blockDataQuality(merge.message);
                SessionLedger.recordUpdate(this, blocked.update, Collections.emptyList());
                presentAurum(blocked.update, "Leitura rejeitada: " + merge.message,
                        blocked.snapshot, masterBlocked);
                return;
            }
            setOperationalStatus("Leitura rejeitada: " + merge.message,
                    "DADOS DESATUALIZADOS • NÃO CONSIDERAR ALERTA");
            overlay.hide();
            return;
        }
        AppStateStore.saveHistory(this, merge.history);
        syncSessionBoundary();
        if (AppStateStore.aurumLockEnabled(this)) {
            String capture = merge.message != null && merge.message.toLowerCase().contains("manual")
                    ? "MANUAL CONFIRMADO" : "OCR CONFIRMADO";
            AurumLockSession.Outcome outcome = aurumLockSession.update(
                    merge.history, merge.newNumbers, true, capture);
            long capturedAt = lastAnalysisCaptureAt > 0L
                    ? lastAnalysisCaptureAt : System.currentTimeMillis();
            MasterSignalSnapshot master = hardExpertSession.update(
                    merge.history, merge.newNumbers, true, capturedAt,
                    1.0, "LIVE", outcome.snapshot);
            SessionLedger.recordUpdate(this, outcome.update, merge.newNumbers);
            MasterAlertLedger.advanceAndRecord(this, master, merge.newNumbers);
            presentAurum(outcome.update, merge.message, outcome.snapshot, master);
            return;
        }
        LearningModel learning = SessionLedger.learningModel(this);
        ConfluenceVerdict previousVerdict = radarSession.lastVerdict();
        RadarSession.State previousState = radarSession.state();
        SignalUpdate update = radarSession.update(merge.history, merge.newNumbers,
                learning, AppStateStore.conservativeMode(this));
        recordEarlyTouch(previousVerdict, previousState, merge.newNumbers);
        ShadowAuditStore.record(this, SessionLedger.activeSessionId(this),
                merge.history, merge.newNumbers, radarSession.state(),
                update, radarSession.lastVerdict(), radarSession.lastChampionShadow());
        SessionLedger.recordUpdate(this, update, merge.newNumbers);
        long capturedAt = lastAnalysisCaptureAt > 0L
                ? lastAnalysisCaptureAt : System.currentTimeMillis();
        MasterSignalSnapshot master = hardExpertSession.update(
                merge.history, merge.newNumbers, true, capturedAt,
                1.0, "LIVE", null);
        MasterAlertLedger.advanceAndRecord(this, master, merge.newNumbers);
        present(update, merge.message, master);
    }

    private void presentAurum(SignalUpdate update, String scanMessage,
                              AurumLockSnapshot snapshot,
                              MasterSignalSnapshot master) {
        int accent = accentFor(update.kind, update.strength);
        AppStateStore.saveAurumVisualSnapshot(this, snapshot);
        SignalUpdate masterUpdate = masterUpdate(master);
        saveMasterPresentation(master, masterUpdate);

        if (master != null && master.strongOrExtreme() && !master.stale) {
            overlay.showMaster(master);
        } else if (shouldSurfaceAurumOverlay(update.kind)) {
            overlay.showAurum(update, snapshot, accent);
        } else {
            // Pré-Lock existe na tela principal, mas nunca vira bolha/alarme oficial.
            overlay.hide();
        }

        AppStateStore.saveStatus(this,
                scanMessage + " • " + synchronizer.current().size() + " números",
                masterUpdate.headline + "\n" + masterUpdate.detail);
        updateNotification("HARD EXPERT • " + master.state.label + " • pressão "
                + master.pressure + " • " + master.freshnessLabel);
        if (standaloneMode && master.shouldAlert) {
            notifyMasterSignal(master);
        } else if (standaloneMode && shouldNotifyAurum(update.kind)) {
            notifyAurumSignal(update, snapshot);
        }
        if (master.shouldAlert) alerts.playMaster(masterUpdate,
                master.state == MasterSignalSnapshot.State.EXTREME);
        else if (update.kind == SignalUpdate.Kind.HIT
                || update.kind == SignalUpdate.Kind.EXPIRED
                || update.kind == SignalUpdate.Kind.INVALIDATED) alerts.play(update);
        broadcastState();
    }

    private void present(SignalUpdate update, String scanMessage,
                         MasterSignalSnapshot master) {
        int accent = accentFor(update.kind, update.strength);
        String body = update.detail;
        ConfluenceVerdict verdict = radarSession.lastVerdict();
        AppStateStore.saveRadarSnapshot(this,
                verdict == null ? update.strength : verdict.aurumScore,
                verdict == null ? update.confluenceCount : verdict.independentFamilies,
                verdict == null ? update.kind.name() : verdict.decision.name(),
                update.target, update.playLabel, update.headline, update.detail,
                verdict == null ? Collections.emptyList() : verdict.reasons);
        AppStateStore.saveRadarBackstage(this,
                RadarBackstageFormatter.focus(verdict),
                RadarBackstageFormatter.sectorRanking(verdict,
                        radarSession.consensusVelocity(), radarSession.runnerConsensusVelocity()),
                RadarBackstageFormatter.heat(verdict),
                RadarBackstageFormatter.families(verdict),
                RadarBackstageFormatter.gate(verdict, update,
                        radarSession.consensusVelocity(), radarSession.runnerConsensusVelocity(),
                        radarSession.saturationRemaining()));
        SignalUpdate masterUpdate = masterUpdate(master);
        saveMasterPresentation(master, masterUpdate);

        if (master != null && master.strongOrExtreme() && !master.stale) {
            overlay.showMaster(master);
        } else if (standaloneMode) {
            if (shouldSurfaceStandaloneOverlay(update.kind)) {
                String compact = compactStandaloneBody(update, verdict);
                overlay.show(update.headline, compact, accent);
            } else {
                overlay.hide();
            }
        } else {
            overlay.show(update.headline, body, accent);
        }

        AppStateStore.saveStatus(this,
                scanMessage + " • " + synchronizer.current().size() + " números",
                masterUpdate.headline + "\n" + masterUpdate.detail);
        boolean terminalSignal = update.signalType != null
                && (update.signalType.contains("TERMINAL")
                || update.signalType.contains("MAX_CONFLUENCE"));
        int score = terminalSignal ? update.strength
                : verdict == null ? update.strength : verdict.aurumScore;
        int families = terminalSignal ? update.confluenceCount
                : verdict == null ? update.confluenceCount : verdict.independentFamilies;
        updateNotification("HARD EXPERT • " + master.state.label + " • pressão "
                + master.pressure + " • " + master.freshnessLabel);
        if (standaloneMode && master.shouldAlert) {
            notifyMasterSignal(master);
        } else if (standaloneMode && shouldNotifyStandalone(update.kind)) {
            notifyStandaloneSignal(update, verdict);
        }
        if (master.shouldAlert) alerts.playMaster(masterUpdate,
                master.state == MasterSignalSnapshot.State.EXTREME);
        else alerts.play(update);
        broadcastState();
    }

    private SignalUpdate masterUpdate(MasterSignalSnapshot master) {
        if (master == null) {
            return new SignalUpdate(SignalUpdate.Kind.SCANNING,
                    "SILÊNCIO INTELIGENTE", "Aguardando dados validados.", -1,
                    Collections.emptyList(), 0, 0, "");
        }
        SignalUpdate.Kind kind;
        switch (master.state) {
            case EXTREME:
            case STRONG:
                kind = SignalUpdate.Kind.ENTRY;
                break;
            case MODERATE:
                kind = SignalUpdate.Kind.ACTIVE;
                break;
            case HEATING:
                kind = SignalUpdate.Kind.PREPARE;
                break;
            case BLOCKED:
                kind = SignalUpdate.Kind.WAITING;
                break;
            case SILENCE:
            default:
                kind = SignalUpdate.Kind.SCANNING;
                break;
        }

        List<Integer> coverage = new ArrayList<>(master.sector);
        for (Integer number : master.secondarySector) {
            if (!coverage.contains(number)) coverage.add(number);
        }
        StringBuilder detail = new StringBuilder()
                .append("Pressão ").append(master.pressure).append("/100")
                .append(" • Qualidade ").append(master.configurationQuality).append("/100")
                .append(" • Confiança do modelo ").append(master.modelConfidence).append("/100")
                .append("\n").append(master.independentReadings).append(" leituras independentes")
                .append(" • persistência ").append(master.persistence).append(" giros")
                .append(" • aceleração ").append(master.acceleration);
        if (master.rival >= 0) {
            detail.append("\nRival ").append(master.rival)
                    .append(" (").append(master.rivalPressure).append(")");
        }
        if (master.dualPressure) detail.append(" • DUPLA PRESSÃO");
        if (master.migrating) detail.append("\nPRESSÃO MIGRANDO DENTRO DO MESMO SETOR");
        detail.append("\n").append(master.freshnessLabel);
        if (!master.blockReason.isEmpty()) detail.append("\n").append(master.blockReason);
        detail.append("\nScore interno; não representa probabilidade matemática.");
        String speech = master.shouldAlert
                ? (master.state == MasterSignalSnapshot.State.EXTREME
                ? "Atenção. Pressão extrema no setor " : "Alerta forte no setor ")
                + master.target : "";
        return new SignalUpdate(kind, master.headline(), detail.toString(), master.target,
                coverage, master.pressure, master.remainingSpins, speech,
                master.evidenceLabels, master.independentReadings, -1, 0,
                master.playLabel());
    }

    private void saveMasterPresentation(MasterSignalSnapshot master,
                                        SignalUpdate update) {
        if (master == null || update == null) return;
        AppStateStore.saveMasterSnapshot(this, master);
        List<String> reasons = new ArrayList<>(master.evidenceLabels);
        reasons.add("qualidade da configuração " + master.configurationQuality + "/100");
        reasons.add(master.freshnessLabel);
        AppStateStore.saveRadarSnapshot(this, master.pressure,
                master.independentReadings, master.state.name(), master.target,
                master.playLabel(), update.headline, update.detail, reasons);
        String sector = "Principal " + master.sector + " • pressão " + master.pressure;
        if (master.dualPressure) {
            sector += "\nSecundário " + master.secondarySector
                    + " • pressão " + master.secondarySectorPressure;
        }
        AppStateStore.saveRadarBackstage(this,
                master.playLabel() + " • regime " + master.regime,
                sector,
                "Curva " + master.pressureSeries,
                "Evidências independentes " + master.independentReadings
                        + "\n" + master.evidenceLabels,
                master.stale ? "VETO: " + master.freshnessLabel
                        : "Validade " + master.remainingSpins + "/"
                        + master.validitySpins + " giros");
    }


    private void recordEarlyTouch(ConfluenceVerdict previousVerdict,
                                  RadarSession.State previousState,
                                  List<Integer> newNumbers) {
        if (previousVerdict == null || previousVerdict.target < 0
                || previousVerdict.coverage == null || previousVerdict.coverage.isEmpty()
                || newNumbers == null || newNumbers.isEmpty()) return;
        if (previousState != RadarSession.State.OBSERVING
                && previousState != RadarSession.State.BUILDING
                && previousState != RadarSession.State.PREPARE) return;
        for (int result : newNumbers) {
            if (!previousVerdict.coverage.contains(result)) continue;
            AppStateStore.saveEarlyTouch(this,
                    "⚡ TOQUE ANTECIPADO • " + result + " entrou em "
                            + previousVerdict.playLabel()
                            + " antes de sinal oficial. Não conta como STRYKE; "
                            + "o CORE reavalia a estrutura sem exigir que a região bata novamente.");
            return;
        }
    }

    private boolean shouldSurfaceStandaloneOverlay(SignalUpdate.Kind kind) {
        return kind == SignalUpdate.Kind.PREPARE
                || kind == SignalUpdate.Kind.ENTRY
                || kind == SignalUpdate.Kind.ACTIVE
                || kind == SignalUpdate.Kind.HIT
                || kind == SignalUpdate.Kind.SECONDARY_HIT
                || kind == SignalUpdate.Kind.EXPIRED
                || kind == SignalUpdate.Kind.INVALIDATED;
    }

    private boolean shouldNotifyStandalone(SignalUpdate.Kind kind) {
        return kind == SignalUpdate.Kind.PREPARE
                || kind == SignalUpdate.Kind.ENTRY
                || kind == SignalUpdate.Kind.HIT
                || kind == SignalUpdate.Kind.SECONDARY_HIT
                || kind == SignalUpdate.Kind.EXPIRED;
    }

    private boolean shouldSurfaceAurumOverlay(SignalUpdate.Kind kind) {
        return kind == SignalUpdate.Kind.ENTRY
                || kind == SignalUpdate.Kind.ACTIVE;
    }

    private boolean shouldNotifyAurum(SignalUpdate.Kind kind) {
        return kind == SignalUpdate.Kind.ENTRY
                || kind == SignalUpdate.Kind.HIT
                || kind == SignalUpdate.Kind.EXPIRED
                || kind == SignalUpdate.Kind.INVALIDATED;
    }

    private String compactAurumBody(SignalUpdate update, AurumLockSnapshot snapshot) {
        String target = update.playLabel == null || update.playLabel.isEmpty()
                ? (update.target >= 0 ? String.valueOf(update.target) : update.headline)
                : update.playLabel;
        String validity = snapshot.activeRemaining > 0
                ? " • restam " + snapshot.activeRemaining + "/3" : "";
        return target + "\nQ" + snapshot.q + " • Readiness " + snapshot.readiness
                + " • " + snapshot.regime + validity
                + "\nQ = qualidade estrutural, não probabilidade.";
    }

    private String compactStandaloneBody(SignalUpdate update, ConfluenceVerdict verdict) {
        boolean terminalSignal = update.signalType != null
                && (update.signalType.contains("TERMINAL")
                || update.signalType.contains("MAX_CONFLUENCE"));
        int score = terminalSignal ? update.strength
                : verdict == null ? update.strength : verdict.aurumScore;
        int families = terminalSignal ? update.confluenceCount
                : verdict == null ? update.confluenceCount : verdict.independentFamilies;
        String target = update.playLabel == null || update.playLabel.isEmpty()
                ? (update.target >= 0 ? String.valueOf(update.target) : update.headline)
                : update.playLabel;
        int window = terminalSignal ? 5 : 3;
        return target + " • Radar " + score + "/100 • " + families
                + " confluências" + (update.nextRound > 0
                ? " • giro " + update.nextRound + "/" + window : "");
    }

    private int accentFor(SignalUpdate.Kind kind, int strength) {
        if (kind == SignalUpdate.Kind.HIT
                || kind == SignalUpdate.Kind.SECONDARY_HIT) return Ui.GREEN;
        if (kind == SignalUpdate.Kind.ENTRY || kind == SignalUpdate.Kind.ACTIVE) return Ui.GREEN;
        if (kind == SignalUpdate.Kind.BUILDING || kind == SignalUpdate.Kind.SCANNING) return Ui.CYAN;
        if (kind == SignalUpdate.Kind.PREPARE || kind == SignalUpdate.Kind.OBSERVE) return Ui.AMBER;
        if (kind == SignalUpdate.Kind.INVALIDATED || kind == SignalUpdate.Kind.COOLDOWN) {
            return kind == SignalUpdate.Kind.INVALIDATED ? Ui.RED : Ui.CYAN;
        }
        if (kind == SignalUpdate.Kind.TRIAL || kind == SignalUpdate.Kind.LATE_WATCH
                || kind == SignalUpdate.Kind.LATE_HIT) return Ui.AMBER;
        if (kind == SignalUpdate.Kind.EXPIRED || kind == SignalUpdate.Kind.NO_ENTRY
                || kind == SignalUpdate.Kind.LATE_MISS) return Ui.RED;
        return Ui.AMBER;
    }

    private void syncSessionBoundary() {
        long current = SessionLedger.activeSessionId(this);
        if (current == lastSessionId) return;
        radarSession.resetSignal();
        aurumLockSession.reset();
        hardExpertSession.reset();
        lastSessionId = current;
    }

    private String dealerSuffix() {
        String dealer = AppStateStore.dealer(this);
        return dealer == null || dealer.trim().isEmpty() ? "" : " • " + dealer.trim();
    }

    private void setOperationalStatus(String status, String signal) {
        AppStateStore.saveStatus(this, status, signal);
        updateNotification(status);
        broadcastState();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Leitura ao vivo", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Mantém a captura autorizada da mesa enquanto a leitura estiver ativa.");
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }

    private void createSignalNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                SIGNAL_CHANNEL_ID, "Sinais Aurum", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Alertas FORTE e EXTREMO do Aurum Hard Expert.");
        channel.enableVibration(true);
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }

    private void notifyStandaloneSignal(SignalUpdate update, ConfluenceVerdict verdict) {
        Intent mainIntent = new Intent(this, StandaloneActivity.class);
        PendingIntent main = PendingIntent.getActivity(this, 11, mainIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        int score = verdict == null ? update.strength : verdict.aurumScore;
        int families = verdict == null ? update.confluenceCount : verdict.independentFamilies;
        String target = update.playLabel == null || update.playLabel.isEmpty()
                ? (update.target >= 0 ? String.valueOf(update.target) : update.headline)
                : update.playLabel;
        String body = target + " • Radar " + score + "/100 • " + families + " confluências";
        Notification notification = new Notification.Builder(this, SIGNAL_CHANNEL_ID)
                .setSmallIcon(com.xspaceart.radar30.R.drawable.ic_radar)
                .setContentTitle("Aurum • " + update.headline)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(main)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_EVENT)
                .build();
        getSystemService(NotificationManager.class).notify(SIGNAL_NOTIFICATION_ID, notification);
    }

    private void notifyAurumSignal(SignalUpdate update, AurumLockSnapshot snapshot) {
        Intent mainIntent = new Intent(this, StandaloneActivity.class);
        PendingIntent main = PendingIntent.getActivity(this, 12, mainIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String target = update.playLabel == null || update.playLabel.isEmpty()
                ? (update.target >= 0 ? String.valueOf(update.target) : update.headline)
                : update.playLabel;
        String body = target + " • Q" + snapshot.q + " • Readiness "
                + snapshot.readiness + " • " + snapshot.regime;
        Notification notification = new Notification.Builder(this, SIGNAL_CHANNEL_ID)
                .setSmallIcon(com.xspaceart.radar30.R.drawable.ic_radar)
                .setContentTitle(update.headline)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body
                        + "\nQ mede qualidade estrutural; não é probabilidade."))
                .setContentIntent(main)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_EVENT)
                .build();
        getSystemService(NotificationManager.class).notify(SIGNAL_NOTIFICATION_ID, notification);
    }

    private void notifyMasterSignal(MasterSignalSnapshot snapshot) {
        if (snapshot == null || snapshot.stale || !snapshot.shouldAlert) return;
        Intent mainIntent = new Intent(this, StandaloneActivity.class);
        PendingIntent main = PendingIntent.getActivity(this, 13, mainIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String body = snapshot.playLabel() + " • Pressão " + snapshot.pressure
                + "/100 • Qualidade " + snapshot.configurationQuality + "/100"
                + " • " + snapshot.independentReadings + " leituras independentes"
                + (snapshot.rival >= 0 ? " • Rival " + snapshot.rival : "")
                + " • " + snapshot.freshnessLabel;
        Notification notification = new Notification.Builder(this, SIGNAL_CHANNEL_ID)
                .setSmallIcon(com.xspaceart.radar30.R.drawable.ic_radar)
                .setContentTitle(snapshot.headline() + " • " + snapshot.target)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body
                        + "\nScore interno; não é probabilidade matemática."))
                .setContentIntent(main)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .build();
        getSystemService(NotificationManager.class).notify(SIGNAL_NOTIFICATION_ID, notification);
    }

    private void ensureForeground(String text) {
        startForeground(NOTIFICATION_ID, buildNotification(text));
    }

    private void updateNotification(String text) {
        if (mediaProjection == null) return;
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private Notification buildNotification(String text) {
        Intent mainIntent = new Intent(this,
                standaloneMode ? StandaloneActivity.class
                        : integratedSourceOnly ? IntegratedActivity.class : MainActivity.class);
        PendingIntent main = PendingIntent.getActivity(this, 1, mainIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent calibrationIntent = new Intent(this, CalibrationActivity.class);
        PendingIntent calibrate = PendingIntent.getActivity(this, 2, calibrationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, ScreenCaptureService.class).setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 3, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent bubbleIntent = new Intent(this, ScreenCaptureService.class)
                .setAction(ACTION_TOGGLE_OVERLAY);
        PendingIntent bubble = PendingIntent.getService(this, 4, bubbleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(com.xspaceart.radar30.R.drawable.ic_radar)
                .setContentTitle(standaloneMode ? "Aurum AI 37 • OCR"
                        : integratedSourceOnly ? "Aurum AI 37 • Integrated" : "Aurum AI 37")
                .setContentText(text)
                .setContentIntent(main)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(
                        com.xspaceart.radar30.R.drawable.ic_radar, "Calibrar", calibrate).build())
                .addAction(new Notification.Action.Builder(
                        com.xspaceart.radar30.R.drawable.ic_radar,
                        AppStateStore.overlayHidden(this) ? "Mostrar bolha" : "Ocultar bolha",
                        bubble).build())
                .addAction(new Notification.Action.Builder(
                        com.xspaceart.radar30.R.drawable.ic_radar, "Parar", stop).build())
                .build();
    }

    private void broadcastState() {
        sendBroadcast(new Intent(MainActivity.ACTION_STATE_UPDATED).setPackage(getPackageName()));
    }

    private static int bound(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
