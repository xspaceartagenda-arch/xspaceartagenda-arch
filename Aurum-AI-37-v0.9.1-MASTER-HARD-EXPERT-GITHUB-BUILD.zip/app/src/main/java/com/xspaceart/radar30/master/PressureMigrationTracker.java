package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;

/** Mantém persistência quando o candidato migra dentro da mesma região física. */
public final class PressureMigrationTracker {
    private SectorClusterEngine.Cluster previous = SectorClusterEngine.Cluster.empty();
    private int persistence;

    public Result update(SectorClusterEngine.Cluster current) {
        if (current == null || !current.available()) {
            previous = SectorClusterEngine.Cluster.empty();
            persistence = 0;
            return new Result(false, 0, -1);
        }
        int prior = previous.center;
        boolean sameRegion = previous.available()
                && (overlap(previous, current) > 0
                || Wheel.distance(previous.center, current.center)
                <= Math.max(previous.radius, current.radius) + 2);
        boolean migrating = sameRegion && previous.center != current.center;
        persistence = sameRegion ? persistence + 1 : 1;
        previous = current;
        return new Result(migrating, persistence, prior);
    }

    public void reset() {
        previous = SectorClusterEngine.Cluster.empty();
        persistence = 0;
    }

    private static int overlap(SectorClusterEngine.Cluster a, SectorClusterEngine.Cluster b) {
        int count = 0;
        for (Integer value : a.members) if (b.members.contains(value)) count++;
        return count;
    }

    public static final class Result {
        public final boolean migrating;
        public final int persistence;
        public final int previousCenter;

        Result(boolean migrating, int persistence, int previousCenter) {
            this.migrating = migrating;
            this.persistence = Math.max(0, persistence);
            this.previousCenter = previousCenter;
        }
    }
}
