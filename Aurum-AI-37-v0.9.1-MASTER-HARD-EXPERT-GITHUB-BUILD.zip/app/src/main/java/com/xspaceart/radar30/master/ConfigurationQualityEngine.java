package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;

import java.util.List;

/**
 * Segundo filtro do sinal. Compara a assinatura atual somente com contextos
 * anteriores e seus seguidores já conhecidos, sem usar o futuro da janela atual.
 */
public final class ConfigurationQualityEngine {
    private ConfigurationQualityEngine() {}

    public static Result evaluate(MasterHistoryIndex index, List<Integer> sector,
                                  int independentReadings, int persistence,
                                  int patternStrength, int contradiction) {
        if (index == null || index.size() < 4 || sector == null || sector.isEmpty()) {
            return new Result(0, 0, 0, false);
        }
        List<Integer> history = index.chronological(Math.min(500, index.size()));
        int currentStart = history.size() - 3;
        int samples = 0;
        int hits = 0;
        for (int start = 0; start + 3 < currentStart; start++) {
            double similarity = signatureSimilarity(history, start, currentStart);
            if (similarity < 0.66) continue;
            samples++;
            int follower = history.get(start + 3);
            if (sector.contains(follower)) hits++;
        }

        double baseline = sector.size() / 37.0;
        double smoothed = (hits + 5.0 * baseline) / (samples + 5.0);
        double lift = Math.max(0.0, (smoothed - baseline) / Math.max(1e-9, 1.0 - baseline));
        double depth = Math.min(1.0, index.size() / 150.0);
        double sample = Math.min(1.0, samples / 12.0);
        double diversity = Math.min(1.0, independentReadings / 4.0);
        double stable = Math.min(1.0, persistence / 4.0);
        double echo = Math.max(0.0, Math.min(1.0, patternStrength / 100.0));
        double value = 100.0 * (0.18 * depth + 0.18 * sample + 0.26 * lift
                + 0.20 * diversity + 0.10 * stable + 0.08 * echo)
                - 0.20 * Math.max(0, contradiction);
        int score = clamp((int) Math.round(value));
        if (index.size() < 15) score = Math.min(score, 43);
        else if (index.size() < 30) score = Math.min(score, 58);
        if (samples == 0) score = Math.min(score, 55);
        return new Result(score, samples, hits, index.size() >= 60 && samples >= 5);
    }

    private static double signatureSimilarity(List<Integer> history, int a, int b) {
        double score = 0.0;
        for (int i = 0; i < 3; i++) {
            int x = history.get(a + i);
            int y = history.get(b + i);
            if (x % 10 == y % 10) score += 0.16;
            int distance = Wheel.distance(x, y);
            score += distance == 0 ? 0.17 : distance <= 2 ? 0.13 : distance <= 4 ? 0.07 : 0.0;
        }
        int a1 = signedStep(history.get(a), history.get(a + 1));
        int a2 = signedStep(history.get(a + 1), history.get(a + 2));
        int b1 = signedStep(history.get(b), history.get(b + 1));
        int b2 = signedStep(history.get(b + 1), history.get(b + 2));
        if (Math.abs(a1 - b1) <= 2) score += 0.17;
        if (Math.abs(a2 - b2) <= 2) score += 0.17;
        return Math.min(1.0, score);
    }

    private static int signedStep(int from, int to) {
        int d = Wheel.EUROPEAN.indexOf(to) - Wheel.EUROPEAN.indexOf(from);
        if (d > 18) d -= 37;
        if (d < -18) d += 37;
        return d;
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }

    public static final class Result {
        public final int score;
        public final int historicalSamples;
        public final int matchingFollowers;
        public final boolean outOfSampleReady;

        Result(int score, int historicalSamples, int matchingFollowers,
               boolean outOfSampleReady) {
            this.score = clamp(score);
            this.historicalSamples = Math.max(0, historicalSamples);
            this.matchingFollowers = Math.max(0, matchingFollowers);
            this.outOfSampleReady = outOfSampleReady;
        }
    }
}
