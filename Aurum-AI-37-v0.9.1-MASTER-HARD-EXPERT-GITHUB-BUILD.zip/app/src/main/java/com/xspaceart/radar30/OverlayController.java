package com.xspaceart.radar30;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.lock.AurumLockSnapshot;
import com.xspaceart.radar30.master.MasterSignalSnapshot;

/** Mini Bubble compacta, expansível, arrastável e removível. */
public final class OverlayController {
    private static final int COMPACT_DP = 62;
    private static final int EXPANDED_DP = 304;

    private final Context context;
    private final WindowManager windowManager;
    private final Handler main = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private LinearLayout compactPanel;
    private LinearLayout expandedPanel;
    private TextView compactTarget;
    private TextView compactHint;
    private TextView headline;
    private TextView play;
    private TextView metrics;
    private TextView detail;
    private WindowManager.LayoutParams params;
    private int accent = Ui.GREEN;

    public OverlayController(Context context) {
        this.context = context.getApplicationContext();
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
    }

    /** Compatibilidade com o motor Stable. */
    public void show(String title, String body, int accent) {
        main.post(() -> showOnMain(title, body, -1, "", 0, 0, "", 0,
                accent, true));
    }

    public void showAurum(SignalUpdate update, AurumLockSnapshot snapshot, int accent) {
        if (update == null || snapshot == null) return;
        String label = update.playLabel == null || update.playLabel.trim().isEmpty()
                ? snapshot.playLabel() : update.playLabel;
        main.post(() -> showOnMain(update.headline, update.detail, snapshot.target,
                label, snapshot.q, snapshot.readiness, snapshot.regime.name(),
                snapshot.activeRemaining, accent, false));
    }

    public void showMaster(MasterSignalSnapshot snapshot) {
        if (snapshot == null || snapshot.target < 0 || snapshot.stale) return;
        int masterAccent = snapshot.state == MasterSignalSnapshot.State.EXTREME
                ? Ui.RED : Ui.GOLD;
        String detailText = "Pressão " + snapshot.pressure + "/100"
                + " • Qualidade " + snapshot.configurationQuality + "/100"
                + "\n" + snapshot.independentReadings + " leituras independentes"
                + " • persistência " + snapshot.persistence + " giros"
                + (snapshot.dualPressure ? "\nDUPLA PRESSÃO • rival " + snapshot.rival : "")
                + (snapshot.migrating ? "\nPRESSÃO MIGRANDO NO MESMO SETOR" : "")
                + "\n" + snapshot.freshnessLabel
                + "\nScore interno; não é probabilidade.";
        main.post(() -> showOnMain(snapshot.headline(), detailText, snapshot.target,
                snapshot.playLabel(), snapshot.pressure,
                snapshot.configurationQuality, snapshot.state.label,
                snapshot.remainingSpins, masterAccent, false));
    }

    /** Restaura o último lock ativo, sem recalcular nem publicar novo sinal. */
    public void showStoredAurum() {
        AppStateStore.setOverlayHidden(context, false);
        String masterState = AppStateStore.masterState(context);
        int masterTarget = AppStateStore.masterTarget(context);
        if (masterTarget >= 0 && ("STRONG".equals(masterState)
                || "EXTREME".equals(masterState))) {
            int pressure = AppStateStore.masterPressure(context);
            int quality = AppStateStore.masterQuality(context);
            int remaining = AppStateStore.masterRemaining(context);
            int storedAccent = "EXTREME".equals(masterState) ? Ui.RED : Ui.GOLD;
            main.post(() -> showOnMain(AppStateStore.radarHeadline(context),
                    AppStateStore.radarDetail(context), masterTarget,
                    AppStateStore.radarPlayLabel(context), pressure, quality,
                    "EXTREME".equals(masterState) ? "EXTREMA" : "FORTE",
                    remaining, storedAccent, false));
            return;
        }
        int storedTarget = AppStateStore.radarTarget(context);
        int remaining = AppStateStore.aurumActiveRemaining(context);
        if (storedTarget < 0 || remaining <= 0) {
            Toast.makeText(context, "Não há Aurum Lock ativo para mostrar.", Toast.LENGTH_SHORT).show();
            return;
        }
        main.post(() -> showOnMain(AppStateStore.radarHeadline(context),
                AppStateStore.radarDetail(context), storedTarget,
                AppStateStore.radarPlayLabel(context), AppStateStore.radarScore(context),
                AppStateStore.aurumReadiness(context), AppStateStore.aurumRegime(context),
                remaining, Ui.GREEN, false));
    }

    /** Remove a janela sem alterar a preferência do usuário. */
    public void hide() { main.post(this::removeOnMain); }

    /** Atualiza apenas o selo de saúde da captura sem recriar nem mover a bolha. */
    public void refreshCaptureState() {
        main.post(() -> {
            if (root == null || compactHint == null) return;
            applyCaptureStateToCompactHint();
        });
    }

    /** Oculta até restauração pelo app ou pela notificação. */
    public void hideByUser() {
        AppStateStore.setOverlayHidden(context, true);
        main.post(() -> {
            removeOnMain();
            Toast.makeText(context,
                    "Mini Bubble ocultada. Restaure pelo app ou pela notificação.",
                    Toast.LENGTH_SHORT).show();
        });
    }

    private void showOnMain(String title, String body, int target, String playLabel,
                            int q, int readiness, String regime, int remaining,
                            int accent, boolean legacy) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || !Settings.canDrawOverlays(context)) return;
        if (AppStateStore.overlayHidden(context)) {
            removeOnMain();
            return;
        }
        this.accent = accent;
        boolean first = root == null;
        if (first) createRoot(legacy);
        compactTarget.setText(target >= 0 ? String.valueOf(target) : "A");
        compactHint.setText(target >= 0 ? "±2" : "AI");
        applyCaptureStateToCompactHint();
        headline.setText(title == null || title.trim().isEmpty() ? "AURUM AI 37" : title);
        play.setText(playLabel == null || playLabel.trim().isEmpty()
                ? (target >= 0 ? "NÚCLEO " + target + " • SETOR +2" : "SINAL AURUM")
                : playLabel);
        boolean hardExpert = title != null && (title.contains("PRESSÃO")
                || title.contains("ALERTA FORTE") || title.contains("DADOS DESATUALIZADOS"));
        metrics.setText(target >= 0
                ? (hardExpert
                ? "Pressão " + q + "  •  Qualidade " + readiness + "  •  " + regime
                        + (remaining > 0 ? "  •  validade " + remaining + " giros" : "")
                : "Q" + q + "  •  Readiness " + readiness + "  •  " + regime
                        + (remaining > 0 ? "  •  " + remaining + "/3" : ""))
                : "Toque na bolha para abrir os detalhes");
        detail.setText(body == null ? "" : body);
        refreshBackgrounds();
        if (first) applyMode(legacy);
        if (!root.isAttachedToWindow()) {
            try { windowManager.addView(root, params); }
            catch (RuntimeException ignored) { clearReferences(); return; }
        } else {
            try { windowManager.updateViewLayout(root, params); }
            catch (RuntimeException ignored) { clearReferences(); }
        }
    }

    private void applyCaptureStateToCompactHint() {
        if (compactHint == null) return;
        String health = AppStateStore.captureHealth(context);
        if ("RESYNC".equalsIgnoreCase(health)) {
            if (compactTarget != null) compactTarget.setText("…");
            compactHint.setText("SYNC");
            compactHint.setTextColor(Ui.AMBER);
        } else if ("ERRO".equalsIgnoreCase(health)) {
            if (compactTarget != null) compactTarget.setText("!");
            compactHint.setText("ERR");
            compactHint.setTextColor(Ui.RED);
        } else if ("LIVE".equalsIgnoreCase(health)) {
            int target = AppStateStore.radarTarget(context);
            if (compactTarget != null && target >= 0) compactTarget.setText(String.valueOf(target));
            compactHint.setText("LIVE");
            compactHint.setTextColor(Ui.GREEN);
        } else {
            compactHint.setText("AI");
            compactHint.setTextColor(Ui.GOLD);
        }
    }

    private void createRoot(boolean legacy) {
        root = new FrameLayout(context);
        root.setClipChildren(false);
        root.setElevation(Ui.dp(context, 16));

        compactPanel = new LinearLayout(context);
        compactPanel.setOrientation(LinearLayout.VERTICAL);
        compactPanel.setGravity(Gravity.CENTER);
        compactPanel.setPadding(Ui.dp(context, 4), Ui.dp(context, 3),
                Ui.dp(context, 4), Ui.dp(context, 3));
        compactTarget = Ui.text(context, "A", 23, Ui.TEXT, true);
        compactTarget.setGravity(Gravity.CENTER);
        compactHint = Ui.text(context, "AI", 8, Ui.GOLD, true);
        compactHint.setGravity(Gravity.CENTER);
        compactPanel.addView(compactTarget, new LinearLayout.LayoutParams(-1, -2));
        compactPanel.addView(compactHint, new LinearLayout.LayoutParams(-1, -2));
        root.addView(compactPanel, new FrameLayout.LayoutParams(-1, -1));

        expandedPanel = new LinearLayout(context);
        expandedPanel.setOrientation(LinearLayout.VERTICAL);
        expandedPanel.setPadding(Ui.dp(context, 15), Ui.dp(context, 11),
                Ui.dp(context, 15), Ui.dp(context, 13));
        LinearLayout dragBar = new LinearLayout(context);
        dragBar.setOrientation(LinearLayout.HORIZONTAL);
        dragBar.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = Ui.text(context, "AURUM AI 37 • LIVE", 11, Ui.GOLD, true);
        TextView minimize = Ui.text(context, "—", 20, Ui.MUTED, true);
        minimize.setGravity(Gravity.CENTER);
        TextView close = Ui.text(context, "×", 22, Ui.RED, true);
        close.setGravity(Gravity.CENTER);
        dragBar.addView(brand, new LinearLayout.LayoutParams(0, Ui.dp(context, 34), 1));
        dragBar.addView(minimize,
                new LinearLayout.LayoutParams(Ui.dp(context, 40), Ui.dp(context, 34)));
        dragBar.addView(close,
                new LinearLayout.LayoutParams(Ui.dp(context, 40), Ui.dp(context, 34)));
        expandedPanel.addView(dragBar);
        headline = Ui.text(context, "AURUM LOCK", 14, Ui.GREEN, true);
        play = Ui.text(context, "NÚCLEO —", 23, Ui.TEXT, true);
        metrics = Ui.text(context, "Q0 • Readiness 0", 11, Ui.CYAN, true);
        detail = Ui.text(context, "", 11, Ui.MUTED, false);
        expandedPanel.addView(headline, Ui.margins(-1, -2, context, 0, 2, 0, 0));
        expandedPanel.addView(play, Ui.margins(-1, -2, context, 0, 5, 0, 0));
        expandedPanel.addView(metrics, Ui.margins(-1, -2, context, 0, 5, 0, 0));
        expandedPanel.addView(detail, Ui.margins(-1, -2, context, 0, 7, 0, 0));
        root.addView(expandedPanel, new FrameLayout.LayoutParams(-1, -2));

        minimize.setOnClickListener(v -> applyMode(false));
        close.setOnClickListener(v -> hideByUser());
        compactPanel.setOnTouchListener(new DragListener(true));
        dragBar.setOnTouchListener(new DragListener(false));

        int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
        params = new WindowManager.LayoutParams(
                Ui.dp(context, legacy ? EXPANDED_DP : COMPACT_DP),
                legacy ? WindowManager.LayoutParams.WRAP_CONTENT : Ui.dp(context, COMPACT_DP),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = AppStateStore.overlayX(context,
                Math.max(0, screenWidth - Ui.dp(context, COMPACT_DP + 14)));
        params.y = AppStateStore.overlayY(context, Ui.dp(context, 92));
    }

    private void applyMode(boolean expand) {
        if (root == null || params == null) return;
        compactPanel.setVisibility(expand ? View.GONE : View.VISIBLE);
        expandedPanel.setVisibility(expand ? View.VISIBLE : View.GONE);
        params.width = Ui.dp(context, expand ? EXPANDED_DP : COMPACT_DP);
        params.height = expand ? WindowManager.LayoutParams.WRAP_CONTENT : Ui.dp(context, COMPACT_DP);
        clampPosition();
        try { if (root.isAttachedToWindow()) windowManager.updateViewLayout(root, params); }
        catch (RuntimeException ignored) { /* janela encerrada durante o toque */ }
    }

    private void refreshBackgrounds() {
        GradientDrawable compact = Ui.verticalGradient(Ui.SURFACE_ALT, Ui.BG,
                accent, 999, context);
        compact.setStroke(Ui.dp(context, 2), accent);
        compactPanel.setBackground(compact);
        expandedPanel.setBackground(Ui.verticalGradient(Ui.SURFACE_ALT, Ui.BG,
                accent, 19, context));
        headline.setTextColor(accent);
    }

    private void snapToEdge() {
        int width = context.getResources().getDisplayMetrics().widthPixels;
        int panelWidth = params.width > 0 ? params.width : Ui.dp(context, COMPACT_DP);
        params.x = params.x + panelWidth / 2 < width / 2
                ? Ui.dp(context, 8) : Math.max(0, width - panelWidth - Ui.dp(context, 8));
        clampPosition();
        AppStateStore.saveOverlayPosition(context, params.x, params.y);
        try { windowManager.updateViewLayout(root, params); }
        catch (RuntimeException ignored) { /* janela já removida */ }
    }

    private void clampPosition() {
        int width = context.getResources().getDisplayMetrics().widthPixels;
        int height = context.getResources().getDisplayMetrics().heightPixels;
        int panelWidth = params.width > 0 ? params.width : Ui.dp(context, COMPACT_DP);
        params.x = Math.max(0, Math.min(params.x, Math.max(0, width - panelWidth)));
        params.y = Math.max(Ui.dp(context, 24),
                Math.min(params.y, Math.max(Ui.dp(context, 24), height - Ui.dp(context, 108))));
    }

    private void removeOnMain() {
        if (root != null) {
            try { windowManager.removeView(root); }
            catch (RuntimeException ignored) { /* o sistema pode já ter removido a janela */ }
        }
        clearReferences();
    }

    private void clearReferences() {
        root = null;
        compactPanel = null;
        expandedPanel = null;
        compactTarget = null;
        compactHint = null;
        headline = null;
        play = null;
        metrics = null;
        detail = null;
        params = null;
    }

    private final class DragListener implements View.OnTouchListener {
        private final boolean tapExpands;
        private int startX;
        private int startY;
        private float touchX;
        private float touchY;
        private boolean moved;

        DragListener(boolean tapExpands) { this.tapExpands = tapExpands; }

        @Override public boolean onTouch(View view, MotionEvent event) {
            if (params == null || root == null) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = params.x;
                    startY = params.y;
                    touchX = event.getRawX();
                    touchY = event.getRawY();
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = Math.round(event.getRawX() - touchX);
                    int dy = Math.round(event.getRawY() - touchY);
                    if (Math.abs(dx) > Ui.dp(context, 5) || Math.abs(dy) > Ui.dp(context, 5)) moved = true;
                    params.x = startX + dx;
                    params.y = startY + dy;
                    clampPosition();
                    int screenHeight = context.getResources().getDisplayMetrics().heightPixels;
                    root.setAlpha(params.y > screenHeight - Ui.dp(context, 190) ? 0.52f : 1f);
                    try { windowManager.updateViewLayout(root, params); }
                    catch (RuntimeException ignored) { return false; }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    root.setAlpha(1f);
                    int displayHeight = context.getResources().getDisplayMetrics().heightPixels;
                    if (moved && params.y > displayHeight - Ui.dp(context, 150)) {
                        hideByUser();
                    } else if (!moved && tapExpands) {
                        applyMode(true);
                    } else {
                        snapToEdge();
                    }
                    return true;
                default:
                    return true;
            }
        }
    }
}
