package com.xspaceart.radar30.master;

import java.util.Arrays;

/** Vetor de pressão com grupo de dependência explícito para evitar voto duplicado. */
public final class MasterEvidence {
    public enum Family { PHYSICAL, SEQUENTIAL, NUMERIC, PATTERN_ECHO, LEGACY_FUSION }

    public final Family family;
    public final String dependencyGroup;
    public final String label;
    public final double confidence;
    public final boolean independent;
    private final double[] pressure;

    public MasterEvidence(Family family, String dependencyGroup, String label,
                          double[] values, double confidence, boolean independent) {
        if (family == null) throw new IllegalArgumentException("family required");
        if (values == null || values.length != 37) {
            throw new IllegalArgumentException("pressure vector must have 37 positions");
        }
        this.family = family;
        this.dependencyGroup = clean(dependencyGroup, family.name());
        this.label = clean(label, family.name());
        this.confidence = clamp01(confidence);
        this.independent = independent;
        this.pressure = sanitizeAndNormalize(values);
    }

    public double at(int number) {
        return number >= 0 && number < 37 ? pressure[number] : 0.0;
    }

    public double strongest(Iterable<Integer> numbers) {
        double best = 0.0;
        if (numbers != null) for (Integer n : numbers) if (n != null) best = Math.max(best, at(n));
        return best;
    }

    public double[] copyPressure() { return pressure.clone(); }

    public boolean isEmpty() {
        for (double value : pressure) if (value > 0.0) return false;
        return true;
    }

    private static double[] sanitizeAndNormalize(double[] values) {
        double[] out = Arrays.copyOf(values, 37);
        double max = 0.0;
        for (int i = 0; i < out.length; i++) {
            if (!Double.isFinite(out[i]) || out[i] < 0.0) out[i] = 0.0;
            max = Math.max(max, out[i]);
        }
        if (max > 1e-12) for (int i = 0; i < out.length; i++) out[i] /= max;
        return out;
    }

    private static String clean(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private static double clamp01(double value) {
        return Double.isFinite(value) ? Math.max(0.0, Math.min(1.0, value)) : 0.0;
    }
}
