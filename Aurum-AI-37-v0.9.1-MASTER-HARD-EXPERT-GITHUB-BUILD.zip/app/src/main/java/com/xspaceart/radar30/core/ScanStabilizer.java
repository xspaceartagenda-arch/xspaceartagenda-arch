package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Confirma o OCR em duas leituras consecutivas, tolerando pequena oscilação
 * nas células antigas. O cabeçalho da grade (resultado mais recente) precisa
 * permanecer idêntico; a cauda pode ter até duas divergências nas 12 primeiras
 * posições. Isso evita o congelamento causado por um único dígito antigo que o
 * ML Kit alterna entre dois valores.
 */
public final class ScanStabilizer {
    private List<Integer> candidate = Collections.emptyList();
    private int repeats = 0;
    private List<Integer> lastEmitted = Collections.emptyList();

    public boolean accept(List<Integer> numbers) {
        List<Integer> clean = copy(numbers);
        if (clean.size() < 8) return false;

        if (sameObservation(candidate, clean)) {
            repeats++;
            // Mantém a leitura mais nova: se uma célula antiga foi corrigida no
            // segundo frame, o synchronizer recebe a versão mais recente.
            candidate = clean;
        } else {
            candidate = clean;
            repeats = 1;
        }

        if (repeats >= 2 && !sameObservation(lastEmitted, candidate)) {
            lastEmitted = new ArrayList<>(candidate);
            return true;
        }
        return false;
    }

    /** Permite ao capturador pedir rapidamente o frame de confirmação. */
    public boolean needsConfirmation() {
        return repeats == 1 && !candidate.isEmpty() && !sameObservation(lastEmitted, candidate);
    }

    /**
     * Duas leituras representam a mesma grade quando o número mais recente é
     * exatamente igual e pelo menos 10 das primeiras 12 posições coincidem.
     * Um giro novo (inclusive repetição, ex. 9→9) desloca a sequência e não é
     * confundido com jitter de OCR.
     */
    static boolean sameObservation(List<Integer> a, List<Integer> b) {
        if (a == null || b == null || a.size() < 8 || b.size() < 8) return false;
        if (!a.get(0).equals(b.get(0))) return false;
        int compared = Math.min(12, Math.min(a.size(), b.size()));
        int equal = 0;
        for (int i = 0; i < compared; i++) if (a.get(i).equals(b.get(i))) equal++;
        int allowedMismatches = compared >= 10 ? 2 : 1;
        return equal >= compared - allowedMismatches;
    }

    private static List<Integer> copy(List<Integer> source) {
        if (source == null || source.isEmpty()) return Collections.emptyList();
        return new ArrayList<>(source);
    }
}
