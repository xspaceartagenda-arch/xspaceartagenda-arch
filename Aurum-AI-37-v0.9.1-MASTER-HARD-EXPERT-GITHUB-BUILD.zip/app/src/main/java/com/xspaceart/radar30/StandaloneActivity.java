package com.xspaceart.radar30;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.xspaceart.radar30.echo.PatternEchoActivity;

import java.util.List;
import java.util.Locale;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * v0.7.5: interface operacional standalone. A roleta roda em outro app.
 * O ScreenCaptureService é o único dono da captura OCR + RadarSession.
 */
public final class StandaloneActivity extends Activity {
    private static final int REQUEST_CAPTURE = 7501;
    private static final int REQUEST_NOTIFICATIONS = 7502;
    private static final long STATE_REFRESH_DEBOUNCE_MS = 150L;
    private static final long SESSION_SUMMARY_REFRESH_MS = 2_000L;
    private static final long ACTIVE_UI_REFRESH_MS = 250L;
    private static final long IDLE_UI_REFRESH_MIN_MS = 600L;
    private static final long IDLE_UI_REFRESH_MAX_MS = 1_000L;
    private static final long ACTIVE_UI_WINDOW_MS = 1_500L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService sessionSummaryExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean sessionSummaryInFlight = new AtomicBoolean(false);
    private final AtomicBoolean stateHasChanged = new AtomicBoolean(true);
    private final Runnable coalescedStateRefresh = this::refreshState;
    private TextView liveBadge;
    private TextView radarValue;
    private TextView radarMeta;
    private TextView radarReasons;
    private TextView radarFocus;
    private TextView radarSectors;
    private TextView radarHeat;
    private TextView radarFamilyDetail;
    private TextView radarGate;
    private TextView radarEarlyTouch;
    private TextView signalTitle;
    private TextView signalTarget;
    private TextView signalMeta;
    private TextView historyText;
    private TextView ocrStatus;
    private TextView sessionText;
    private ProgressBar radarBar;
    private Button startButton;
    private Button floatButton;
    private Switch precisionSwitch;
    private Switch voiceSwitch;
    private Switch soundSwitch;
    private AurumGaugeView aurumGauge;
    private AurumPressureView pressureView;
    private TextView pressureSectorText;
    private TextView pressureTerminalText;
    private TextView pressureNumbersText;
    private TextView pressureDriversText;
    private TextView pressureSampleText;
    private TextView readinessValue;
    private TextView regimePill;
    private TextView statePill;
    private TextView runnerValue;
    private TextView validityValue;
    private TextView coverageValue;
    private TextView capturePill;
    private LinearLayout historyChips;
    private Button bubbleButton;
    private LinearLayout masterSignalCard;
    private TextView patternEchoStatus;
    private TextView patternEchoDetail;
    private TextView freshnessValue;
    private TextView thermalValue;
    private ObjectAnimator signalPulse;
    private String lastHistoryVisual = "";
    private String cachedSessionSummary = "Carregando sessão…";
    private long lastSessionSummaryRequestAt;
    private boolean receiverRegistered;
    private volatile boolean destroyed;
    private long lastRenderedStateToken = Long.MIN_VALUE;
    private long lastUiStateChangeAt = SystemClock.elapsedRealtime();

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            // Vários componentes podem publicar o mesmo estado quase juntos.
            // Coalescer evita uma fila de atualizações pesadas na thread principal.
            stateHasChanged.set(true);
            handler.removeCallbacks(coalescedStateRefresh);
            handler.postDelayed(coalescedStateRefresh, STATE_REFRESH_DEBOUNCE_MS);
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refreshState();
            long elapsed = SystemClock.elapsedRealtime();
            boolean activelyChanging = AppStateStore.captureActive(StandaloneActivity.this)
                    && elapsed - lastUiStateChangeAt <= ACTIVE_UI_WINDOW_MS;
            long thermalIdle = AppStateStore.thermalUiRefreshMs(StandaloneActivity.this);
            long idleDelay = Math.max(IDLE_UI_REFRESH_MIN_MS,
                    Math.min(IDLE_UI_REFRESH_MAX_MS, thermalIdle));
            handler.postDelayed(this, activelyChanging ? ACTIVE_UI_REFRESH_MS : idleDelay);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        AppStateStore.ensureStandaloneDefaults(this);
        setContentView(buildUi());
        requestNotificationPermission();
        registerStateReceiver();
        handler.post(ticker);
    }

    @Override protected void onResume() {
        super.onResume();
        stateHasChanged.set(true);
        refreshState();
        // v0.7.11: se a captura continua ativa em segundo plano, voltar à Aurum
        // não reinicia o CORE. Apenas força uma sincronização visual imediata.
        if (AppStateStore.captureActive(this)) {
            Intent service = new Intent(this, ScreenCaptureService.class)
                    .setAction(ScreenCaptureService.ACTION_FAST_RESYNC);
            startService(service);
        }
    }

    @Override protected void onDestroy() {
        destroyed = true;
        stopSignalPulse();
        handler.removeCallbacksAndMessages(null);
        sessionSummaryExecutor.shutdownNow();
        if (receiverRegistered) {
            try { unregisterReceiver(receiver); } catch (IllegalArgumentException ignored) {}
        }
        super.onDestroy();
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Captura OCR não autorizada.", Toast.LENGTH_LONG).show();
            return;
        }
        SessionLedger.ensureActive(this, AppStateStore.provider(this), AppStateStore.dealer(this));
        AppStateStore.clearOcrSnapshot(this);
        Intent service = new Intent(this, ScreenCaptureService.class)
                .setAction(ScreenCaptureService.ACTION_START)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                .putExtra(ScreenCaptureService.EXTRA_PIPELINE_MODE,
                        ScreenCaptureService.MODE_STANDALONE_OCR);
        startForegroundService(service);
        Toast.makeText(this,
                AppStateStore.isCalibrated(this)
                        ? "OCR iniciado. Agora abra a roleta e mantenha o histórico visível."
                        : "OCR iniciado. Agora calibre somente a área do histórico.",
                Toast.LENGTH_LONG).show();
        refreshState();
    }

    private View buildUi() {
        return AppStateStore.premiumUiEnabled(this) ? buildPremiumUi() : buildLegacyUi();
    }

    private View buildPremiumUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        scroll.setClipToPadding(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this, 14), Ui.dp(this, 48), Ui.dp(this, 14), Ui.dp(this, 28));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout identity = new LinearLayout(this);
        identity.setOrientation(LinearLayout.VERTICAL);
        TextView brand = Ui.text(this, "AURUM AI 37", 25, Ui.TEXT, true);
        brand.setLetterSpacing(0.03f);
        identity.addView(brand);
        identity.addView(Ui.text(this, "INTELLIGENCE CONSOLE", 10, Ui.GOLD, true));
        liveBadge = Ui.pill(this, "● OCR PARADO", Ui.AMBER);
        header.addView(identity, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(liveBadge);
        root.addView(header);

        LinearLayout versionRow = new LinearLayout(this);
        versionRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView version = Ui.pill(this, "v0.9.1 MASTER", Ui.CYAN);
        TextView engine = Ui.pill(this, "HARD EXPERT • ON", Ui.GREEN);
        versionRow.addView(version);
        versionRow.addView(engine, Ui.margins(-2, -2, this, 7, 0, 0, 0));
        root.addView(versionRow, Ui.margins(-1, -2, this, 0, 10, 0, 12));

        LinearLayout hero = Ui.card(this);
        hero.setBackground(Ui.verticalGradient(Ui.SURFACE_ALT, Ui.SURFACE,
                Ui.withAlpha(Ui.GREEN, 90), 22, this));
        LinearLayout heroHeader = new LinearLayout(this);
        heroHeader.setOrientation(LinearLayout.HORIZONTAL);
        heroHeader.setGravity(Gravity.CENTER_VERTICAL);
        heroHeader.addView(Ui.sectionLabel(this, "QUALIDADE ESTRUTURAL"),
                new LinearLayout.LayoutParams(0, -2, 1));
        capturePill = Ui.pill(this, "CAPTURA —", Ui.MUTED);
        heroHeader.addView(capturePill);
        hero.addView(heroHeader);

        aurumGauge = new AurumGaugeView(this);
        hero.addView(aurumGauge, new LinearLayout.LayoutParams(-1, Ui.dp(this, 194)));

        LinearLayout pills = new LinearLayout(this);
        pills.setOrientation(LinearLayout.HORIZONTAL);
        pills.setGravity(Gravity.CENTER);
        regimePill = Ui.pill(this, "DISPERSION", Ui.CYAN);
        statePill = Ui.pill(this, "IDLE", Ui.MUTED);
        pills.addView(regimePill);
        pills.addView(statePill, Ui.margins(-2, -2, this, 7, 0, 0, 0));
        hero.addView(pills);

        readinessValue = Ui.text(this, "SIGNAL READINESS 0/100", 12, Ui.PURPLE, true);
        readinessValue.setGravity(Gravity.CENTER);
        radarBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        radarBar.setMax(100);
        Ui.tintProgress(radarBar, Ui.GREEN, Ui.BORDER);
        hero.addView(readinessValue, Ui.margins(-1, -2, this, 0, 13, 0, 5));
        hero.addView(radarBar, Ui.margins(-1, Ui.dp(this, 7), this, 6, 0, 6, 0));

        radarValue = Ui.text(this, "AURUM Q0 / 100", 13, Ui.TEXT, true);
        radarValue.setGravity(Gravity.CENTER);
        radarMeta = Ui.text(this, "Aguardando histórico validado", 11, Ui.MUTED, false);
        radarMeta.setGravity(Gravity.CENTER);
        hero.addView(radarValue, Ui.margins(-1, -2, this, 0, 9, 0, 0));
        hero.addView(radarMeta, Ui.margins(-1, -2, this, 0, 3, 0, 0));
        TextView disclaimer = Ui.text(this,
                "Q mede qualidade estrutural. Não representa probabilidade de vitória.",
                10, Ui.MUTED, false);
        disclaimer.setGravity(Gravity.CENTER);
        hero.addView(disclaimer, Ui.margins(-1, -2, this, 4, 8, 4, 0));
        LinearLayout signal = Ui.card(this);
        masterSignalCard = signal;
        signal.setBackground(Ui.verticalGradient(Ui.withAlpha(Ui.GREEN_DARK, 115), Ui.SURFACE,
                Ui.withAlpha(Ui.GREEN, 100), 20, this));
        LinearLayout signalHeader = new LinearLayout(this);
        signalHeader.setOrientation(LinearLayout.HORIZONTAL);
        signalHeader.setGravity(Gravity.CENTER_VERTICAL);
        signalTitle = Ui.text(this, "ANALISANDO", 12, Ui.AMBER, true);
        TextView live = Ui.pill(this, "LIVE", Ui.GREEN);
        signalHeader.addView(signalTitle, new LinearLayout.LayoutParams(0, -2, 1));
        signalHeader.addView(live);
        signal.addView(signalHeader);
        signalTarget = Ui.text(this, "SEM SINAL", 35, Ui.TEXT, true);
        signalTarget.setGravity(Gravity.CENTER);
        signal.addView(signalTarget, Ui.margins(-1, -2, this, 0, 12, 0, 6));
        coverageValue = Ui.text(this, "Cobertura: —", 13, Ui.GOLD, true);
        coverageValue.setGravity(Gravity.CENTER);
        signal.addView(coverageValue);
        signalMeta = Ui.text(this,
                "A Aurum permanece em silêncio até existir uma estrutura madura.",
                12, Ui.MUTED, false);
        signalMeta.setGravity(Gravity.CENTER);
        signal.addView(signalMeta, Ui.margins(-1, -2, this, 0, 7, 0, 10));

        LinearLayout signalMetrics = new LinearLayout(this);
        signalMetrics.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout rivalMetric = Ui.metric(this, "RIVAL", "—", Ui.CYAN);
        runnerValue = (TextView) rivalMetric.getChildAt(1);
        LinearLayout validMetric = Ui.metric(this, "VALIDADE", "—", Ui.GREEN);
        validityValue = (TextView) validMetric.getChildAt(1);
        signalMetrics.addView(rivalMetric, new LinearLayout.LayoutParams(0, -2, 1));
        signalMetrics.addView(validMetric, Ui.margins(0, -2, this, 8, 0, 0, 0));
        ((LinearLayout.LayoutParams) validMetric.getLayoutParams()).weight = 1;
        signal.addView(signalMetrics);
        root.addView(signal, Ui.margins(-1, -2, this, 0, 0, 0, 11));
        root.addView(buildPatternEchoCard(), Ui.margins(-1, -2, this, 0, 0, 0, 11));
        root.addView(hero, Ui.margins(-1, -2, this, 0, 0, 0, 11));

        LinearLayout controls = Ui.card(this);
        controls.addView(Ui.sectionLabel(this, "CONTROLE RÁPIDO"));
        startButton = Ui.button(this, "▶ INICIAR LEITURA OCR", Ui.GREEN, Color.BLACK);
        floatButton = Ui.button(this, "◉ ABRIR ROLETA / MODO FLUTUANTE", Ui.GOLD, Color.BLACK);
        Button calibrate = Ui.button(this, "▣ CALIBRAR ÁREA DO HISTÓRICO", Ui.CYAN, Color.BLACK);
        bubbleButton = Ui.button(this, "● OCULTAR MINI BUBBLE", Ui.SURFACE, Ui.TEXT);
        controls.addView(startButton, Ui.margins(-1, Ui.dp(this, 54), this, 0, 9, 0, 0));
        controls.addView(floatButton, Ui.margins(-1, Ui.dp(this, 50), this, 0, 7, 0, 0));
        controls.addView(calibrate, Ui.margins(-1, Ui.dp(this, 48), this, 0, 7, 0, 0));
        controls.addView(bubbleButton, Ui.margins(-1, Ui.dp(this, 46), this, 0, 7, 0, 0));
        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        Button clear = Ui.button(this, "↻ LIMPAR", Ui.SURFACE, Ui.TEXT);
        Button correct = Ui.button(this, "✎ CORRIGIR", Ui.SURFACE, Ui.TEXT);
        Button manual = Ui.button(this, "+ MANUAL", Ui.SURFACE, Ui.TEXT);
        quick.addView(clear, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        quick.addView(correct, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        quick.addView(manual, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        controls.addView(quick, Ui.margins(-1, Ui.dp(this, 46), this, 0, 7, 0, 0));
        root.addView(controls, Ui.margins(-1, -2, this, 0, 0, 0, 11));

        LinearLayout trendCard = Ui.card(this);
        LinearLayout trendHeader = new LinearLayout(this);
        trendHeader.setOrientation(LinearLayout.HORIZONTAL);
        trendHeader.setGravity(Gravity.CENTER_VERTICAL);
        trendHeader.addView(Ui.sectionLabel(this, "MAPA DE PRESSÃO DA LEITURA"),
                new LinearLayout.LayoutParams(0, -2, 1));
        trendHeader.addView(Ui.pill(this, "CPE • ATIVO", Ui.CYAN));
        trendCard.addView(trendHeader);
        pressureView = new AurumPressureView(this);
        trendCard.addView(pressureView, Ui.margins(-1, Ui.dp(this, 235), this, 0, 8, 0, 0));
        root.addView(trendCard, Ui.margins(-1, -2, this, 0, 0, 0, 11));

        LinearLayout familiesCard = Ui.card(this);
        familiesCard.addView(Ui.sectionLabel(this, "RAIO-X DO PRÓXIMO GIRO"));
        pressureSectorText = Ui.text(this, "Setores: aguardando leitura condicional.", 12, Ui.TEXT, true);
        pressureTerminalText = Ui.text(this, "Terminais: aguardando leitura condicional.", 11, Ui.GOLD, true);
        pressureNumbersText = Ui.text(this, "Top números: —", 12, Ui.CYAN, true);
        pressureDriversText = Ui.text(this, "Motores dominantes: —", 11, Ui.MUTED, false);
        pressureSampleText = Ui.text(this, "Qualidade amostral: — • score não é probabilidade.", 10, Ui.MUTED, false);
        familiesCard.addView(pressureSectorText, Ui.margins(-1, -2, this, 0, 8, 0, 0));
        familiesCard.addView(pressureTerminalText, Ui.margins(-1, -2, this, 0, 6, 0, 0));
        familiesCard.addView(pressureNumbersText, Ui.margins(-1, -2, this, 0, 6, 0, 0));
        familiesCard.addView(pressureDriversText, Ui.margins(-1, -2, this, 0, 6, 0, 0));
        familiesCard.addView(pressureSampleText, Ui.margins(-1, -2, this, 0, 7, 0, 0));
        radarFamilyDetail = Ui.text(this, "Evidências técnicas: aguardando leitura.", 10, Ui.MUTED, false);
        familiesCard.addView(radarFamilyDetail);
        root.addView(familiesCard, Ui.margins(-1, -2, this, 0, 0, 0, 11));

        LinearLayout history = Ui.card(this);
        history.addView(Ui.sectionLabel(this, "HISTÓRICO OCR CONFIRMADO"));
        HorizontalScrollView chipsScroll = new HorizontalScrollView(this);
        chipsScroll.setHorizontalScrollBarEnabled(false);
        historyChips = new LinearLayout(this);
        historyChips.setOrientation(LinearLayout.HORIZONTAL);
        chipsScroll.addView(historyChips);
        history.addView(chipsScroll, Ui.margins(-1, Ui.dp(this, 52), this, 0, 8, 0, 0));
        historyText = Ui.text(this, "Últimos: —", 11, Ui.MUTED, false);
        historyText.setVisibility(View.GONE);
        ocrStatus = Ui.text(this, "OCR parado", 11, Ui.MUTED, false);
        history.addView(historyText);
        history.addView(ocrStatus);
        root.addView(history, Ui.margins(-1, -2, this, 0, 0, 0, 11));

        LinearLayout intelligence = Ui.card(this);
        intelligence.addView(Ui.sectionLabel(this, "AUDITORIA / EVIDÊNCIAS TÉCNICAS"));
        radarFocus = Ui.text(this, "Foco: aguardando candidato.", 13, Ui.TEXT, true);
        radarSectors = Ui.text(this, "Setores: aguardando mapa.", 11, Ui.MUTED, false);
        radarHeat = Ui.text(this, "Calor relativo: aguardando mapa.", 11, Ui.MUTED, false);
        radarGate = Ui.text(this, "Régua: aguardando veredito.", 11, Ui.GOLD, true);
        radarEarlyTouch = Ui.text(this, "", 11, Ui.CYAN, true);
        radarReasons = Ui.text(this, "As principais confluências aparecerão aqui.", 11, Ui.MUTED, false);
        intelligence.addView(radarFocus, Ui.margins(-1, -2, this, 0, 9, 0, 0));
        intelligence.addView(radarSectors, Ui.margins(-1, -2, this, 0, 6, 0, 0));
        intelligence.addView(radarHeat, Ui.margins(-1, -2, this, 0, 5, 0, 0));
        intelligence.addView(radarGate, Ui.margins(-1, -2, this, 0, 7, 0, 0));
        intelligence.addView(radarEarlyTouch, Ui.margins(-1, -2, this, 0, 6, 0, 0));
        intelligence.addView(radarReasons, Ui.margins(-1, -2, this, 0, 8, 0, 0));
        root.addView(intelligence, Ui.margins(-1, -2, this, 0, 0, 0, 11));

        LinearLayout options = Ui.card(this);
        options.addView(Ui.sectionLabel(this, "PREFERÊNCIAS E FERRAMENTAS"));
        precisionSwitch = new Switch(this);
        precisionSwitch.setText("Precision máximo (mais seletivo)");
        precisionSwitch.setTextColor(Ui.TEXT);
        precisionSwitch.setChecked(AppStateStore.conservativeMode(this));
        voiceSwitch = new Switch(this);
        voiceSwitch.setText("Aviso por voz");
        voiceSwitch.setTextColor(Ui.TEXT);
        voiceSwitch.setChecked(AppStateStore.voiceEnabled(this));
        soundSwitch = new Switch(this);
        soundSwitch.setText("Som dos alertas FORTE / EXTREMO");
        soundSwitch.setTextColor(Ui.TEXT);
        soundSwitch.setChecked(AppStateStore.masterSoundEnabled(this));
        Button patternEcho = Ui.button(this, "ABRIR PATTERN ECHO", Ui.SURFACE, Ui.TEXT);
        options.addView(precisionSwitch, Ui.margins(-1, -2, this, 0, 6, 0, 0));
        options.addView(voiceSwitch);
        options.addView(soundSwitch);
        options.addView(patternEcho, Ui.margins(-1, Ui.dp(this, 46), this, 0, 7, 0, 0));
        root.addView(options, Ui.margins(-1, -2, this, 0, 0, 0, 11));

        LinearLayout session = Ui.card(this);
        session.addView(Ui.sectionLabel(this, "SESSÃO"));
        sessionText = Ui.text(this, "Nenhuma sessão ativa.", 12, Ui.TEXT, false);
        Button finish = Ui.button(this, "■ FINALIZAR SESSÃO", Ui.SURFACE, Ui.TEXT);
        Button archive = Ui.button(this, "▣ PASTA DE SESSÕES", Ui.SURFACE, Ui.TEXT);
        session.addView(sessionText, Ui.margins(-1, -2, this, 0, 8, 0, 5));
        session.addView(finish, Ui.margins(-1, Ui.dp(this, 46), this, 0, 5, 0, 0));
        session.addView(archive, Ui.margins(-1, Ui.dp(this, 46), this, 0, 6, 0, 0));
        root.addView(session);

        TextView footer = Ui.text(this,
                "CAPTURA VALIDADA  →  DELTA INCREMENTAL  →  Q  →  READINESS  →  LOCK OU SILÊNCIO",
                9, Ui.MUTED, true);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, Ui.margins(-1, -2, this, 4, 16, 4, 0));

        startButton.setOnClickListener(v -> startReading());
        floatButton.setOnClickListener(v -> enterFloatingMode());
        calibrate.setOnClickListener(v -> openCalibration());
        bubbleButton.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_TOGGLE_OVERLAY));
        clear.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_RESET));
        correct.setOnClickListener(v -> showCorrectionDialog());
        manual.setOnClickListener(v -> showNumberDialog("GIRO MANUAL", -1,
                n -> sendNumberAction(ScreenCaptureService.ACTION_MANUAL, n)));
        finish.setOnClickListener(v -> finishSession());
        archive.setOnClickListener(v -> showSessionArchive());
        precisionSwitch.setOnCheckedChangeListener((button, checked) -> {
            AppStateStore.setConservativeMode(this, checked);
            Toast.makeText(this, checked ? "Precision ativado: régua máxima."
                    : "Balanced operacional ativado.", Toast.LENGTH_SHORT).show();
        });
        voiceSwitch.setOnCheckedChangeListener((button, checked) ->
                AppStateStore.setVoiceEnabled(this, checked));
        soundSwitch.setOnCheckedChangeListener((button, checked) ->
                AppStateStore.setMasterSoundEnabled(this, checked));
        patternEcho.setOnClickListener(v ->
                startActivity(new Intent(this, PatternEchoActivity.class)));
        return scroll;
    }

    private LinearLayout buildPatternEchoCard() {
        LinearLayout card = Ui.card(this);
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(Ui.sectionLabel(this, "PATTERN ECHO"),
                new LinearLayout.LayoutParams(0, -2, 1));
        patternEchoStatus = Ui.pill(this, "AGUARDANDO", Ui.MUTED);
        header.addView(patternEchoStatus);
        card.addView(header);
        patternEchoDetail = Ui.text(this,
                "Força — • correspondência — • padrão — • idade —", 12, Ui.TEXT, true);
        freshnessValue = Ui.text(this,
                "Último giro — • captura — • processamento — • análise —", 10, Ui.MUTED, false);
        thermalValue = Ui.text(this, "THERMAL GUARD • MÁXIMO", 10, Ui.CYAN, true);
        card.addView(patternEchoDetail, Ui.margins(-1, -2, this, 0, 9, 0, 0));
        card.addView(freshnessValue, Ui.margins(-1, -2, this, 0, 7, 0, 0));
        card.addView(thermalValue, Ui.margins(-1, -2, this, 0, 5, 0, 0));
        card.setClickable(true);
        card.setOnClickListener(v -> startActivity(new Intent(this, PatternEchoActivity.class)));
        return card;
    }

    private View buildLegacyUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 24));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = Ui.text(this, "AURUM AI 37", 25, Ui.GREEN, true);
        liveBadge = Ui.text(this, "● OCR PARADO", 11, Ui.AMBER, true);
        liveBadge.setGravity(Gravity.RIGHT);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(liveBadge, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header);
        root.addView(Ui.text(this, "v0.9.1 MASTER • HARD EXPERT • STARTUP FIX • BASE VALIDADA v0.8.6", 12, Ui.CYAN, true),
                Ui.margins(-1, -2, this, 0, 2, 0, 12));

        // Radar é o centro da interface.
        LinearLayout radar = Ui.card(this);
        radar.addView(Ui.text(this, "RADAR DE CONFLUÊNCIA", 14, Ui.CYAN, true));
        radarValue = Ui.text(this, "AURUM Q0 / 100", 34, Ui.TEXT, true);
        radarMeta = Ui.text(this, "Aguardando histórico OCR", 14, Ui.MUTED, true);
        radarBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        radarBar.setMax(100);
        radarBar.setProgress(0);
        radarReasons = Ui.text(this, "As principais confluências aparecerão aqui.", 12, Ui.MUTED, false);
        radarFocus = Ui.text(this, "Foco: aguardando candidato.", 13, Ui.TEXT, true);
        radarSectors = Ui.text(this, "Setores: aguardando mapa.", 12, Ui.MUTED, false);
        radarHeat = Ui.text(this, "Calor relativo: aguardando mapa.", 12, Ui.MUTED, false);
        radarFamilyDetail = Ui.text(this, "Famílias: aguardando leitura.", 12, Ui.MUTED, false);
        radarGate = Ui.text(this, "Régua: aguardando veredito.", 12, Ui.AMBER, true);
        radarEarlyTouch = Ui.text(this, "", 12, Ui.CYAN, true);
        radar.addView(radarValue, Ui.margins(-1, -2, this, 0, 8, 0, 2));
        radar.addView(radarMeta);
        radar.addView(radarBar, Ui.margins(-1, Ui.dp(this, 12), this, 0, 9, 0, 7));
        radar.addView(Ui.text(this, "BASTIDOR DO RADAR", 12, Ui.CYAN, true),
                Ui.margins(-1, -2, this, 0, 8, 0, 3));
        radar.addView(radarFocus);
        radar.addView(radarSectors, Ui.margins(-1, -2, this, 0, 5, 0, 0));
        radar.addView(radarHeat, Ui.margins(-1, -2, this, 0, 5, 0, 0));
        radar.addView(radarFamilyDetail, Ui.margins(-1, -2, this, 0, 5, 0, 0));
        radar.addView(radarGate, Ui.margins(-1, -2, this, 0, 7, 0, 0));
        radar.addView(radarEarlyTouch, Ui.margins(-1, -2, this, 0, 7, 0, 0));
        radar.addView(Ui.text(this, "MOTIVOS DO CORE", 11, Ui.MUTED, true),
                Ui.margins(-1, -2, this, 0, 8, 0, 2));
        radar.addView(radarReasons);
        root.addView(radar, Ui.margins(-1, -2, this, 0, 0, 0, 10));

        // Sinal grande e limpo.
        LinearLayout signal = Ui.card(this);
        masterSignalCard = signal;
        signalTitle = Ui.text(this, "ANALISANDO", 13, Ui.AMBER, true);
        signalTarget = Ui.text(this, "SEM SINAL", 31, Ui.TEXT, true);
        signalMeta = Ui.text(this,
                "Quando a confluência atingir a régua operacional, a Aurum avisa por bolha, voz e notificação.",
                13, Ui.MUTED, false);
        signal.addView(signalTitle);
        signal.addView(signalTarget, Ui.margins(-1, -2, this, 0, 5, 0, 4));
        signal.addView(signalMeta);
        root.addView(signal, Ui.margins(-1, -2, this, 0, 0, 0, 10));
        root.addView(buildPatternEchoCard(), Ui.margins(-1, -2, this, 0, 0, 0, 10));

        // Controles principais.
        LinearLayout controls = Ui.card(this);
        controls.addView(Ui.text(this, "CONTROLE", 12, Ui.MUTED, true));
        startButton = Ui.button(this, "▶ INICIAR LEITURA OCR", Ui.GREEN, Color.BLACK);
        floatButton = Ui.button(this, "◉ MODO FLUTUANTE / IR PARA ROLETA", Ui.AMBER, Color.BLACK);
        Button calibrate = Ui.button(this, "▣ CALIBRAR ÁREA DO HISTÓRICO", Ui.CYAN, Color.BLACK);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button clear = Ui.button(this, "↻ LIMPAR", Ui.SURFACE, Ui.TEXT);
        Button correct = Ui.button(this, "✎ CORRIGIR", Ui.SURFACE, Ui.TEXT);
        Button manual = Ui.button(this, "+ MANUAL", Ui.SURFACE, Ui.TEXT);
        row.addView(clear, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        row.addView(correct, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        row.addView(manual, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        controls.addView(startButton, Ui.margins(-1, Ui.dp(this, 54), this, 0, 8, 0, 0));
        controls.addView(floatButton, Ui.margins(-1, Ui.dp(this, 50), this, 0, 6, 0, 0));
        controls.addView(calibrate, Ui.margins(-1, Ui.dp(this, 48), this, 0, 6, 0, 0));
        controls.addView(row, Ui.margins(-1, Ui.dp(this, 46), this, 0, 6, 0, 0));
        root.addView(controls, Ui.margins(-1, -2, this, 0, 0, 0, 10));

        // Só os ajustes realmente úteis ficam na tela principal.
        LinearLayout options = Ui.card(this);
        options.addView(Ui.text(this, "MODO", 12, Ui.MUTED, true));
        precisionSwitch = new Switch(this);
        precisionSwitch.setText("Precision máximo (mais seletivo)");
        precisionSwitch.setTextColor(Ui.TEXT);
        precisionSwitch.setChecked(AppStateStore.conservativeMode(this));
        voiceSwitch = new Switch(this);
        voiceSwitch.setText("Aviso por voz");
        voiceSwitch.setTextColor(Ui.TEXT);
        voiceSwitch.setChecked(AppStateStore.voiceEnabled(this));
        soundSwitch = new Switch(this);
        soundSwitch.setText("Som dos alertas FORTE / EXTREMO");
        soundSwitch.setTextColor(Ui.TEXT);
        soundSwitch.setChecked(AppStateStore.masterSoundEnabled(this));
        TextView lockStatus = Ui.text(this,
                "Aurum Lock rápido: " + (AppStateStore.aurumLockEnabled(this) ? "ATIVO" : "FALLBACK LEGACY")
                        + " • Q mede qualidade estrutural, não probabilidade.",
                11, Ui.CYAN, true);
        Button patternEcho = Ui.button(this, "ABRIR PATTERN ECHO", Ui.SURFACE, Ui.TEXT);
        options.addView(lockStatus);
        options.addView(precisionSwitch);
        options.addView(voiceSwitch);
        options.addView(soundSwitch);
        options.addView(patternEcho, Ui.margins(-1, Ui.dp(this, 44), this, 0, 6, 0, 0));
        root.addView(options, Ui.margins(-1, -2, this, 0, 0, 0, 10));

        LinearLayout history = Ui.card(this);
        history.addView(Ui.text(this, "HISTÓRICO OCR CONFIRMADO", 12, Ui.MUTED, true));
        historyText = Ui.text(this, "Últimos: —", 13, Ui.TEXT, false);
        ocrStatus = Ui.text(this, "OCR parado", 11, Ui.MUTED, false);
        history.addView(historyText, Ui.margins(-1, -2, this, 0, 7, 0, 4));
        history.addView(ocrStatus);
        root.addView(history, Ui.margins(-1, -2, this, 0, 0, 0, 10));

        LinearLayout session = Ui.card(this);
        session.addView(Ui.text(this, "SESSÃO", 12, Ui.MUTED, true));
        sessionText = Ui.text(this, "Nenhuma sessão ativa.", 12, Ui.TEXT, false);
        Button finish = Ui.button(this, "■ FINALIZAR SESSÃO", Ui.SURFACE, Ui.TEXT);
        Button archive = Ui.button(this, "▣ PASTA DE SESSÕES", Ui.SURFACE, Ui.TEXT);
        session.addView(sessionText, Ui.margins(-1, -2, this, 0, 6, 0, 5));
        session.addView(finish, Ui.margins(-1, Ui.dp(this, 46), this, 0, 4, 0, 0));
        session.addView(archive, Ui.margins(-1, Ui.dp(this, 46), this, 0, 5, 0, 0));
        root.addView(session);

        TextView footer = Ui.text(this,
                "OCR → Data Quality Gate → atualização incremental → Q → Readiness/Regime → Aurum Lock.",
                11, Ui.MUTED, false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, Ui.margins(-1, -2, this, 0, 14, 0, 0));

        startButton.setOnClickListener(v -> startReading());
        floatButton.setOnClickListener(v -> enterFloatingMode());
        calibrate.setOnClickListener(v -> openCalibration());
        clear.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_RESET));
        correct.setOnClickListener(v -> showCorrectionDialog());
        manual.setOnClickListener(v -> showNumberDialog("GIRO MANUAL", -1,
                n -> sendNumberAction(ScreenCaptureService.ACTION_MANUAL, n)));
        finish.setOnClickListener(v -> finishSession());
        archive.setOnClickListener(v -> showSessionArchive());
        precisionSwitch.setOnCheckedChangeListener((button, checked) -> {
            AppStateStore.setConservativeMode(this, checked);
            Toast.makeText(this, checked
                    ? "Precision ativado: régua máxima."
                    : "Balanced operacional ativado: confluência forte entra mais cedo.",
                    Toast.LENGTH_SHORT).show();
        });
        voiceSwitch.setOnCheckedChangeListener((button, checked) ->
                AppStateStore.setVoiceEnabled(this, checked));
        soundSwitch.setOnCheckedChangeListener((button, checked) ->
                AppStateStore.setMasterSoundEnabled(this, checked));
        patternEcho.setOnClickListener(v ->
                startActivity(new Intent(this, PatternEchoActivity.class)));
        return scroll;
    }

    private void startReading() {
        SessionLedger.ensureActive(this, AppStateStore.provider(this), AppStateStore.dealer(this));
        if (AppStateStore.captureActive(this)) {
            Intent service = new Intent(this, ScreenCaptureService.class)
                    .setAction(ScreenCaptureService.ACTION_START)
                    .putExtra(ScreenCaptureService.EXTRA_PIPELINE_MODE,
                            ScreenCaptureService.MODE_STANDALONE_OCR);
            startService(service);
            Toast.makeText(this, "Leitura OCR já está ativa.", Toast.LENGTH_SHORT).show();
            refreshState();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager)
                getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    private void enterFloatingMode() {
        if (!AppStateStore.captureActive(this)) {
            Toast.makeText(this, "Inicie a leitura OCR primeiro.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(permission);
            Toast.makeText(this,
                    "Autorize a bolha da Aurum. Depois toque em Modo flutuante novamente.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this,
                "Aurum continua lendo por OCR. Abra agora o aplicativo da roleta.",
                Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }

    private void openCalibration() {
        if (!AppStateStore.captureActive(this)) {
            Toast.makeText(this, "Ative a leitura OCR antes de calibrar.", Toast.LENGTH_LONG).show();
            startReading();
            return;
        }
        sendServiceAction(ScreenCaptureService.ACTION_CAPTURE_PREVIEW);
        Toast.makeText(this, "Atualizando prévia para calibração…", Toast.LENGTH_SHORT).show();
        handler.postDelayed(() -> {
            if (destroyed) return;
            if (!CaptureRepository.hasLatest()) {
                Toast.makeText(this, "Aguardando uma imagem da tela. Tente novamente.",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(this, CalibrationActivity.class));
        }, 550L);
    }

    private void finishSession() {
        SessionLedger.finishSession(this, null);
        sendServiceAction(ScreenCaptureService.ACTION_STOP);
        Toast.makeText(this, "Sessão finalizada e salva.", Toast.LENGTH_LONG).show();
        refreshState();
    }

    private void showSessionArchive() {
        String archive = SessionLedger.sessionArchive(this, 12);
        String recent = SessionLedger.recentSignals(this, 8);
        new AlertDialog.Builder(this)
                .setTitle("PASTA DE SESSÕES")
                .setMessage(archive + "\n\nÚLTIMOS SINAIS DA SESSÃO SELECIONADA\n" + recent)
                .setPositiveButton("Fechar", null)
                .show();
    }

    private void showCorrectionDialog() {
        List<Integer> history = AppStateStore.loadHistory(this);
        if (history.isEmpty()) {
            Toast.makeText(this, "Histórico vazio.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("CORRIGIR ÚLTIMO GIRO")
                .setItems(new String[]{"Substituir último número", "Remover último número"},
                        (dialog, which) -> {
                            if (which == 0) {
                                showNumberDialog("SUBSTITUIR ÚLTIMO", history.get(0),
                                        n -> sendNumberAction(ScreenCaptureService.ACTION_REPLACE_LATEST, n));
                            } else {
                                sendServiceAction(ScreenCaptureService.ACTION_REMOVE_LATEST);
                            }
                        })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private interface NumberConsumer { void accept(int value); }

    private void showNumberDialog(String title, int current, NumberConsumer consumer) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("0–36");
        if (current >= 0) input.setText(String.valueOf(current));
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(input)
                .setPositiveButton("Confirmar", (dialog, which) -> {
                    try {
                        int value = Integer.parseInt(input.getText().toString().trim());
                        if (value < 0 || value > 36) throw new NumberFormatException();
                        consumer.accept(value);
                    } catch (NumberFormatException error) {
                        Toast.makeText(this, "Digite um número de 0 a 36.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void sendNumberAction(String action, int number) {
        Intent service = new Intent(this, ScreenCaptureService.class)
                .setAction(action)
                .putExtra(ScreenCaptureService.EXTRA_MANUAL_NUMBER, number);
        startService(service);
    }

    private void sendServiceAction(String action) {
        Intent service = new Intent(this, ScreenCaptureService.class).setAction(action);
        startService(service);
    }

    private void refreshState() {
        if (radarBar == null) return;
        long now = System.currentTimeMillis();
        long stateToken = AppStateStore.uiStateToken(this, now);
        if (stateToken != lastRenderedStateToken) stateHasChanged.set(true);
        if (!stateHasChanged.compareAndSet(true, false)
                || stateToken == lastRenderedStateToken) return;
        lastRenderedStateToken = stateToken;
        lastUiStateChangeAt = SystemClock.elapsedRealtime();
        boolean capture = AppStateStore.captureActive(this);
        boolean calibrated = AppStateStore.isCalibrated(this);
        String captureHealth = AppStateStore.captureHealth(this);
        String captureHealthDetail = AppStateStore.captureHealthDetail(this);
        int recoveredSpins = AppStateStore.captureRecoveredSpins(this);
        List<Integer> history = AppStateStore.loadHistory(this);
        long ocrAt = AppStateStore.ocrSnapshotAt(this);
        long capturedAt = AppStateStore.masterCapturedAt(this);
        long analyzedAt = AppStateStore.masterAnalyzedAt(this);
        int score = AppStateStore.masterPressure(this);
        int families = AppStateStore.masterIndependent(this);
        int quality = AppStateStore.masterQuality(this);
        int confidence = AppStateStore.masterConfidence(this);
        int target = AppStateStore.masterTarget(this);
        int rival = AppStateStore.masterRival(this);
        int rivalPressure = AppStateStore.masterRivalPressure(this);
        int gap = AppStateStore.masterGap(this);
        int persistence = AppStateStore.masterPersistence(this);
        int acceleration = AppStateStore.masterAcceleration(this);
        int remaining = AppStateStore.masterRemaining(this);
        boolean dual = AppStateStore.masterDual(this);
        boolean migrating = AppStateStore.masterMigrating(this);
        String storedState = AppStateStore.masterState(this);
        boolean liveCapture = capture && calibrated && "LIVE".equalsIgnoreCase(captureHealth)
                && ocrAt > 0L && now - ocrAt <= 4500L;
        boolean staleNow = AppStateStore.masterStale(this)
                || (target >= 0 && !liveCapture);
        String decision = staleNow ? "BLOCKED" : storedState;
        String headline = masterHeadline(decision, dual);
        String playLabel = target < 0 ? ""
                : dual && rival >= 0 ? target + "  ↔  " + rival : String.valueOf(target);
        String detail = "Estado " + masterStateLabel(decision)
                + " • pressão " + score + "/100"
                + " • qualidade " + quality + "/100"
                + " • confiança do modelo " + confidence + "/100"
                + " • persistência " + persistence + " giros"
                + " • aceleração " + acceleration
                + (migrating ? " • pressão migrando dentro do mesmo setor" : "")
                + (dual ? " • dupla pressão" : "")
                + (staleNow ? " • NÃO CONSIDERAR ALERTA" : "")
                + " • score interno, não probabilidade";
        String reasons = AppStateStore.radarReasons(this);
        String backstageFocus = AppStateStore.radarFocus(this);
        String backstageSectors = AppStateStore.radarSectors(this);
        String backstageHeat = AppStateStore.radarHeat(this);
        String backstageFamilies = AppStateStore.radarFamilyDetail(this);
        String backstageGate = AppStateStore.radarGate(this);
        String earlyTouch = AppStateStore.radarEarlyTouch(this);
        String regime = AppStateStore.masterRegime(this);
        String stateLabel = masterStateLabel(decision);

        radarBar.setProgress(score);
        radarValue.setText("PRESSÃO " + score + " / 100");
        radarValue.setTextColor(staleNow ? Ui.RED
                : score >= 90 ? Ui.RED : score >= 76 ? Ui.GOLD : score >= 48 ? Ui.AMBER : Ui.TEXT);
        radarMeta.setText(stateLabel + " • " + families
                + "/5 leituras independentes • qualidade " + quality + "/100");
        radarReasons.setText(reasons == null || reasons.trim().isEmpty()
                ? "Aguardando confluências confirmadas entre famílias diferentes."
                : reasons);
        radarFocus.setText(emptyOr(backstageFocus, "Foco: aguardando candidato."));
        radarSectors.setText(emptyOr(backstageSectors, "Setores: aguardando mapa."));
        radarHeat.setText(emptyOr(backstageHeat, "Calor relativo: aguardando mapa."));
        radarFamilyDetail.setText(emptyOr(backstageFamilies, "Famílias: aguardando leitura."));
        radarGate.setText(emptyOr(backstageGate, "Régua: aguardando veredito."));
        radarEarlyTouch.setText(earlyTouch == null ? "" : earlyTouch);
        Ui.setVisible(radarEarlyTouch, earlyTouch != null && !earlyTouch.trim().isEmpty());

        signalTitle.setText(headline);
        signalTitle.setTextColor(signalColor(headline, decision));
        signalTitle.setTextSize(("STRONG".equals(decision) || "EXTREME".equals(decision))
                && !staleNow ? 20f : 12f);
        signalTarget.setText(playLabel == null || playLabel.trim().isEmpty()
                ? (capture ? "ANALISANDO" : "OCR PARADO") : playLabel);
        signalMeta.setText(compactDetail(detail));
        updateSignalCard(decision, staleNow);

        historyText.setText(historyLine(history));
        refreshHistoryChips(history);
        String ocrAge = ageLabel(ocrAt, now);
        String recovery = recoveredSpins > 0
                ? " • +" + recoveredSpins + " recuperado" + (recoveredSpins == 1 ? "" : "s")
                : "";
        ocrStatus.setText("OCR " + (capture ? "ATIVO" : "PARADO")
                + " • " + captureHealth
                + " • ROI " + (calibrated ? "CALIBRADA ✓" : "NÃO CALIBRADA")
                + " • " + history.size() + " números • último OCR " + ocrAge
                + recovery
                + (captureHealthDetail == null || captureHealthDetail.trim().isEmpty()
                ? "" : " • " + captureHealthDetail));
        boolean captureHealthy = liveCapture;
        ocrStatus.setTextColor(captureHealthy ? Ui.GREEN : Ui.AMBER);

        liveBadge.setText(capture
                ? ("RESYNC".equalsIgnoreCase(captureHealth) ? "● RESYNC AUTOMÁTICO"
                : "ERRO".equalsIgnoreCase(captureHealth) ? "● CAPTURA EM ERRO"
                : "● OCR LIVE")
                : "● OCR PARADO");
        liveBadge.setTextColor(captureHealthy ? Ui.GREEN : Ui.AMBER);

        boolean echoActive = AppStateStore.masterEchoActive(this);
        int echoStrength = AppStateStore.masterEchoStrength(this);
        setPill(patternEchoStatus, echoActive ? "ATIVO" : "SEM ECO",
                echoActive ? Ui.GREEN : Ui.MUTED);
        patternEchoDetail.setText("Força " + echoStrength + "/100 • correspondência "
                + AppStateStore.masterEchoCorrespondence(this)
                + "\nPadrão " + AppStateStore.masterEchoType(this)
                + " • idade " + AppStateStore.masterEchoAge(this) + " giro(s)"
                + " • " + AppStateStore.masterEchoMatches(this) + " correspondência(s)");
        String lastSpin = history.isEmpty() ? "—" : String.valueOf(history.get(0));
        freshnessValue.setText((staleNow ? "DADOS DESATUALIZADOS • NÃO CONSIDERAR ALERTA\n" : "")
                + "Último giro detectado " + lastSpin
                + " • captura " + clockLabel(capturedAt) + " (" + ageLabel(capturedAt, now) + ")"
                + "\nProcessamento " + AppStateStore.masterProcessingMs(this) + "ms"
                + " • idade da análise " + ageLabel(analyzedAt, now));
        freshnessValue.setTextColor(staleNow ? Ui.RED : Ui.MUTED);
        String thermalMode = AppStateStore.thermalMode(this);
        thermalValue.setText("THERMAL GUARD • " + thermalMode
                + " • status " + AppStateStore.thermalStatus(this));
        thermalValue.setTextColor("PROTECTED".equals(thermalMode) ? Ui.RED
                : "CONSERVATIVE".equals(thermalMode) ? Ui.AMBER : Ui.CYAN);

        if (aurumGauge != null) {
            aurumGauge.setValues(score, quality, stateLabel);
            readinessValue.setText("QUALIDADE DA CONFIGURAÇÃO " + quality + "/100");
            readinessValue.setTextColor(quality >= 82 ? Ui.GREEN
                    : quality >= 62 ? Ui.GOLD : quality < 45 ? Ui.RED : Ui.PURPLE);
            setPill(regimePill, regime, regimeColor(regime));
            setPill(statePill, stateLabel, stateColor(decision));
            String capturePillText = !capture ? "OCR PARADO"
                    : !calibrated ? "ROI PENDENTE"
                    : "RESYNC".equalsIgnoreCase(captureHealth) ? "RESYNC"
                    : "ERRO".equalsIgnoreCase(captureHealth) ? "CAPTURA ERRO"
                    : "CAPTURA LIVE";
            setPill(capturePill, capturePillText,
                    captureHealthy ? Ui.GREEN : Ui.AMBER);
            List<Integer> cpeNumbers = AppStateStore.masterRankNumbers(this);
            List<Integer> cpeScores = AppStateStore.masterRankScores(this);
            if (cpeNumbers.isEmpty()) cpeNumbers = AppStateStore.aurumCpeTopNumbers(this);
            if (cpeScores.isEmpty()) cpeScores = AppStateStore.aurumCpeTopScores(this);
            List<Integer> cpeSector1 = AppStateStore.masterSector(this);
            List<Integer> cpeSector2 = AppStateStore.masterSecondarySector(this);
            int cpeSector1Score = score;
            int cpeSector2Score = AppStateStore.masterSecondaryPressure(this);
            int cpeTerminal1 = AppStateStore.aurumCpePrimaryTerminal(this);
            int cpeTerminal1Score = AppStateStore.aurumCpePrimaryTerminalScore(this);
            int cpeTerminal2 = AppStateStore.aurumCpeSecondaryTerminal(this);
            int cpeTerminal2Score = AppStateStore.aurumCpeSecondaryTerminalScore(this);
            pressureView.setData(cpeNumbers, cpeScores, cpeSector1, cpeSector1Score,
                    cpeSector2, cpeSector2Score, cpeTerminal1, cpeTerminal1Score);
            pressureSectorText.setText("Setor líder: " + joinNumbers(cpeSector1) + " • " + cpeSector1Score
                    + "/100\n2º setor: " + joinNumbers(cpeSector2) + " • " + cpeSector2Score + "/100");
            pressureTerminalText.setText("Terminal líder: T" + (cpeTerminal1 < 0 ? "—" : cpeTerminal1)
                    + " • " + cpeTerminal1Score + "/100   |   2º: T"
                    + (cpeTerminal2 < 0 ? "—" : cpeTerminal2) + " • " + cpeTerminal2Score + "/100");
            pressureNumbersText.setText("Top números: " + rankedLabel(cpeNumbers, cpeScores));
            pressureDriversText.setText("Motores dominantes: "
                    + emptyOr(AppStateStore.masterEvidence(this), "—"));
            pressureSampleText.setText("Qualidade " + quality
                    + "/100 • confiança do modelo " + confidence
                    + "/100 • gap líder " + gap
                    + " • score interno ≠ probabilidade");
            coverageValue.setText(dual
                    ? "Setor A: " + joinNumbers(cpeSector1) + "   |   Setor B: " + joinNumbers(cpeSector2)
                    : "Setor dominante: " + joinNumbers(cpeSector1));
            runnerValue.setText(rival < 0 ? "—" : rival + "  " + rivalPressure + "/100");
            validityValue.setText(staleNow ? "BLOQUEADA"
                    : remaining > 0 ? remaining + " GIROS" : "SEM ALERTA");
            validityValue.setTextColor(staleNow ? Ui.RED
                    : remaining > 0 ? Ui.GREEN : Ui.MUTED);
            bubbleButton.setText(AppStateStore.overlayHidden(this)
                    ? "● MOSTRAR MINI BUBBLE" : "● OCULTAR MINI BUBBLE");
        }
        startButton.setText(capture ? "✓ LEITURA OCR ATIVA" : "▶ INICIAR LEITURA OCR");
        floatButton.setEnabled(capture);
        precisionSwitch.setChecked(AppStateStore.conservativeMode(this));
        voiceSwitch.setChecked(AppStateStore.voiceEnabled(this));
        if (soundSwitch != null) soundSwitch.setChecked(AppStateStore.masterSoundEnabled(this));
        sessionText.setText(cachedSessionSummary);
        refreshSessionSummaryAsync();
    }

    private void updateSignalCard(String state, boolean stale) {
        if (masterSignalCard == null) return;
        int accent = stale || "BLOCKED".equals(state) ? Ui.RED
                : "EXTREME".equals(state) ? Ui.RED
                : "STRONG".equals(state) ? Ui.GOLD
                : "MODERATE".equals(state) ? Ui.GREEN
                : "HEATING".equals(state) ? Ui.AMBER : Ui.CYAN;
        int top = "EXTREME".equals(state) && !stale
                ? Ui.withAlpha(Ui.RED, 145)
                : "STRONG".equals(state) && !stale
                ? Ui.withAlpha(Ui.GOLD, 95) : Ui.SURFACE_ALT;
        masterSignalCard.setBackground(Ui.verticalGradient(top, Ui.SURFACE,
                Ui.withAlpha(accent, 150), 20, this));
        boolean pulse = !stale && ("STRONG".equals(state) || "EXTREME".equals(state))
                && AppStateStore.thermalAnimationsAllowed(this);
        if (pulse) startSignalPulse("EXTREME".equals(state));
        else stopSignalPulse();
    }

    private void startSignalPulse(boolean extreme) {
        if (signalPulse != null && signalPulse.isRunning()) return;
        if (masterSignalCard == null) return;
        signalPulse = ObjectAnimator.ofFloat(masterSignalCard, View.ALPHA,
                1f, extreme ? 0.70f : 0.82f, 1f);
        signalPulse.setDuration(extreme ? 900L : 1250L);
        signalPulse.setRepeatCount(ValueAnimator.INFINITE);
        signalPulse.start();
    }

    private void stopSignalPulse() {
        if (signalPulse != null) {
            signalPulse.cancel();
            signalPulse = null;
        }
        if (masterSignalCard != null) masterSignalCard.setAlpha(1f);
    }

    private static String masterHeadline(String state, boolean dual) {
        if ("BLOCKED".equals(state)) return "DADOS DESATUALIZADOS • NÃO CONSIDERAR ALERTA";
        if (dual) return "DUPLA PRESSÃO";
        if ("EXTREME".equals(state)) return "⚠🔥 PRESSÃO EXTREMA";
        if ("STRONG".equals(state)) return "🔥 ALERTA FORTE";
        if ("MODERATE".equals(state)) return "PRESSÃO MODERADA";
        if ("HEATING".equals(state)) return "AQUECENDO";
        return "SILÊNCIO INTELIGENTE";
    }

    private static String masterStateLabel(String state) {
        if ("HEATING".equals(state)) return "AQUECENDO";
        if ("MODERATE".equals(state)) return "MODERADA";
        if ("STRONG".equals(state)) return "FORTE";
        if ("EXTREME".equals(state)) return "EXTREMA";
        if ("BLOCKED".equals(state)) return "BLOQUEADA";
        return "SILÊNCIO";
    }

    private static String ageLabel(long timestamp, long now) {
        if (timestamp <= 0L) return "—";
        long delta = Math.max(0L, now - timestamp);
        if (delta < 10_000L) return String.format(Locale.US, "%.1fs", delta / 1000.0);
        if (delta < 60_000L) return (delta / 1000L) + "s";
        return (delta / 60_000L) + "min";
    }

    private static String clockLabel(long timestamp) {
        if (timestamp <= 0L) return "—";
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(new Date(timestamp));
    }

    private void refreshSessionSummaryAsync() {
        if (sessionText == null || destroyed) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastSessionSummaryRequestAt < SESSION_SUMMARY_REFRESH_MS
                || !sessionSummaryInFlight.compareAndSet(false, true)) return;
        lastSessionSummaryRequestAt = now;
        Context appContext = getApplicationContext();
        try {
            sessionSummaryExecutor.execute(() -> {
                String summary;
                try {
                    summary = SessionLedger.sessionSummary(appContext);
                } catch (RuntimeException error) {
                    summary = "Sessão indisponível momentaneamente.";
                }
                String result = summary;
                handler.post(() -> {
                    sessionSummaryInFlight.set(false);
                    if (destroyed) return;
                    cachedSessionSummary = result;
                    if (sessionText != null) sessionText.setText(result);
                });
            });
        } catch (RuntimeException error) {
            sessionSummaryInFlight.set(false);
        }
    }

    private static String emptyOr(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value;
    }

    private static String compactDetail(String detail) {
        String value = detail.replace("\\n", " • ").replaceAll("\\s+", " ").trim();
        return value.length() > 260 ? value.substring(0, 260) + "…" : value;
    }

    private static String historyLine(List<Integer> history) {
        if (history == null || history.isEmpty()) return "Últimos: —";
        StringBuilder out = new StringBuilder("Últimos: ");
        int end = Math.min(15, history.size());
        for (int i = 0; i < end; i++) {
            if (i > 0) out.append(" • ");
            out.append(history.get(i));
        }
        return out.toString();
    }

    private void refreshHistoryChips(List<Integer> history) {
        if (historyChips == null) return;
        String fingerprint = history == null ? "" : history.toString();
        if (fingerprint.equals(lastHistoryVisual)) return;
        lastHistoryVisual = fingerprint;
        historyChips.removeAllViews();
        if (history == null || history.isEmpty()) {
            TextView empty = Ui.text(this, "Aguardando giros validados", 11, Ui.MUTED, false);
            historyChips.addView(empty, Ui.margins(-2, Ui.dp(this, 42), this, 2, 0, 6, 0));
            return;
        }
        int end = Math.min(18, history.size());
        for (int i = 0; i < end; i++) {
            int number = history.get(i);
            int color = number == 0 ? Ui.GREEN : rouletteRed(number) ? Ui.RED : Ui.SURFACE_ALT;
            TextView chip = Ui.text(this, String.valueOf(number), 13, Ui.TEXT, true);
            chip.setGravity(Gravity.CENTER);
            chip.setBackground(Ui.roundedStroke(color, i == 0 ? Ui.GOLD : Ui.BORDER,
                    i == 0 ? 2 : 1, 999, this));
            historyChips.addView(chip,
                    Ui.margins(Ui.dp(this, 42), Ui.dp(this, 42), this, 0, 0, 7, 0));
        }
    }

    private void setPill(TextView view, String label, int color) {
        if (view == null) return;
        view.setText(label == null || label.trim().isEmpty() ? "—" : label);
        view.setTextColor(color);
        view.setBackground(Ui.roundedStroke(Ui.withAlpha(color, 32),
                Ui.withAlpha(color, 128), 1, 999, this));
    }

    private static int regimeColor(String regime) {
        String value = regime == null ? "" : regime.toUpperCase(Locale.ROOT);
        if (value.contains("PEAK") || value.contains("CONVERGENCE")) return Ui.GREEN;
        if (value.contains("CONCENTRATION")) return Ui.GOLD;
        if (value.contains("DECAY") || value.contains("TRANSITION")
                || value.contains("SATURATION")) return Ui.RED;
        return Ui.CYAN;
    }

    private static int stateColor(String state) {
        String value = state == null ? "" : state.toUpperCase(Locale.ROOT);
        if (value.contains("EXTREME") || value.contains("BLOCKED")) return Ui.RED;
        if (value.contains("STRONG") || value.contains("MODERATE")) return Ui.GREEN;
        if (value.contains("HEATING")) return Ui.GOLD;
        if (value.contains("LOCKED") || value.contains("ARMED")) return Ui.GREEN;
        if (value.contains("PRE_LOCK") || value.contains("FORMING")) return Ui.GOLD;
        if (value.contains("DECAY") || value.contains("INVALID")
                || value.contains("SATURATED")) return Ui.RED;
        return Ui.CYAN;
    }

    private static String joinNumbers(List<Integer> values) {
        if (values == null || values.isEmpty()) return "—";
        StringBuilder out = new StringBuilder();
        for (Integer value : values) {
            if (out.length() > 0) out.append(" • ");
            out.append(value);
        }
        return out.toString();
    }

    private static String rankedLabel(List<Integer> numbers, List<Integer> scores) {
        if (numbers == null || numbers.isEmpty()) return "—";
        StringBuilder out = new StringBuilder();
        int n = Math.min(numbers.size(), scores == null ? 0 : scores.size());
        for (int i = 0; i < n; i++) {
            if (i > 0) out.append("   ");
            out.append(i + 1).append("º ").append(numbers.get(i)).append("[").append(scores.get(i)).append("]");
        }
        return out.length() == 0 ? "—" : out.toString();
    }

    private static boolean rouletteRed(int number) {
        switch (number) {
            case 1: case 3: case 5: case 7: case 9: case 12: case 14: case 16:
            case 18: case 19: case 21: case 23: case 25: case 27: case 30: case 32:
            case 34: case 36: return true;
            default: return false;
        }
    }

    private static int signalColor(String headline, String decision) {
        String value = ((headline == null ? "" : headline) + " "
                + (decision == null ? "" : decision)).toUpperCase(Locale.ROOT);
        if (value.contains("DESATUAL") || value.contains("BLOCKED")
                || value.contains("EXTREM")) return Ui.RED;
        if (value.contains("ALERTA FORTE") || value.contains("STRONG")) return Ui.GOLD;
        if (value.contains("MODERAD")) return Ui.GREEN;
        if (value.contains("AQUEC") || value.contains("HEATING")) return Ui.AMBER;
        if (value.contains("EXPIR") || value.contains("INVALID") || value.contains("CANCEL")) return Ui.RED;
        if (value.contains("AURUM LOCK") || value.contains("ENTRADA")
                || value.contains("STRYKE") || value.contains("HIT")) return Ui.GREEN;
        if (value.contains("PREPAR") || value.contains("CONFLU") || value.contains("OBSERV")) return Ui.AMBER;
        return Ui.CYAN;
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private void registerStateReceiver() {
        IntentFilter filter = new IntentFilter(MainActivity.ACTION_STATE_UPDATED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, filter);
        }
        receiverRegistered = true;
    }
}
