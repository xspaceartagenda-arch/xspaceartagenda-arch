package com.xspaceart.radar30;

import android.content.Context;
import android.os.Build;
import android.os.PowerManager;

import com.xspaceart.radar30.master.ThermalPolicy;

/** Ponte Android do Thermal Guard; captura crítica nunca é desligada. */
public final class ThermalPerformanceController {
    public interface Listener { void onPolicyChanged(ThermalPolicy policy, int status); }

    private final PowerManager powerManager;
    private final PowerManager.OnThermalStatusChangedListener thermalListener;
    private volatile int status;
    private volatile ThermalPolicy policy = ThermalPolicy.forStatus(0);
    private Listener listener;
    private boolean registered;

    public ThermalPerformanceController(Context context) {
        powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        thermalListener = newStatus -> applyStatus(newStatus);
    }

    public void start(Listener listener) {
        this.listener = listener;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null) {
            try {
                applyStatus(powerManager.getCurrentThermalStatus());
                powerManager.addThermalStatusListener(thermalListener);
                registered = true;
            } catch (RuntimeException ignored) {
                applyStatus(0);
            }
        } else {
            applyStatus(0);
        }
    }

    public void stop() {
        if (registered && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null) {
            try { powerManager.removeThermalStatusListener(thermalListener); }
            catch (RuntimeException ignored) { /* listener já removido pelo sistema */ }
        }
        registered = false;
        listener = null;
    }

    public ThermalPolicy policy() { return policy; }
    public int status() { return status; }

    private void applyStatus(int newStatus) {
        status = Math.max(0, newStatus);
        // O listener troca atomicamente a política consultada no hot path:
        // NONE=350 ms, MODERATE=450 ms e SEVERE+=700 ms.
        policy = ThermalPolicy.forStatus(status);
        Listener current = listener;
        if (current != null) current.onPolicyChanged(policy, status);
    }
}
