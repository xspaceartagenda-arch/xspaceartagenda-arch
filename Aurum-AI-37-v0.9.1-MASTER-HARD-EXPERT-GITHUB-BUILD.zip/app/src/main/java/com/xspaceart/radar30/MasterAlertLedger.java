package com.xspaceart.radar30;

import android.content.Context;
import android.content.SharedPreferences;

import com.xspaceart.radar30.master.MasterSignalSnapshot;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;
import java.util.List;

/** Log de calibração; não retroalimenta o modelo e mantém resultados 1..5 separados. */
public final class MasterAlertLedger {
    private static final String PREFS = "aurum_master_alert_ledger";
    private static final String EVENTS = "events_v1";
    private static final int LIMIT = 250;

    private MasterAlertLedger() {}

    public static synchronized void advanceAndRecord(Context context,
                                                     MasterSignalSnapshot snapshot,
                                                     List<Integer> newestFirstDelta) {
        if (context == null || snapshot == null) return;
        JSONArray events = load(context);
        List<Integer> delta = newestFirstDelta == null
                ? Collections.emptyList() : newestFirstDelta;
        advance(events, delta);
        if (snapshot.newEvent && (snapshot.state == MasterSignalSnapshot.State.MODERATE
                || snapshot.state == MasterSignalSnapshot.State.STRONG
                || snapshot.state == MasterSignalSnapshot.State.EXTREME)) {
            int lastSpin = delta.isEmpty() ? -1 : delta.get(0);
            events.put(toJson(snapshot, lastSpin));
        }
        while (events.length() > LIMIT) events = dropFirst(events);
        save(context, events);
    }

    public static synchronized int eventCount(Context context) {
        return load(context).length();
    }

    private static void advance(JSONArray events, List<Integer> newestFirstDelta) {
        for (int i = 0; i < events.length(); i++) {
            JSONObject event = events.optJSONObject(i);
            if (event == null || event.optBoolean("closed", false)) continue;
            int round = event.optInt("observed_rounds", 0);
            int validity = Math.max(1, Math.min(5, event.optInt("validity", 3)));
            JSONArray sector = event.optJSONArray("sector");
            for (int d = newestFirstDelta.size() - 1; d >= 0 && round < 5; d--) {
                int result = newestFirstDelta.get(d);
                round++;
                try { event.put("result_after_" + round, result); }
                catch (JSONException ignored) { /* JSONObject local */ }
                if (contains(sector, result) && event.optInt("hit_round", 0) == 0) {
                    try {
                        event.put("hit_round", round);
                        event.put("hit_within_validity", round <= validity);
                    } catch (JSONException ignored) { /* JSONObject local */ }
                }
            }
            try {
                event.put("observed_rounds", round);
                event.put("closed", round >= 5);
            }
            catch (JSONException ignored) { /* JSONObject local */ }
        }
    }

    private static JSONObject toJson(MasterSignalSnapshot s, int lastSpin) {
        JSONObject out = new JSONObject();
        try {
            out.put("timestamp", s.analyzedAtMs);
            out.put("captured_at", s.capturedAtMs);
            out.put("last_spin", lastSpin);
            out.put("candidate", s.target);
            out.put("sector", new JSONArray(s.sector));
            out.put("secondary_sector", new JSONArray(s.secondarySector));
            out.put("state", s.state.label);
            out.put("score", s.pressure);
            out.put("configuration_quality", s.configurationQuality);
            out.put("model_confidence", s.modelConfidence);
            out.put("pattern_echo", s.patternEcho.strength);
            out.put("pattern_type", s.patternEcho.patternType);
            boolean cpeActive = false;
            for (String label : s.evidenceLabels) {
                if (label != null && label.toUpperCase().contains("CPE")) cpeActive = true;
            }
            out.put("cpe_active", cpeActive);
            out.put("confluences", new JSONArray(s.evidenceLabels));
            out.put("rival", s.rival);
            out.put("rival_pressure", s.rivalPressure);
            out.put("regime", s.regime);
            out.put("validity", s.validitySpins);
            out.put("dual_pressure", s.dualPressure);
            out.put("fresh", !s.stale);
            out.put("observed_rounds", 0);
            out.put("hit_round", 0);
            out.put("closed", false);
            out.put("history_fingerprint", s.historyFingerprint);
        } catch (JSONException ignored) { /* JSONObject local */ }
        return out;
    }

    private static boolean contains(JSONArray values, int target) {
        if (values == null) return false;
        for (int i = 0; i < values.length(); i++) if (values.optInt(i, -1) == target) return true;
        return false;
    }

    private static JSONArray load(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try { return new JSONArray(prefs.getString(EVENTS, "[]")); }
        catch (JSONException ignored) { return new JSONArray(); }
    }

    private static void save(Context context, JSONArray events) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(EVENTS, events.toString()).apply();
    }

    private static JSONArray dropFirst(JSONArray source) {
        JSONArray out = new JSONArray();
        for (int i = 1; i < source.length(); i++) out.put(source.opt(i));
        return out;
    }
}
