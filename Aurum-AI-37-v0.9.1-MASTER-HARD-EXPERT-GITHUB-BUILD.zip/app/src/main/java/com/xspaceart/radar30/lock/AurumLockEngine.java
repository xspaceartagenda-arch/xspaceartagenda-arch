package com.xspaceart.radar30.lock;

import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.cpe.ConditionalPredictionEngine;
import com.xspaceart.radar30.cpe.ConditionalPredictionSnapshot;
import com.xspaceart.radar30.echo.PatternEchoEngine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Fast Fusion do Aurum Lock. O histórico pesado vive no índice incremental;
 * cada análise cria apenas vetores fixos de 37 posições.
 */
public final class AurumLockEngine {
    private static final int[] WHEEL_INDEX = new int[37];
    static {
        java.util.Arrays.fill(WHEEL_INDEX, -1);
        for (int i = 0; i < Wheel.EUROPEAN.size(); i++) {
            WHEEL_INDEX[Wheel.EUROPEAN.get(i)] = i;
        }
    }

    private final AurumLockConfig config;

    public AurumLockEngine(AurumLockConfig config) {
        this.config = config == null ? AurumLockConfig.defaults() : config;
    }

    public AurumLockSnapshot analyze(IncrementalAurumIndex index,
                                     TemporalContext previous,
                                     boolean dataQualityValid,
                                     String captureLabel,
                                     boolean publicationAllowed) {
        if (previous == null) previous = TemporalContext.empty();
        String capture = captureLabel == null || captureLabel.trim().isEmpty()
                ? "CAPTURA CONFIRMADA" : captureLabel.trim();

        if (!dataQualityValid) {
            return new AurumLockSnapshot.Builder()
                    .dataQualityValid(false)
                    .captureLabel(capture)
                    .regime(AurumLockSnapshot.Regime.TRANSITION)
                    .readinessState(AurumLockSnapshot.ReadinessState.INVALIDATED)
                    .fastAuditPassed(false)
                    .reasons(Collections.singletonList(
                            "LOCK BLOCKED — DATA QUALITY: " + capture))
                    .historyFingerprint(index == null ? 0L : index.deterministicFingerprint())
                    .build();
        }

        if (index == null || index.size() < config.minimumHistory) {
            int size = index == null ? 0 : index.size();
            return new AurumLockSnapshot.Builder()
                    .dataQualityValid(true)
                    .captureLabel(capture)
                    .regime(AurumLockSnapshot.Regime.DISPERSION)
                    .readinessState(AurumLockSnapshot.ReadinessState.IDLE)
                    .reasons(Collections.singletonList(
                            "Histórico em formação: " + size + "/" + config.minimumHistory + " giros."))
                    .historyFingerprint(index == null ? 0L : index.deterministicFingerprint())
                    .build();
        }

        long now = System.currentTimeMillis();
        double[] physical5 = physicalWindow(index, 5);
        double[] physical10 = physicalWindow(index, 10);
        double[] physical30 = physicalWindow(index, 30);
        double[] physicalRaw = combine(physical5, 0.50, physical10, 0.30, physical30, 0.20);
        AurumEvidence.FamilyVector physical = new AurumEvidence.Builder(AurumEvidence.Family.PHYSICAL)
                .add("wheel-concentration-5-10-30", "physical:recent-wheel",
                        physicalRaw, physicalConfidence(physicalRaw),
                        AurumEvidence.recentMask(30), "")
                .build(now);

        NumericVector numericData = numericVector(index);
        AurumEvidence.FamilyVector numeric = new AurumEvidence.Builder(AurumEvidence.Family.NUMERIC)
                .add("terminal-arithmetic-fusion", "numeric:recent-relations",
                        numericData.mass, numericData.confidence,
                        AurumEvidence.recentMask(30), "")
                .build(now);

        SequentialVector sequentialData = sequentialVector(index);
        AurumEvidence.FamilyVector sequential = new AurumEvidence.Builder(AurumEvidence.Family.SEQUENTIAL)
                .add("transition-route-delta", "sequential:transition-route",
                        sequentialData.mass, sequentialData.confidence,
                        AurumEvidence.recentMask(64), "")
                .build(now);

        List<AurumEvidence.FamilyVector> families = new ArrayList<>();
        families.add(physical);
        families.add(numeric);
        families.add(sequential);

        Fusion preliminary = fuse(families, physical5, physical10, physical30);
        int preliminaryQ = structuralQ(preliminary);
        if (preliminaryQ >= config.echoMinimumBaseQ) {
            AurumEvidence.FamilyVector echo = patternEcho(index, now);
            if (!echo.isEmpty()) families.add(echo);
        }

        ConditionalPredictionSnapshot cpe = ConditionalPredictionEngine.analyze(index);
        Fusion fused = fuse(families, physical5, physical10, physical30, cpe);
        int q = structuralQ(fused);
        int stableUpdates = fused.target == previous.previousTarget
                ? previous.stableTargetUpdates + 1 : 1;
        int qTrend = previous.previousTarget < 0 ? 0 : q - previous.previousQ;
        int peak = fused.target == previous.previousTarget
                ? Math.max(previous.recentPeakQ, q) : q;

        AurumLockSnapshot.Regime regime = StructuralRegimeDetector.detect(
                q, previous.previousQ, peak, fused.target, previous.previousTarget,
                stableUpdates, fused.independentFamilies, fused.margin, qTrend,
                Math.max(42, config.preLockQ - 14),
                Math.max(48, config.confirmedQ - 4), config.instantQ);
        int readiness = readiness(q, fused, stableUpdates, qTrend, regime);
        boolean audit = fastAudit(index, families, fused);

        List<String> reasons = new ArrayList<>();
        reasons.add("Q" + q + " = qualidade estrutural; não é probabilidade de vitória.");
        reasons.add(fused.independentFamilies + " famílias independentes: "
                + joinStrings(fused.familyLabels, " + ") + ".");
        reasons.add("Consistência 5/10/30: " + fused.windowConsistency
                + "/100 • margem sobre rival: " + fused.margin + "/100.");
        reasons.add("Provenance compacto: " + fused.provenance.size()
                + " grupos sem votos duplicados.");
        reasons.add(audit ? "Fast Audit obrigatório aprovado."
                : "Fast Audit bloqueou a publicação.");
        if (cpe.available()) {
            reasons.add("CPE ATIVO: líder " + cpe.topNumbers.get(0) + " pressão "
                    + cpe.topScores.get(0) + "/100 • gap " + cpe.leaderGap
                    + " • amostra " + cpe.sampleQuality + "/100 • peso adaptativo limitado.");
        }

        AurumLockSnapshot provisional = new AurumLockSnapshot.Builder()
                .q(q)
                .readiness(readiness)
                .regime(regime)
                .target(fused.target)
                .runnerUp(fused.runnerUp)
                .margin(fused.margin)
                .windowConsistency(fused.windowConsistency)
                .contradiction(fused.contradiction)
                .independentFamilies(fused.independentFamilies)
                .stableTargetUpdates(stableUpdates)
                .qTrend(qTrend)
                .dataQualityValid(true)
                .fastAuditPassed(audit)
                .captureLabel(capture)
                .signalType(fused.signalType)
                .nucleus(fused.nucleus)
                .coverage(fused.coverage)
                .familyStrengths(fused.familyStrengths)
                .familyLabels(fused.familyLabels)
                .reasons(reasons)
                .provenance(fused.provenance)
                .historyFingerprint(index.deterministicFingerprint())
                .conditionalPrediction(cpe)
                .build();
        return AurumLockPolicy.apply(provisional, config, publicationAllowed);
    }

    private Fusion fuse(List<AurumEvidence.FamilyVector> families,
                        double[] physical5, double[] physical10, double[] physical30) {
        return fuse(families, physical5, physical10, physical30, ConditionalPredictionSnapshot.empty());
    }

    private Fusion fuse(List<AurumEvidence.FamilyVector> families,
                        double[] physical5, double[] physical10, double[] physical30,
                        ConditionalPredictionSnapshot cpe) {
        double[] combined = new double[37];
        EnumMap<AurumEvidence.Family, AurumEvidence.FamilyVector> byFamily =
                new EnumMap<>(AurumEvidence.Family.class);
        for (AurumEvidence.FamilyVector family : families) {
            if (family == null || family.isEmpty()) continue;
            byFamily.put(family.family, family);
            double weight = familyWeight(family.family) * Math.max(0.18, family.confidence);
            for (int number = 0; number < 37; number++) {
                combined[number] += weight * family.relativeAt(number);
            }
        }

        // v0.8.5: CPE deixa de ser apenas SHADOW. Ele entra como camada auxiliar
        // com peso adaptativo limitado: histórico/amostra fracos não podem dominar
        // as famílias estruturais já validadas.
        double cpeWeight = cpeInfluenceWeight(cpe);
        if (cpeWeight > 0.0) {
            for (int number = 0; number < 37; number++) {
                combined[number] += cpeWeight * cpe.pressureAt(number);
            }
        }

        int target = argMax(combined, null);
        if (target < 0) return Fusion.empty();
        List<Integer> coverage = Wheel.coverage(target, 2);
        int runner = argMax(combined, new HashSet<>(coverage));
        if (runner < 0) runner = secondBest(combined, target);
        double top = combined[target];
        double rival = runner < 0 ? 0.0 : combined[runner];
        int margin = score(top <= 0.0 ? 0.0 : 100.0 * (top - rival) / top);

        double activeWeight = 0.0;
        double alignmentWeighted = 0.0;
        double contradictionWeight = 0.0;
        int independent = 0;
        List<String> labels = new ArrayList<>();
        List<Integer> familyStrengths = new ArrayList<>(
                java.util.Arrays.asList(0, 0, 0, 0));
        List<AurumEvidence.Provenance> provenance = new ArrayList<>();
        boolean physicalSupport = false;
        boolean numericSupport = false;
        for (AurumEvidence.FamilyVector family : families) {
            if (family == null || family.isEmpty()) continue;
            double weight = familyWeight(family.family) * Math.max(0.18, family.confidence);
            double support = family.strongestRelative(coverage);
            familyStrengths.set(family.family.ordinal(),
                    score(100.0 * (0.65 * support + 0.35 * family.confidence)));
            activeWeight += weight;
            alignmentWeighted += weight * support;
            if (support < 0.38) contradictionWeight += weight * (1.0 - support);
            if (support >= 0.72 && family.confidence >= 0.25) {
                independent++;
                labels.add(family.family.label);
                provenance.addAll(family.provenance);
                if (family.family == AurumEvidence.Family.PHYSICAL) physicalSupport = true;
                if (family.family == AurumEvidence.Family.NUMERIC) numericSupport = true;
            }
        }
        if (cpeWeight > 0.0) {
            double cpeSupport = 0.0;
            for (Integer number : coverage) cpeSupport = Math.max(cpeSupport, cpe.pressureAt(number));
            activeWeight += cpeWeight;
            alignmentWeighted += cpeWeight * cpeSupport;
            // Divergência CPE forte entra como contradição, mas não conta como uma
            // nova família independente para não inflar artificialmente a confluência.
            if (cpeSupport < 0.35) contradictionWeight += cpeWeight * (1.0 - cpeSupport);
        }
        int alignment = score(activeWeight <= 0.0 ? 0.0
                : 100.0 * alignmentWeighted / activeWeight);
        int contradiction = score(activeWeight <= 0.0 ? 100.0
                : 100.0 * contradictionWeight / activeWeight);
        int windowConsistency = windowConsistency(coverage, physical5, physical10, physical30);

        double[] normalized = combined.clone();
        AurumEvidence.normalizeInPlace(normalized);
        double sectorMass = 0.0;
        for (Integer number : coverage) sectorMass += normalized[number];
        double baseline = coverage.size() / 37.0;
        int concentration = score(100.0 * Math.max(0.0, sectorMass - baseline)
                / Math.max(1e-9, 1.0 - baseline));

        AurumLockSnapshot.SignalType signalType = physicalSupport && numericSupport
                ? AurumLockSnapshot.SignalType.HYBRID_CONFLUENCE
                : AurumLockSnapshot.SignalType.SECTOR_STRONG;
        List<Integer> nucleus = new ArrayList<>();
        if (signalType == AurumLockSnapshot.SignalType.HYBRID_CONFLUENCE) {
            int terminal = target % 10;
            for (Integer number : coverage) if (number % 10 == terminal) nucleus.add(number);
        }
        if (nucleus.isEmpty()) nucleus.add(target);

        return new Fusion(target, runner, margin, alignment, concentration,
                windowConsistency, contradiction, independent, coverage, nucleus,
                familyStrengths, labels, provenance, signalType);
    }

    private AurumEvidence.FamilyVector patternEcho(IncrementalAurumIndex index, long now) {
        List<Integer> chronological = index.chronological(config.echoLookback);
        PatternEchoEngine.Result result = PatternEchoEngine.analyze(chronological,
                new PatternEchoEngine.Settings(3, PatternEchoEngine.Mode.AUTO, 18, 2, 82.0));
        if (!result.hasEcho()) return AurumEvidence.empty(AurumEvidence.Family.PATTERN_ECHO);

        double[] raw = new double[37];
        double best = 0.0;
        long sourceMask = AurumEvidence.recentMask(3);
        for (PatternEchoEngine.Match match : result.matches) {
            double recency = 1.0 / (1.0 + Math.min(120, match.distanceFromCurrent) / 40.0);
            double support = (match.compatibility / 100.0) * recency;
            best = Math.max(best, match.compatibility / 100.0);
            List<Integer> region = match.projectedRegion == null || match.projectedRegion.isEmpty()
                    ? Collections.singletonList(match.projectedPrimary) : match.projectedRegion;
            int unique = Math.max(1, new HashSet<>(region).size());
            for (Integer number : new HashSet<>(region)) {
                if (number != null && Wheel.valid(number)) raw[number] += support / unique;
            }
            int bit = 3 + Math.max(0, match.distanceFromCurrent);
            if (bit < Long.SIZE) sourceMask |= 1L << bit;
        }
        double confidence = Math.min(0.90,
                (0.24 + 0.11 * Math.min(5, result.matches.size())) * best);
        String patternId = "echo3:" + result.currentSequence;
        return new AurumEvidence.Builder(AurumEvidence.Family.PATTERN_ECHO)
                .add("pattern-echo-auto", "pattern-echo:single-support",
                        raw, confidence, sourceMask, patternId)
                .build(now);
    }

    private NumericVector numericVector(IncrementalAurumIndex index) {
        double[] terminal = new double[37];
        double[] terminalStrength = new double[10];
        int[] windows = {5, 10, 30};
        double[] weights = {0.50, 0.30, 0.20};
        for (int w = 0; w < windows.length; w++) {
            int size = Math.max(1, index.windowSize(windows[w]));
            for (int number = 0; number < 37; number++) {
                terminalStrength[number % 10] += weights[w]
                        * index.windowCount(windows[w], number) / size;
            }
        }
        for (int t = 0; t < 10; t++) {
            int members = t <= 6 ? 4 : 3;
            for (int number = t; number <= 36; number += 10) {
                terminal[number] += terminalStrength[t] / members;
            }
        }
        AurumEvidence.normalizeInPlace(terminal);

        double[] arithmetic = new double[37];
        int latest = index.recent(0);
        arithmetic[36 - latest] += 0.30;
        if (index.size() >= 2) {
            int previous = index.recent(1);
            arithmetic[(latest + previous) % 37] += 0.38;
            arithmetic[Math.abs(latest - previous)] += 0.32;
        }
        AurumEvidence.normalizeInPlace(arithmetic);
        double[] mass = combine(terminal, 0.78, arithmetic, 0.22);

        double maxTerminal = 0.0;
        for (double value : terminalStrength) maxTerminal = Math.max(maxTerminal, value);
        double dominance = Math.max(0.0, (maxTerminal - 0.10) / 0.35);
        return new NumericVector(mass, clamp(0.32 + 0.42 * dominance, 0.25, 0.82));
    }

    private SequentialVector sequentialVector(IncrementalAurumIndex index) {
        double[] transitions = new double[37];
        double[] route = new double[37];
        int latest = index.recent(0);
        int samples = index.transitionSamples(latest);
        if (samples > 0) {
            for (int number = 0; number < 37; number++) {
                transitions[number] = index.transitionCount(latest, number) / (double) samples;
            }
        }

        double consistency = 0.0;
        if (index.size() >= 2) {
            int step = signedWheelStep(index.recent(1), latest);
            int projected = shiftOnWheel(latest, step);
            route[projected] += 0.70;
            route[shiftOnWheel(projected, -1)] += 0.15;
            route[shiftOnWheel(projected, 1)] += 0.15;
            if (index.size() >= 3) {
                int priorStep = signedWheelStep(index.recent(2), index.recent(1));
                int delta = Math.abs(step - priorStep);
                consistency = Math.max(0.0, 1.0 - Math.min(18, delta) / 18.0);
            }
        } else {
            route[latest] = 1.0;
        }
        AurumEvidence.normalizeInPlace(route);
        double[] mass = samples > 0
                ? combine(transitions, 0.74, route, 0.26) : route;
        double confidence = clamp(0.20 + 0.48 * Math.min(1.0, samples / 8.0)
                + 0.20 * consistency, 0.20, 0.90);
        return new SequentialVector(mass, confidence);
    }

    private double[] physicalWindow(IncrementalAurumIndex index, int window) {
        double[] raw = new double[37];
        int count = Math.min(window, index.size());
        for (int offset = 0; offset < count; offset++) {
            double recency = 1.0 / (1.0 + 0.12 * offset);
            addWheelKernel(raw, index.recent(offset), recency);
        }
        AurumEvidence.normalizeInPlace(raw);
        return raw;
    }

    private static void addWheelKernel(double[] out, int center, double weight) {
        int centerIndex = WHEEL_INDEX[center];
        int[] distance = {0, -1, 1, -2, 2};
        double[] kernel = {1.0, 0.72, 0.72, 0.42, 0.42};
        for (int i = 0; i < distance.length; i++) {
            int p = (centerIndex + distance[i]) % 37;
            if (p < 0) p += 37;
            out[Wheel.EUROPEAN.get(p)] += weight * kernel[i];
        }
    }

    private static double physicalConfidence(double[] mass) {
        int top = argMax(mass, null);
        if (top < 0) return 0.0;
        double sector = 0.0;
        for (Integer number : Wheel.coverage(top, 2)) sector += mass[number];
        double baseline = 5.0 / 37.0;
        double concentrated = Math.max(0.0, (sector - baseline) / (1.0 - baseline));
        return clamp(0.32 + 1.25 * concentrated, 0.25, 0.92);
    }

    private int structuralQ(Fusion f) {
        if (f.target < 0) return 0;
        double diversity = 100.0 * f.independentFamilies / 4.0;
        double value = 0.40 * f.alignment
                + 0.22 * diversity
                + 0.15 * f.windowConsistency
                + 0.13 * f.margin
                + 0.10 * f.concentration
                - 0.18 * f.contradiction;
        return score(value);
    }

    private static int readiness(int q, Fusion f, int stableUpdates, int qTrend,
                                 AurumLockSnapshot.Regime regime) {
        double value = 0.68 * q
                + 3.0 * f.independentFamilies
                + 3.0 * Math.min(4, stableUpdates)
                + 0.08 * f.windowConsistency
                + 0.25 * Math.min(24, f.margin)
                + Math.max(-5.0, Math.min(6.0, qTrend));
        if (regime == AurumLockSnapshot.Regime.TRANSITION) value -= 22.0;
        else if (regime == AurumLockSnapshot.Regime.DECAY) value -= 30.0;
        else if (regime == AurumLockSnapshot.Regime.SATURATION) value -= 20.0;
        else if (regime == AurumLockSnapshot.Regime.DISPERSION) value -= 6.0;
        return score(value);
    }

    private static boolean fastAudit(IncrementalAurumIndex index,
                                     List<AurumEvidence.FamilyVector> families,
                                     Fusion fusion) {
        if (index == null || !index.invariantHolds() || fusion.target < 0) return false;
        if (fusion.independentFamilies < 1 || fusion.contradiction > 68) return false;
        Set<String> dependencyKeys = new HashSet<>();
        for (AurumEvidence.FamilyVector family : families) {
            if (family == null || family.isEmpty()) continue;
            double total = family.totalMass();
            if (!Double.isFinite(total) || Math.abs(total - 1.0) > 1e-7) return false;
            for (AurumEvidence.Provenance provenance : family.provenance) {
                String key = provenance.family.name() + ":" + provenance.dependencyGroup;
                if (!dependencyKeys.add(key)) return false;
            }
        }
        return true;
    }

    private int windowConsistency(List<Integer> coverage, double[]... windows) {
        double total = 0.0;
        for (double[] window : windows) {
            double peak = 0.0;
            double coveredPeak = 0.0;
            double sectorMass = 0.0;
            for (double value : window) peak = Math.max(peak, value);
            for (Integer number : coverage) {
                coveredPeak = Math.max(coveredPeak, window[number]);
                sectorMass += window[number];
            }
            double ratio = peak <= 0.0 ? 0.0 : coveredPeak / peak;
            double baseline = coverage.size() / 37.0;
            double concentration = Math.max(0.0, sectorMass - baseline)
                    / Math.max(1e-9, 1.0 - baseline);
            total += 50.0 * ratio + 50.0 * Math.min(1.0, concentration);
        }
        return score(total / Math.max(1, windows.length));
    }

    private static double cpeInfluenceWeight(ConditionalPredictionSnapshot cpe) {
        if (cpe == null || !cpe.available() || cpe.sampleQuality < 40) return 0.0;
        double sample = Math.max(0.0, Math.min(1.0, (cpe.sampleQuality - 35.0) / 65.0));
        double separation = Math.max(0.0, Math.min(1.0, cpe.leaderGap / 12.0));
        double sector = Math.max(0.0, Math.min(1.0, cpe.primarySectorScore / 100.0));
        double trust = 0.55 * sample + 0.25 * separation + 0.20 * sector;
        return 0.08 + 0.14 * trust; // 0.08..0.22, sempre auxiliar.
    }

    private double familyWeight(AurumEvidence.Family family) {
        switch (family) {
            case PHYSICAL: return config.physicalWeight;
            case NUMERIC: return config.numericWeight;
            case SEQUENTIAL: return config.sequentialWeight;
            case PATTERN_ECHO: return config.patternEchoWeight;
            default: return 0.0;
        }
    }

    private static double[] combine(double[] a, double wa, double[] b, double wb) {
        double[] out = new double[37];
        for (int i = 0; i < 37; i++) out[i] = a[i] * wa + b[i] * wb;
        AurumEvidence.normalizeInPlace(out);
        return out;
    }

    private static double[] combine(double[] a, double wa, double[] b, double wb,
                                    double[] c, double wc) {
        double[] out = new double[37];
        for (int i = 0; i < 37; i++) out[i] = a[i] * wa + b[i] * wb + c[i] * wc;
        AurumEvidence.normalizeInPlace(out);
        return out;
    }

    private static int argMax(double[] values, Set<Integer> excluded) {
        int best = -1;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (int number = 0; number < values.length; number++) {
            if (excluded != null && excluded.contains(number)) continue;
            if (values[number] > bestScore + 1e-12) {
                best = number;
                bestScore = values[number];
            }
        }
        return bestScore > 0.0 ? best : -1;
    }

    private static int secondBest(double[] values, int target) {
        Set<Integer> excluded = new HashSet<>();
        excluded.add(target);
        return argMax(values, excluded);
    }

    private static int signedWheelStep(int from, int to) {
        int step = WHEEL_INDEX[to] - WHEEL_INDEX[from];
        if (step > 18) step -= 37;
        if (step < -18) step += 37;
        return step;
    }

    private static int shiftOnWheel(int number, int offset) {
        int value = (WHEEL_INDEX[number] + offset) % 37;
        if (value < 0) value += 37;
        return Wheel.EUROPEAN.get(value);
    }

    private static int score(double value) {
        if (!Double.isFinite(value)) return 0;
        return Math.max(0, Math.min(100, (int) Math.round(value)));
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String joinStrings(List<String> values, String separator) {
        if (values == null || values.isEmpty()) return "—";
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (out.length() > 0) out.append(separator);
            out.append(value);
        }
        return out.toString();
    }

    public static final class TemporalContext {
        public final int previousQ;
        public final int recentPeakQ;
        public final int previousTarget;
        public final int stableTargetUpdates;

        public TemporalContext(int previousQ, int recentPeakQ,
                               int previousTarget, int stableTargetUpdates) {
            this.previousQ = Math.max(0, Math.min(100, previousQ));
            this.recentPeakQ = Math.max(0, Math.min(100, recentPeakQ));
            this.previousTarget = previousTarget;
            this.stableTargetUpdates = Math.max(0, stableTargetUpdates);
        }

        public static TemporalContext empty() { return new TemporalContext(0, 0, -1, 0); }

        public TemporalContext advance(AurumLockSnapshot snapshot) {
            if (snapshot == null || snapshot.target < 0 || !snapshot.dataQualityValid) return this;
            int peak = snapshot.target == previousTarget
                    ? Math.max(recentPeakQ, snapshot.q) : snapshot.q;
            return new TemporalContext(snapshot.q, peak, snapshot.target,
                    snapshot.stableTargetUpdates);
        }
    }

    private static final class NumericVector {
        final double[] mass; final double confidence;
        NumericVector(double[] mass, double confidence) { this.mass = mass; this.confidence = confidence; }
    }

    private static final class SequentialVector {
        final double[] mass; final double confidence;
        SequentialVector(double[] mass, double confidence) { this.mass = mass; this.confidence = confidence; }
    }

    private static final class Fusion {
        final int target, runnerUp, margin, alignment, concentration;
        final int windowConsistency, contradiction, independentFamilies;
        final List<Integer> coverage, nucleus;
        final List<Integer> familyStrengths;
        final List<String> familyLabels;
        final List<AurumEvidence.Provenance> provenance;
        final AurumLockSnapshot.SignalType signalType;

        Fusion(int target, int runnerUp, int margin, int alignment, int concentration,
               int windowConsistency, int contradiction, int independentFamilies,
               List<Integer> coverage, List<Integer> nucleus, List<Integer> familyStrengths,
               List<String> familyLabels,
               List<AurumEvidence.Provenance> provenance,
               AurumLockSnapshot.SignalType signalType) {
            this.target = target; this.runnerUp = runnerUp; this.margin = margin;
            this.alignment = alignment; this.concentration = concentration;
            this.windowConsistency = windowConsistency; this.contradiction = contradiction;
            this.independentFamilies = independentFamilies;
            this.coverage = Collections.unmodifiableList(new ArrayList<>(coverage));
            this.nucleus = Collections.unmodifiableList(new ArrayList<>(nucleus));
            this.familyStrengths = Collections.unmodifiableList(new ArrayList<>(familyStrengths));
            this.familyLabels = Collections.unmodifiableList(new ArrayList<>(familyLabels));
            this.provenance = Collections.unmodifiableList(new ArrayList<>(provenance));
            this.signalType = signalType;
        }

        static Fusion empty() {
            return new Fusion(-1, -1, 0, 0, 0, 0, 100, 0,
                    Collections.emptyList(), Collections.emptyList(),
                    java.util.Arrays.asList(0, 0, 0, 0),
                    Collections.emptyList(), Collections.emptyList(),
                    AurumLockSnapshot.SignalType.SECTOR_STRONG);
        }
    }
}
