package com.xspaceart.radar30.master;

import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Fusão deduplicada dos vetores; nenhum score é tratado como probabilidade. */
public final class MasterSignalFusion {
    public static final int MIN_STRONG_QUALITY = 80;
    public static final int MIN_STRONG_CONFIDENCE = 85;
    public static final int RIVAL_STRONG_VETO = 45;
    public static final int RIVAL_PROJECTION_LIMIT = 40;
    public static final String BIPOLAR_OBSERVATION_STATUS =
            "OBSERVAÇÃO / DISPERSÃO BIPOLAR";
    public static final String RIVAL_VETO_REASON =
            "Rival ativo (>45%) - Risco de dispersão oposta";

    private MasterSignalFusion() {}

    public static Result fuse(List<MasterEvidence> input) {
        return fuse(input, null);
    }

    /** Fusão enriquecida com entropia recente e concordância física/temporal. */
    public static Result fuse(List<MasterEvidence> input, MasterHistoryIndex history) {
        Map<String, MasterEvidence> unique = new LinkedHashMap<>();
        if (input != null) for (MasterEvidence evidence : input) {
            if (evidence == null || evidence.isEmpty()) continue;
            MasterEvidence current = unique.get(evidence.dependencyGroup);
            if (current == null || evidence.confidence > current.confidence) {
                unique.put(evidence.dependencyGroup, evidence);
            }
        }

        double[] combined = new double[37];
        double totalWeight = 0.0;
        for (MasterEvidence evidence : unique.values()) {
            double weight = familyWeight(evidence.family) * Math.max(0.15, evidence.confidence);
            totalWeight += weight;
            for (int n = 0; n < 37; n++) combined[n] += weight * evidence.at(n);
        }
        if (totalWeight > 0.0) for (int n = 0; n < 37; n++) combined[n] /= totalWeight;
        SpatialPressureEngine.Result spatial = SpatialPressureEngine.spread(combined);
        SectorClusterEngine.Result sectors = SectorClusterEngine.cluster(
                spatial.pressure, spatial.adaptiveRadius, history);
        SectorClusterEngine.Cluster primary = sectors.primary;
        SectorClusterEngine.Cluster secondary = sectors.secondary;

        int target = strongestIn(spatial.pressure, primary.members);
        int rival = strongestIn(spatial.pressure, secondary.members);
        if (rival < 0) rival = strongestOutside(spatial.pressure, primary.members);
        int targetScore = target < 0 ? 0 : clamp((int) Math.round(100.0 * spatial.pressure[target]));
        int rivalScore = rival < 0 ? 0 : clamp((int) Math.round(100.0 * spatial.pressure[rival]));
        int gap = clamp(Math.max(0, targetScore - rivalScore));

        int independent = 0;
        List<String> labels = new ArrayList<>();
        boolean terminalEvidence = false;
        boolean auxiliaryEvidence = false;
        for (MasterEvidence evidence : unique.values()) {
            double support = evidence.strongest(primary.members);
            if (evidence.independent && support >= 0.62 && evidence.confidence >= 0.24) {
                independent++;
                labels.add(evidence.label);
            }
            if ((evidence.family == MasterEvidence.Family.NUMERIC
                    || evidence.family == MasterEvidence.Family.SEQUENTIAL)
                    && support >= 0.56 && evidence.confidence >= 0.24) {
                terminalEvidence = true;
            }
            if (evidence.family == MasterEvidence.Family.PHYSICAL
                    && support >= 0.58 && evidence.confidence >= 0.24) {
                auxiliaryEvidence = true;
            }
        }

        NoiseProfile noise = NoiseProfile.from(history, primary);
        TrendProfile trend = TrendProfile.from(history, primary.members);
        boolean enoughHistory = history != null && history.size() >= 12;
        boolean physicalAgreement = !enoughHistory || primary.statisticallyHot
                || (primary.zScore >= 0.75
                && primary.observedDensity >= primary.expectedDensity * 1.35);
        boolean terminalAgreement = !enoughHistory || terminalEvidence || trend.supported;
        boolean auxiliaryAgreement = !enoughHistory || auxiliaryEvidence;
        boolean entropyBlocked = noise.randomLike;
        boolean rivalVetoActive = rivalScore >= RIVAL_STRONG_VETO;
        boolean strongConfluenceEligible = physicalAgreement && terminalAgreement
                && auxiliaryAgreement && !entropyBlocked && !rivalVetoActive;
        if (primary.statisticallyHot) {
            labels.add("hot cluster físico z=" + oneDecimal(primary.zScore));
        }
        if (trend.supported) labels.add(trend.label);
        if (noise.penalty > 0) {
            labels.add("filtro de entropia " + noise.entropyScore
                    + "/100 • penalidade " + noise.penalty);
        }
        if (entropyBlocked) {
            labels.add("forte confluência vetada: entropia recente acima do limiar seguro");
        }
        if (rivalVetoActive) {
            labels.add(RIVAL_VETO_REASON);
        }
        if (enoughHistory && !strongConfluenceEligible) {
            labels.add("forte confluência vetada: exige físico + terminal/dezena + motor auxiliar");
        }

        List<Integer> ranking = new ArrayList<>();
        for (int n = 0; n < 37; n++) ranking.add(n);
        ranking.sort((a, b) -> {
            int c = Double.compare(spatial.pressure[b], spatial.pressure[a]);
            return c != 0 ? c : Integer.compare(a, b);
        });
        List<Integer> topNumbers = new ArrayList<>();
        List<Integer> topScores = new ArrayList<>();
        for (int i = 0; i < Math.min(5, ranking.size()); i++) {
            int n = ranking.get(i);
            topNumbers.add(n);
            topScores.add(clamp((int) Math.round(100.0 * spatial.pressure[n])));
        }
        int agreements = (physicalAgreement ? 1 : 0)
                + (terminalAgreement ? 1 : 0) + (auxiliaryAgreement ? 1 : 0);
        int confluenceConfidence = clamp((int) Math.round(
                0.26 * primary.score + 0.18 * targetScore
                        + 0.18 * spatial.concentration + 0.14 * gap
                        + 0.24 * (agreements * 100.0 / 3.0) - noise.penalty));
        List<Integer> protectionTerminals = protectionTerminals(spatial.pressure);
        int recommendedSpins = target < 0 ? 0 : confluenceConfidence >= 72 ? 3 : 2;
        if (rivalScore > RIVAL_PROJECTION_LIMIT && recommendedSpins > 0) {
            recommendedSpins = Math.min(2, recommendedSpins);
        }
        return new Result(spatial.pressure, primary, secondary, target, targetScore,
                rival, rivalScore, gap, independent, labels, topNumbers, topScores,
                spatial.concentration, unique.size(), noise.entropyScore,
                noise.penalty, entropyBlocked, rivalVetoActive,
                strongConfluenceEligible, physicalAgreement,
                terminalAgreement, auxiliaryAgreement, confluenceConfidence,
                protectionTerminals, recommendedSpins);
    }

    /** Hard gate final; qualidade/confiança são calculadas pelo orquestrador. */
    public static StrongGate evaluateStrongGate(int qualityScore, int modelConfidence,
                                                int rivalScore, boolean entropyBlocked) {
        int quality = clamp(qualityScore);
        int confidence = clamp(modelConfidence);
        int rival = clamp(rivalScore);
        if (rival >= RIVAL_STRONG_VETO) {
            return new StrongGate(false, true, false,
                    BIPOLAR_OBSERVATION_STATUS, RIVAL_VETO_REASON);
        }
        if (entropyBlocked) {
            return new StrongGate(false, false, true,
                    "OBSERVAÇÃO / ENTROPIA ALTA",
                    "Entropia recente acima do limiar seguro - forte confluência vetada");
        }
        if (quality < MIN_STRONG_QUALITY || confidence < MIN_STRONG_CONFIDENCE) {
            return new StrongGate(false, false, false,
                    "MODERADA / AGUARDANDO QUALIDADE",
                    "Gate forte exige qualidade >=80 e confiança >=85"
                            + " (atual " + quality + "/" + confidence + ")");
        }
        return new StrongGate(true, false, false, "FORTE ELEGÍVEL", "");
    }

    public static int temporalAcceleration(int previousPressure, int currentPressure,
                                           int microAcceleration) {
        return clamp((int) Math.round(50.0 + 1.8 * (currentPressure - previousPressure)
                + 0.45 * (microAcceleration - 50)));
    }

    private static double familyWeight(MasterEvidence.Family family) {
        switch (family) {
            case PHYSICAL: return 0.34;
            case SEQUENTIAL: return 0.24;
            case NUMERIC: return 0.18;
            case PATTERN_ECHO: return 0.14;
            case LEGACY_FUSION: return 0.10;
            default: return 0.0;
        }
    }

    private static int strongestIn(double[] values, List<Integer> allowed) {
        int best = -1;
        double score = 0.0;
        if (allowed == null) return -1;
        for (Integer n : allowed) {
            if (n != null && Wheel.valid(n) && values[n] > score) { score = values[n]; best = n; }
        }
        return best;
    }

    private static int strongestOutside(double[] values, List<Integer> excluded) {
        int best = -1;
        double score = 0.0;
        for (int n = 0; n < 37; n++) {
            if (excluded != null && excluded.contains(n)) continue;
            if (values[n] > score) { score = values[n]; best = n; }
        }
        return best;
    }

    private static List<Integer> protectionTerminals(double[] pressure) {
        double[] terminalPressure = new double[10];
        for (int number = 0; number < 37; number++) {
            terminalPressure[number % 10] = Math.max(
                    terminalPressure[number % 10], pressure[number]);
        }
        List<Integer> terminals = new ArrayList<>();
        for (int terminal = 0; terminal < 10; terminal++) terminals.add(terminal);
        terminals.sort((a, b) -> {
            int c = Double.compare(terminalPressure[b], terminalPressure[a]);
            return c != 0 ? c : Integer.compare(a, b);
        });
        return Collections.unmodifiableList(new ArrayList<>(terminals.subList(0, 2)));
    }

    private static String oneDecimal(double value) {
        return String.format(java.util.Locale.US, "%.1f", value);
    }

    private static int clamp(int value) { return Math.max(0, Math.min(100, value)); }

    public static final class StrongGate {
        public final boolean allowStrong;
        public final boolean rivalVeto;
        public final boolean entropyVeto;
        public final String status;
        public final String reason;

        StrongGate(boolean allowStrong, boolean rivalVeto, boolean entropyVeto,
                   String status, String reason) {
            this.allowStrong = allowStrong;
            this.rivalVeto = rivalVeto;
            this.entropyVeto = entropyVeto;
            this.status = status == null ? "" : status;
            this.reason = reason == null ? "" : reason;
        }
    }

    public static final class Result {
        public final double[] pressure;
        public final SectorClusterEngine.Cluster primary;
        public final SectorClusterEngine.Cluster secondary;
        public final int target;
        public final int targetScore;
        public final int rival;
        public final int rivalScore;
        public final int gap;
        public final int independentReadings;
        public final List<String> evidenceLabels;
        public final List<Integer> rankingNumbers;
        public final List<Integer> rankingScores;
        public final int concentration;
        public final int deduplicatedEvidenceCount;
        public final int recentEntropy;
        public final int noisePenalty;
        public final boolean entropyBlocked;
        public final boolean rivalVetoActive;
        public final boolean strongConfluenceEligible;
        public final boolean physicalAgreement;
        public final boolean terminalAgreement;
        public final boolean auxiliaryAgreement;
        public final int confluenceConfidence;
        public final List<Integer> protectionTerminals;
        public final int recommendedSpins;

        Result(double[] pressure, SectorClusterEngine.Cluster primary,
               SectorClusterEngine.Cluster secondary, int target, int targetScore,
               int rival, int rivalScore, int gap, int independentReadings,
               List<String> evidenceLabels, List<Integer> rankingNumbers,
               List<Integer> rankingScores, int concentration,
               int deduplicatedEvidenceCount, int recentEntropy,
               int noisePenalty, boolean entropyBlocked,
               boolean rivalVetoActive, boolean strongConfluenceEligible,
               boolean physicalAgreement, boolean terminalAgreement,
               boolean auxiliaryAgreement, int confluenceConfidence,
               List<Integer> protectionTerminals, int recommendedSpins) {
            this.pressure = pressure.clone();
            this.primary = primary;
            this.secondary = secondary;
            this.target = target;
            this.targetScore = targetScore;
            this.rival = rival;
            this.rivalScore = rivalScore;
            this.gap = gap;
            this.independentReadings = independentReadings;
            this.evidenceLabels = Collections.unmodifiableList(new ArrayList<>(evidenceLabels));
            this.rankingNumbers = Collections.unmodifiableList(new ArrayList<>(rankingNumbers));
            this.rankingScores = Collections.unmodifiableList(new ArrayList<>(rankingScores));
            this.concentration = concentration;
            this.deduplicatedEvidenceCount = deduplicatedEvidenceCount;
            this.recentEntropy = clamp(recentEntropy);
            this.noisePenalty = clamp(noisePenalty);
            this.entropyBlocked = entropyBlocked;
            this.rivalVetoActive = rivalVetoActive;
            this.strongConfluenceEligible = strongConfluenceEligible;
            this.physicalAgreement = physicalAgreement;
            this.terminalAgreement = terminalAgreement;
            this.auxiliaryAgreement = auxiliaryAgreement;
            this.confluenceConfidence = clamp(confluenceConfidence);
            this.protectionTerminals = Collections.unmodifiableList(
                    new ArrayList<>(protectionTerminals));
            this.recommendedSpins = Math.max(0, Math.min(3, recommendedSpins));
        }
    }

    private static final class NoiseProfile {
        final int entropyScore;
        final int penalty;
        final boolean randomLike;

        NoiseProfile(int entropyScore, int penalty, boolean randomLike) {
            this.entropyScore = entropyScore;
            this.penalty = penalty;
            this.randomLike = randomLike;
        }

        static NoiseProfile from(MasterHistoryIndex history,
                                 SectorClusterEngine.Cluster primary) {
            if (history == null || history.size() < 12) return new NoiseProfile(0, 0, false);
            int count = Math.min(18, history.size());
            int[] bins = new int[12];
            for (int offset = 0; offset < count; offset++) {
                int position = Wheel.EUROPEAN.indexOf(history.recent(offset));
                bins[Math.min(11, position * 12 / 37)]++;
            }
            double entropy = 0.0;
            for (int hits : bins) if (hits > 0) {
                double p = hits / (double) count;
                entropy -= p * Math.log(p);
            }
            entropy /= Math.log(Math.min(12, count));

            double distance = 0.0;
            int pairs = 0;
            for (int i = 0; i < count; i++) for (int j = i + 1; j < count; j++) {
                distance += Wheel.distance(history.recent(i), history.recent(j));
                pairs++;
            }
            double dispersion = pairs == 0 ? 0.0 : Math.min(1.0, distance / pairs / 9.25);
            int maxClusterHits = 0;
            for (int center = 0; center < 37; center++) {
                int hits = 0;
                for (int offset = 0; offset < count; offset++) {
                    if (Wheel.distance(center, history.recent(offset)) <= 3) hits++;
                }
                maxClusterHits = Math.max(maxClusterHits, hits);
            }
            double clusterShare = maxClusterHits / (double) count;
            double score = Math.max(0.0, Math.min(1.0,
                    0.58 * entropy + 0.42 * dispersion));
            boolean randomLike = score >= 0.78 && entropy >= 0.80
                    && clusterShare < 0.50 && (primary == null || !primary.statisticallyHot);
            int penalty = randomLike
                    ? clamp((int) Math.round(8.0 + 52.0 * (score - 0.72))) : 0;
            return new NoiseProfile(clamp((int) Math.round(100.0 * score)),
                    Math.min(24, penalty), randomLike);
        }
    }

    private static final class TrendProfile {
        final boolean supported;
        final String label;

        TrendProfile(boolean supported, String label) {
            this.supported = supported;
            this.label = label;
        }

        static TrendProfile from(MasterHistoryIndex history, List<Integer> sector) {
            if (history == null || history.size() < 8 || sector == null || sector.isEmpty()) {
                return new TrendProfile(false, "");
            }
            int count = Math.min(18, history.size());
            int[] terminals = new int[10];
            int[] dozens = new int[3];
            int nonZero = 0;
            for (int offset = 0; offset < count; offset++) {
                int number = history.recent(offset);
                terminals[number % 10]++;
                if (number > 0) {
                    dozens[Math.min(2, (number - 1) / 12)]++;
                    nonZero++;
                }
            }
            int terminal = argMax(terminals);
            int dozen = argMax(dozens);
            boolean terminalPattern = terminals[terminal] >= Math.max(3,
                    (int) Math.ceil(count * 0.20));
            boolean dozenPattern = nonZero >= 6 && dozens[dozen] >= Math.max(3,
                    (int) Math.ceil(nonZero * 0.34));
            boolean terminalAligned = false, dozenAligned = false;
            for (Integer number : sector) if (number != null) {
                terminalAligned |= number % 10 == terminal;
                dozenAligned |= number > 0 && (number - 1) / 12 == dozen;
            }
            if (terminalPattern && terminalAligned) {
                return new TrendProfile(true, "tendência de terminal T" + terminal);
            }
            if (dozenPattern && dozenAligned) {
                return new TrendProfile(true, "tendência de " + (dozen + 1) + "ª dúzia");
            }
            return new TrendProfile(false, "");
        }

        private static int argMax(int[] values) {
            int best = 0;
            for (int i = 1; i < values.length; i++) {
                if (values[i] > values[best]) best = i;
            }
            return best;
        }
    }
}
