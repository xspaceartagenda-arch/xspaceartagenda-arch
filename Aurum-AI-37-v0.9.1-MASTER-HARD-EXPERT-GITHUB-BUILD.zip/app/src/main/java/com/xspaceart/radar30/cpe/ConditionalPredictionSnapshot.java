package com.xspaceart.radar30.cpe;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Snapshot de pressão condicional. Todos os scores são índices relativos 0..100;
 * não representam probabilidade matemática do próximo giro.
 */
public final class ConditionalPredictionSnapshot {
    public final List<Integer> topNumbers;
    public final List<Integer> topScores;
    public final List<Integer> primarySector;
    public final int primarySectorScore;
    public final List<Integer> secondarySector;
    public final int secondarySectorScore;
    public final int primaryTerminal;
    public final int primaryTerminalScore;
    public final int secondaryTerminal;
    public final int secondaryTerminalScore;
    public final int leaderGap;
    public final int sampleQuality;
    public final List<String> drivers;
    public final boolean shadow;
    private final double[] relativePressure;

    public ConditionalPredictionSnapshot(List<Integer> topNumbers,
                                         List<Integer> topScores,
                                         List<Integer> primarySector,
                                         int primarySectorScore,
                                         List<Integer> secondarySector,
                                         int secondarySectorScore,
                                         int primaryTerminal,
                                         int primaryTerminalScore,
                                         int secondaryTerminal,
                                         int secondaryTerminalScore,
                                         int leaderGap,
                                         int sampleQuality,
                                         List<String> drivers,
                                         boolean shadow,
                                         double[] relativePressure) {
        this.topNumbers = immutableInts(topNumbers);
        this.topScores = immutableScores(topScores);
        this.primarySector = immutableInts(primarySector);
        this.primarySectorScore = clamp(primarySectorScore);
        this.secondarySector = immutableInts(secondarySector);
        this.secondarySectorScore = clamp(secondarySectorScore);
        this.primaryTerminal = primaryTerminal >= 0 && primaryTerminal <= 9 ? primaryTerminal : -1;
        this.primaryTerminalScore = clamp(primaryTerminalScore);
        this.secondaryTerminal = secondaryTerminal >= 0 && secondaryTerminal <= 9 ? secondaryTerminal : -1;
        this.secondaryTerminalScore = clamp(secondaryTerminalScore);
        this.leaderGap = clamp(leaderGap);
        this.sampleQuality = clamp(sampleQuality);
        this.drivers = immutableStrings(drivers);
        this.shadow = shadow;
        this.relativePressure = sanitizePressure(relativePressure);
    }

    public static ConditionalPredictionSnapshot empty() {
        return new ConditionalPredictionSnapshot(Collections.emptyList(), Collections.emptyList(),
                Collections.emptyList(), 0, Collections.emptyList(), 0,
                -1, 0, -1, 0, 0, 0, Collections.emptyList(), false, new double[37]);
    }

    public boolean available() { return !topNumbers.isEmpty(); }

    /** Pressão relativa 0..1 usada pela fusão ativa do Aurum Lock v0.8.5. */
    public double pressureAt(int number) {
        return number >= 0 && number < relativePressure.length ? relativePressure[number] : 0.0;
    }

    public double[] copyPressure() { return relativePressure.clone(); }

    private static List<Integer> immutableInts(List<Integer> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        return Collections.unmodifiableList(new ArrayList<>(values));
    }

    private static List<Integer> immutableScores(List<Integer> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        List<Integer> out = new ArrayList<>();
        for (Integer v : values) out.add(clamp(v == null ? 0 : v));
        return Collections.unmodifiableList(out);
    }

    private static List<String> immutableStrings(List<String> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        List<String> out = new ArrayList<>();
        for (String v : values) if (v != null && !v.trim().isEmpty()) out.add(v.trim());
        return Collections.unmodifiableList(out);
    }

    private static double[] sanitizePressure(double[] values) {
        double[] out = new double[37];
        if (values == null) return out;
        int n = Math.min(out.length, values.length);
        for (int i = 0; i < n; i++) {
            double v = values[i];
            out[i] = Double.isFinite(v) ? Math.max(0.0, Math.min(1.0, v)) : 0.0;
        }
        return out;
    }

    private static int clamp(int v) { return Math.max(0, Math.min(100, v)); }
}
