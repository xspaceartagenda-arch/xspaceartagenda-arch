package com.xspaceart.radar30;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class OverlayController {
    private final Context context;
    private final WindowManager windowManager;
    private final Handler main = new Handler(Looper.getMainLooper());
    private LinearLayout panel;
    private TextView headline;
    private TextView detail;
    private TextView collapse;
    private WindowManager.LayoutParams params;
    private boolean expanded = true;

    public OverlayController(Context context) {
        this.context = context.getApplicationContext();
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
    }

    public void show(String title, String body, int accent) {
        main.post(() -> showOnMain(title, body, accent));
    }

    public void hide() {
        main.post(() -> {
            if (panel != null) {
                try {
                    windowManager.removeView(panel);
                } catch (RuntimeException ignored) {
                    // O sistema pode já ter removido a janela.
                }
                panel = null;
            }
        });
    }

    private void showOnMain(String title, String body, int accent) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || !Settings.canDrawOverlays(context)) return;
        if (panel == null) createPanel();
        headline.setText(title);
        detail.setText(body);
        GradientDrawable background = Ui.rounded(Ui.SURFACE, 16, context);
        background.setStroke(Ui.dp(context, 2), accent);
        panel.setBackground(background);
        if (!panel.isAttachedToWindow()) {
            try {
                windowManager.addView(panel, params);
            } catch (RuntimeException ignored) {
                panel = null;
            }
        } else {
            windowManager.updateViewLayout(panel, params);
        }
    }

    private void createPanel() {
        panel = new LinearLayout(context);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(context, 14), Ui.dp(context, 11), Ui.dp(context, 14), Ui.dp(context, 11));

        LinearLayout dragBar = new LinearLayout(context);
        dragBar.setOrientation(LinearLayout.HORIZONTAL);
        dragBar.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = Ui.text(context, "AURUM AI 37 • PRECISION", 12, Ui.AMBER, true);
        collapse = Ui.text(context, "—", 18, Ui.MUTED, true);
        collapse.setGravity(Gravity.CENTER);
        collapse.setPadding(Ui.dp(context, 12), 0, Ui.dp(context, 4), 0);
        dragBar.addView(brand, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        dragBar.addView(collapse, new LinearLayout.LayoutParams(
                Ui.dp(context, 42), Ui.dp(context, 32)));
        panel.addView(dragBar);

        headline = Ui.text(context, "ANALISANDO", 16, Ui.TEXT, true);
        detail = Ui.text(context, "Aguardando leitura", 13, Ui.MUTED, false);
        panel.addView(headline, Ui.margins(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT, context, 0, 3, 0, 0));
        panel.addView(detail, Ui.margins(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT, context, 0, 4, 0, 0));
        collapse.setOnClickListener(v -> {
            expanded = !expanded;
            Ui.setVisible(detail, expanded);
            collapse.setText(expanded ? "—" : "+");
            try {
                windowManager.updateViewLayout(panel, params);
            } catch (RuntimeException ignored) {
                // O painel pode ser encerrado ao mesmo tempo.
            }
        });

        params = new WindowManager.LayoutParams(
                Ui.dp(context, 310),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        // Standalone v0.7.5: canto inferior direito por padrão para não cobrir
        // o histórico da roleta, que normalmente fica na metade superior da tela.
        params.gravity = Gravity.BOTTOM | Gravity.END;
        params.x = Ui.dp(context, 14);
        params.y = Ui.dp(context, 110);

        panel.setElevation(Ui.dp(context, 12));

        dragBar.setOnTouchListener(new View.OnTouchListener() {
            private int startX;
            private int startY;
            private float touchX;
            private float touchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + Math.round(event.getRawX() - touchX);
                        params.y = startY + Math.round(event.getRawY() - touchY);
                        try {
                            windowManager.updateViewLayout(panel, params);
                        } catch (RuntimeException ignored) {
                            // A janela pode ser encerrada durante o gesto.
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }
}
