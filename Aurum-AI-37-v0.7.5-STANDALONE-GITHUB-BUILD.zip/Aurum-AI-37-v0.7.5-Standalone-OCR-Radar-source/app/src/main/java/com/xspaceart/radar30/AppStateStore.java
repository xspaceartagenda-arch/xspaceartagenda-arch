package com.xspaceart.radar30;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.RectF;

import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.core.CurrentTableHistory;

import java.util.ArrayList;
import java.util.List;

public final class AppStateStore {
    private static final String PREFS = "radar30_state";
    private static final String CALIBRATED = "calibrated";
    private static final String ROI_LEFT = "roi_left";
    private static final String ROI_TOP = "roi_top";
    private static final String ROI_RIGHT = "roi_right";
    private static final String ROI_BOTTOM = "roi_bottom";
    private static final String HISTORY = "history";
    private static final String HISTORY_SESSION = "history_session";
    private static final String STATUS = "status";
    private static final String SIGNAL = "signal";
    private static final String VOICE = "voice";
    private static final String CONSERVATIVE = "conservative";
    private static final String PROVIDER = "provider";
    private static final String DEALER = "dealer";
    private static final String OCR_SNAPSHOT = "ocr_snapshot";
    private static final String OCR_SNAPSHOT_AT = "ocr_snapshot_at";
    private static final String OCR_SCAN_COUNT = "ocr_scan_count";
    private static final String CAPTURE_ACTIVE = "capture_active";
    private static final String RADAR_SCORE = "radar_score";
    private static final String RADAR_FAMILIES = "radar_families";
    private static final String RADAR_DECISION = "radar_decision";
    private static final String RADAR_TARGET = "radar_target";
    private static final String RADAR_PLAY_LABEL = "radar_play_label";
    private static final String RADAR_HEADLINE = "radar_headline";
    private static final String RADAR_DETAIL = "radar_detail";
    private static final String RADAR_REASONS = "radar_reasons";
    private static final String RADAR_UPDATED_AT = "radar_updated_at";
    private static final String STANDALONE_DEFAULTS = "standalone_defaults_v075";

    private AppStateStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isCalibrated(Context context) {
        SharedPreferences p = prefs(context);
        String suffix = providerSuffix(context);
        if (p.getBoolean(CALIBRATED + "_" + suffix, false)) return true;
        return isLegacyProvider(context) && p.getBoolean(CALIBRATED, false);
    }

    public static RectF getRoi(Context context) {
        SharedPreferences p = prefs(context);
        String suffix = providerSuffix(context);
        boolean providerCalibrated = p.getBoolean(CALIBRATED + "_" + suffix, false);
        String keyPrefix = providerCalibrated ? suffix + "_" : "";
        return new RectF(
                p.getFloat(keyPrefix + ROI_LEFT, 0.05f),
                p.getFloat(keyPrefix + ROI_TOP, 0.25f),
                p.getFloat(keyPrefix + ROI_RIGHT, 0.95f),
                p.getFloat(keyPrefix + ROI_BOTTOM, 0.75f));
    }

    public static void saveRoi(Context context, RectF normalized) {
        String suffix = providerSuffix(context);
        prefs(context).edit()
                .putBoolean(CALIBRATED + "_" + suffix, true)
                .putFloat(suffix + "_" + ROI_LEFT, normalized.left)
                .putFloat(suffix + "_" + ROI_TOP, normalized.top)
                .putFloat(suffix + "_" + ROI_RIGHT, normalized.right)
                .putFloat(suffix + "_" + ROI_BOTTOM, normalized.bottom)
                .apply();
    }

    public static void saveHistory(Context context, List<Integer> history) {
        StringBuilder out = new StringBuilder();
        int end = Math.min(CurrentTableHistory.MAX_RESULTS, history.size());
        for (int i = 0; i < end; i++) {
            if (i > 0) out.append(',');
            out.append(history.get(i));
        }
        prefs(context).edit()
                .putString(HISTORY, out.toString())
                .putLong(HISTORY_SESSION, SessionLedger.activeSessionId(context))
                .apply();
    }

    public static List<Integer> loadHistory(Context context) {
        List<Integer> result = new ArrayList<>();
        long activeSession = SessionLedger.activeSessionId(context);
        long storedSession = prefs(context).getLong(HISTORY_SESSION, Long.MIN_VALUE);
        if (activeSession < 0L || storedSession != activeSession) return result;
        String value = prefs(context).getString(HISTORY, "");
        if (value == null || value.trim().isEmpty()) return result;
        for (String token : value.split(",")) {
            try {
                int number = Integer.parseInt(token.trim());
                if (Wheel.valid(number)) result.add(number);
            } catch (NumberFormatException ignored) {
                // Ignora valor persistido inválido.
            }
        }
        return result;
    }

    public static void saveStatus(Context context, String status, String signal) {
        prefs(context).edit()
                .putString(STATUS, status == null ? "" : status)
                .putString(SIGNAL, signal == null ? "" : signal)
                .apply();
    }

    public static String getStatus(Context context) {
        return prefs(context).getString(STATUS, "Leitura parada");
    }

    public static String getSignal(Context context) {
        return prefs(context).getString(SIGNAL, "SCANNING • sem sinal ativo");
    }

    public static boolean voiceEnabled(Context context) {
        return prefs(context).getBoolean(VOICE, true);
    }

    public static void setVoiceEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(VOICE, enabled).apply();
    }

    public static boolean conservativeMode(Context context) {
        return prefs(context).getBoolean(CONSERVATIVE, true);
    }

    public static void setConservativeMode(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(CONSERVATIVE, enabled).apply();
    }

    public static String provider(Context context) {
        SharedPreferences p = prefs(context);
        String stored = p.getString(PROVIDER, null);
        if (stored != null && !stored.trim().isEmpty()) return stored;
        // Migração da v0.1: o único recorte antigo conhecido era Betão / Roleta Brasil.
        String migrated = p.getBoolean(CALIBRATED, false)
                ? "Betão / Roleta Brasil" : "Roleta ao vivo";
        p.edit().putString(PROVIDER, migrated).apply();
        return migrated;
    }

    public static void setProvider(Context context, String provider) {
        String value = provider == null || provider.trim().isEmpty()
                ? "Roleta ao vivo" : provider.trim();
        prefs(context).edit().putString(PROVIDER, value).apply();
    }


    /** Snapshot visual bruto mais recente, independente do motor Stable. */
    public static void saveOcrSnapshot(Context context, List<Integer> history, long observedAt) {
        StringBuilder out = new StringBuilder();
        int end = Math.min(CurrentTableHistory.MAX_RESULTS, history == null ? 0 : history.size());
        for (int i = 0; i < end; i++) {
            Integer value = history.get(i);
            if (value == null || !Wheel.valid(value)) continue;
            if (out.length() > 0) out.append(',');
            out.append(value);
        }
        SharedPreferences p = prefs(context);
        long scans = p.getLong(OCR_SCAN_COUNT, 0L) + 1L;
        p.edit()
                .putString(OCR_SNAPSHOT, out.toString())
                .putLong(OCR_SNAPSHOT_AT, observedAt)
                .putLong(OCR_SCAN_COUNT, scans)
                .apply();
    }

    public static List<Integer> loadOcrSnapshot(Context context) {
        List<Integer> result = new ArrayList<>();
        String value = prefs(context).getString(OCR_SNAPSHOT, "");
        if (value == null || value.trim().isEmpty()) return result;
        for (String token : value.split(",")) {
            try {
                int number = Integer.parseInt(token.trim());
                if (Wheel.valid(number)) result.add(number);
            } catch (NumberFormatException ignored) {
                // Snapshot inválido não contamina a leitura.
            }
        }
        return result;
    }

    public static long ocrSnapshotAt(Context context) {
        return prefs(context).getLong(OCR_SNAPSHOT_AT, 0L);
    }

    public static long ocrScanCount(Context context) {
        return prefs(context).getLong(OCR_SCAN_COUNT, 0L);
    }

    public static void setCaptureActive(Context context, boolean active) {
        prefs(context).edit().putBoolean(CAPTURE_ACTIVE, active).apply();
    }

    public static boolean captureActive(Context context) {
        return prefs(context).getBoolean(CAPTURE_ACTIVE, false);
    }

    public static void clearOcrSnapshot(Context context) {
        prefs(context).edit().remove(OCR_SNAPSHOT).remove(OCR_SNAPSHOT_AT).apply();
    }

    public static String dealer(Context context) {
        return prefs(context).getString(DEALER, "");
    }

    public static void setDealer(Context context, String dealer) {
        prefs(context).edit().putString(DEALER,
                dealer == null ? "" : dealer.trim()).apply();
    }


    public static void ensureStandaloneDefaults(Context context) {
        SharedPreferences p = prefs(context);
        if (p.getBoolean(STANDALONE_DEFAULTS, false)) return;
        p.edit()
                .putBoolean(CONSERVATIVE, false)
                .putBoolean(VOICE, true)
                .putBoolean(STANDALONE_DEFAULTS, true)
                .apply();
    }

    public static void saveRadarSnapshot(Context context,
                                         int score, int families, String decision,
                                         int target, String playLabel,
                                         String headline, String detail,
                                         List<String> reasons) {
        StringBuilder reasonText = new StringBuilder();
        int end = Math.min(5, reasons == null ? 0 : reasons.size());
        for (int i = 0; i < end; i++) {
            String value = reasons.get(i);
            if (value == null || value.trim().isEmpty()) continue;
            if (reasonText.length() > 0) reasonText.append("\n");
            reasonText.append("• ").append(value.trim());
        }
        prefs(context).edit()
                .putInt(RADAR_SCORE, Math.max(0, Math.min(100, score)))
                .putInt(RADAR_FAMILIES, Math.max(0, families))
                .putString(RADAR_DECISION, decision == null ? "" : decision)
                .putInt(RADAR_TARGET, target)
                .putString(RADAR_PLAY_LABEL, playLabel == null ? "" : playLabel)
                .putString(RADAR_HEADLINE, headline == null ? "" : headline)
                .putString(RADAR_DETAIL, detail == null ? "" : detail)
                .putString(RADAR_REASONS, reasonText.toString())
                .putLong(RADAR_UPDATED_AT, System.currentTimeMillis())
                .apply();
    }

    public static void clearRadarSnapshot(Context context) {
        prefs(context).edit()
                .remove(RADAR_SCORE).remove(RADAR_FAMILIES)
                .remove(RADAR_DECISION).remove(RADAR_TARGET)
                .remove(RADAR_PLAY_LABEL).remove(RADAR_HEADLINE)
                .remove(RADAR_DETAIL).remove(RADAR_REASONS)
                .remove(RADAR_UPDATED_AT).apply();
    }

    public static int radarScore(Context context) { return prefs(context).getInt(RADAR_SCORE, 0); }
    public static int radarFamilies(Context context) { return prefs(context).getInt(RADAR_FAMILIES, 0); }
    public static String radarDecision(Context context) { return prefs(context).getString(RADAR_DECISION, ""); }
    public static int radarTarget(Context context) { return prefs(context).getInt(RADAR_TARGET, -1); }
    public static String radarPlayLabel(Context context) { return prefs(context).getString(RADAR_PLAY_LABEL, ""); }
    public static String radarHeadline(Context context) { return prefs(context).getString(RADAR_HEADLINE, "ANALISANDO"); }
    public static String radarDetail(Context context) { return prefs(context).getString(RADAR_DETAIL, "Aguardando leitura OCR."); }
    public static String radarReasons(Context context) { return prefs(context).getString(RADAR_REASONS, ""); }
    public static long radarUpdatedAt(Context context) { return prefs(context).getLong(RADAR_UPDATED_AT, 0L); }

    public static void clearHistory(Context context) {
        prefs(context).edit().remove(HISTORY).remove(HISTORY_SESSION)
                .remove(SIGNAL).apply();
    }

    private static String providerSuffix(Context context) {
        return provider(context).toLowerCase()
                .replaceAll("[^a-z0-9]+", "_")
                .replaceAll("^_+|_+$", "");
    }

    private static boolean isLegacyProvider(Context context) {
        return "Betão / Roleta Brasil".equals(provider(context));
    }
}
