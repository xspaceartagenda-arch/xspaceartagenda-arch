package com.xspaceart.radar30;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

/**
 * v0.7.5: interface operacional standalone. A roleta roda em outro app.
 * O ScreenCaptureService é o único dono da captura OCR + RadarSession.
 */
public final class StandaloneActivity extends Activity {
    private static final int REQUEST_CAPTURE = 7501;
    private static final int REQUEST_NOTIFICATIONS = 7502;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView liveBadge;
    private TextView radarValue;
    private TextView radarMeta;
    private TextView radarReasons;
    private TextView signalTitle;
    private TextView signalTarget;
    private TextView signalMeta;
    private TextView historyText;
    private TextView ocrStatus;
    private TextView sessionText;
    private ProgressBar radarBar;
    private Button startButton;
    private Button floatButton;
    private Switch precisionSwitch;
    private Switch voiceSwitch;
    private boolean receiverRegistered;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            refreshState();
        }
    };

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refreshState();
            handler.postDelayed(this, 900L);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        AppStateStore.ensureStandaloneDefaults(this);
        setContentView(buildUi());
        requestNotificationPermission();
        registerStateReceiver();
        handler.post(ticker);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshState();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (receiverRegistered) {
            try { unregisterReceiver(receiver); } catch (IllegalArgumentException ignored) {}
        }
        super.onDestroy();
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Captura OCR não autorizada.", Toast.LENGTH_LONG).show();
            return;
        }
        SessionLedger.ensureActive(this, AppStateStore.provider(this), AppStateStore.dealer(this));
        AppStateStore.clearOcrSnapshot(this);
        Intent service = new Intent(this, ScreenCaptureService.class)
                .setAction(ScreenCaptureService.ACTION_START)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                .putExtra(ScreenCaptureService.EXTRA_PIPELINE_MODE,
                        ScreenCaptureService.MODE_STANDALONE_OCR);
        startForegroundService(service);
        Toast.makeText(this,
                AppStateStore.isCalibrated(this)
                        ? "OCR iniciado. Agora abra a roleta e mantenha o histórico visível."
                        : "OCR iniciado. Agora calibre somente a área do histórico.",
                Toast.LENGTH_LONG).show();
        refreshState();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 24));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = Ui.text(this, "AURUM AI 37", 25, Ui.GREEN, true);
        liveBadge = Ui.text(this, "● OCR PARADO", 11, Ui.AMBER, true);
        liveBadge.setGravity(Gravity.RIGHT);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(liveBadge, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header);
        root.addView(Ui.text(this, "STANDALONE OCR RADAR • v0.7.5", 12, Ui.CYAN, true),
                Ui.margins(-1, -2, this, 0, 2, 0, 12));

        // Radar é o centro da interface.
        LinearLayout radar = Ui.card(this);
        radar.addView(Ui.text(this, "RADAR DE CONFLUÊNCIA", 14, Ui.CYAN, true));
        radarValue = Ui.text(this, "RADAR 0/100", 34, Ui.TEXT, true);
        radarMeta = Ui.text(this, "Aguardando histórico OCR", 14, Ui.MUTED, true);
        radarBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        radarBar.setMax(100);
        radarBar.setProgress(0);
        radarReasons = Ui.text(this, "As principais confluências aparecerão aqui.", 12, Ui.MUTED, false);
        radar.addView(radarValue, Ui.margins(-1, -2, this, 0, 8, 0, 2));
        radar.addView(radarMeta);
        radar.addView(radarBar, Ui.margins(-1, Ui.dp(this, 12), this, 0, 9, 0, 7));
        radar.addView(radarReasons);
        root.addView(radar, Ui.margins(-1, -2, this, 0, 0, 0, 10));

        // Sinal grande e limpo.
        LinearLayout signal = Ui.card(this);
        signalTitle = Ui.text(this, "ANALISANDO", 13, Ui.AMBER, true);
        signalTarget = Ui.text(this, "SEM SINAL", 31, Ui.TEXT, true);
        signalMeta = Ui.text(this,
                "Quando a confluência atingir a régua operacional, a Aurum avisa por bolha, voz e notificação.",
                13, Ui.MUTED, false);
        signal.addView(signalTitle);
        signal.addView(signalTarget, Ui.margins(-1, -2, this, 0, 5, 0, 4));
        signal.addView(signalMeta);
        root.addView(signal, Ui.margins(-1, -2, this, 0, 0, 0, 10));

        // Controles principais.
        LinearLayout controls = Ui.card(this);
        controls.addView(Ui.text(this, "CONTROLE", 12, Ui.MUTED, true));
        startButton = Ui.button(this, "▶ INICIAR LEITURA OCR", Ui.GREEN, Color.BLACK);
        floatButton = Ui.button(this, "◉ MODO FLUTUANTE / IR PARA ROLETA", Ui.AMBER, Color.BLACK);
        Button calibrate = Ui.button(this, "▣ CALIBRAR ÁREA DO HISTÓRICO", Ui.CYAN, Color.BLACK);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button clear = Ui.button(this, "↻ LIMPAR", Ui.SURFACE, Ui.TEXT);
        Button correct = Ui.button(this, "✎ CORRIGIR", Ui.SURFACE, Ui.TEXT);
        Button manual = Ui.button(this, "+ MANUAL", Ui.SURFACE, Ui.TEXT);
        row.addView(clear, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        row.addView(correct, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        row.addView(manual, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        controls.addView(startButton, Ui.margins(-1, Ui.dp(this, 54), this, 0, 8, 0, 0));
        controls.addView(floatButton, Ui.margins(-1, Ui.dp(this, 50), this, 0, 6, 0, 0));
        controls.addView(calibrate, Ui.margins(-1, Ui.dp(this, 48), this, 0, 6, 0, 0));
        controls.addView(row, Ui.margins(-1, Ui.dp(this, 46), this, 0, 6, 0, 0));
        root.addView(controls, Ui.margins(-1, -2, this, 0, 0, 0, 10));

        // Só os ajustes realmente úteis ficam na tela principal.
        LinearLayout options = Ui.card(this);
        options.addView(Ui.text(this, "MODO", 12, Ui.MUTED, true));
        precisionSwitch = new Switch(this);
        precisionSwitch.setText("Precision máximo (mais seletivo)");
        precisionSwitch.setTextColor(Ui.TEXT);
        precisionSwitch.setChecked(AppStateStore.conservativeMode(this));
        voiceSwitch = new Switch(this);
        voiceSwitch.setText("Aviso por voz");
        voiceSwitch.setTextColor(Ui.TEXT);
        voiceSwitch.setChecked(AppStateStore.voiceEnabled(this));
        options.addView(precisionSwitch);
        options.addView(voiceSwitch);
        root.addView(options, Ui.margins(-1, -2, this, 0, 0, 0, 10));

        LinearLayout history = Ui.card(this);
        history.addView(Ui.text(this, "HISTÓRICO OCR CONFIRMADO", 12, Ui.MUTED, true));
        historyText = Ui.text(this, "Últimos: —", 13, Ui.TEXT, false);
        ocrStatus = Ui.text(this, "OCR parado", 11, Ui.MUTED, false);
        history.addView(historyText, Ui.margins(-1, -2, this, 0, 7, 0, 4));
        history.addView(ocrStatus);
        root.addView(history, Ui.margins(-1, -2, this, 0, 0, 0, 10));

        LinearLayout session = Ui.card(this);
        session.addView(Ui.text(this, "SESSÃO", 12, Ui.MUTED, true));
        sessionText = Ui.text(this, "Nenhuma sessão ativa.", 12, Ui.TEXT, false);
        Button finish = Ui.button(this, "■ FINALIZAR SESSÃO", Ui.SURFACE, Ui.TEXT);
        session.addView(sessionText, Ui.margins(-1, -2, this, 0, 6, 0, 5));
        session.addView(finish, Ui.margins(-1, Ui.dp(this, 46), this, 0, 4, 0, 0));
        root.addView(session);

        TextView footer = Ui.text(this,
                "OCR → histórico validado → CORE → Radar → sinal. Sem navegador interno e sem DOM operacional.",
                11, Ui.MUTED, false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, Ui.margins(-1, -2, this, 0, 14, 0, 0));

        startButton.setOnClickListener(v -> startReading());
        floatButton.setOnClickListener(v -> enterFloatingMode());
        calibrate.setOnClickListener(v -> openCalibration());
        clear.setOnClickListener(v -> sendServiceAction(ScreenCaptureService.ACTION_RESET));
        correct.setOnClickListener(v -> showCorrectionDialog());
        manual.setOnClickListener(v -> showNumberDialog("GIRO MANUAL", -1,
                n -> sendNumberAction(ScreenCaptureService.ACTION_MANUAL, n)));
        finish.setOnClickListener(v -> finishSession());
        precisionSwitch.setOnCheckedChangeListener((button, checked) -> {
            AppStateStore.setConservativeMode(this, checked);
            Toast.makeText(this, checked
                    ? "Precision ativado: régua máxima."
                    : "Balanced operacional ativado: confluência forte entra mais cedo.",
                    Toast.LENGTH_SHORT).show();
        });
        voiceSwitch.setOnCheckedChangeListener((button, checked) ->
                AppStateStore.setVoiceEnabled(this, checked));
        return scroll;
    }

    private void startReading() {
        SessionLedger.ensureActive(this, AppStateStore.provider(this), AppStateStore.dealer(this));
        if (AppStateStore.captureActive(this)) {
            Intent service = new Intent(this, ScreenCaptureService.class)
                    .setAction(ScreenCaptureService.ACTION_START)
                    .putExtra(ScreenCaptureService.EXTRA_PIPELINE_MODE,
                            ScreenCaptureService.MODE_STANDALONE_OCR);
            startForegroundService(service);
            Toast.makeText(this, "Leitura OCR já está ativa.", Toast.LENGTH_SHORT).show();
            refreshState();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager)
                getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    private void enterFloatingMode() {
        if (!AppStateStore.captureActive(this)) {
            Toast.makeText(this, "Inicie a leitura OCR primeiro.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(permission);
            Toast.makeText(this,
                    "Autorize a bolha da Aurum. Depois toque em Modo flutuante novamente.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this,
                "Aurum continua lendo por OCR. Abra agora o aplicativo da roleta.",
                Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }

    private void openCalibration() {
        if (!AppStateStore.captureActive(this)) {
            Toast.makeText(this, "Ative a leitura OCR antes de calibrar.", Toast.LENGTH_LONG).show();
            startReading();
            return;
        }
        if (!CaptureRepository.hasLatest()) {
            Toast.makeText(this, "Aguardando uma imagem da tela. Tente novamente em 1 segundo.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(new Intent(this, CalibrationActivity.class));
    }

    private void finishSession() {
        SessionLedger.finishSession(this, null);
        sendServiceAction(ScreenCaptureService.ACTION_STOP);
        Toast.makeText(this, "Sessão finalizada e salva.", Toast.LENGTH_LONG).show();
        refreshState();
    }

    private void showCorrectionDialog() {
        List<Integer> history = AppStateStore.loadHistory(this);
        if (history.isEmpty()) {
            Toast.makeText(this, "Histórico vazio.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("CORRIGIR ÚLTIMO GIRO")
                .setItems(new String[]{"Substituir último número", "Remover último número"},
                        (dialog, which) -> {
                            if (which == 0) {
                                showNumberDialog("SUBSTITUIR ÚLTIMO", history.get(0),
                                        n -> sendNumberAction(ScreenCaptureService.ACTION_REPLACE_LATEST, n));
                            } else {
                                sendServiceAction(ScreenCaptureService.ACTION_REMOVE_LATEST);
                            }
                        })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private interface NumberConsumer { void accept(int value); }

    private void showNumberDialog(String title, int current, NumberConsumer consumer) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("0–36");
        if (current >= 0) input.setText(String.valueOf(current));
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(input)
                .setPositiveButton("Confirmar", (dialog, which) -> {
                    try {
                        int value = Integer.parseInt(input.getText().toString().trim());
                        if (value < 0 || value > 36) throw new NumberFormatException();
                        consumer.accept(value);
                    } catch (NumberFormatException error) {
                        Toast.makeText(this, "Digite um número de 0 a 36.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void sendNumberAction(String action, int number) {
        Intent service = new Intent(this, ScreenCaptureService.class)
                .setAction(action)
                .putExtra(ScreenCaptureService.EXTRA_MANUAL_NUMBER, number);
        startForegroundService(service);
    }

    private void sendServiceAction(String action) {
        Intent service = new Intent(this, ScreenCaptureService.class).setAction(action);
        startForegroundService(service);
    }

    private void refreshState() {
        if (radarBar == null) return;
        boolean capture = AppStateStore.captureActive(this);
        boolean calibrated = AppStateStore.isCalibrated(this);
        int score = AppStateStore.radarScore(this);
        int families = AppStateStore.radarFamilies(this);
        String decision = AppStateStore.radarDecision(this);
        String headline = AppStateStore.radarHeadline(this);
        String playLabel = AppStateStore.radarPlayLabel(this);
        String detail = AppStateStore.radarDetail(this);
        String reasons = AppStateStore.radarReasons(this);
        long updated = AppStateStore.radarUpdatedAt(this);

        radarBar.setProgress(score);
        radarValue.setText("RADAR " + score + "/100");
        radarValue.setTextColor(score >= 70 ? Ui.GREEN : score >= 60 ? Ui.AMBER : Ui.TEXT);
        String phase = decision == null || decision.isEmpty() ? "ANALISANDO" : decision;
        radarMeta.setText(phase + " • " + families + " confluências independentes");
        radarReasons.setText(reasons == null || reasons.trim().isEmpty()
                ? "Aguardando confluências confirmadas entre famílias diferentes."
                : reasons);

        signalTitle.setText(headline == null || headline.trim().isEmpty() ? "ANALISANDO" : headline);
        signalTitle.setTextColor(signalColor(headline, decision));
        signalTarget.setText(playLabel == null || playLabel.trim().isEmpty()
                ? (capture ? "ANALISANDO" : "OCR PARADO") : playLabel);
        signalMeta.setText(detail == null || detail.trim().isEmpty()
                ? "Aguardando leitura." : compactDetail(detail));

        List<Integer> history = AppStateStore.loadHistory(this);
        historyText.setText(historyLine(history));
        String age = updated <= 0 ? "—" : String.format(Locale.US, "%.1fs",
                Math.max(0, System.currentTimeMillis() - updated) / 1000.0);
        ocrStatus.setText("OCR " + (capture ? "ATIVO" : "PARADO")
                + " • ROI " + (calibrated ? "CALIBRADA ✓" : "NÃO CALIBRADA")
                + " • " + history.size() + " números • radar atualizado " + age);
        ocrStatus.setTextColor(capture && calibrated ? Ui.GREEN : Ui.AMBER);

        liveBadge.setText(capture ? "● OCR ATIVO" : "● OCR PARADO");
        liveBadge.setTextColor(capture ? Ui.GREEN : Ui.AMBER);
        startButton.setText(capture ? "✓ LEITURA OCR ATIVA" : "▶ INICIAR LEITURA OCR");
        floatButton.setEnabled(capture);
        precisionSwitch.setChecked(AppStateStore.conservativeMode(this));
        voiceSwitch.setChecked(AppStateStore.voiceEnabled(this));
        sessionText.setText(SessionLedger.sessionSummary(this));
    }

    private static String compactDetail(String detail) {
        String value = detail.replace("\\n", " • ").replaceAll("\\s+", " ").trim();
        return value.length() > 260 ? value.substring(0, 260) + "…" : value;
    }

    private static String historyLine(List<Integer> history) {
        if (history == null || history.isEmpty()) return "Últimos: —";
        StringBuilder out = new StringBuilder("Últimos: ");
        int end = Math.min(15, history.size());
        for (int i = 0; i < end; i++) {
            if (i > 0) out.append(" • ");
            out.append(history.get(i));
        }
        return out.toString();
    }

    private static int signalColor(String headline, String decision) {
        String value = ((headline == null ? "" : headline) + " "
                + (decision == null ? "" : decision)).toUpperCase(Locale.ROOT);
        if (value.contains("ENTRADA") || value.contains("STRYKE") || value.contains("HIT")) return Ui.GREEN;
        if (value.contains("PREPAR") || value.contains("CONFLU") || value.contains("OBSERV")) return Ui.AMBER;
        if (value.contains("EXPIR") || value.contains("INVALID")) return Ui.RED;
        return Ui.CYAN;
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    private void registerStateReceiver() {
        IntentFilter filter = new IntentFilter(MainActivity.ACTION_STATE_UPDATED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, filter);
        }
        receiverRegistered = true;
    }
}
