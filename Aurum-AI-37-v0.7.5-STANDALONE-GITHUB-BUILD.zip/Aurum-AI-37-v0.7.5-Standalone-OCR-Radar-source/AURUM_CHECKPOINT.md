# AURUM AI 37 — CHECKPOINT OFICIAL

## Versão em preparação
Aurum AI 37 v0.7.3 — Stability Pipeline

## Base física
v0.7.2 Integrated Operational instalada/testada no Samsung S25 FE.
Resultado físico da v0.7.2: REPROVADA em estabilidade operacional.
Motor estratégico demonstrou comportamento útil, porém a aquisição/continuidade do histórico apresentou paradas, bootstrap parcial e dependência de intervenção manual.

## Objetivo único da v0.7.3
Estabilizar o pipeline operacional sem alterar a lógica estratégica do CORE.

## Implementado
- `versionCode 4` / `versionName 0.7.3-stability-pipeline`.
- CORE estratégico congelado: 17/17 arquivos conferidos por SHA-256.
- `ReadingPipelineController` com fases IDLE / BOOTSTRAP / TRACKING / RECOVERING / FINISHED.
- Fonte operacional única e sticky: DOM ou OCR; nunca dois motores alimentando o CORE em paralelo.
- ScreenCaptureService em `MODE_INTEGRATED_SOURCE_ONLY`: captura/OCR publica dados, mas não executa RadarSession/overlay Stable durante sessão Integrated.
- Interface Stable bloqueada enquanto a leitura Integrated está ativa.
- BOOTSTRAP completo: ao iniciar sessão, uma fonte saudável carrega de uma vez o histórico visível antes do TRACKING.
- Preferência de bootstrap por fonte visual OCR quando DOM/OCR estão em empate ou quase empate; DOM claramente mais completo ainda pode ser escolhido.
- TRACKING incremental-only: depois do bootstrap, snapshots inteiros não substituem o CORE. Apenas deltas temporais comprovados entram como giros novos.
- Reconciliação de failover por `SourceDelta` contra o histórico confirmado do CORE.
- Failover simétrico por progresso: se standby enxerga giro ainda ausente do CORE por duas confirmações, ele assume mesmo quando a fonte ativa continua emitindo heartbeat.
- Watchdog de saúde de fonte e fase RECOVERING.
- OCR hot standby com ROI calibrada, heartbeat e estabilização de duas leituras.
- DOM com histerese de lock, relock automático e memória estrutural por host/provedor.
- Correção/manual protegidos contra eco atrasado de DOM/OCR.
- Pulsos visuais de pipeline e Radar, contadores de scan/análise, fonte ativa, CORE, último giro, failovers e recuperações.
- DOM continua coletando contexto auxiliar (racetrack/timeline/estatísticas/etc.) sem enviar esses números ao histórico.

## Testes executados localmente
PASS PrecisionCoreTest
PASS DualTargetCoreTest
PASS V063BalancedCalibrationTest
PASS IntegratedOperationalTest
PASS SourceOrderTrackerTest
PASS ManualEchoReconcilerTest
PASS ReadingPipelineControllerTest
PASS v073_static_validation.py
PASS CORE_PRESERVATION 17/17

## Build Android local
NÃO concluído no ambiente local.
Motivo: Gradle Wrapper 8.9 não está em cache e `services.gradle.org` não é acessível no ambiente atual (UnknownHostException).
Isso não é erro de código confirmado; o build final deve ser realizado no GitHub Actions, como na v0.7.2.

## Estado real
IMPLEMENTADO: SIM — candidato v0.7.3 preparado
TESTES HOST/ESTÁTICOS: PASS
CORE PRESERVADO: PASS 17/17
COMPILADO ANDROID/GRADLE: PENDENTE GITHUB ACTIONS
APK v0.7.3: AINDA NÃO GERADO
INSTALADO S25 FE: NÃO
TESTADO FISICAMENTE S25 FE: NÃO

## Critério de aprovação física
A v0.7.3 só deve ser aprovada depois de sessão longa no Samsung S25 FE:
1. iniciar leitura uma única vez;
2. bootstrap carregar todo histórico visível de uma vez;
3. acompanhar giros consecutivos automaticamente;
4. não exigir limpar/reiniciar/finalizar para recuperar leitura;
5. DOM/OCR trocar automaticamente quando necessário sem duplicar giros;
6. gráficos, telemetria e Radar permanecerem vivos e coerentes;
7. CORE receber apenas giros confirmados;
8. sinais/placar permanecerem associados à sessão;
9. login/WebView/cookies permanecerem funcionais;
10. instalação por cima da v0.7.2 preservar dados/assinatura.

## Próximo passo exato
1. Subir `Aurum-AI-37-Integrated-LAB-GITHUB-BUILD.zip` atualizado na raiz do repositório, substituindo o anterior.
2. Manter `.github/workflows/build-integrated.yml` apontando para esse ZIP.
3. Rodar GitHub Actions `Build Aurum v0.7.3 Stability Pipeline`.
4. Validar package/versionCode/versionName/certificado/alinhamento.
5. Instalar APK por cima da v0.7.2 sem desinstalar/limpar dados.
6. Executar teste físico longo.
