package com.xspaceart.radar30;

import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.TargetRanking;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * v0.7.6: transforma o estado interno do Radar em um painel legível.
 * Os percentuais de apoio abaixo são índices normalizados do mapa interno;
 * não representam probabilidade matemática do próximo giro.
 */
public final class RadarBackstageFormatter {
    private RadarBackstageFormatter() {}

    public static String focus(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.target < 0) {
            return "FOCO • ainda sem candidato dominante";
        }
        StringBuilder out = new StringBuilder();
        out.append("FOCO AGORA • ").append(verdict.playLabel());
        if (!verdict.coverage.isEmpty()) {
            out.append("\nCobertura física: ").append(numbers(verdict.coverage));
        }
        out.append("\nEspacial: ").append(spatial(verdict.spatialRegime))
                .append(" • formato: ").append(shape(verdict.signalShape))
                .append(" • dispersão global ").append(percent(verdict.evidenceDispersion));
        return out.toString();
    }

    /** Mostra os três polos independentes mesmo antes de existir hipótese oficial. */
    public static String sectorRanking(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.heatMap == null || verdict.heatMap.length < 37) {
            return "ALVOS EM DISPUTA • aguardando mapa";
        }
        TargetRanking ranking = TargetRanking.fromHeatMap(verdict.heatMap);
        StringBuilder out = new StringBuilder("ALVOS EM DISPUTA");
        appendCandidate(out, "\n1º", ranking.primary);
        if (ranking.secondary != null && ranking.secondary.target >= 0) {
            appendCandidate(out, "\n2º", ranking.secondary);
        }
        if (ranking.third != null && ranking.third.target >= 0) {
            appendCandidate(out, "\n3º", ranking.third);
        }
        out.append("\nMargem do líder: ").append(percent(ranking.primaryMargin))
                .append(" • mapa ").append(spatial(ranking.spatialRegime));
        return out.toString();
    }

    public static String heat(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.heatMap == null || verdict.heatMap.length < 37) {
            return "QUENTE / FRIO • aguardando mapa";
        }
        List<HeatPoint> points = new ArrayList<>();
        for (int number = 0; number < 37; number++) {
            points.add(new HeatPoint(number, safe(verdict.heatMap[number])));
        }
        points.sort(Comparator.comparingDouble((HeatPoint p) -> p.value).reversed()
                .thenComparingInt(p -> p.number));
        StringBuilder out = new StringBuilder("QUENTE • ");
        for (int i = 0; i < Math.min(5, points.size()); i++) {
            if (i > 0) out.append("  ");
            HeatPoint p = points.get(i);
            out.append(p.number).append(" ").append(percent(p.value));
        }
        out.append("\nFRIO / MENOR APOIO • ");
        int start = Math.max(0, points.size() - 4);
        for (int i = start; i < points.size(); i++) {
            if (i > start) out.append("  ");
            HeatPoint p = points.get(i);
            out.append(p.number).append(" ").append(percent(p.value));
        }
        out.append("\nApoio relativo do Radar; não é chance matemática do próximo giro.");
        return out.toString();
    }

    public static String families(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.supportingFamilies == null
                || verdict.supportingFamilies.isEmpty()) {
            return "FAMÍLIAS DO FOCO • nenhuma família independente confirmada";
        }
        StringBuilder out = new StringBuilder("FAMÍLIAS DO FOCO • ");
        appendFamilies(out, verdict.supportingFamilies);
        out.append("\nTotal: ").append(verdict.independentFamilies)
                .append(" • contradição ").append(percent(verdict.contradictionScore))
                .append(" • dominância ").append(percent(verdict.dominanceMargin));
        if (verdict.secondaryQualified && verdict.secondaryTarget >= 0
                && verdict.secondarySupportingFamilies != null
                && !verdict.secondarySupportingFamilies.isEmpty()) {
            out.append("\n2º polo ").append(verdict.secondaryTarget).append(" • ");
            appendFamilies(out, verdict.secondarySupportingFamilies);
        }
        return out.toString();
    }

    /** Explica exatamente o que ainda falta para a política liberar o sinal. */
    public static String gate(ConfluenceVerdict verdict, SignalUpdate update) {
        if (verdict == null) return "RÉGUA • aguardando veredito do CORE";
        if (verdict.mode == ConfluenceVerdict.Mode.PRECISION) {
            return precisionGate(verdict, update);
        }
        return balancedGate(verdict, update);
    }

    private static String balancedGate(ConfluenceVerdict v, SignalUpdate u) {
        boolean rawScore = v.aurumScore >= 72;
        boolean rawFamilies = v.independentFamilies >= 4;
        boolean rawContradiction = v.contradictionScore <= 0.26;
        boolean rawDominance = v.dominanceMargin >= 0.07 || v.secondaryQualified;
        boolean predictive = predictive(v.supportingFamilies);
        boolean recent = recent(v.supportingFamilies);
        boolean dispersed = v.signalShape == TargetRanking.SignalShape.HIGH_DISPERSION;

        // Exceção operacional v0.7.6: caso como o observado fisicamente (Radar ~60,
        // 5 famílias, contradição baixa e dominância local forte) não precisa esperar
        // a região "bater de novo" só para provar algo que o mapa já mostrou.
        boolean fastScore = v.aurumScore >= 60;
        boolean fastFamilies = v.independentFamilies >= 5;
        boolean fastContradiction = v.contradictionScore <= 0.20;
        boolean fastDominance = v.dominanceMargin >= 0.15;
        boolean fastTrack = fastScore && fastFamilies && fastContradiction
                && fastDominance && predictive && recent;

        int updates = u == null ? 0 : Math.max(0, u.nextRound);
        boolean persistentRoute = updates >= 2 && v.aurumScore >= 64
                && v.independentFamilies >= 4 && v.contradictionScore <= 0.32
                && (v.dominanceMargin >= 0.04 || v.secondaryQualified)
                && predictive && recent && !dispersed;

        StringBuilder out = new StringBuilder("RÉGUA BALANCED • ");
        if (v.entryQualified) out.append("ENTRADA BRUTA QUALIFICADA");
        else if (fastTrack) out.append("FAST TRACK QUALIFICADO");
        else if (persistentRoute) out.append("ROTA PERSISTENTE QUALIFICADA");
        else if (v.decision == ConfluenceVerdict.Decision.PREPARE) out.append("PREPARAR");
        else if (v.decision == ConfluenceVerdict.Decision.OBSERVE) out.append("OBSERVAR");
        else out.append("AINDA SEM GATE");

        out.append("\nEntrada bruta 72+: score ").append(v.aurumScore)
                .append(" ").append(check(rawScore))
                .append(" • 4+ famílias ").append(check(rawFamilies))
                .append(" • contradição ≤26% ").append(check(rawContradiction))
                .append(" • dominância ≥7%/2º polo ").append(check(rawDominance));

        out.append("\nFAST TRACK 60+: 5+ famílias ").append(check(fastFamilies))
                .append(" • contradição ≤20% ").append(check(fastContradiction))
                .append(" • dominância ≥15% ").append(check(fastDominance));
        out.append("\nPreditivo ").append(check(predictive))
                .append(" • recente ").append(check(recent))
                .append(" • persistência atual ").append(updates);
        out.append("\nConfirmação = estrutura/persistência; não é necessário o alvo acertar novamente.");

        if (dispersed && !fastTrack) {
            out.append("\nBLOQUEIO ATUAL • mapa muito disperso. Só a exceção FAST TRACK pode liberar nessa condição.");
        } else if (dispersed) {
            out.append("\nDISPERSÃO ALTA, mas o polo local passou a exceção FAST TRACK.");
        } else if (!v.entryQualified && !fastTrack && !persistentRoute) {
            out.append("\nFalta: completar uma das três rotas acima; não é necessário o alvo acertar para confirmar.");
        }
        return out.toString();
    }

    private static String precisionGate(ConfluenceVerdict v, SignalUpdate u) {
        int need = Math.max(0, 82 - v.aurumScore);
        boolean fam = v.independentFamilies >= 6;
        boolean contradiction = v.contradictionScore <= 0.16;
        boolean dominance = v.dominanceMargin >= 0.16 || v.secondaryQualified;
        boolean dispersion = v.signalShape == TargetRanking.SignalShape.HIGH_DISPERSION;
        int updates = u == null ? 0 : Math.max(0, u.nextRound);
        StringBuilder out = new StringBuilder("RÉGUA PRECISION • ");
        out.append(v.entryQualified ? "CORE QUALIFICOU" : "AGUARDANDO");
        out.append("\nScore ").append(v.aurumScore).append("/82 ")
                .append(need == 0 ? "✓" : "• faltam " + need)
                .append(" • 6 famílias (ou 5 excepcionais) ").append(check(fam));
        out.append("\nContradição ≤16% ").append(check(contradiction))
                .append(" • dominância forte ").append(check(dominance))
                .append(" • persistência ").append(updates);
        if (dispersion) out.append("\nBLOQUEIO • HIGH_DISPERSION");
        return out.toString();
    }

    private static boolean predictive(List<EvidenceFamily> families) {
        if (families == null) return false;
        return families.contains(EvidenceFamily.TRANSITION)
                || families.contains(EvidenceFamily.SEQUENCE)
                || families.contains(EvidenceFamily.HISTORICAL_SIMILARITY)
                || families.contains(EvidenceFamily.WHEEL_GEOMETRY);
    }

    private static boolean recent(List<EvidenceFamily> families) {
        if (families == null) return false;
        return families.contains(EvidenceFamily.RECENCY)
                || families.contains(EvidenceFamily.REGIME)
                || families.contains(EvidenceFamily.TRANSITION);
    }

    private static void appendCandidate(StringBuilder out, String rank, TargetRanking.Candidate c) {
        out.append(rank).append(" alvo ").append(c.target)
                .append(" +2V • apoio ").append(percent(c.score));
        if (c.coverage != null && !c.coverage.isEmpty()) {
            out.append(" • ").append(numbers(c.coverage));
        }
    }

    private static void appendFamilies(StringBuilder out, List<EvidenceFamily> families) {
        for (int i = 0; i < families.size(); i++) {
            if (i > 0) out.append(" • ");
            out.append(label(families.get(i)));
        }
    }

    private static String numbers(List<Integer> values) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) out.append("·");
            out.append(values.get(i));
        }
        return out.toString();
    }

    private static String check(boolean value) { return value ? "✓" : "✕"; }

    private static double safe(double value) {
        if (!Double.isFinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }

    private static String percent(double value) {
        return String.format(new Locale("pt", "BR"), "%.0f%%", safe(value) * 100.0);
    }

    private static String spatial(TargetRanking.SpatialRegime regime) {
        if (regime == null) return "—";
        switch (regime) {
            case CONCENTRATED: return "CONCENTRADO";
            case BIMODAL: return "BIMODAL";
            case DISPERSED: return "DISPERSO";
            default: return regime.name();
        }
    }

    private static String shape(TargetRanking.SignalShape value) {
        if (value == null) return "—";
        switch (value) {
            case SINGLE_TARGET: return "ALVO ÚNICO";
            case DUAL_TARGET: return "DUPLO POLO";
            case SINGLE_MACRO_CLUSTER: return "MACRO CLUSTER";
            case HIGH_DISPERSION: return "ALTA DISPERSÃO";
            default: return value.name();
        }
    }

    private static String label(EvidenceFamily family) {
        if (family == null) return "—";
        switch (family) {
            case SEQUENCE: return "sequência";
            case TRANSITION: return "transição";
            case WHEEL_GEOMETRY: return "geometria da roda";
            case TERMINAL: return "terminais";
            case RECENCY: return "recência";
            case FREQUENCY: return "frequência";
            case ARITHMETIC: return "soma/subtração";
            case HISTORICAL_SIMILARITY: return "similaridade";
            case REGIME: return "regime atual";
            case GAP: return "ausência/gap";
            case CLUSTER: return "cluster";
            default: return family.name().toLowerCase(Locale.ROOT);
        }
    }

    private static final class HeatPoint {
        final int number;
        final double value;
        HeatPoint(int number, double value) {
            this.number = number;
            this.value = value;
        }
    }
}
