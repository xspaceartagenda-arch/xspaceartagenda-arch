package com.xspaceart.radar30;

import android.content.Context;
import android.content.SharedPreferences;

import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.SignalUpdate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Persiste sessões e sinais no aparelho e produz a base do aprendizado local. */
public final class SessionLedger {
    private static final String PREFS = "radar30_learning_v2";
    private static final String SESSIONS = "sessions";
    private static final String RECORDS = "records";
    private static final String NEXT_ID = "next_id";
    private static final int MAX_SESSIONS = 60;
    private static final int MAX_RECORDS = 600;
    private static final String ENGINE_V4 = "balanced-v4";
    private static final String ENGINE_V5 = "validation-v5";
    private static final String ENGINE_V6 = "precision-confluence-v1";
    private static final String ENGINE_V7 = "secondary-confluence-v2";
    private static final int MIN_SCOPE_SIGNALS = 100;

    private static final String PENDING = "PENDING";
    private static final String HIT = "HIT";
    private static final String EXPIRED = "EXPIRED";
    private static final String CANCELLED = "CANCELLED";

    private SessionLedger() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized boolean startSession(Context context, String provider,
                                                    String dealer, Long bankStartCents) {
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        if (findActiveSession(sessions) != null) return false;
        try {
            long id = nextId(p);
            sessions.put(newSession(id, provider, dealer, bankStartCents));
            trim(sessions, MAX_SESSIONS);
            return p.edit().putString(SESSIONS, sessions.toString()).commit();
        } catch (JSONException error) {
            return false;
        }
    }

    public static synchronized boolean finishSession(Context context, Long bankEndCents) {
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        JSONArray records = readArray(p, RECORDS);
        JSONObject active = findActiveSession(sessions);
        if (active == null) return false;
        long sessionId = active.optLong("id", -1L);
        try {
            active.put("ended", System.currentTimeMillis());
            if (bankEndCents != null) active.put("bankEnd", Math.max(0L, bankEndCents));
            cancelPendingInternal(records, sessionId);
            return save(p, sessions, records);
        } catch (JSONException error) {
            return false;
        }
    }

    public static synchronized long ensureActive(Context context, String provider, String dealer) {
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        JSONObject active = findActiveSession(sessions);
        if (active != null) return active.optLong("id", -1L);
        try {
            long id = nextId(p);
            sessions.put(newSession(id, provider, dealer, null));
            trim(sessions, MAX_SESSIONS);
            p.edit().putString(SESSIONS, sessions.toString()).commit();
            return id;
        } catch (JSONException error) {
            return -1L;
        }
    }

    public static synchronized boolean hasActiveSession(Context context) {
        return findActiveSession(readArray(prefs(context), SESSIONS)) != null;
    }

    public static synchronized long activeSessionId(Context context) {
        JSONObject session = findActiveSession(readArray(prefs(context), SESSIONS));
        return session == null ? -1L : session.optLong("id", -1L);
    }

    public static synchronized void recordUpdate(Context context, SignalUpdate update,
                                                 List<Integer> newNumbersNewestFirst) {
        if (update == null) return;
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        JSONArray records = readArray(p, RECORDS);
        JSONObject active = findActiveSession(sessions);

        try {
            if ((update.kind == SignalUpdate.Kind.ENTRY
                    || update.kind == SignalUpdate.Kind.TRIAL)
                    && update.nextRound == 1) {
                if (active == null) {
                    long id = nextId(p);
                    active = newSession(id, AppStateStore.provider(context),
                            AppStateStore.dealer(context), null);
                    sessions.put(active);
                }
                long sessionId = active.optLong("id", -1L);
                cancelPendingInternal(records, sessionId);
                records.put(newRecord(context, nextId(p), sessionId, update));
                trim(sessions, MAX_SESSIONS);
                trim(records, MAX_RECORDS);
                save(p, sessions, records);
                return;
            }

            if (active == null) return;
            long activeSessionId = active.optLong("id", -1L);

            if (update.kind == SignalUpdate.Kind.LATE_WATCH
                    || update.kind == SignalUpdate.Kind.LATE_HIT
                    || update.kind == SignalUpdate.Kind.LATE_MISS) {
                JSONObject late = findLateTrackable(records, activeSessionId, update);
                if (late == null) return;
                appendLateResults(late, newNumbersNewestFirst, update.resolvedRound);
                if (update.kind == SignalUpdate.Kind.LATE_HIT) {
                    late.put("lateHitRound", update.resolvedRound);
                    late.put("lateResult", update.eventResult);
                    late.put("lateClosed", true);
                } else if (update.kind == SignalUpdate.Kind.LATE_MISS) {
                    late.put("lateClosed", true);
                }
                save(p, sessions, records);
                return;
            }

            JSONObject pending = findPending(records, activeSessionId);
            if (pending == null) return;

            int roundLimit = update.kind == SignalUpdate.Kind.HIT
                    || update.kind == SignalUpdate.Kind.SECONDARY_HIT
                    || update.kind == SignalUpdate.Kind.EXPIRED
                    ? update.resolvedRound
                    : Math.max(0, update.nextRound - 1);
            appendResults(pending, newNumbersNewestFirst, roundLimit);

            if (update.kind == SignalUpdate.Kind.SECONDARY_HIT) {
                pending.put("secondaryHitRound", update.resolvedRound);
                pending.put("secondaryResult", update.eventResult);
                pending.put("resultType", update.resultType);
                pending.put("primaryAfterSecondary", update.primaryAfterSecondary);
                if (!update.primaryStillActive) {
                    pending.put("outcome", HIT);
                    pending.put("closed", System.currentTimeMillis());
                    pending.put("hitRound", update.resolvedRound);
                    pending.put("result", update.eventResult);
                }
            } else if (update.kind == SignalUpdate.Kind.HIT) {
                pending.put("outcome", HIT);
                pending.put("closed", System.currentTimeMillis());
                pending.put("hitRound", update.resolvedRound);
                pending.put("result", update.eventResult);
                pending.put("resultType", update.resultType);
            } else if (update.kind == SignalUpdate.Kind.EXPIRED) {
                boolean secondaryHit = pending.optInt("secondaryHitRound", 0) > 0;
                pending.put("outcome", secondaryHit ? HIT : EXPIRED);
                pending.put("closed", System.currentTimeMillis());
                pending.put("hitRound", secondaryHit
                        ? pending.optInt("secondaryHitRound", 0) : 0);
                pending.put("result", secondaryHit
                        ? pending.optInt("secondaryResult", -1)
                        : update.eventResult);
                pending.put("resultType", update.resultType);
                pending.put("primaryOutcome", "EXPIRED");
                pending.put("lateClosed", false);
            }
            save(p, sessions, records);
        } catch (JSONException ignored) {
            // Mantém a leitura ativa mesmo se um registro local estiver corrompido.
        }
    }

    public static synchronized void cancelPending(Context context) {
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        JSONArray records = readArray(p, RECORDS);
        JSONObject active = findActiveSession(sessions);
        if (active == null) return;
        cancelPendingInternal(records, active.optLong("id", -1L));
        save(p, sessions, records);
    }

    public static synchronized LearningModel learningModel(Context context) {
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        JSONArray records = readArray(p, RECORDS);
        JSONObject reference = findActiveSession(sessions);
        if (reference == null) reference = latestSession(sessions);
        if (reference == null) return LearningModel.empty();

        String provider = reference.optString("provider", "Roleta ao vivo");
        String dealer = reference.optString("dealer", "");
        Map<Long, JSONObject> sessionById = sessionMap(sessions);

        List<JSONObject> providerRecords = compatibleRecords(resolvedRecords(records, sessionById,
                provider, "", false));
        List<JSONObject> exactRecords = dealer.isEmpty()
                ? providerRecords
                : compatibleRecords(resolvedRecords(records, sessionById, provider, dealer, true));
        List<JSONObject> selected = exactRecords.size() >= MIN_SCOPE_SIGNALS
                ? exactRecords : providerRecords;

        Map<String, int[]> evidence = new LinkedHashMap<>();
        int hits = 0;
        double expectedHits = 0.0;
        int validationStart = selected.size() / 2;
        for (int index = 0; index < selected.size(); index++) {
            JSONObject record = selected.get(index);
            boolean hit = HIT.equals(record.optString("outcome"));
            boolean validation = index >= validationStart;
            if (hit) hits++;
            int coverageSize = coverageSize(record);
            expectedHits += LearningModel.threeSpinBaseline(coverageSize);
            String model = LearningModel.modelFeature(coverageSize);
            String band = LearningModel.strengthBand(
                    record.optInt("strength", 0), coverageSize);
            addEvidence(evidence, model, hit, validation);
            addEvidence(evidence, band, hit, validation);
            JSONArray features = record.optJSONArray("features");
            if (features == null) continue;
            for (int i = 0; i < features.length(); i++) {
                String feature = features.optString(i, "");
                if (!feature.isEmpty()
                        && !feature.equals(band)
                        && !feature.equals(model)) {
                    addEvidence(evidence, feature, hit, validation);
                }
            }
        }
        return new LearningModel(evidence, selected.size(), hits, expectedHits);
    }

    public static synchronized String sessionSummary(Context context) {
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        JSONArray records = readArray(p, RECORDS);
        JSONObject session = findActiveSession(sessions);
        boolean active = session != null;
        if (session == null) session = latestSession(sessions);
        if (session == null) return "Nenhuma sessão iniciada.";

        long id = session.optLong("id", -1L);
        int hit = 0;
        int expired = 0;
        int pending = 0;
        int lateHits = 0;
        for (int i = 0; i < records.length(); i++) {
            JSONObject record = records.optJSONObject(i);
            if (record == null || record.optLong("session", -2L) != id) continue;
            String outcome = record.optString("outcome", "");
            if (HIT.equals(outcome)) hit++;
            else if (EXPIRED.equals(outcome)) {
                expired++;
                if (record.optInt("lateHitRound", 0) > 3) lateHits++;
            }
            else if (PENDING.equals(outcome)) pending++;
        }
        int resolved = hit + expired;
        StringBuilder out = new StringBuilder();
        out.append(active ? "SESSÃO ATIVA" : "SESSÃO FINALIZADA");
        out.append(" • ").append(sessionLabel(session));
        out.append("\n").append(hit).append(" STRYKES • ")
                .append(expired).append(" LOSS/REDS");
        if (lateHits > 0) out.append(" • ").append(lateHits).append(" apareceram tardio");
        if (pending > 0) out.append(" • ").append(pending).append(" em auditoria");
        if (resolved > 0) out.append(" • ").append(Math.round(hit * 100.0 / resolved))
                .append("% observado em 3");

        long start = session.optLong("bankStart", -1L);
        long end = session.optLong("bankEnd", -1L);
        if (start >= 0) {
            out.append("\nBanca: ").append(currency(start));
            if (end >= 0) {
                long difference = end - start;
                out.append(" → ").append(currency(end)).append(" (")
                        .append(difference >= 0 ? "+" : "").append(currency(difference)).append(")");
            } else {
                out.append(" → aguardando fechamento");
            }
        }
        return out.toString();
    }

    public static synchronized String sessionArchive(Context context, int limit) {
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        JSONArray records = readArray(p, RECORDS);
        if (sessions.length() == 0) return "Nenhuma sessão salva.";
        int wanted = Math.max(1, limit);
        StringBuilder out = new StringBuilder();
        int shown = 0;
        SimpleDateFormat format = new SimpleDateFormat("dd/MM HH:mm", new Locale("pt", "BR"));
        for (int i = sessions.length() - 1; i >= 0 && shown < wanted; i--) {
            JSONObject session = sessions.optJSONObject(i);
            if (session == null) continue;
            long id = session.optLong("id", -1L);
            int hit = 0;
            int red = 0;
            int pending = 0;
            for (int r = 0; r < records.length(); r++) {
                JSONObject record = records.optJSONObject(r);
                if (record == null || record.optLong("session", -2L) != id) continue;
                String outcome = record.optString("outcome", "");
                if (HIT.equals(outcome)) hit++;
                else if (EXPIRED.equals(outcome)) red++;
                else if (PENDING.equals(outcome)) pending++;
            }
            if (shown > 0) out.append("\n\n");
            long started = session.optLong("started", 0L);
            long ended = session.optLong("ended", 0L);
            out.append(ended == 0L ? "● ATIVA" : "■ FINALIZADA")
                    .append(" • ")
                    .append(started > 0L ? format.format(new Date(started)) : "sem horário")
                    .append(" • ").append(sessionLabel(session))
                    .append("\n").append(hit).append(" STRYKES • ")
                    .append(red).append(" LOSS/REDS");
            if (pending > 0) out.append(" • ").append(pending).append(" pendente");
            int resolved = hit + red;
            if (resolved > 0) out.append(" • ").append(Math.round(hit * 100.0 / resolved))
                    .append("% observado");
            long bankStart = session.optLong("bankStart", -1L);
            long bankEnd = session.optLong("bankEnd", -1L);
            if (bankStart >= 0) {
                out.append("\nBanca ").append(currency(bankStart));
                if (bankEnd >= 0) out.append(" → ").append(currency(bankEnd));
            }
            shown++;
        }
        return shown == 0 ? "Nenhuma sessão salva." : out.toString();
    }

    public static synchronized String recentSignals(Context context, int limit) {
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        JSONArray records = readArray(p, RECORDS);
        JSONObject session = findActiveSession(sessions);
        if (session == null) session = latestSession(sessions);
        if (session == null) return "Nenhuma hipótese registrada.";
        long sessionId = session.optLong("id", -1L);

        StringBuilder out = new StringBuilder();
        int shown = 0;
        for (int i = records.length() - 1; i >= 0 && shown < limit; i--) {
            JSONObject record = records.optJSONObject(i);
            if (record == null || record.optLong("session", -2L) != sessionId) continue;
            String outcome = record.optString("outcome", "");
            if (CANCELLED.equals(outcome)) continue;
            if (shown > 0) out.append("\n");
            String resultType = record.optString("resultType", "");
            if (HIT.equals(outcome) && resultType.startsWith("SECONDARY_HIT")) {
                out.append("⚡ SECONDARY HIT • ");
            } else if (HIT.equals(outcome)) out.append("⚡ STRYKE • ");
            else if (EXPIRED.equals(outcome)) out.append("🔴 RED • ");
            else out.append("🎯 ATIVO • ");
            int strength = record.optInt("strength", 0);
            String playLabel = record.optString("playLabel", "");
            if (playLabel.isEmpty()) playLabel = "Alvo " + record.optInt("target", -1);
            out.append(playLabel)
                    .append(" • Aurum Score ").append(strength).append("/100")
                    .append(" • ").append(classification(strength));
            if (HIT.equals(outcome)) {
                out.append(" • confirmou no giro ").append(record.optInt("hitRound", 0))
                        .append(" (").append(record.optInt("result", -1)).append(")");
            } else if (EXPIRED.equals(outcome)) {
                int lateRound = record.optInt("lateHitRound", 0);
                if (lateRound > 3) {
                    out.append(" • não confirmou em 3; apareceu tardio no giro ")
                            .append(lateRound).append(" (")
                            .append(record.optInt("lateResult", -1)).append(")");
                } else if (record.optBoolean("lateClosed", false)) {
                    out.append(" • não apareceu até o giro 5");
                } else {
                    out.append(" • não confirmou em 3; observando 4–5");
                }
            } else {
                JSONArray rounds = record.optJSONArray("rounds");
                out.append(" • sinal giro ")
                        .append(rounds == null ? 1 : rounds.length() + 1).append("/3");
                if (record.optInt("secondaryHitRound", 0) > 0) {
                    out.append(" • Secondary confirmou no giro ")
                            .append(record.optInt("secondaryHitRound", 0))
                            .append("; Primary em novo Raio-X");
                }
            }
            shown++;
        }
        return shown == 0 ? "Nenhum sinal registrado." : out.toString();
    }

    public static synchronized String learningSummary(Context context) {
        LearningModel model = learningModel(context);
        String scope = learningScope(context);
        if (model.resolvedSignals() == 0) {
            return "Auditoria prospectiva: aguardando hipóteses encerradas • " + scope;
        }
        String rate = String.format(new Locale("pt", "BR"), "%.1f%%",
                model.observedHitRate() * 100.0);
        String baseline = String.format(new Locale("pt", "BR"), "%.1f%%",
                model.expectedHitRate() * 100.0);
        int remaining = Math.max(0, LearningModel.MIN_TOTAL_SIGNALS
                - model.resolvedSignals());
        return "Auditoria prospectiva: " + model.resolvedSignals() + " hipóteses • "
                + model.hits() + " confirmadas • " + rate + " observado • "
                + baseline + " chance-base\nBase local: " + scope
                + (model.isActive()
                ? " • amostra mínima atingida; cada cobertura ainda é testada separadamente"
                : " • faltam " + remaining + " para a amostra mínima de 100");
    }

    private static JSONObject newSession(long id, String provider, String dealer,
                                         Long bankStartCents) throws JSONException {
        JSONObject session = new JSONObject();
        session.put("id", id);
        session.put("started", System.currentTimeMillis());
        session.put("ended", 0L);
        session.put("provider", clean(provider, "Roleta ao vivo"));
        session.put("dealer", clean(dealer, ""));
        if (bankStartCents != null) session.put("bankStart", Math.max(0L, bankStartCents));
        return session;
    }

    private static JSONObject newRecord(Context context, long id, long sessionId,
                                        SignalUpdate update) throws JSONException {
        JSONObject record = new JSONObject();
        record.put("id", id);
        record.put("session", sessionId);
        record.put("opened", System.currentTimeMillis());
        record.put("closed", 0L);
        record.put("target", update.target);
        record.put("playLabel", update.playLabel);
        record.put("protectionLabel", update.protectionLabel);
        record.put("strength", update.strength);
        record.put("confluences", update.confluenceCount);
        record.put("outcome", PENDING);
        record.put("hitRound", 0);
        record.put("result", -1);
        record.put("engine", update.kind == SignalUpdate.Kind.ENTRY
                ? ENGINE_V7 : ENGINE_V5);
        record.put("signalType", update.signalType);
        record.put("resultType", update.resultType);
        record.put("spatialRegime", update.spatialRegime);
        record.put("confluenceVelocity", update.confluenceVelocity);
        record.put("secondaryTarget", update.secondaryTarget);
        record.put("secondaryPlayLabel", update.secondaryPlayLabel);
        record.put("secondaryStrength", update.secondaryStrength);
        record.put("secondaryHitRound", 0);
        record.put("secondaryResult", -1);
        record.put("window", 3);
        record.put("rounds", new JSONArray());
        record.put("lateRounds", new JSONArray());
        record.put("lateHitRound", 0);
        record.put("lateResult", -1);
        record.put("lateClosed", false);
        JSONArray coverage = new JSONArray();
        for (int number : update.coverage) coverage.put(number);
        record.put("coverage", coverage);
        JSONArray primaryCoverage = new JSONArray();
        for (int number : update.primaryCoverage) primaryCoverage.put(number);
        record.put("primaryCoverage", primaryCoverage);
        JSONArray protectionCoverage = new JSONArray();
        for (int number : update.protectionCoverage) protectionCoverage.put(number);
        record.put("protectionCoverage", protectionCoverage);
        JSONArray secondaryCoverage = new JSONArray();
        for (int number : update.secondaryCoverage) secondaryCoverage.put(number);
        record.put("secondaryCoverage", secondaryCoverage);
        JSONArray features = new JSONArray();
        for (String feature : update.featureKeys) features.put(feature);
        record.put("features", features);
        JSONArray currentHistory = new JSONArray();
        for (int number : AppStateStore.loadHistory(context)) currentHistory.put(number);
        record.put("currentHistoryAtSignal", currentHistory);
        String snapshot = ShadowAuditStore.latestSnapshotJson(context);
        if (!snapshot.trim().isEmpty()) {
            try {
                JSONObject state = new JSONObject(snapshot);
                if (state.optLong("session", -1L) == sessionId) {
                    record.put("engineSnapshot", state);
                    JSONObject precision = state.optJSONObject("precision");
                    if (precision != null) {
                        record.put("primaryScore", precision.optInt("score", update.strength));
                        record.put("secondaryScore",
                                precision.optInt("secondaryScore", update.secondaryStrength));
                        record.put("thirdScore", precision.optInt("thirdScore", 0));
                        record.put("secondaryMargin",
                                precision.optDouble("secondaryMargin", 0.0));
                        record.put("dualDominance",
                                precision.optDouble("dualDominance", 0.0));
                        record.put("contradiction",
                                precision.optDouble("contradiction", 1.0));
                        record.put("persistence", state.optInt("persistence", 0));
                    }
                }
            } catch (JSONException ignored) {
                // O sinal continua válido mesmo se o snapshot auxiliar falhar.
            }
        }
        return record;
    }

    private static void appendResults(JSONObject record, List<Integer> newestFirst,
                                      int roundLimit) throws JSONException {
        if (newestFirst == null || newestFirst.isEmpty() || roundLimit <= 0) return;
        JSONArray rounds = record.optJSONArray("rounds");
        if (rounds == null) {
            rounds = new JSONArray();
            record.put("rounds", rounds);
        }
        for (int i = newestFirst.size() - 1; i >= 0 && rounds.length() < roundLimit; i--) {
            rounds.put(newestFirst.get(i));
        }
    }

    private static void appendLateResults(JSONObject record, List<Integer> newestFirst,
                                          int resolvedRound) throws JSONException {
        if (newestFirst == null || newestFirst.isEmpty() || resolvedRound < 4) return;
        JSONArray rounds = record.optJSONArray("lateRounds");
        if (rounds == null) {
            rounds = new JSONArray();
            record.put("lateRounds", rounds);
        }
        int limit = Math.min(2, resolvedRound - 3);
        for (int i = newestFirst.size() - 1; i >= 0 && rounds.length() < limit; i--) {
            rounds.put(newestFirst.get(i));
        }
    }

    private static void cancelPendingInternal(JSONArray records, long sessionId) {
        for (int i = 0; i < records.length(); i++) {
            JSONObject record = records.optJSONObject(i);
            if (record == null || record.optLong("session", -2L) != sessionId) continue;
            if (!PENDING.equals(record.optString("outcome"))) continue;
            try {
                record.put("outcome", CANCELLED);
                record.put("closed", System.currentTimeMillis());
            } catch (JSONException ignored) {
                // Próximo registro ainda poderá ser criado.
            }
        }
    }

    private static JSONObject findPending(JSONArray records, long sessionId) {
        for (int i = records.length() - 1; i >= 0; i--) {
            JSONObject record = records.optJSONObject(i);
            if (record != null
                    && record.optLong("session", -2L) == sessionId
                    && PENDING.equals(record.optString("outcome"))) return record;
        }
        return null;
    }

    private static JSONObject findLateTrackable(JSONArray records, long sessionId,
                                                SignalUpdate update) {
        for (int i = records.length() - 1; i >= 0; i--) {
            JSONObject record = records.optJSONObject(i);
            if (record == null
                    || record.optLong("session", -2L) != sessionId
                    || !EXPIRED.equals(record.optString("outcome"))
                    || record.optBoolean("lateClosed", false)) continue;
            if (record.optInt("target", -1) == update.target
                    && record.optString("playLabel", "").equals(update.playLabel)) {
                return record;
            }
        }
        return null;
    }

    private static JSONObject findActiveSession(JSONArray sessions) {
        for (int i = sessions.length() - 1; i >= 0; i--) {
            JSONObject session = sessions.optJSONObject(i);
            if (session != null && session.optLong("ended", 0L) == 0L) return session;
        }
        return null;
    }

    private static JSONObject latestSession(JSONArray sessions) {
        return sessions.length() == 0 ? null : sessions.optJSONObject(sessions.length() - 1);
    }

    private static Map<Long, JSONObject> sessionMap(JSONArray sessions) {
        Map<Long, JSONObject> result = new HashMap<>();
        for (int i = 0; i < sessions.length(); i++) {
            JSONObject session = sessions.optJSONObject(i);
            if (session != null) result.put(session.optLong("id", -1L), session);
        }
        return result;
    }

    private static List<JSONObject> resolvedRecords(JSONArray records,
                                                     Map<Long, JSONObject> sessionById,
                                                     String provider, String dealer,
                                                     boolean exactDealer) {
        List<JSONObject> result = new ArrayList<>();
        for (int i = 0; i < records.length(); i++) {
            JSONObject record = records.optJSONObject(i);
            if (record == null) continue;
            String outcome = record.optString("outcome", "");
            if (!HIT.equals(outcome) && !EXPIRED.equals(outcome)) continue;
            JSONObject session = sessionById.get(record.optLong("session", -1L));
            if (session == null || !provider.equals(session.optString("provider", "Roleta ao vivo"))) continue;
            if (exactDealer && !dealer.equals(session.optString("dealer", ""))) continue;
            result.add(record);
        }
        return result;
    }

    private static List<JSONObject> compatibleRecords(List<JSONObject> records) {
        List<JSONObject> result = new ArrayList<>();
        for (JSONObject record : records) {
            String engine = record.optString("engine", "");
            if (ENGINE_V6.equals(engine) || ENGINE_V7.equals(engine)) {
                result.add(record);
            }
        }
        return result;
    }

    private static int coverageSize(JSONObject record) {
        JSONArray coverage = record.optJSONArray("coverage");
        return coverage == null ? 5 : Math.max(1, coverage.length());
    }

    private static void addEvidence(Map<String, int[]> evidence, String feature,
                                    boolean hit, boolean validation) {
        int[] values = evidence.computeIfAbsent(feature, key -> new int[]{0, 0, 0, 0});
        values[0]++;
        if (hit) values[1]++;
        if (validation) {
            values[2]++;
            if (hit) values[3]++;
        }
    }

    private static String learningScope(Context context) {
        SharedPreferences p = prefs(context);
        JSONArray sessions = readArray(p, SESSIONS);
        JSONArray records = readArray(p, RECORDS);
        JSONObject reference = findActiveSession(sessions);
        if (reference == null) reference = latestSession(sessions);
        if (reference == null) return "sem provedor definido";
        String provider = reference.optString("provider", "Roleta ao vivo");
        String dealer = reference.optString("dealer", "");
        if (dealer.isEmpty()) return provider;
        Map<Long, JSONObject> map = sessionMap(sessions);
        int exact = compatibleRecords(
                resolvedRecords(records, map, provider, dealer, true)).size();
        return exact >= MIN_SCOPE_SIGNALS
                ? provider + " • crupiê " + dealer : provider + " • geral";
    }

    private static String sessionLabel(JSONObject session) {
        String provider = session.optString("provider", "Roleta ao vivo");
        String dealer = session.optString("dealer", "");
        return dealer.isEmpty() ? provider : provider + " • " + dealer;
    }

    private static String classification(int strength) {
        if (strength >= 82) return "CONFLUÊNCIA FORTE";
        if (strength >= 72) return "EM PREPARAÇÃO";
        return "OBSERVAÇÃO";
    }

    private static String clean(String value, String fallback) {
        if (value == null || value.trim().isEmpty()) return fallback;
        String cleaned = value.trim();
        return cleaned.length() > 60 ? cleaned.substring(0, 60) : cleaned;
    }

    private static String currency(long cents) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
        return format.format(cents / 100.0);
    }

    private static long nextId(SharedPreferences p) {
        long stored = p.getLong(NEXT_ID, 1L);
        long id = Math.max(stored, System.currentTimeMillis());
        p.edit().putLong(NEXT_ID, id + 1L).commit();
        return id;
    }

    private static JSONArray readArray(SharedPreferences p, String key) {
        String value = p.getString(key, "[]");
        try {
            return new JSONArray(value == null ? "[]" : value);
        } catch (JSONException error) {
            return new JSONArray();
        }
    }

    private static boolean save(SharedPreferences p, JSONArray sessions, JSONArray records) {
        trim(sessions, MAX_SESSIONS);
        trim(records, MAX_RECORDS);
        return p.edit()
                .putString(SESSIONS, sessions.toString())
                .putString(RECORDS, records.toString())
                .commit();
    }

    private static void trim(JSONArray array, int limit) {
        while (array.length() > limit) array.remove(0);
    }
}
