# AURUM AI 37 — CHECKPOINT v0.7.7 CONSENSUS RADAR

## STATUS
- Design: COMPLETE
- Implementation candidate: COMPLETE
- Host/static tests: PASS
- Android compile: PENDING — local environment cannot resolve services.gradle.org; GitHub Actions required
- Signed APK: PENDING
- Physical S25 FE validation: PENDING

## BASE
v0.7.6 Radar Backstage + Session Archive.

## PRESERVED
- Standalone OCR operating architecture.
- External roulette app/site workflow.
- Floating app/overlay and top signal bubble.
- Session archive and STRYKE/LOSS bookkeeping.
- Package/signing continuity.
- Precision qualification path.

## v0.7.7 CORE IDEA
The engine now searches for the denominator common between independent evidence families in physical roulette space. Different families may call different numbers, but if those native targets fall inside the same 5-number physical sector, they build one consensus pole.

Pipeline:
OCR -> validated history -> independent family heatmaps -> native family peaks -> physical consensus sectors -> leader/runner competition -> momentum -> saturation -> dynamic Balanced gate -> signal.

## NEW SIGNAL ROUTES (BALANCED ONLY)
- Raw/legacy gate.
- Exceptional consensus.
- Mature persistent consensus.
- Leader momentum vs runner.
- Exceptional local pole despite global dispersion.

## SATURATION
Observation touch != official signal. The touched region is structurally saturated for two new spins and cannot be chased unless a genuinely new exceptional consensus rebuilds it.

## PHYSICAL TEST REQUIRED
1. Run external roulette in portrait with stable OCR.
2. Confirm history is exact.
3. Watch 30–60 minutes.
4. Verify top 3 consensus sectors and family-native numbers make sense relative to visible history.
5. Verify leader/runner momentum changes as new results arrive.
6. Verify observation touch activates saturation and does not become STRYKE.
7. Verify signals occur more often than the v0.7.6 long-silence behavior without flooding every few spins.
8. Verify signal overlay remains at top.
9. Verify session archive records only official entries/results.
10. Only then approve physically.
