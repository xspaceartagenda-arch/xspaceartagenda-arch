# Aurum AI 37 — v0.7.5 Standalone OCR Radar checkpoint

## State
Candidate source implemented locally from v0.7.4. Android build not yet executed.

## Why this version exists
v0.7.4 proved that DOM could remain stable yet ingest wrong numbers. OCR in the older Stable path was physically observed to read the roulette history more reliably. The integrated roulette also reduced the visible size of the game/history and the signal gate was too conservative.

## Operational architecture
External roulette app/site -> MediaProjection -> calibrated ROI -> ML Kit OCR -> ScanStabilizer -> ScanSynchronizer -> RadarSession -> Radar UI / overlay / voice / Android notification.

No WebView or DOM participates in the v0.7.5 operational launcher.

## Main changes
- New `StandaloneActivity` is launcher.
- `ScreenCaptureService.MODE_STANDALONE_OCR` uses the proven Stable OCR path and remains owner of the strategic engine in the foreground service.
- Radar 0–100 is the visual center of the UI.
- Major confluence reasons and independent-family count are persisted in `AppStateStore` for the standalone UI.
- Bubble is signal-only and positioned bottom-right by default.
- Dedicated high-priority signal notification channel.
- Balanced operational default; Precision remains available via switch.
- Manual, clear, replace-latest and remove-latest controls retained.

## CORE policy
15/17 v0.7.4 CORE files are byte-identical.
Authorized changes only:
- `PrecisionConfluenceEngine.java`: Balanced entry calibration.
- `RadarSession.java`: Balanced persistence/cadence calibration.
Precision gate is preserved.

## Current validation
IMPLEMENTED=PASS
STATIC_VALIDATION=PASS
HOST_TESTS=PASS
CORE_V074_UNCHANGED=15_OF_17
CORE_AUTHORIZED_BALANCED_GATE=2_OF_17
PRECISION_PRESERVED=PASS
ANDROID_COMPILED=PENDING
PACKAGE_AUDIT=PENDING
SIGNATURE_AUDIT=PENDING
INSTALLED=PENDING
PHYSICAL_S25FE=PENDING

## Physical acceptance criteria
1. Install over v0.7.4 without uninstalling or clearing data.
2. Launch Aurum standalone; no internal roulette/browser is shown.
3. Start OCR and calibrate only the external roulette history ROI.
4. Put Aurum in floating/background mode and open roulette app separately.
5. Verify exact OCR history for at least 30–60 minutes; no invented DOM numbers.
6. Radar must remain visible in Aurum and update score/families/reasons.
7. PREPARE/ENTRY must surface through bottom overlay + notification; voice when enabled.
8. Bubble must not cover the calibrated history ROI in normal placement.
9. Balanced should produce operational signals when a strong 4+ family confluence persists; Precision must remain more selective.
10. Session STRYKE/LOSS tracking and corrections must remain functional.
