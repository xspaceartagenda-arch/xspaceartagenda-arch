package com.xspaceart.radar30;

/** Stub usado somente na recompilação manual contra o APK-base validado. */
public final class R {
    public static final class drawable {
        public static final int ic_radar = 0x7f07006c;

        private drawable() {}
    }

    private R() {}
}
