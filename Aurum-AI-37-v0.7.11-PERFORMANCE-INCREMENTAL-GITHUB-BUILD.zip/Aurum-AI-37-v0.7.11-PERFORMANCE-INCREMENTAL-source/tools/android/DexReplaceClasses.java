import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.immutable.ImmutableDexFile;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

import java.io.File;
import java.util.Map;
import java.util.TreeMap;

/**
 * Substitui, em um DEX-base, apenas as classes presentes em outro DEX.
 * Mantém dependências e classes R do APK Gradle já validado.
 */
public final class DexReplaceClasses {
    private DexReplaceClasses() {}

    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            throw new IllegalArgumentException(
                    "uso: DexReplaceClasses BASE.dex REPLACEMENT.dex OUTPUT.dex");
        }
        DexBackedDexFile base = DexFileFactory.loadDexFile(
                new File(args[0]), null);
        DexBackedDexFile replacement = DexFileFactory.loadDexFile(
                new File(args[1]), base.getOpcodes());

        Map<String, ClassDef> merged = new TreeMap<>();
        for (ClassDef value : base.getClasses()) merged.put(value.getType(), value);
        int replaced = 0;
        for (ClassDef value : replacement.getClasses()) {
            if (merged.put(value.getType(), value) != null) replaced++;
        }
        if (replacement.getClasses().isEmpty()) {
            throw new IllegalStateException("DEX de substituição vazio");
        }

        DexPool.writeTo(args[2], new ImmutableDexFile(
                base.getOpcodes(), merged.values()));
        System.out.println("classes base=" + base.getClasses().size()
                + " replacement=" + replacement.getClasses().size()
                + " substituídas=" + replaced
                + " total=" + merged.size());
    }
}
