import com.xspaceart.radar30.RadarBackstageFormatter;
import com.xspaceart.radar30.core.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** O painel precisa mostrar o denominador comum, disputa e o que falta para entrada. */
public final class V077RadarExplainabilityTest {
    public static void main(String[] args) {
        List<Evidence> evidence = Arrays.asList(
                e(EvidenceFamily.RECENCY, 21), e(EvidenceFamily.TRANSITION, 2),
                e(EvidenceFamily.FREQUENCY, 25), e(EvidenceFamily.ARITHMETIC, 17),
                e(EvidenceFamily.REGIME, 34));
        ConsensusSnapshot consensus = ConsensusSnapshot.analyze(evidence, fused(evidence));
        double[] heat = fused(evidence);
        ConfluenceVerdict v = new ConfluenceVerdict(ConfluenceVerdict.Decision.PREPARE,
                consensus.primary.target, consensus.primary.coverage,
                Arrays.asList(25, 17), 61, 5, 0.18, 0.08, 0.99,
                0.78, 0.70, new RegimeDetector().detect(Collections.emptyList()),
                Arrays.asList(EvidenceFamily.RECENCY, EvidenceFamily.TRANSITION,
                        EvidenceFamily.FREQUENCY, EvidenceFamily.ARITHMETIC, EvidenceFamily.REGIME),
                Collections.singletonList("consenso local"), Collections.emptyList(), heat,
                false, false, false, ConfluenceVerdict.Mode.BALANCED,
                -1, Collections.emptyList(), Collections.emptyList(), 0, 0, 1.0,
                0.0, 0.0, 32, 50, 0.50, TargetRanking.SpatialRegime.DISPERSED,
                TargetRanking.SignalShape.HIGH_DISPERSION,
                Collections.emptyList(), Collections.emptyList(), false, consensus);
        SignalUpdate u = new SignalUpdate(SignalUpdate.Kind.BUILDING, "CONVERGINDO", "",
                v.target, v.coverage, 61, 2, "");

        String sectors = RadarBackstageFormatter.sectorRanking(v, 4.0, -1.0);
        String families = RadarBackstageFormatter.families(v);
        String gate = RadarBackstageFormatter.gate(v, u, 4.0, -1.0, 0);
        contains(sectors, "CONSENSO ESPACIAL");
        contains(sectors, "momentum líder");
        contains(families, "DENOMINADOR COMUM");
        contains(families, "chama 21");
        contains(families, "chama 25");
        contains(gate, "Rotas de entrada");
        contains(gate, "Momentum líder");
        contains(gate, "nunca esperar o setor acertar várias vezes");
        System.out.println("V077_RADAR_EXPLAINABILITY=PASS");
    }

    private static Evidence e(EvidenceFamily f, int target) {
        double[] h = new double[37];
        List<Integer> zone = Wheel.coverage(target, 2);
        double[] w = {0.28, 0.62, 1.0, 0.62, 0.28};
        for (int i = 0; i < zone.size(); i++) h[zone.get(i)] = w[i];
        return new Evidence(f, h, 0.9, 0.92, 28, 0.9, 0.92, 0.05, f + " chama " + target);
    }

    private static double[] fused(List<Evidence> evidence) {
        double[] out = new double[37]; double total = 0.0;
        for (Evidence e : evidence) {
            double w = e.weight(); total += w;
            for (int n = 0; n < 37; n++) out[n] += e.heat[n] * w;
        }
        if (total > 0) for (int n = 0; n < 37; n++) out[n] /= total;
        return out;
    }

    private static void contains(String value, String expected) {
        if (value == null || !value.contains(expected)) {
            throw new AssertionError("Esperado '" + expected + "' em: " + value);
        }
    }
}
