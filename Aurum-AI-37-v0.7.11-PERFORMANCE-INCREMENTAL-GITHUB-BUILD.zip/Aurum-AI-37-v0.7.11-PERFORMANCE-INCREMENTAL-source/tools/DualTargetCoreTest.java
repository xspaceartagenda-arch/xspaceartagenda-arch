import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.RegimeDetector;
import com.xspaceart.radar30.core.SignalPolicy;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.TargetRanking;
import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Cenários de aceitação A–H da evolução Secondary Confluence. */
public final class DualTargetCoreTest {
    public static void main(String[] args) {
        primaryOnly();
        trueDualTarget();
        overlappingMacroCluster();
        highDispersion();
        secondaryHitStrengthensPrimary();
        secondaryHitInvalidatesPrimary();
        prepareHitIsMissedOpportunity();
        expiryDoesNotChase();
        System.out.println("OK dual target core A-H");
    }

    private static void primaryOnly() {
        double[] heat = new double[37];
        deposit(heat, 33, 1.0);
        TargetRanking ranking = TargetRanking.fromHeatMap(heat);
        check(ranking.spatialRegime == TargetRanking.SpatialRegime.CONCENTRATED,
                "A: one pole must be concentrated");
        check(ranking.shape(false) == TargetRanking.SignalShape.SINGLE_TARGET,
                "A: primary must remain single");
    }

    private static void trueDualTarget() {
        double[] heat = new double[37];
        deposit(heat, 33, 1.0);
        deposit(heat, 32, 0.82);
        TargetRanking ranking = TargetRanking.fromHeatMap(heat);
        check(ranking.spatialRegime == TargetRanking.SpatialRegime.BIMODAL,
                "B: two distinct poles must be bimodal");
        check(Wheel.distance(ranking.primary.target, ranking.secondary.target) >= 5,
                "B: poles must be physically independent");
        check(ranking.shape(true) == TargetRanking.SignalShape.DUAL_TARGET,
                "B: qualified second pole must become dual target");
    }

    private static void overlappingMacroCluster() {
        double[] heat = new double[37];
        deposit(heat, 33, 1.0);
        deposit(heat, 20, 0.94);
        TargetRanking ranking = TargetRanking.fromHeatMap(heat);
        check(ranking.shape(false) == TargetRanking.SignalShape.SINGLE_MACRO_CLUSTER,
                "C: overlapping poles must merge into one macro cluster; got "
                        + ranking.shape(false) + " primary=" + ranking.primary.target
                        + " overlapping=" + (ranking.overlappingCluster == null
                        ? -1 : ranking.overlappingCluster.target)
                        + " spatial=" + ranking.spatialRegime);
    }

    private static void highDispersion() {
        double[] heat = new double[37];
        deposit(heat, 33, 1.0);
        deposit(heat, 32, 0.94);
        deposit(heat, 6, 0.92);
        TargetRanking ranking = TargetRanking.fromHeatMap(heat);
        check(ranking.highDispersion,
                "D: three comparable independent poles must be dispersed; primary="
                        + ranking.primary.target + "/" + ranking.primary.score
                        + " secondary=" + ranking.secondary.target + "/"
                        + ranking.secondary.score + " third=" + ranking.third.target
                        + "/" + ranking.third.score + " entropy=" + ranking.entropy);
        check(ranking.shape(true) == TargetRanking.SignalShape.HIGH_DISPERSION,
                "D: high dispersion must veto dual target");
    }

    private static void secondaryHitStrengthensPrimary() {
        ConfluenceVerdict current = verdict(33, 91, 0.10);
        SignalPolicy.PrimaryAfterSecondary result =
                SignalPolicy.classifyPrimaryAfterSecondary(
                        Wheel.coverage(33, 2), 87, current, 2);
        check(result == SignalPolicy.PrimaryAfterSecondary.PRIMARY_STRENGTHENED,
                "E: stronger primary must remain active");
    }

    private static void secondaryHitInvalidatesPrimary() {
        ConfluenceVerdict current = verdict(32, 51, 0.48);
        SignalPolicy.PrimaryAfterSecondary result =
                SignalPolicy.classifyPrimaryAfterSecondary(
                        Wheel.coverage(33, 2), 88, current, 2);
        check(result == SignalPolicy.PrimaryAfterSecondary.PRIMARY_INVALIDATED,
                "F: collapsed primary must be invalidated");
    }

    private static void prepareHitIsMissedOpportunity() {
        check(SignalPolicy.isMissedOpportunity(
                        ConfluenceVerdict.Decision.PREPARE,
                        Wheel.coverage(33, 2), 33, false),
                "G: PREPARE hit before ENTRY must be audited");
        check(!SignalPolicy.isMissedOpportunity(
                        ConfluenceVerdict.Decision.PREPARE,
                        Wheel.coverage(33, 2), 33, true),
                "G: released entry is not missed");
    }

    private static void expiryDoesNotChase() {
        RadarSession session = new RadarSession();
        List<Integer> history = exceptionalHistory();
        session.update(history, Collections.emptyList());
        history = prepend(history, 32);
        session.update(history, Collections.singletonList(32));
        history = prepend(history, 15);
        SignalUpdate entry = session.update(history, Collections.singletonList(15));
        check(entry.kind == SignalUpdate.Kind.ENTRY, "H: fixture must open entry");
        for (int number : new int[]{1, 2}) {
            history = prepend(history, number);
            SignalUpdate active = session.update(history, Collections.singletonList(number));
            check(active.kind == SignalUpdate.Kind.ACTIVE,
                    "H: first two misses remain inside locked window");
        }
        history = prepend(history, 3);
        SignalUpdate expired = session.update(history, Collections.singletonList(3));
        check(expired.kind == SignalUpdate.Kind.EXPIRED,
                "H: third miss must expire");
        history = prepend(history, 4);
        SignalUpdate cooldown = session.update(history, Collections.singletonList(4));
        check(cooldown.kind == SignalUpdate.Kind.COOLDOWN,
                "H: expiry cannot immediately chase the old target");
    }

    private static ConfluenceVerdict verdict(int target, int score,
                                              double contradiction) {
        return new ConfluenceVerdict(ConfluenceVerdict.Decision.ENTRY,
                target, Wheel.coverage(target, 2), Wheel.coverage(target, 1),
                score, 7, contradiction, 0.25, 0.75, 0.90, 0.55,
                new RegimeDetector().detect(Collections.emptyList()),
                Collections.emptyList(),
                Collections.emptyList(), Collections.emptyList(),
                new double[37], true);
    }

    private static void deposit(double[] heat, int center, double amplitude) {
        List<Integer> coverage = Wheel.coverage(center, 2);
        double[] kernel = {0.58, 0.82, 1.0, 0.82, 0.58};
        for (int index = 0; index < coverage.size(); index++) {
            int number = coverage.get(index);
            heat[number] += amplitude * kernel[index];
        }
        double max = 0.0;
        for (double value : heat) max = Math.max(max, value);
        if (max > 1.0) {
            for (int number = 0; number < heat.length; number++) heat[number] /= max;
        }
    }

    private static List<Integer> exceptionalHistory() {
        int[] loop = {32, 15, 19, 0, 26, 32, 19, 15, 26, 0};
        List<Integer> history = new ArrayList<>();
        for (int i = 0; i < 500; i++) history.add(loop[i % loop.length]);
        return history;
    }

    private static List<Integer> prepend(List<Integer> history, int number) {
        List<Integer> result = new ArrayList<>();
        result.add(number);
        result.addAll(history);
        if (result.size() > 500) result.remove(result.size() - 1);
        return result;
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
