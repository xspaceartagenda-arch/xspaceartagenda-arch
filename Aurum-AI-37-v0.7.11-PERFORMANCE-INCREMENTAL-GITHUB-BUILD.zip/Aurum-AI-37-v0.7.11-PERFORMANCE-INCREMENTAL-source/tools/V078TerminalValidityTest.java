import com.xspaceart.radar30.core.*;

import java.util.Arrays;
import java.util.Collections;

/** Janela de 5 é teto: estrutura rompida cancela antes da expiração. */
public final class V078TerminalValidityTest {
    public static void main(String[] args) {
        ConfluenceVerdict stable = verdict(25, terminal(5, 66, 4, 0.80, 0.25, 0.09), 61, 4, 0.80, 0.25);
        assertTrue(TerminalSignalPolicy.terminalStillValid(stable, 5, false),
                "T5 estável deve continuar válido");
        assertTrue(TerminalSignalPolicy.terminalStillValid(stable, 5, true),
                "T5+setor alinhados devem continuar válidos");

        ConfluenceVerdict changedTerminal = verdict(25, terminal(4, 70, 5, 0.84, 0.20, 0.12),
                62, 4, 0.80, 0.24);
        assertFalse(TerminalSignalPolicy.terminalStillValid(changedTerminal, 5, false),
                "troca do terminal líder deve cancelar");

        ConfluenceVerdict broken = verdict(25, terminal(5, 52, 2, 0.62, 0.46, 0.02),
                60, 4, 0.78, 0.26);
        assertFalse(TerminalSignalPolicy.terminalStillValid(broken, 5, false),
                "estrutura terminal fraca deve cancelar");

        ConfluenceVerdict sectorBreak = verdict(17, terminal(5, 66, 4, 0.80, 0.24, 0.09),
                53, 2, 0.62, 0.43);
        assertTrue(TerminalSignalPolicy.terminalStillValid(sectorBreak, 5, false),
                "terminal isolado pode sobreviver a setor divergente");
        assertFalse(TerminalSignalPolicy.terminalStillValid(sectorBreak, 5, true),
                "sinal ouro deve cancelar quando o setor rompe");

        System.out.println("V078_TERMINAL_VALIDITY=PASS maxWindow="
                + TerminalSignalPolicy.TERMINAL_VALIDITY_SPINS + " liveRevalidation=PASS");
    }

    private static TerminalSnapshot terminal(int terminal, int score, int families,
                                             double alignment, double contradiction, double margin) {
        TerminalSnapshot.Candidate p = new TerminalSnapshot.Candidate(terminal, score, families,
                alignment, contradiction, 0.72, 0.76, true, true, Collections.emptyList());
        TerminalSnapshot.Candidate s = new TerminalSnapshot.Candidate((terminal + 1) % 10,
                Math.max(0, score - 10), 3, 0.70, 0.30, 0.58, 0.60, true, true,
                Collections.emptyList());
        return new TerminalSnapshot(p, s, TerminalSnapshot.Candidate.empty(), margin, 6);
    }

    private static ConfluenceVerdict verdict(int sectorTarget, TerminalSnapshot terminal,
                                             int sectorScore, int sectorFamilies,
                                             double sectorAlignment, double sectorContradiction) {
        ConsensusSnapshot.Candidate p = new ConsensusSnapshot.Candidate(sectorTarget, sectorScore,
                sectorFamilies, sectorAlignment, sectorContradiction, 0.70, 0.72,
                true, true, Collections.emptyList());
        ConsensusSnapshot.Candidate s = new ConsensusSnapshot.Candidate(32, 45, 3,
                0.68, 0.32, 0.50, 0.52, true, true, Collections.emptyList());
        ConsensusSnapshot sector = new ConsensusSnapshot(p, s, ConsensusSnapshot.Candidate.empty(),
                0.08, 6);
        double[] heat = new double[37]; heat[sectorTarget] = 1.0;
        return new ConfluenceVerdict(ConfluenceVerdict.Decision.PREPARE, sectorTarget,
                Wheel.coverage(sectorTarget, 2), Arrays.asList(sectorTarget), 60, 4,
                0.22, 0.08, 0.7, 0.7, 0.6,
                new RegimeDetector().detect(Collections.emptyList()), Collections.emptyList(),
                Collections.singletonList("validity synthetic"), Collections.emptyList(), heat,
                false, false, false, ConfluenceVerdict.Mode.BALANCED,
                -1, Collections.emptyList(), Collections.emptyList(), 0, 0, 1.0,
                0.0, 0.0, 32, 40, 0.4, TargetRanking.SpatialRegime.CONCENTRATED,
                TargetRanking.SignalShape.SINGLE_TARGET, Collections.emptyList(),
                Collections.emptyList(), false, sector, terminal);
    }

    private static void assertTrue(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    private static void assertFalse(boolean value, String message) {
        if (value) throw new AssertionError(message);
    }
}
