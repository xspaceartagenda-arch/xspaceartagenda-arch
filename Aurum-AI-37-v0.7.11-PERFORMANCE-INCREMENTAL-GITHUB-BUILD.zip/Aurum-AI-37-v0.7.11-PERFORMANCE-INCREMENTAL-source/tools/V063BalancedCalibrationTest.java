import com.xspaceart.radar30.core.CurrentTableHistory;
import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.SignalUpdate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Regressão simples da calibração Balanced v0.6.3. */
public final class V063BalancedCalibrationTest {
    public static void main(String[] args) {
        if (CurrentTableHistory.MIN_DEEP_SCAN_RESULTS != 36) {
            throw new AssertionError("Warm-up profundo mudou: "
                    + CurrentTableHistory.MIN_DEEP_SCAN_RESULTS);
        }
        Result precision = run(true, 500, 370401L);
        Result balanced = run(false, 500, 370401L);
        if (precision.starts != 0) {
            throw new AssertionError("Precision deveria permanecer rígido neste vetor: "
                    + precision.starts);
        }
        if (balanced.starts < 1) {
            throw new AssertionError("Balanced calibrado não publicou nenhuma entrada.");
        }
        if (balanced.firstStart < CurrentTableHistory.MIN_DEEP_SCAN_RESULTS - 1) {
            throw new AssertionError("Entrada antes do histórico mínimo: " + balanced.firstStart);
        }
        System.out.println("PASS v0.6.3 precision=" + precision.starts
                + " balanced=" + balanced.starts
                + " firstBalancedSpin=" + balanced.firstStart);
    }

    private static Result run(boolean conservative, int spins, long seed) {
        RadarSession session = new RadarSession();
        List<Integer> history = new ArrayList<>();
        Random random = new Random(seed);
        int starts = 0;
        int firstStart = -1;
        for (int spin = 0; spin < spins; spin++) {
            int result = random.nextInt(37);
            history.add(0, result);
            if (history.size() > 500) history.remove(history.size() - 1);
            SignalUpdate update = session.update(history,
                    Collections.singletonList(result), LearningModel.empty(), conservative);
            if (update.kind == SignalUpdate.Kind.ENTRY) {
                starts++;
                if (firstStart < 0) firstStart = spin;
            }
        }
        return new Result(starts, firstStart);
    }

    private static final class Result {
        final int starts;
        final int firstStart;
        Result(int starts, int firstStart) {
            this.starts = starts;
            this.firstStart = firstStart;
        }
    }
}
