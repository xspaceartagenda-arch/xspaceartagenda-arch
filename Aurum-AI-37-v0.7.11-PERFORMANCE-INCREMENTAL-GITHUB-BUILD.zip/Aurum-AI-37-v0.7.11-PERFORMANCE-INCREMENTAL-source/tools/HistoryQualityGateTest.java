import com.xspaceart.radar30.integrated.scanner.HistoryQualityGate;
import java.util.*;

public final class HistoryQualityGateTest {
    private static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
    public static void main(String[] args){
        List<Integer> good=Arrays.asList(17,32,5,21,8,14,29,2,35,11,6,24,19,3,27,9,31,12,4,22,16,7,30,1);
        HistoryQualityGate.Assessment a=HistoryQualityGate.assess(good,17,88,true,92);
        check(a.accepted,"good structured history must pass: "+a.reason);

        List<Integer> board=new ArrayList<>(); for(int i=0;i<=36;i++)board.add(i);
        check(!HistoryQualityGate.assess(board,36,95,true,95).accepted,"0..36 board must be rejected");

        List<Integer> polluted=Arrays.asList(0,0,0,5,0,1,0,5,0,1,0,5,0,1,0,5,0,1,0,5,0,1,0,5);
        check(!HistoryQualityGate.assess(polluted,0,95,true,90).accepted,"repetitive DOM contamination must be rejected");

        List<Integer> tooWide=new ArrayList<>(); for(int i=0;i<121;i++)tooWide.add(i%37);
        check(!HistoryQualityGate.assess(tooWide,0,95,true,90).accepted,"huge region must be rejected");
        System.out.println("HistoryQualityGateTest PASS");
    }
}
