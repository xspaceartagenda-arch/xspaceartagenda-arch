#!/usr/bin/env python3
"""Proxy local de build: entrega repositórios Maven usando curl com cache."""

from __future__ import annotations

import argparse
import hashlib
import os
import pathlib
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit

try:
    import urllib3
except ImportError:  # Pip já inclui uma cópia; evita um curl por artefato no build isolado.
    try:
        from pip._vendor import urllib3
    except ImportError:  # O helper continua portátil mesmo sem a dependência opcional.
        urllib3 = None


UPSTREAMS = {
    "google": "https://dl.google.com/dl/android/maven2",
    "maven": "https://repo.maven.apache.org/maven2",
    "plugins": "https://plugins.gradle.org/m2",
}


class RepositoryHandler(BaseHTTPRequestHandler):
    cache_root: pathlib.Path
    locks: dict[str, threading.Lock] = {}
    locks_guard = threading.Lock()
    http = None

    def do_HEAD(self) -> None:  # noqa: N802
        self._serve(send_body=False)

    def do_GET(self) -> None:  # noqa: N802
        self._serve(send_body=True)

    def _serve(self, send_body: bool) -> None:
        parts = [part for part in unquote(urlsplit(self.path).path).split("/") if part]
        if len(parts) < 2 or parts[0] not in UPSTREAMS or any(part == ".." for part in parts):
            self.send_error(404)
            return

        repository = parts[0]
        relative = "/".join(parts[1:])
        cache_file = self.cache_root / repository / relative
        if not cache_file.is_file() and not self._fetch(repository, relative, cache_file):
            self.send_error(404)
            return

        size = cache_file.stat().st_size
        self.send_response(200)
        self.send_header("Content-Length", str(size))
        self.send_header("Cache-Control", "public, max-age=86400")
        self.end_headers()
        if send_body:
            with cache_file.open("rb") as source:
                while chunk := source.read(256 * 1024):
                    self.wfile.write(chunk)

    def _fetch(self, repository: str, relative: str, destination: pathlib.Path) -> bool:
        key = repository + "/" + relative
        with self.locks_guard:
            lock = self.locks.setdefault(key, threading.Lock())
        with lock:
            if destination.is_file():
                return True
            destination.parent.mkdir(parents=True, exist_ok=True)
            suffix = hashlib.sha256(key.encode("utf-8")).hexdigest()[:12]
            temporary = destination.with_name(destination.name + "." + suffix + ".part")
            url = UPSTREAMS[repository].rstrip("/") + "/" + relative
            if self.http is not None:
                fetched = self._fetch_with_pool(url, temporary)
            else:
                result = subprocess.run(
                    [
                        "curl", "-fL", "--silent", "--retry", "3",
                        "--connect-timeout", "20", "--output", str(temporary), url,
                    ],
                    check=False,
                )
                fetched = result.returncode == 0 and temporary.is_file()
            if not fetched:
                try:
                    temporary.unlink()
                except FileNotFoundError:
                    pass
                return False
            os.replace(temporary, destination)
            return True

    def _fetch_with_pool(self, url: str, destination: pathlib.Path) -> bool:
        if self.http is None:
            return False
        response = None
        try:
            response = self.http.request(
                "GET", url, preload_content=False,
                timeout=urllib3.Timeout(connect=20.0, read=180.0),
                retries=urllib3.Retry(
                    total=3, backoff_factor=0.4,
                    status_forcelist=(429, 500, 502, 503, 504),
                    raise_on_status=False,
                ),
            )
            if response.status != 200:
                return False
            with destination.open("wb") as output:
                for chunk in response.stream(256 * 1024):
                    output.write(chunk)
            return True
        except Exception:
            return False
        finally:
            if response is not None:
                response.release_conn()

    def log_message(self, format_string: str, *args: object) -> None:
        return


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8877)
    parser.add_argument("--cache", default="/tmp/aurum-maven-cache")
    args = parser.parse_args()
    RepositoryHandler.cache_root = pathlib.Path(args.cache)
    RepositoryHandler.cache_root.mkdir(parents=True, exist_ok=True)
    if urllib3 is not None and os.environ.get("AURUM_MAVEN_USE_CURL") != "1":
        proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
        RepositoryHandler.http = urllib3.ProxyManager(
            proxy,
            cert_reqs="CERT_REQUIRED",
            ca_certs="/etc/ssl/certs/ca-certificates.crt",
            maxsize=16,
        ) if proxy else urllib3.PoolManager(
            cert_reqs="CERT_REQUIRED",
            ca_certs="/etc/ssl/certs/ca-certificates.crt",
            maxsize=16,
        )
    server = ThreadingHTTPServer(("127.0.0.1", args.port), RepositoryHandler)
    server.serve_forever()


if __name__ == "__main__":
    main()
