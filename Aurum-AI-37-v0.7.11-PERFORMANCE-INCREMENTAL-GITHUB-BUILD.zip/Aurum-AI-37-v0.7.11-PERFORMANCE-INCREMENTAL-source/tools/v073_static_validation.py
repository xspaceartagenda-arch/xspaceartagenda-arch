from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
errors = []

def need(condition, message):
    if not condition:
        errors.append(message)

build = (ROOT/'app/build.gradle').read_text()
activity = (ROOT/'app/src/main/java/com/xspaceart/radar30/integrated/IntegratedActivity.java').read_text()
service = (ROOT/'app/src/main/java/com/xspaceart/radar30/ScreenCaptureService.java').read_text()
store = (ROOT/'app/src/main/java/com/xspaceart/radar30/AppStateStore.java').read_text()
repo = (ROOT/'app/src/main/java/com/xspaceart/radar30/CaptureRepository.java').read_text()
controller = (ROOT/'app/src/main/java/com/xspaceart/radar30/integrated/pipeline/ReadingPipelineController.java').read_text()

need("versionCode 4" in build, 'versionCode must be 4')
need("versionName '0.7.3-stability-pipeline'" in build, 'versionName mismatch')
need("applicationId 'com.xspaceart.aurumai37.integratedlab'" in build, 'base applicationId drift')
need("applicationIdSuffix '.debug'" in build, 'debug suffix drift')

# Operational pipeline invariants.
need('pipeline.start(System.currentTimeMillis())' in activity, 'reading start must initialize pipeline')
need('initialBootstrapPending=true' in activity, 'bootstrap gate missing')
need('bridge.replaceBootstrap(snapshot)' in activity, 'full visible bootstrap missing')
need('pipeline.watchdog(now)' in activity, 'watchdog missing')
need('HOT STANDBY' in activity, 'OCR hot standby telemetry missing')
need('DOM_LOCK_FAILURE_LIMIT = 5' in activity, 'DOM hysteresis missing')
need('DOM_RELOCK_HITS = 2' in activity, 'DOM auto relock missing')
need('Finalize a sessão Integrated antes de abrir as ferramentas Stable' in activity,
     'parallel Stable UI must be blocked during Integrated reading')
need('ScreenCaptureService.MODE_INTEGRATED_SOURCE_ONLY' in activity,
     'Integrated must start capture service in source-only mode')
need('pipeline.confirmSource(source,now)' in activity, 'source switch must be confirmed after reconciliation')
need('lastOcrStableObserved' in activity and 'ocrStabilizer.accept(visual)' in activity,
     'OCR stability gate missing')
need('promoteStandbyIfActiveStalled()' in activity, 'symmetric silent-stall failover missing')
need('acceptTrackingDelta("DOM",history,previous)' in activity, 'DOM tracking must be incremental-only')
need('acceptTrackingDelta("OCR",lastOcrStableObserved,previousStable)' in activity, 'OCR tracking must be incremental-only')
need('SourceDelta.between(snapshot,bridge.historySnapshot())' in activity, 'source failover must reconcile by delta against CORE')
need('AppStateStore.loadHistory(this)' not in activity[activity.find('private void syncFromVisualHistory'):activity.find('private void forceDomRediscovery')],
     'Integrated OCR must not fall back to Stable global history')

# Capture is data-only for Integrated and publishes raw OCR heartbeat.
need('MODE_INTEGRATED_SOURCE_ONLY' in service, 'source-only capture mode missing')
need('if (integratedSourceOnly)' in service, 'source-only branch missing')
need('CaptureRepository.setLatestNumbers(numbers, observedAt)' in service, 'in-memory OCR snapshot missing')
need('AppStateStore.saveOcrSnapshot' in service, 'persisted OCR snapshot missing')
need('if (integratedSourceOnly) return;' in service, 'Integrated OCR must return before Stable synchronizer')
need('integratedSourceOnly ? IntegratedActivity.class : MainActivity.class' in service,
     'Integrated capture notification must reopen IntegratedActivity')
idx_branch = service.find('if (integratedSourceOnly)')
idx_engine = service.find('SignalUpdate update = radarSession.update')
need(idx_branch >= 0 and idx_engine > idx_branch, 'Integrated branch must return before Stable radar engine')
need('return;' in service[idx_branch:idx_engine], 'Integrated source-only branch must return before Stable engine')
need('getLatestNumbers' in repo and 'ocrScanCount' in repo, 'OCR memory repository incomplete')
need('OCR_SCAN_COUNT' in store and 'CAPTURE_ACTIVE' in store, 'OCR telemetry persistence incomplete')

# Controller sticky-source and failover semantics.
need('HEALTH_STALE_MS = 5_500L' in controller, 'watchdog stale threshold missing')
need('sourceSwitches++' in controller, 'source switch telemetry missing')
need('Phase.RECOVERING' in controller, 'recovery phase missing')

# Frozen CORE must be byte-identical.
manifest = (ROOT/'CORE_PRESERVATION_SHA256.txt').read_text().splitlines()
checked = 0
for line in manifest:
    m = re.match(r'([0-9a-f]{64})\s+(.+)$', line.strip())
    if not m:
        continue
    checked += 1
    expected, name = m.groups()
    path = ROOT/'app/src/main/java/com/xspaceart/radar30/core'/name
    if not path.exists():
        errors.append(f'missing CORE file: {name}')
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        errors.append(f'CORE drift: {name}')
need(checked == 17, f'expected 17 frozen CORE files, got {checked}')

if errors:
    print('V073_STATIC_VALIDATION=FAIL')
    for error in errors:
        print('-', error)
    sys.exit(1)

print('V073_STATIC_VALIDATION=PASS')
print('CORE_PRESERVATION=PASS checked=17')
print('PIPELINE=bootstrap+incremental-tracking+sticky-source+watchdog+symmetric-failover')
print('OCR=source-only+hot-standby+heartbeat')
print('PHYSICAL_S25FE=PENDING')
