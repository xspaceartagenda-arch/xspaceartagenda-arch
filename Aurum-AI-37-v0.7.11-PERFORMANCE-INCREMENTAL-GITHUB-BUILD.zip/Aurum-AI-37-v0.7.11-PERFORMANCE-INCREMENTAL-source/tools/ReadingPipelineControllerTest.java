import com.xspaceart.radar30.integrated.pipeline.ReadingPipelineController;

public final class ReadingPipelineControllerTest {
    private static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        ReadingPipelineController p = new ReadingPipelineController();
        long t = 1_000L;
        p.start(t);
        check(p.phase() == ReadingPipelineController.Phase.BOOTSTRAP, "must bootstrap");
        check(p.chooseBootstrap(t) == ReadingPipelineController.Source.NONE, "no source yet");

        p.observeDom(true, 24, t + 100);
        check(p.chooseBootstrap(t + 100) == ReadingPipelineController.Source.DOM, "DOM bootstrap");
        p.confirmBootstrap(ReadingPipelineController.Source.DOM, t + 100);
        check(p.activeSource() == ReadingPipelineController.Source.DOM, "DOM active");

        // OCR becomes available, but sticky DOM must not flap while healthy.
        p.observeOcr(true, 30, t + 1_000);
        check(p.watchdog(t + 1_000) == ReadingPipelineController.Source.NONE, "keep healthy DOM");
        check(p.activeSource() == ReadingPipelineController.Source.DOM, "DOM remains active");

        // DOM expires; OCR is proposed, but it only becomes active after the caller
        // reconciles the snapshot and confirms the switch.
        p.observeOcr(true, 30, t + 6_900);
        check(p.watchdog(t + 6_900) == ReadingPipelineController.Source.OCR, "failover candidate OCR");
        check(p.activeSource() == ReadingPipelineController.Source.DOM, "candidate must not steal pipeline before reconciliation");
        p.confirmSource(ReadingPipelineController.Source.OCR, t + 6_900);
        check(p.activeSource() == ReadingPipelineController.Source.OCR, "OCR active after confirmation");
        check(p.sourceSwitches() == 1, "one source switch");

        // OCR expires too -> recovering, not a fake healthy state.
        check(p.watchdog(t + 13_000) == ReadingPipelineController.Source.NONE, "no fake source");
        check(p.phase() == ReadingPipelineController.Phase.RECOVERING, "recovering");

        // DOM comes back: again, proposal first and confirmation after reconciliation.
        p.observeDom(true, 18, t + 13_100);
        check(p.watchdog(t + 13_100) == ReadingPipelineController.Source.DOM, "recover DOM candidate");
        check(p.activeSource() == ReadingPipelineController.Source.OCR, "keep OCR until DOM snapshot is accepted");
        p.confirmSource(ReadingPipelineController.Source.DOM, t + 13_100);
        check(p.activeSource() == ReadingPipelineController.Source.DOM, "DOM restored");
        check(p.phase() == ReadingPipelineController.Phase.TRACKING, "tracking restored");

        p.resetToBootstrap(t + 14_000);
        p.observeDom(true, 12, t + 14_010);
        p.observeOcr(true, 26, t + 14_010);
        check(p.chooseBootstrap(t + 14_010) == ReadingPipelineController.Source.OCR,
                "deeper OCR source should win bootstrap");

        ReadingPipelineController q = new ReadingPipelineController();
        q.start(t + 20_000);
        q.observeDom(true, 24, t + 20_010);
        q.observeOcr(true, 23, t + 20_010);
        check(q.chooseBootstrap(t + 20_010) == ReadingPipelineController.Source.OCR,
                "stable OCR should win near-tie bootstrap");
        ReadingPipelineController r = new ReadingPipelineController();
        r.start(t + 30_000);
        r.observeDom(true, 30, t + 30_010);
        r.observeOcr(true, 23, t + 30_010);
        check(r.chooseBootstrap(t + 30_010) == ReadingPipelineController.Source.DOM,
                "clearly deeper DOM may win bootstrap");

        System.out.println("ReadingPipelineControllerTest PASS");
    }
}
