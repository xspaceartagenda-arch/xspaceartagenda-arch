from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
app = root / 'app'
java = app / 'src/main/java/com/xspaceart/radar30'
core = java / 'core'

build = (app / 'build.gradle').read_text(encoding='utf-8')
manifest = (app / 'src/main/AndroidManifest.xml').read_text(encoding='utf-8')
standalone = (java / 'StandaloneActivity.java').read_text(encoding='utf-8')
service = (java / 'ScreenCaptureService.java').read_text(encoding='utf-8')
overlay = (java / 'OverlayController.java').read_text(encoding='utf-8')
formatter = (java / 'RadarBackstageFormatter.java').read_text(encoding='utf-8')
ledger = (java / 'SessionLedger.java').read_text(encoding='utf-8')
session = (core / 'RadarSession.java').read_text(encoding='utf-8')
precision = (core / 'PrecisionConfluenceEngine.java').read_text(encoding='utf-8')
verdict = (core / 'ConfluenceVerdict.java').read_text(encoding='utf-8')
terminal = (core / 'TerminalSnapshot.java').read_text(encoding='utf-8')
policy = (core / 'TerminalSignalPolicy.java').read_text(encoding='utf-8')

# Identity / update continuity.
assert 'versionCode 9' in build
assert "versionName '0.7.8-terminal-sector-confluence'" in build
assert "applicationId 'com.xspaceart.aurumai37.integratedlab'" in build
assert "applicationIdSuffix '.debug'" in build
assert "signingConfig signingConfigs.aurumStable" in build
assert 'android:name="com.xspaceart.radar30.StandaloneActivity"' in manifest
assert 'STANDALONE OCR RADAR • v0.7.8' in standalone

# v0.7.7 standalone/OCR UX remains present.
assert 'BASTIDOR DO RADAR' in standalone
assert 'PASTA DE SESSÕES' in standalone
assert 'Gravity.TOP | Gravity.END' in overlay
assert 'params.y = Ui.dp(context, 72)' in overlay
assert 'RadarBackstageFormatter.focus(verdict)' in service

# Independent terminal engine attached to the existing verdict.
assert 'TerminalSnapshot terminal' in verdict
assert 'TerminalSnapshot.analyze(evidence, centralHeat, history)' in precision
assert 'terminal_score_' in precision
assert 'terminal_sector_aligned' in precision
for marker in [
    'public static int terminalOf(int number)',
    'public static List<Integer> coverageOf(int terminal)',
    'currentContext(List<Integer> history, int terminal)',
    'familyCount', 'alignment', 'contradiction', 'leaderMargin'
]:
    assert marker in terminal, marker

# Two signal models + max cross-confluence decision layer.
assert 'SECTOR_VALIDITY_SPINS = 3' in policy
assert 'TERMINAL_VALIDITY_SPINS = 5' in policy
for marker in ['terminalPrepare(', 'terminalReady(', 'maxConfluenceReady(',
               'aligned(', 'crossScore(', 'terminalStillValid(']:
    assert marker in policy, marker
assert 'verdict.mode == ConfluenceVerdict.Mode.BALANCED' in policy
assert 'MAX_CONFLUENCE_TERMINAL_SECTOR' in session
assert 'TERMINAL_SIGNAL' in session
assert 'SECTOR_SIGNAL' in session
assert 'ActiveSignal.forTerminal' in session
assert 'STRUCTURAL_CANCEL' in session
assert 'terminalSaturationRemaining = 2' in session
assert 'TERMINAL REALIZADO DURANTE OBSERVAÇÃO' in session
assert 'Não conta como STRYKE' in session

# UI explainability and 5-spin presentation.
for marker in ['TERMINAL ENGINE', 'CRUZAMENTO TERMINAL+SETOR',
               'CONFLUÊNCIA MÁXIMA', 'índice']:
    assert marker in formatter, marker
assert 'terminalSignal ? 5 : 3' in service
assert 'signalWindow(update)' in ledger
assert 'CANCELLED_BY_STRUCTURE' in ledger
assert 'terminal-sector-confluence-v078' in ledger

# Precision strictness is not relaxed by the terminal path.
assert 'if (!verdict.entryQualified || hypothesis.updates < 3) return false;' in session
assert 'hypothesis.recentMinimum(3) < 78' in session
assert 'boolean precision = aurumScore >= 82' in precision
assert 'fusion.supporting.size() >= 6 || fiveExceptional' in precision
assert 'if (!balanced(verdict)) return false;' in policy

# Only 3 original v0.7.7 CORE files may drift; Terminal* are additive.
baseline = {}
for line in (root / 'CORE_BASELINE_V077_SHA256.txt').read_text(encoding='utf-8').splitlines():
    m = re.match(r'([0-9a-f]{64})\s+(.+)$', line.strip())
    if m:
        baseline[m.group(2)] = m.group(1)
authorized = {'ConfluenceVerdict.java', 'PrecisionConfluenceEngine.java', 'RadarSession.java'}
checked = 0
for name, digest in baseline.items():
    if name in authorized:
        continue
    path = core / name
    assert path.exists(), name
    got = hashlib.sha256(path.read_bytes()).hexdigest()
    assert got == digest, f'unauthorized CORE drift over v0.7.7: {name}'
    checked += 1
assert checked == 16, checked
assert (core / 'TerminalSnapshot.java').exists()
assert (core / 'TerminalSignalPolicy.java').exists()

print('V078_STATIC_VALIDATION=PASS')
print('ARCHITECTURE=standalone-ocr-preserved+sector-engine+terminal-engine+max-cross-confluence')
print('SIGNALS=SECTOR_SIGNAL(3)+TERMINAL_SIGNAL(5)+MAX_CONFLUENCE_TERMINAL_SECTOR(5)')
print('TERMINAL=family-votes+T0..T9+leader-margin+live-revalidation')
print('SATURATION=terminal-observation-touch->2-spin-cooldown')
print('PRECISION=PRESERVED')
print('CORE_PRESERVATION=PASS unchanged=16 authorized_original=3 additive=2')
print('PHYSICAL_S25FE=PENDING')
