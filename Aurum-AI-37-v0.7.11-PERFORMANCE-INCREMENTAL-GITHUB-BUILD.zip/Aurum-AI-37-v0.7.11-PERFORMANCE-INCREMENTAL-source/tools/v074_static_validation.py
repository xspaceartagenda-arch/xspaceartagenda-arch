from pathlib import Path
import hashlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
def need(condition, message):
    if not condition: errors.append(message)

build=(ROOT/'app/build.gradle').read_text()
activity=(ROOT/'app/src/main/java/com/xspaceart/radar30/integrated/IntegratedActivity.java').read_text()
source=(ROOT/'app/src/main/java/com/xspaceart/radar30/integrated/scanner/SourceHunter.java').read_text()
quality=(ROOT/'app/src/main/java/com/xspaceart/radar30/integrated/scanner/HistoryQualityGate.java').read_text()
agreement=(ROOT/'app/src/main/java/com/xspaceart/radar30/integrated/scanner/HistoryAgreement.java').read_text()
controller=(ROOT/'app/src/main/java/com/xspaceart/radar30/integrated/pipeline/ReadingPipelineController.java').read_text()
service=(ROOT/'app/src/main/java/com/xspaceart/radar30/ScreenCaptureService.java').read_text()

need('versionCode 5' in build,'versionCode must be 5')
need("versionName '0.7.4-dom-history-accuracy'" in build,'versionName mismatch')
need("applicationId 'com.xspaceart.aurumai37.integratedlab'" in build,'applicationId drift')
need("applicationIdSuffix '.debug'" in build,'debug suffix drift')

# v0.7.3 stability pipeline remains intact.
for marker,msg in [
 ('pipeline.start(System.currentTimeMillis())','pipeline start missing'),
 ('bridge.replaceBootstrap(snapshot)','full bootstrap missing'),
 ('pipeline.watchdog(now)','watchdog missing'),
 ('promoteStandbyIfActiveStalled()','hot standby failover missing'),
 ('acceptTrackingDelta("DOM",history,previous)','DOM incremental tracking missing'),
 ('acceptTrackingDelta("OCR",lastOcrStableObserved,previousStable)','OCR incremental tracking missing'),
 ('ScreenCaptureService.MODE_INTEGRATED_SOURCE_ONLY','source-only OCR mode missing')]: need(marker in activity,msg)

# v0.7.4 capture-accuracy protections.
need('HistoryQualityGate.assess' in activity,'DOM quality gate missing')
need('HistoryAgreement.score' in activity,'DOM/OCR consensus missing')
need('domStabilizer.accept(history)' in activity,'DOM double-scan stabilization missing')
need('DOM_QUARANTINE_MS' in activity and 'quarantineDom' in activity,'DOM quarantine missing')
need('DomSourceMemory.invalidate' in activity[activity.find('private void clearOperationalHistory'):activity.find('private void showCorrectionDialog')],
     'clear history must invalidate DOM lock')
need('pipeline.invalidateDom()' in activity,'immediate DOM invalidation missing')
need("extractionMode:'CELLS'" in source or "mode:'CELLS'" in source,'structured cell extraction missing')
need('wheelish' in source,'roulette-grid rejection missing')
need('t.length>700' in source,'broad text fallback limit missing')
need('MAX_VISIBLE_HISTORY = 120' in quality,'history width guard missing')
need('repetição estrutural suspeita' in quality,'repetition contamination guard missing')
need('DOM_OCR_MIN_AGREEMENT = 0.78' in activity,'consensus threshold missing')
need('invalidateDom()' in controller,'controller DOM invalidation missing')
need('domHealthyAt = 0L' in controller and 'ocrHealthyAt = 0L' in controller,'fresh-session source health reset missing')

# Integrated OCR remains source-only; no second strategic engine.
need('MODE_INTEGRATED_SOURCE_ONLY' in service,'source-only capture mode missing')
need('if (integratedSourceOnly) return;' in service,'Integrated OCR must return before Stable engine')

# Frozen strategic CORE must remain byte-identical.
manifest=(ROOT/'CORE_PRESERVATION_SHA256.txt').read_text().splitlines(); checked=0
for line in manifest:
    m=re.match(r'([0-9a-f]{64})\s+(.+)$',line.strip())
    if not m: continue
    checked+=1; expected,name=m.groups(); path=ROOT/'app/src/main/java/com/xspaceart/radar30/core'/name
    if not path.exists(): errors.append(f'missing CORE file: {name}'); continue
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected: errors.append(f'CORE drift: {name}')
need(checked==17,f'expected 17 frozen CORE files, got {checked}')

if errors:
    print('V074_STATIC_VALIDATION=FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('V074_STATIC_VALIDATION=PASS')
print('CORE_PRESERVATION=PASS checked=17')
print('DOM_ACCURACY=structured-cells+quality-gate+double-confirmation+OCR-consensus+quarantine')
print('PIPELINE=v0.7.3-stability-preserved')
print('PHYSICAL_S25FE=PENDING')
