from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
app = root / 'app'
manifest = (app / 'src/main/AndroidManifest.xml').read_text()
build = (app / 'build.gradle').read_text()
standalone = (app / 'src/main/java/com/xspaceart/radar30/StandaloneActivity.java').read_text()
service = (app / 'src/main/java/com/xspaceart/radar30/ScreenCaptureService.java').read_text()
store = (app / 'src/main/java/com/xspaceart/radar30/AppStateStore.java').read_text()
overlay = (app / 'src/main/java/com/xspaceart/radar30/OverlayController.java').read_text()
precision = (app / 'src/main/java/com/xspaceart/radar30/core/PrecisionConfluenceEngine.java').read_text()
session = (app / 'src/main/java/com/xspaceart/radar30/core/RadarSession.java').read_text()

assert "versionCode 6" in build
assert "0.7.5-standalone-ocr-radar" in build
assert 'android:name="com.xspaceart.radar30.StandaloneActivity"' in manifest
launcher_block = re.search(r'<activity\s+android:name="com\.xspaceart\.radar30\.StandaloneActivity".*?</activity>', manifest, re.S)
assert launcher_block and 'android.intent.action.MAIN' in launcher_block.group(0)
assert 'MODE_STANDALONE_OCR' in standalone
assert 'moveTaskToBack(true)' in standalone
assert 'RADAR 0/100' in standalone
assert 'CALIBRAR ÁREA DO HISTÓRICO' in standalone
assert 'WebView' not in standalone
assert 'MODE_STANDALONE_OCR = "standalone_ocr"' in service
assert 'saveRadarSnapshot' in service
assert 'SIGNAL_CHANNEL_ID' in service
assert 'shouldSurfaceStandaloneOverlay' in service
assert 'integratedSourceOnly = false' in service
assert '.putBoolean(CONSERVATIVE, false)' in store
assert 'ensureStandaloneDefaults' in store
assert 'Gravity.BOTTOM | Gravity.END' in overlay

# Balanced-only gate calibration markers. Precision hard gate must stay at 82/6 families.
assert 'boolean precision = aurumScore >= 82' in precision
assert 'fusion.supporting.size() >= 6 || fiveExceptional' in precision
assert 'boolean balanced = aurumScore >= 72' in precision
assert 'fusion.supporting.size() >= 4 || fourExceptional' in precision
assert 'predictiveSamples >= 18' in precision
assert 'verdict.aurumScore >= 64' in session
assert 'hypothesis.recentMinimum(2) >= 62' in session
assert '? 72 : 64)' in session

# 15 of 17 CORE files must still be byte-identical to v0.7.4.
baseline = {}
for line in (root / 'CORE_BASELINE_V074_SHA256.txt').read_text().splitlines():
    m = re.match(r'([0-9a-f]{64})\s+(.+)$', line.strip())
    if m:
        baseline[m.group(2)] = m.group(1)
authorized = {'PrecisionConfluenceEngine.java', 'RadarSession.java'}
checked = 0
for name, digest in baseline.items():
    if name in authorized:
        continue
    path = app / 'src/main/java/com/xspaceart/radar30/core' / name
    assert path.exists(), name
    got = hashlib.sha256(path.read_bytes()).hexdigest()
    assert got == digest, f'unauthorized CORE drift: {name}'
    checked += 1
assert checked == 15, checked

print('V075_STATIC_VALIDATION=PASS')
print('ARCHITECTURE=standalone-app+external-roulette+ocr-primary+foreground-service')
print('UI=radar-first+signal-hero+reduced-telemetry')
print('ALERTS=bottom-overlay+voice+high-priority-notification')
print('SIGNAL_GATE=balanced-operational+precision-preserved')
print('CORE_PRESERVATION=PASS unchanged=15 authorized=2')
print('PHYSICAL_S25FE=PENDING')
