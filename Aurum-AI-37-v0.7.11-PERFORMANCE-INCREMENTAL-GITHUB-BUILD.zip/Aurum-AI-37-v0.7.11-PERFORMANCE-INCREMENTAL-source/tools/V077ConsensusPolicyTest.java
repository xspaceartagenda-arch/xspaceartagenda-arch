import com.xspaceart.radar30.core.*;

import java.util.Arrays;
import java.util.Collections;

/** Valida as novas rotas sem permitir sinal quando a hipótese acabou de realizar. */
public final class V077ConsensusPolicyTest {
    public static void main(String[] args) {
        ConsensusSnapshot strong = snapshot(72, 5, 0.88, 0.16, 0.12);
        ConfluenceVerdict v = verdict(strong);
        assertTrue(ConsensusPolicy.persistent(v, 2, 0.0, false), "consenso maduro");
        assertFalse(ConsensusPolicy.persistent(v, 2, 0.0, true), "saturação precisa bloquear");

        ConsensusSnapshot rising = snapshot(64, 4, 0.82, 0.18, 0.08);
        ConfluenceVerdict m = verdict(rising);
        assertTrue(ConsensusPolicy.momentum(m, 2, 4.0, -1.0, false), "momentum válido");
        assertFalse(ConsensusPolicy.momentum(m, 2, 1.0, -1.0, false), "líder sem aceleração");
        assertFalse(ConsensusPolicy.momentum(m, 2, 4.0, 3.0, false), "rival acelerando junto");

        ConsensusSnapshot exceptional = snapshot(80, 5, 0.93, 0.12, 0.16);
        ConfluenceVerdict e = verdict(exceptional);
        assertTrue(ConsensusPolicy.immediate(e, false), "consenso excepcional");
        assertTrue(ConsensusPolicy.recurrenceOverride(e), "recorrência excepcional pode reabrir");

        ConfluenceVerdict precision = verdict(exceptional, ConfluenceVerdict.Mode.PRECISION);
        assertFalse(ConsensusPolicy.immediate(precision, false), "Precision não pode usar rota Balanced");
        System.out.println("V077_CONSENSUS_POLICY=PASS");
    }

    private static ConsensusSnapshot snapshot(int score, int families, double alignment,
                                              double contradiction, double margin) {
        ConsensusSnapshot.Candidate primary = new ConsensusSnapshot.Candidate(2, score, families,
                alignment, contradiction, 0.78, 0.82, true, true,
                Collections.emptyList());
        ConsensusSnapshot.Candidate secondary = new ConsensusSnapshot.Candidate(32,
                Math.max(0, score - (int)Math.round(score * margin)), 3,
                0.72, 0.25, 0.62, 0.60, true, true, Collections.emptyList());
        ConsensusSnapshot.Candidate third = new ConsensusSnapshot.Candidate(12, 48, 2,
                0.65, 0.30, 0.50, 0.50, false, true, Collections.emptyList());
        return new ConsensusSnapshot(primary, secondary, third, margin, 7);
    }

    private static ConfluenceVerdict verdict(ConsensusSnapshot snapshot) {
        return verdict(snapshot, ConfluenceVerdict.Mode.BALANCED);
    }

    private static ConfluenceVerdict verdict(ConsensusSnapshot snapshot, ConfluenceVerdict.Mode mode) {
        double[] heat = new double[37]; heat[2] = 1.0; heat[25] = 0.9; heat[17] = 0.85;
        return new ConfluenceVerdict(ConfluenceVerdict.Decision.PREPARE, 2,
                Wheel.coverage(2, 2), Arrays.asList(2, 25), 60, 4,
                0.20, 0.08, 0.98, 0.75, 0.68,
                new RegimeDetector().detect(Collections.emptyList()),
                Arrays.asList(EvidenceFamily.RECENCY, EvidenceFamily.TRANSITION,
                        EvidenceFamily.ARITHMETIC, EvidenceFamily.REGIME),
                Collections.singletonList("consenso sintético"), Collections.emptyList(), heat,
                false, false, false, mode, -1, Collections.emptyList(), Collections.emptyList(),
                0, 0, 1.0, 0.0, 0.0, 32, 50, 0.5,
                TargetRanking.SpatialRegime.DISPERSED, TargetRanking.SignalShape.HIGH_DISPERSION,
                Collections.emptyList(), Collections.emptyList(), false, snapshot);
    }

    private static void assertTrue(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    private static void assertFalse(boolean value, String message) {
        if (value) throw new AssertionError(message);
    }
}
