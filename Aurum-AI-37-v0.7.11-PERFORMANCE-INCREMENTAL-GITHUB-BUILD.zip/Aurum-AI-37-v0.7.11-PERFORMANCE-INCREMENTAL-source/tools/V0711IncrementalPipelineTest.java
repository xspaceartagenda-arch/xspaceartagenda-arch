import com.xspaceart.radar30.core.ScanStabilizer;
import com.xspaceart.radar30.core.ScanSynchronizer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class V0711IncrementalPipelineTest {
    public static void main(String[] args) {
        List<Integer> base = Arrays.asList(
                25, 7, 32, 14, 2, 21, 9, 18, 34, 5,
                27, 11, 30, 16, 3, 22, 8, 29, 12, 35,
                1, 24, 6, 33, 15, 20, 4, 31, 17, 10);

        ScanStabilizer stabilizer = new ScanStabilizer();
        require(!stabilizer.accept(base), "first OCR must not emit");
        require(stabilizer.needsConfirmation(), "second confirmation must be requested immediately");
        require(stabilizer.accept(base), "second identical OCR must emit");
        require(!stabilizer.needsConfirmation(), "confirmed grid must not stay pending");

        ScanSynchronizer sync = new ScanSynchronizer();
        sync.restore(base);

        List<Integer> oneNew = new ArrayList<>();
        oneNew.add(19);
        oneNew.addAll(base);
        ScanSynchronizer.MergeResult one = sync.merge(oneNew);
        require(one.accepted && one.newNumbers.size() == 1 && one.newNumbers.get(0) == 19,
                "single spin delta failed");
        require(one.history.get(0) == 19 && one.history.get(1) == 25,
                "confirmed history was not preserved");

        List<Integer> current = new ArrayList<>(one.history);
        List<Integer> catchup = Arrays.asList(36, 13, 28, 0, 23, 10, 6);
        List<Integer> returnedGrid = new ArrayList<>(catchup);
        returnedGrid.addAll(current);
        ScanSynchronizer.MergeResult resumed = sync.merge(returnedGrid);
        require(resumed.accepted, "fast resume rejected a valid aligned grid");
        require(resumed.newNumbers.equals(catchup), "fast resume delta order mismatch");
        require(resumed.history.subList(0, catchup.size()).equals(catchup),
                "resume did not prepend only missing spins");
        require(resumed.message.contains("Retomada rápida"), "resume marker missing");

        System.out.println("V0711_INCREMENTAL_PIPELINE=PASS delta=1 catchup="
                + catchup.size() + " preserved=" + resumed.history.size());
    }

    private static void require(boolean value, String message) {
        if (!value) throw new IllegalStateException(message);
    }
}
