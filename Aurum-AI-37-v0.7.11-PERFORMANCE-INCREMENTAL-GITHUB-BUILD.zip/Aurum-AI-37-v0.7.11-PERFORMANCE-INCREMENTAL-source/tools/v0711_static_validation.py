from pathlib import Path
import hashlib, sys
R=Path(__file__).resolve().parents[1]
def need(v,m):
    if not v:
        print('V0711_STATIC_VALIDATION=FAIL',m); sys.exit(1)
def text(rel): return (R/rel).read_text(encoding='utf-8')

gradle=text('app/build.gradle')
svc=text('app/src/main/java/com/xspaceart/radar30/ScreenCaptureService.java')
act=text('app/src/main/java/com/xspaceart/radar30/StandaloneActivity.java')
stab=text('app/src/main/java/com/xspaceart/radar30/core/ScanStabilizer.java')
sync=text('app/src/main/java/com/xspaceart/radar30/core/ScanSynchronizer.java')
manifest=text('app/src/main/AndroidManifest.xml')

need('versionCode 12' in gradle, 'versionCode')
need("versionName '0.7.11-performance-incremental'" in gradle, 'versionName')
need('applicationId \'com.xspaceart.aurumai37.integratedlab\'' in gradle, 'package base')
need("applicationIdSuffix '.debug'" in gradle, 'debug suffix')
need('STANDALONE OCR RADAR • v0.7.11 PERFORMANCE • CÉREBRO v0.7.8' in act, 'UI marker')
need('ACTION_FAST_RESYNC' in svc and 'Sincronização rápida' in svc, 'fast resync')
need('private static final long FRAME_INTERVAL_MS = 320L;' in svc, 'normal frame interval')
need('private static final long FAST_FRAME_INTERVAL_MS = 180L;' in svc, 'fast frame interval')
need('reader.acquireLatestImage()' in svc, 'latest image / no backlog')
need('if (ocrBusy.get()) return;' in svc, 'busy drop')
need('roiVisuallyChanged' in svc and 'sampleRoiLuma' in svc, 'visual change gate')
need('Callbacks no Handler de captura' in svc and 'captureHandler' in svc, 'background callback')
need('needsConfirmation()' in stab, 'stabilizer fast second confirmation')
need('int maxOffset = Math.min(12, clean.size() - 1);' in sync, 'catchup 12')
need('bestOffset > 5 ? 0.95 : 0.85' in sync, 'strict catchup ratio')
need('foregroundServiceType="mediaProjection"' in manifest, 'foreground media projection')
need('radarSession.resetSignal();' not in svc[svc.index('if (ACTION_FAST_RESYNC.equals(action))'):svc.index('if (ACTION_START.equals(action))',svc.index('if (ACTION_FAST_RESYNC.equals(action))'))], 'fast resync resets signal')
need('SurgicalPrecision' not in ''.join(p.name for p in (R/'app/src/main/java').rglob('*.java')), 'surgical v079 present')

# Every Java file outside the four authorized performance files must be byte-identical
# to the known-good v0.7.10/v0.7.8 source baseline.
for line in text('V0711_PROTECTED_V0710_SHA256.txt').splitlines():
    if not line.strip(): continue
    expected, rel = line.split(None,1)
    rel=rel.strip()
    p=R/rel
    need(p.exists(), 'protected file missing '+rel)
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    need(actual==expected, 'protected file drift '+rel)

print('V0711_STATIC_VALIDATION=PASS')
print('BASE=v0.7.10 rollback / SIGNAL_BRAIN=v0.7.8 PRESERVED')
print('PIPELINE=latest-frame+visual-change-gate+two-scan-confirmation+delta-merge')
print('BACKGROUND=foreground-mediaProjection+notification-only-compatible')
print('FAST_RESYNC=NO_CORE_RESET')
print('CATCHUP=up-to-12-strict-alignment')
print('ANDROID_BUILD=PENDING')
