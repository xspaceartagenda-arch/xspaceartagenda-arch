from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parents[1]
errors=[]
def need(cond,msg):
    if not cond: errors.append(msg)

gradle=(root/'app/build.gradle').read_text(errors='replace')
need('versionCode 11' in gradle,'versionCode must be 11')
need("versionName '0.7.10-rollback-v078'" in gradle,'versionName mismatch')
need("applicationId 'com.xspaceart.aurumai37.integratedlab'" in gradle,'base applicationId changed')
need("applicationIdSuffix '.debug'" in gradle,'debug suffix changed')
need("storeFile file('../keystore/aurum-integrated.jks')" in gradle,'stable keystore changed')
activity=(root/'app/src/main/java/com/xspaceart/radar30/StandaloneActivity.java').read_text(errors='replace')
need('v0.7.10 • BASE v0.7.8' in activity,'rollback UI marker missing')
# v0.7.8 architecture must exist
for rel in [
 'app/src/main/java/com/xspaceart/radar30/core/TerminalSnapshot.java',
 'app/src/main/java/com/xspaceart/radar30/core/TerminalSignalPolicy.java',
 'app/src/main/java/com/xspaceart/radar30/core/RadarSession.java',
 'app/src/main/java/com/xspaceart/radar30/RadarBackstageFormatter.java']:
    need((root/rel).exists(), f'missing v0.7.8 component: {rel}')
# Surgical v0.7.9 implementation must not exist in app source
bad=[]
for p in (root/'app/src').rglob('*'):
    if p.is_file() and p.suffix in {'.java','.kt','.xml'}:
        txt=p.read_text(errors='ignore').lower()
        if any(x in txt for x in ['surgical precision','surgicalgate','microalvo priorit','microtarget','v0.7.9']):
            bad.append(p.relative_to(root).as_posix())
need(not bad, 'v0.7.9 surgical markers found: '+','.join(bad[:10]))
# exact preservation of every app file except build.gradle + version label
manifest=root/'V0710_V078_BASELINE_SHA256.txt'
for line in manifest.read_text().splitlines():
    if not line.strip(): continue
    expected, rel=line.split('  ',1)
    p=root/rel
    if not p.exists():
        errors.append('missing baseline file '+rel); continue
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    if actual != expected:
        errors.append('v0.7.8 drift '+rel)
if errors:
    print('V0710_ROLLBACK_VALIDATION=FAIL')
    for e in errors: print('ERROR='+e)
    sys.exit(1)
print('V0710_ROLLBACK_VALIDATION=PASS')
print('BASE=v0.7.8-terminal-sector-confluence')
print('BEHAVIOR=v0.7.8-preserved')
print('SURGICAL_V079=ABSENT')
print('VERSION_CODE=11')
print('INSTALL_OVER_V079=SUPPORTED_BY_VERSION_ORDER')
print('PHYSICAL_S25FE=PENDING')
