import com.xspaceart.radar30.core.AnalysisResult;
import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarEngine;
import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Teste de cadência, não prova de ganho. Confirma que o filtro equilibrado não
 * libera toda janela uniforme e detecta uma concentração física sintética.
 */
public final class PrecisionSimulationTest {
    public static void main(String[] args) {
        RadarEngine engine = new RadarEngine();
        Random random = new Random(370303L);
        int fairSamples = 10_000;
        int fairEntries = 0;
        for (int sample = 0; sample < fairSamples; sample++) {
            List<Integer> history = new ArrayList<>();
            for (int spin = 0; spin < 30; spin++) history.add(random.nextInt(37));
            AnalysisResult result = engine.analyze(history, LearningModel.empty(), true);
            if (result.decision == AnalysisResult.Decision.ENTER) fairEntries++;
        }

        int biasedSamples = 2_000;
        int biasedEntries = 0;
        int matchingEntries = 0;
        List<Integer> targetZone = Wheel.coverage(32, 2);
        for (int sample = 0; sample < biasedSamples; sample++) {
            List<Integer> history = new ArrayList<>();
            for (int spin = 0; spin < 30; spin++) {
                if (random.nextDouble() < 0.55) {
                    history.add(targetZone.get(random.nextInt(targetZone.size())));
                } else {
                    history.add(random.nextInt(37));
                }
            }
            AnalysisResult result = engine.analyze(history, LearningModel.empty(), true);
            if (result.decision == AnalysisResult.Decision.ENTER) {
                biasedEntries++;
                if (overlap(result.coverage, targetZone) >= 3) matchingEntries++;
            }
        }

        double fairRate = fairEntries / (double) fairSamples;
        double detectionRate = matchingEntries / (double) biasedSamples;
        if (fairRate < 0.13 || fairRate > 0.18) {
            throw new AssertionError("uniform release cadence outside calibrated band: "
                    + fairRate);
        }
        if (detectionRate < 0.20) {
            throw new AssertionError("synthetic persistent-zone sensitivity too low: "
                    + detectionRate);
        }
        if (matchingEntries < Math.max(1, biasedEntries * 0.90)) {
            throw new AssertionError("too many signals outside synthetic target");
        }

        System.out.println("OK precision simulation");
        System.out.println("Uniform releases=" + fairEntries + "/" + fairSamples
                + " (" + percent(fairRate) + ")");
        System.out.println("Synthetic persistent-zone matches=" + matchingEntries
                + "/" + biasedSamples + " (" + percent(detectionRate) + ")");
    }

    private static int overlap(List<Integer> first, List<Integer> second) {
        int count = 0;
        for (int number : first) if (second.contains(number)) count++;
        return count;
    }

    private static String percent(double value) {
        return String.format(java.util.Locale.US, "%.2f%%", value * 100.0);
    }
}
