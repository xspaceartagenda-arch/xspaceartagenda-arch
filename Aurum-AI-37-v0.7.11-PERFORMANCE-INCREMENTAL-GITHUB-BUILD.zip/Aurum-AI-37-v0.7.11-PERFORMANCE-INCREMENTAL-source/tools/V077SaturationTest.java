import com.xspaceart.radar30.core.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Um acerto durante observação não pode virar STRYKE retroativo nem reforçar perseguição. */
public final class V077SaturationTest {
    public static void main(String[] args) {
        RadarSession session = new RadarSession();
        List<Integer> history = new ArrayList<>();
        Random random = new Random(77117L);
        boolean exercised = false;
        for (int spin = 0; spin < 700; spin++) {
            int result = random.nextInt(37);
            history.add(0, result);
            SignalUpdate u = session.update(history, Collections.singletonList(result),
                    LearningModel.empty(), false);
            ConfluenceVerdict v = session.lastVerdict();
            RadarSession.State st = session.state();
            if ((st == RadarSession.State.OBSERVING || st == RadarSession.State.BUILDING
                    || st == RadarSession.State.PREPARE)
                    && v != null && v.target >= 0 && !v.coverage.isEmpty()) {
                int touch = v.coverage.get(v.coverage.size() / 2);
                history.add(0, touch);
                SignalUpdate after = session.update(history, Collections.singletonList(touch),
                        LearningModel.empty(), false);
                if (after.kind == SignalUpdate.Kind.ENTRY
                        || after.kind == SignalUpdate.Kind.HIT
                        || after.kind == SignalUpdate.Kind.SECONDARY_HIT) {
                    throw new AssertionError("toque observado virou sinal/strike retroativo: " + after.kind);
                }
                if (session.saturationRemaining() <= 0) {
                    throw new AssertionError("saturação curta não foi ativada");
                }
                exercised = true;
                break;
            }
        }
        if (!exercised) throw new AssertionError("vetor não encontrou hipótese observável");
        System.out.println("V077_SATURATION=PASS");
    }
}
