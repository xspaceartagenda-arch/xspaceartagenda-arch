import com.xspaceart.radar30.integrated.normalize.ManualEchoReconciler;
import java.util.*;
public final class ManualEchoReconcilerTest {
  private static void ok(boolean c,String m){if(!c)throw new AssertionError(m);}
  public static void main(String[] a){
    ManualEchoReconciler r=new ManualEchoReconciler();r.record(12);ok(r.suppress(Arrays.asList(12)).isEmpty(),"single echo");
    r.record(7);r.record(18);List<Integer> fresh=r.suppress(Arrays.asList(5,18,7));ok(fresh.equals(Collections.singletonList(5)),"multi echo suffix");ok(r.pendingCount()==0,"pending clear");
    r.record(9);fresh=r.suppress(Arrays.asList(4));ok(fresh.equals(Collections.singletonList(4)),"unrelated spin preserved");ok(r.pendingCount()==1,"unrelated does not consume pending");
    System.out.println("PASS manual echo reconciler");
  }
}
