import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.CurrentTableHistory;
import com.xspaceart.radar30.core.PrecisionConfluenceEngine;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.RegimeDetector;
import com.xspaceart.radar30.core.ScanSynchronizer;
import com.xspaceart.radar30.core.SignalUpdate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public final class PrecisionCoreTest {
    public static void main(String[] args) {
        historyCapacityAndMerge();
        regimeChangeDetection();
        exceptionalConfluence();
        stateMachineAndLock();
        fairSilence();
        System.out.println("OK precision core v1");
    }

    private static void historyCapacityAndMerge() {
        List<Integer> source = new ArrayList<>();
        for (int i = 0; i < 620; i++) source.add(i % 37);
        check(CurrentTableHistory.clean(source).size() == 500,
                "current history must keep 500");

        ScanSynchronizer synchronizer = new ScanSynchronizer();
        synchronizer.restore(source.subList(0, 500));
        List<Integer> visible = new ArrayList<>();
        visible.add(9);
        visible.addAll(source.subList(0, 50));
        ScanSynchronizer.MergeResult merge = synchronizer.merge(visible);
        check(merge.accepted && merge.newNumbers.equals(Collections.singletonList(9)),
                "recent OCR row must prepend one result");
        check(merge.history.size() == 500 && merge.history.get(0) == 9,
                "short OCR must preserve confirmed tail");
    }

    private static void regimeChangeDetection() {
        List<Integer> history = new ArrayList<>();
        int[] recent = {32, 15, 19, 0, 26, 32, 15};
        for (int i = 0; i < 35; i++) history.add(recent[i % recent.length]);
        for (int i = 0; i < 240; i++) history.add(i % 37);
        RegimeDetector.Snapshot snapshot = new RegimeDetector().detect(history);
        check(snapshot.changeDetected, "clear regime change was not detected");
        check(snapshot.currentRegimeStart >= 24 && snapshot.currentRegimeStart <= 55,
                "dynamic regime boundary outside expected area: " + snapshot.currentRegimeStart);
        check(snapshot.previousRegimeWeight < 0.55,
                "previous regime was not aggressively reduced");
    }

    private static void exceptionalConfluence() {
        ConfluenceVerdict verdict = new PrecisionConfluenceEngine()
                .analyze(exceptionalHistory());
        check(verdict.decision == ConfluenceVerdict.Decision.ENTRY,
                "exceptional convergence should qualify after engine scan");
        check(verdict.target == 32, "expected physical core 32, got " + verdict.target);
        check(verdict.independentFamilies >= 6, "independent family gate missing");
        check(verdict.contradictionScore <= 0.16, "contradiction gate missing");
        check(verdict.dominanceMargin >= 0.16, "dominance gate missing");
    }

    private static void stateMachineAndLock() {
        RadarSession session = new RadarSession();
        List<Integer> history = exceptionalHistory();
        SignalUpdate first = session.update(history, Collections.emptyList());
        check(first.kind == SignalUpdate.Kind.OBSERVE,
                "first exceptional scan must still observe, got " + first.kind);
        history = prepend(history, 32);
        SignalUpdate second = session.update(history, Collections.singletonList(32));
        check(second.kind == SignalUpdate.Kind.BUILDING
                        || second.kind == SignalUpdate.Kind.PREPARE,
                "second scan should build, got " + second.kind);
        history = prepend(history, 15);
        SignalUpdate entry = session.update(history, Collections.singletonList(15));
        check(entry.kind == SignalUpdate.Kind.ENTRY,
                "third persistent scan should enter, got " + entry.kind);
        List<Integer> locked = new ArrayList<>(entry.coverage);

        history = prepend(history, 1);
        SignalUpdate active = session.update(history, Collections.singletonList(1));
        check(active.kind == SignalUpdate.Kind.ACTIVE && active.coverage.equals(locked),
                "active signal changed target after one miss");
        history = prepend(history, 2);
        SignalUpdate active2 = session.update(history, Collections.singletonList(2));
        check(active2.kind == SignalUpdate.Kind.ACTIVE && active2.coverage.equals(locked),
                "active signal changed target after two misses");
        history = prepend(history, 3);
        SignalUpdate red = session.update(history, Collections.singletonList(3));
        check(red.kind == SignalUpdate.Kind.EXPIRED && red.resolvedRound == 3,
                "signal did not expire exactly at round three");

        for (int i = 0; i < 2; i++) {
            history = prepend(history, 1);
            SignalUpdate cooldown = session.update(history, Collections.singletonList(1));
            check(cooldown.kind == SignalUpdate.Kind.COOLDOWN,
                    "absence must not recreate the signal during cooldown");
        }
    }

    private static void fairSilence() {
        PrecisionConfluenceEngine engine = new PrecisionConfluenceEngine();
        Random random = new Random(370037L);
        List<Integer> history = new ArrayList<>();
        for (int i = 0; i < 500; i++) history.add(random.nextInt(37));
        int entries = 0;
        for (int scan = 0; scan < 500; scan++) {
            history.add(0, random.nextInt(37));
            history.remove(history.size() - 1);
            if (engine.analyze(history).decision == ConfluenceVerdict.Decision.ENTRY) entries++;
        }
        check(entries <= 2, "precision engine forced too many entries on fair data: " + entries);
    }

    private static List<Integer> exceptionalHistory() {
        int[] loop = {32, 15, 19, 0, 26, 32, 19, 15, 26, 0};
        List<Integer> history = new ArrayList<>();
        for (int i = 0; i < 500; i++) history.add(loop[i % loop.length]);
        return history;
    }

    private static List<Integer> prepend(List<Integer> history, int number) {
        List<Integer> result = new ArrayList<>();
        result.add(number);
        result.addAll(history);
        if (result.size() > 500) result.remove(result.size() - 1);
        return result;
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
