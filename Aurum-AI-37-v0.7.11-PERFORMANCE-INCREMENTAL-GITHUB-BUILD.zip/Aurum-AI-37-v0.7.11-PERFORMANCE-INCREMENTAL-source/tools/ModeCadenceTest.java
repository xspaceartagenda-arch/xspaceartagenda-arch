import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.SignalUpdate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/** Mede cadência e acertos esperados em uma sequência uniforme. */
public final class ModeCadenceTest {
    public static void main(String[] args) {
        run("precision-confluence-v1", 3_600, 370401L);
    }

    private static void run(String label, int spins, long seed) {
        RadarSession session = new RadarSession();
        List<Integer> history = new ArrayList<>();
        Random random = new Random(seed);
        int starts = 0;
        int hits = 0;
        int expired = 0;
        long gapSum = 0;
        int previousStart = -1;
        long coverageSum = 0;
        double baseExpectationSum = 0.0;

        for (int spin = 0; spin < spins; spin++) {
            int result = random.nextInt(37);
            history.add(0, result);
            if (history.size() > 500) history.remove(history.size() - 1);
            SignalUpdate update = session.update(history,
                    Collections.singletonList(result));
            if (update.kind == SignalUpdate.Kind.ENTRY) {
                starts++;
                coverageSum += update.coverage.size();
                double perSpin = update.coverage.size() / 37.0;
                baseExpectationSum += 1.0 - Math.pow(1.0 - perSpin, 3);
                if (previousStart >= 0) gapSum += spin - previousStart;
                previousStart = spin;
            } else if (update.kind == SignalUpdate.Kind.HIT) {
                hits++;
            } else if (update.kind == SignalUpdate.Kind.EXPIRED) {
                expired++;
            }
        }
        int resolved = hits + expired;
        double hitRate = resolved == 0 ? 0.0 : hits * 100.0 / resolved;
        double averageGap = starts <= 1 ? 0.0 : gapSum / (double) (starts - 1);
        double averageCoverage = starts == 0 ? 0.0 : coverageSum / (double) starts;
        double expectedHitRate = starts == 0 ? 0.0
                : baseExpectationSum * 100.0 / starts;
        System.out.printf(Locale.US,
                "%s starts=%d resolved=%d hit-rate=%.2f%% base=%.2f%% avg-gap=%.1f spins avg-coverage=%.2f%n",
                label, starts, resolved, hitRate, expectedHitRate, averageGap,
                averageCoverage);
    }
}
