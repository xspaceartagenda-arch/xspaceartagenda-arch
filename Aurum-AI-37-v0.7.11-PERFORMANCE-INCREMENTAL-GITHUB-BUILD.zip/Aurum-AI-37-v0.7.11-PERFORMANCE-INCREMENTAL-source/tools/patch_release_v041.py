#!/usr/bin/env python3
"""Aplica a calibração v0.4.1 sobre o APK estável v0.4.0."""

from __future__ import annotations

import hashlib
import struct
import sys
import zlib
import zipfile
from pathlib import Path


OLD_LEGEND = (
    "VERDE: entrada confirmada  •  AMARELO: se preparar, sem apostar"
    "  •  VERMELHO: não entrar"
)
NEW_LEGEND = (
    "VERDE: sinal forte  •  AMARELO: moderado ou se preparar"
    "  •  VERMELHO: baixo:  não entrar"
)


def u32(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def read_uleb128(data: bytes | bytearray, offset: int) -> tuple[int, int]:
    value = 0
    shift = 0
    while True:
        current = data[offset]
        offset += 1
        value |= (current & 0x7F) << shift
        if current < 0x80:
            return value, offset
        shift += 7


def dex_strings(data: bytes | bytearray) -> list[tuple[int, int, bytes]]:
    count = u32(data, 0x38)
    table = u32(data, 0x3C)
    result: list[tuple[int, int, bytes]] = []
    for index in range(count):
        item = u32(data, table + index * 4)
        _, text_start = read_uleb128(data, item)
        text_end = data.index(0, text_start)
        text = bytes(data[text_start:text_end])
        result.append((text_start, text_end, text))
    return result


def replace_dex_string(data: bytearray, old: str, new: str) -> None:
    old_bytes = old.encode("utf-8")
    new_bytes = new.encode("utf-8")
    if len(old) != len(new) or len(old_bytes) != len(new_bytes):
        raise ValueError(f"replacement must preserve DEX length: {old!r} -> {new!r}")
    matches = [(start, end) for start, end, text in dex_strings(data)
               if text == old_bytes]
    if len(matches) != 1:
        raise ValueError(f"expected one DEX string {old!r}, found {len(matches)}")
    start, end = matches[0]
    if end - start != len(old_bytes):
        raise ValueError(f"unexpected encoded length for {old!r}")
    data[start:end] = new_bytes


def patch_dex(source: bytes) -> bytes:
    data = bytearray(source)

    # O javac/D8 produz: terminal ? const/16 88 : const/16 84.
    # A v0.4.1 preserva todos os outros bloqueios e muda apenas a régua
    # de liberação moderada para 80 (terminal) e 78 (setor).
    matches: list[int] = []
    for offset in range(0, len(data) - 10, 2):
        register = data[offset + 1]
        if data[offset:offset + 10] == bytes(
            [0x13, register, 0x58, 0x00, 0x28, 0x03,
             0x13, register, 0x54, 0x00]
        ):
            matches.append(offset)
    if len(matches) != 1:
        raise ValueError(f"expected one score-threshold pattern, found {len(matches)}")
    threshold = matches[0]
    data[threshold + 2:threshold + 4] = struct.pack("<h", 80)
    data[threshold + 8:threshold + 10] = struct.pack("<h", 78)

    replace_dex_string(data, "FRACO", "BAIXO")
    replace_dex_string(data, "FRACO/VERMELHO", "BAIXO/VERMELHO")
    replace_dex_string(
        data,
        "v0.4.0 • CONFLUÊNCIA EQUILIBRADA",
        "v0.4.1 • CONFLUÊNCIA EQUILIBRADA",
    )
    replace_dex_string(data, OLD_LEGEND, NEW_LEGEND)

    data[12:32] = hashlib.sha1(data[32:]).digest()
    struct.pack_into("<I", data, 8, zlib.adler32(data[12:]) & 0xFFFFFFFF)
    return bytes(data)


def patch_manifest(source: bytes) -> bytes:
    data = bytearray(source)
    old = "0.4.0".encode("utf-16le")
    new = "0.4.1".encode("utf-16le")
    if data.count(old) != 1:
        raise ValueError("manifest versionName was not uniquely identified")
    data[data.index(old):data.index(old) + len(old)] = new

    offset = 8
    strings: list[str] = []
    while offset < len(data):
        chunk_type, header_size, chunk_size = struct.unpack_from("<HHI", data, offset)
        if chunk_type == 0x0001:
            count = u32(data, offset + 8)
            flags = u32(data, offset + 16)
            strings_start = u32(data, offset + 20)
            if flags & 0x100:
                raise ValueError("unexpected UTF-8 Android string pool")
            for index in range(count):
                relative = u32(data, offset + header_size + index * 4)
                item = offset + strings_start + relative
                length = struct.unpack_from("<H", data, item)[0]
                item += 2
                if length & 0x8000:
                    length = ((length & 0x7FFF) << 16) | struct.unpack_from("<H", data, item)[0]
                    item += 2
                strings.append(bytes(data[item:item + length * 2]).decode("utf-16le"))
        elif chunk_type == 0x0102 and strings:
            extension = offset + 16
            element_name = strings[u32(data, extension + 4)]
            attribute_start = struct.unpack_from("<H", data, extension + 8)[0]
            attribute_size = struct.unpack_from("<H", data, extension + 10)[0]
            attribute_count = struct.unpack_from("<H", data, extension + 12)[0]
            attributes = extension + attribute_start
            if element_name == "manifest":
                for index in range(attribute_count):
                    attribute = attributes + index * attribute_size
                    name = strings[u32(data, attribute + 4)]
                    if name == "versionCode":
                        struct.pack_into("<I", data, attribute + 16, 6)
                        return bytes(data)
        offset += chunk_size
    raise ValueError("manifest versionCode was not found")


def is_old_signature(name: str) -> bool:
    upper = name.upper()
    if not upper.startswith("META-INF/"):
        return False
    basename = upper.rsplit("/", 1)[-1]
    return basename == "MANIFEST.MF" or basename.endswith((".SF", ".RSA", ".DSA", ".EC"))


def clone_info(info: zipfile.ZipInfo) -> zipfile.ZipInfo:
    cloned = zipfile.ZipInfo(info.filename, info.date_time)
    cloned.compress_type = info.compress_type
    cloned.comment = info.comment
    cloned.extra = info.extra
    cloned.create_system = info.create_system
    cloned.create_version = info.create_version
    cloned.extract_version = info.extract_version
    cloned.flag_bits = info.flag_bits & ~0x08
    cloned.volume = info.volume
    cloned.internal_attr = info.internal_attr
    cloned.external_attr = info.external_attr
    return cloned


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: patch_release_v041.py INPUT.apk OUTPUT-unsigned.apk")
    source_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(source_path, "r") as source, zipfile.ZipFile(
        output_path, "w", allowZip64=True
    ) as output:
        output.comment = source.comment
        for info in source.infolist():
            if is_old_signature(info.filename):
                continue
            payload = source.read(info.filename)
            if info.filename == "classes.dex":
                payload = patch_dex(payload)
            elif info.filename == "AndroidManifest.xml":
                payload = patch_manifest(payload)
            output.writestr(
                clone_info(info), payload,
                compress_type=info.compress_type,
                compresslevel=9 if info.compress_type == zipfile.ZIP_DEFLATED else None,
            )

    print(output_path)


if __name__ == "__main__":
    main()
