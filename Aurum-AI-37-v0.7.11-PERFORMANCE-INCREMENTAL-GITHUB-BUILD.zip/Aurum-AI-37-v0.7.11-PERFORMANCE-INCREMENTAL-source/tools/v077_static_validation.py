from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
app = root / 'app'
build = (app / 'build.gradle').read_text(encoding='utf-8')
manifest = (app / 'src/main/AndroidManifest.xml').read_text(encoding='utf-8')
standalone = (app / 'src/main/java/com/xspaceart/radar30/StandaloneActivity.java').read_text(encoding='utf-8')
service = (app / 'src/main/java/com/xspaceart/radar30/ScreenCaptureService.java').read_text(encoding='utf-8')
overlay = (app / 'src/main/java/com/xspaceart/radar30/OverlayController.java').read_text(encoding='utf-8')
formatter = (app / 'src/main/java/com/xspaceart/radar30/RadarBackstageFormatter.java').read_text(encoding='utf-8')
session = (app / 'src/main/java/com/xspaceart/radar30/core/RadarSession.java').read_text(encoding='utf-8')
precision = (app / 'src/main/java/com/xspaceart/radar30/core/PrecisionConfluenceEngine.java').read_text(encoding='utf-8')
verdict = (app / 'src/main/java/com/xspaceart/radar30/core/ConfluenceVerdict.java').read_text(encoding='utf-8')
consensus = (app / 'src/main/java/com/xspaceart/radar30/core/ConsensusSnapshot.java').read_text(encoding='utf-8')
policy = (app / 'src/main/java/com/xspaceart/radar30/core/ConsensusPolicy.java').read_text(encoding='utf-8')

assert 'versionCode 8' in build
assert "versionName '0.7.7-consensus-radar'" in build
assert 'android:name="com.xspaceart.radar30.StandaloneActivity"' in manifest
assert 'STANDALONE OCR RADAR • v0.7.7' in standalone
assert 'BASTIDOR DO RADAR' in standalone
assert 'PASTA DE SESSÕES' in standalone

# Capture/overlay/session UX from v0.7.6 remains intact.
assert 'RadarBackstageFormatter.focus(verdict)' in service
assert 'radarSession.consensusVelocity()' in service
assert 'radarSession.runnerConsensusVelocity()' in service
assert 'radarSession.saturationRemaining()' in service
assert 'recordEarlyTouch(previousVerdict' in service
assert 'Gravity.TOP | Gravity.END' in overlay
assert 'params.y = Ui.dp(context, 72)' in overlay
assert 'Gravity.BOTTOM | Gravity.END' not in overlay

# New explainability.
for marker in [
    'SETORES EM DISPUTA • CONSENSO ESPACIAL',
    'DENOMINADOR COMUM',
    'Rotas de entrada',
    'Momentum líder',
    'nunca esperar o setor acertar várias vezes',
]:
    assert marker in formatter, marker

# Spatial family voting and anti-artificial-consensus rules.
assert 'nativeDistance <= 2' in consensus
assert 'insideCandidateSector' in consensus
assert 'Famílias independentes' not in consensus  # class works numerically, UI owns wording
assert 'familyCount' in consensus and 'leaderMargin' in consensus
assert 'ConsensusSnapshot consensus' in verdict
assert 'ConsensusSnapshot.analyze(evidence, centralHeat)' in precision
assert 'consensusPrepare' in precision and 'consensusObserve' in precision

# Balanced-only dynamic policy.
for marker in ['immediate(', 'persistent(', 'momentum(', 'localExceptional(', 'recurrenceOverride(']:
    assert marker in policy, marker
assert 'verdict.mode != ConfluenceVerdict.Mode.BALANCED' in policy
assert 'ConsensusPolicy.persistent' in session
assert 'ConsensusPolicy.momentum' in session
assert 'saturationRemaining = 2' in session
assert 'HIPÓTESE REALIZADA DURANTE OBSERVAÇÃO' in session

# Precision gates must remain textually unchanged.
assert 'if (!verdict.entryQualified || hypothesis.updates < 3) return false;' in session
assert 'hypothesis.recentMinimum(3) < 78' in session
assert 'boolean precision = aurumScore >= 82' in precision
assert 'fusion.supporting.size() >= 6 || fiveExceptional' in precision

# Only 3 of the original 17 CORE files may drift from v0.7.6.
baseline = {}
for line in (root / 'CORE_BASELINE_V076_SHA256.txt').read_text(encoding='utf-8').splitlines():
    m = re.match(r'([0-9a-f]{64})\s+(.+)$', line.strip())
    if m:
        baseline[m.group(2)] = m.group(1)
authorized = {'ConfluenceVerdict.java', 'PrecisionConfluenceEngine.java', 'RadarSession.java'}
checked = 0
for name, digest in baseline.items():
    if name in authorized:
        continue
    path = app / 'src/main/java/com/xspaceart/radar30/core' / name
    assert path.exists(), name
    got = hashlib.sha256(path.read_bytes()).hexdigest()
    assert got == digest, f'unauthorized CORE drift: {name}'
    checked += 1
assert checked == 14, checked

# New files must exist; they are additive and not part of the old 17-file baseline.
assert (app / 'src/main/java/com/xspaceart/radar30/core/ConsensusSnapshot.java').exists()
assert (app / 'src/main/java/com/xspaceart/radar30/core/ConsensusPolicy.java').exists()

print('V077_STATIC_VALIDATION=PASS')
print('ARCHITECTURE=standalone-ocr-preserved+consensus-radar+top-overlay+session-archive')
print('CONSENSUS=family-native-peaks->physical-sector->leader-runner-momentum')
print('SATURATION=observation-touch->2-spin-structural-cooldown')
print('BALANCED=raw+exceptional-consensus+mature-consensus+momentum+local-exceptional')
print('PRECISION=PRESERVED')
print('CORE_PRESERVATION=PASS unchanged=14 authorized_original=3 additive=2')
print('PHYSICAL_S25FE=PENDING')
