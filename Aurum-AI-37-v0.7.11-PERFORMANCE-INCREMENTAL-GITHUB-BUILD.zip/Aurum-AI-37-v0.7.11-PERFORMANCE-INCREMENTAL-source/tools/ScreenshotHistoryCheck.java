import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.SignalUpdate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Regressão baseada nos 30 números visíveis no print de teste do usuário. */
public final class ScreenshotHistoryCheck {
    public static void main(String[] args) {
        List<Integer> history = Arrays.asList(
                33, 28, 11, 23, 12, 17, 36, 10, 9, 2,
                2, 3, 14, 24, 29, 27, 19, 8, 19, 23,
                23, 33, 27, 10, 9, 19, 16, 27, 28, 35);
        SignalUpdate update = new RadarSession().update(history,
                Collections.emptyList(), LearningModel.empty(), true);
        System.out.println(update.kind + " | " + update.headline);
        System.out.println(update.detail);
    }
}
