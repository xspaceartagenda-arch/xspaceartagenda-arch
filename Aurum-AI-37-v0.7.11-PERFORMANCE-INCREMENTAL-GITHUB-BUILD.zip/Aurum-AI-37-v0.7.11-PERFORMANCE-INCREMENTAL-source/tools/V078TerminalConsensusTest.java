import com.xspaceart.radar30.core.*;

import java.util.Arrays;
import java.util.List;

/** Valida que famílias independentes podem convergir no mesmo terminal decimal. */
public final class V078TerminalConsensusTest {
    public static void main(String[] args) {
        List<Evidence> evidence = Arrays.asList(
                terminalEvidence(EvidenceFamily.TRANSITION, 5, 15),
                terminalEvidence(EvidenceFamily.SEQUENCE, 5, 25),
                terminalEvidence(EvidenceFamily.ARITHMETIC, 5, 35),
                terminalEvidence(EvidenceFamily.RECENCY, 5, 5),
                terminalEvidence(EvidenceFamily.REGIME, 5, 25),
                terminalEvidence(EvidenceFamily.FREQUENCY, 5, 15)
        );
        double[] fused = fused(evidence);
        List<Integer> history = Arrays.asList(12, 25, 8, 15, 31, 5, 17, 35, 2, 24,
                25, 19, 15, 30, 5, 22, 11, 35, 6, 25, 14, 15, 33, 5, 28, 35, 1, 25, 9, 15);
        TerminalSnapshot snapshot = TerminalSnapshot.analyze(evidence, fused, history);

        assertEquals(5, snapshot.primary.terminal, "terminal líder");
        if (!snapshot.primary.coverage.equals(Arrays.asList(5, 15, 25, 35))) {
            throw new AssertionError("cobertura T5 incorreta: " + snapshot.primary.coverage);
        }
        if (snapshot.primary.familyCount < 5) {
            throw new AssertionError("famílias insuficientes: " + snapshot.primary.familyCount);
        }
        if (snapshot.primary.score < 70) {
            throw new AssertionError("score terminal fraco demais: " + snapshot.primary.score);
        }
        if (!snapshot.primary.predictive || !snapshot.primary.recent) {
            throw new AssertionError("terminal sem suporte preditivo/recente");
        }
        if (snapshot.leaderMargin < 0.10) {
            throw new AssertionError("líder sem separação suficiente: " + snapshot.leaderMargin);
        }
        System.out.println("V078_TERMINAL_CONSENSUS=PASS terminal=" + snapshot.primary.terminal
                + " score=" + snapshot.primary.score + " families=" + snapshot.primary.familyCount
                + " margin=" + Math.round(snapshot.leaderMargin * 100.0) + "% coverage="
                + snapshot.primary.coverage);
    }

    private static Evidence terminalEvidence(EvidenceFamily family, int terminal, int nativeTarget) {
        double[] heat = new double[37];
        for (int n : TerminalSnapshot.coverageOf(terminal)) heat[n] = 0.82;
        heat[nativeTarget] = 1.0;
        // Pequeno ruído fora do terminal, sem criar rival real.
        heat[(nativeTarget + 7) % 37] = 0.10;
        return new Evidence(family, heat, 0.94, 0.95, 30,
                0.93, 0.94, 0.04, family + " -> T" + terminal);
    }

    private static double[] fused(List<Evidence> evidence) {
        double[] out = new double[37];
        double total = 0.0;
        for (Evidence e : evidence) {
            double w = e.weight();
            total += w;
            for (int n = 0; n < 37; n++) out[n] += e.heat[n] * w;
        }
        if (total > 0.0) for (int n = 0; n < 37; n++) out[n] /= total;
        return out;
    }

    private static void assertEquals(int expected, int actual, String label) {
        if (expected != actual) throw new AssertionError(label + ": expected=" + expected + " actual=" + actual);
    }
}
