import com.xspaceart.radar30.core.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Evita os dois extremos: horas sem sinal e flood de entradas a cada poucos giros. */
public final class V077CadenceTest {
    public static void main(String[] args) {
        Result precision = run(true, 500, 370401L);
        Result balanced = run(false, 500, 370401L);
        if (precision.starts != 0) {
            throw new AssertionError("Precision mudou no vetor congelado: " + precision.starts);
        }
        if (balanced.starts < 6) {
            throw new AssertionError("Consensus Radar ainda ficou travado: " + balanced.starts);
        }
        if (balanced.starts > 30) {
            throw new AssertionError("Consensus Radar virou flood de sinais: " + balanced.starts);
        }
        if (balanced.firstStart < CurrentTableHistory.MIN_DEEP_SCAN_RESULTS - 1
                || balanced.firstStart > 110) {
            throw new AssertionError("Primeira entrada fora da janela útil: " + balanced.firstStart);
        }
        System.out.println("V077_CADENCE=PASS precision=" + precision.starts
                + " balanced=" + balanced.starts + " first=" + balanced.firstStart);
    }

    private static Result run(boolean conservative, int spins, long seed) {
        RadarSession session = new RadarSession();
        List<Integer> history = new ArrayList<>();
        Random random = new Random(seed);
        int starts = 0, first = -1;
        for (int spin = 0; spin < spins; spin++) {
            int result = random.nextInt(37);
            history.add(0, result);
            SignalUpdate update = session.update(history, Collections.singletonList(result),
                    LearningModel.empty(), conservative);
            if (update.kind == SignalUpdate.Kind.ENTRY) {
                starts++;
                if (first < 0) first = spin;
            }
        }
        return new Result(starts, first);
    }

    private static final class Result {
        final int starts, firstStart;
        Result(int starts, int firstStart) { this.starts = starts; this.firstStart = firstStart; }
    }
}
