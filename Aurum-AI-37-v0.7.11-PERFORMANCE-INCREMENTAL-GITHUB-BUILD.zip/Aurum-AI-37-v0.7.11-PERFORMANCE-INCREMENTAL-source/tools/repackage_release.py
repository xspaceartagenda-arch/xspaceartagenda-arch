#!/usr/bin/env python3
"""Reempacota o APK Gradle validado com DEX e versão substituídos."""

from __future__ import annotations

import struct
import sys
import zipfile
from pathlib import Path


def u32(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def patch_manifest(source: bytes, old_name: str, new_name: str,
                   old_code: int, new_code: int) -> bytes:
    if len(old_name) != len(new_name):
        raise ValueError("versionName deve manter o mesmo comprimento no AXML")
    data = bytearray(source)
    old = old_name.encode("utf-16le")
    new = new_name.encode("utf-16le")
    if data.count(old) != 1:
        raise ValueError("versionName anterior não foi identificado uma única vez")
    start = data.index(old)
    data[start:start + len(old)] = new

    offset = 8
    strings: list[str] = []
    while offset < len(data):
        chunk_type, header_size, chunk_size = struct.unpack_from("<HHI", data, offset)
        if chunk_size <= 0:
            raise ValueError("chunk AXML inválido")
        if chunk_type == 0x0001:
            count = u32(data, offset + 8)
            flags = u32(data, offset + 16)
            strings_start = u32(data, offset + 20)
            if flags & 0x100:
                raise ValueError("string pool UTF-8 inesperado")
            for index in range(count):
                relative = u32(data, offset + header_size + index * 4)
                item = offset + strings_start + relative
                length = struct.unpack_from("<H", data, item)[0]
                item += 2
                if length & 0x8000:
                    length = ((length & 0x7FFF) << 16) | struct.unpack_from(
                        "<H", data, item)[0]
                    item += 2
                strings.append(bytes(data[item:item + length * 2]).decode("utf-16le"))
        elif chunk_type == 0x0102 and strings:
            extension = offset + 16
            element_name = strings[u32(data, extension + 4)]
            attribute_start = struct.unpack_from("<H", data, extension + 8)[0]
            attribute_size = struct.unpack_from("<H", data, extension + 10)[0]
            attribute_count = struct.unpack_from("<H", data, extension + 12)[0]
            attributes = extension + attribute_start
            if element_name == "manifest":
                for index in range(attribute_count):
                    attribute = attributes + index * attribute_size
                    name = strings[u32(data, attribute + 4)]
                    if name == "versionCode":
                        current = u32(data, attribute + 16)
                        if current != old_code:
                            raise ValueError(
                                f"versionCode esperado {old_code}, encontrado {current}")
                        struct.pack_into("<I", data, attribute + 16, new_code)
                        return bytes(data)
        offset += chunk_size
    raise ValueError("versionCode não foi encontrado no manifesto")


def is_signature(name: str) -> bool:
    upper = name.upper()
    if not upper.startswith("META-INF/"):
        return False
    basename = upper.rsplit("/", 1)[-1]
    return basename == "MANIFEST.MF" or basename.endswith(
        (".SF", ".RSA", ".DSA", ".EC"))


def clone_info(info: zipfile.ZipInfo) -> zipfile.ZipInfo:
    cloned = zipfile.ZipInfo(info.filename, info.date_time)
    cloned.compress_type = info.compress_type
    cloned.comment = info.comment
    cloned.extra = info.extra
    cloned.create_system = info.create_system
    cloned.create_version = info.create_version
    cloned.extract_version = info.extract_version
    cloned.flag_bits = info.flag_bits & ~0x08
    cloned.volume = info.volume
    cloned.internal_attr = info.internal_attr
    cloned.external_attr = info.external_attr
    return cloned


def main() -> None:
    if len(sys.argv) != 8:
        raise SystemExit(
            "uso: repackage_release.py INPUT.apk DEX OUTPUT.apk "
            "OLD_NAME NEW_NAME OLD_CODE NEW_CODE")
    source_path = Path(sys.argv[1])
    dex_path = Path(sys.argv[2])
    output_path = Path(sys.argv[3])
    old_name, new_name = sys.argv[4], sys.argv[5]
    old_code, new_code = int(sys.argv[6]), int(sys.argv[7])
    dex = dex_path.read_bytes()

    replaced_dex = False
    with zipfile.ZipFile(source_path, "r") as source, zipfile.ZipFile(
            output_path, "w", allowZip64=True) as output:
        output.comment = source.comment
        for info in source.infolist():
            if is_signature(info.filename):
                continue
            if info.filename in {
                    "assets/dexopt/baseline.prof",
                    "assets/dexopt/baseline.profm"}:
                continue
            payload = source.read(info.filename)
            if info.filename == "classes.dex":
                payload = dex
                replaced_dex = True
            elif info.filename == "AndroidManifest.xml":
                payload = patch_manifest(payload, old_name, new_name,
                                         old_code, new_code)
            output.writestr(
                clone_info(info), payload,
                compress_type=info.compress_type,
                compresslevel=9 if info.compress_type == zipfile.ZIP_DEFLATED else None,
            )
    if not replaced_dex:
        raise ValueError("classes.dex não foi encontrado no APK-base")
    print(output_path)


if __name__ == "__main__":
    main()
