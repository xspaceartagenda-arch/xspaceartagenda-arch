import com.xspaceart.radar30.integrated.normalize.SourceOrderTracker;
import java.util.*;
public final class SourceOrderTrackerTest {
  private static void ok(boolean c,String m){if(!c)throw new AssertionError(m);}
  public static void main(String[] a){
    List<Integer> base=Arrays.asList(23,4,17,9,31,2,14,28,6,35);
    SourceOrderTracker front=new SourceOrderTracker();front.observe(base);List<Integer> n=new ArrayList<>();n.add(12);n.addAll(base);front.observe(n);ok(front.order()==SourceOrderTracker.Order.NEWEST_FIRST,"front");
    List<Integer> oldest=new ArrayList<>(base);Collections.reverse(oldest);SourceOrderTracker back=new SourceOrderTracker();back.observe(oldest);List<Integer> oldest2=new ArrayList<>(oldest);oldest2.add(12);back.observe(oldest2);ok(back.order()==SourceOrderTracker.Order.OLDEST_FIRST,"back");ok(back.normalize(oldest2).get(0)==12,"normalize");
    SourceOrderTracker immediateFront=new SourceOrderTracker();immediateFront.observe(base,23);ok(immediateFront.order()==SourceOrderTracker.Order.NEWEST_FIRST,"current result learns front on bootstrap");
    SourceOrderTracker immediateBack=new SourceOrderTracker();immediateBack.observe(oldest,23);ok(immediateBack.order()==SourceOrderTracker.Order.OLDEST_FIRST,"current result learns back on bootstrap");
    System.out.println("PASS source order tracker");
  }
}
