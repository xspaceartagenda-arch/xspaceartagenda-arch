import com.xspaceart.radar30.integrated.IntegratedSignalBridge;
import com.xspaceart.radar30.integrated.normalize.SourceDelta;
import java.util.*;

public final class IntegratedOperationalTest {
    private static void ok(boolean c,String m){if(!c)throw new AssertionError(m);}
    public static void main(String[] args){
        IntegratedSignalBridge b=new IntegratedSignalBridge();
        List<Integer> base=Arrays.asList(23,4,17,9,31,2,14,28,6,35,11,20,1,32,8,26,3,19,30,7);
        ok(b.replaceBootstrap(base).accepted,"bootstrap"); ok(b.historySize()==20,"bootstrap size");
        List<Integer> next=new ArrayList<>(); next.add(12); next.addAll(base);
        IntegratedSignalBridge.Result r=b.acceptScan(next); ok(r.accepted,"scan");ok(b.historySnapshot().get(0)==12,"new result");
        b.prependManual(36);ok(b.historySnapshot().get(0)==36,"manual");
        b.replaceLatest(5);ok(b.historySnapshot().get(0)==5,"replace");
        b.removeLatest();ok(b.historySnapshot().get(0)==12,"remove");
        List<Integer> sourceAtClear=new ArrayList<>(next);
        b.clearOperational();ok(b.historySize()==0,"clear");
        SourceDelta.Result unchanged=SourceDelta.between(sourceAtClear,sourceAtClear);ok(unchanged.valid&&unchanged.newestFirst.isEmpty(),"stale snapshot ignored");
        List<Integer> after=new ArrayList<>();after.add(18);after.addAll(sourceAtClear);
        SourceDelta.Result delta=SourceDelta.between(after,sourceAtClear);ok(delta.valid&&delta.newestFirst.equals(Collections.singletonList(18)),"future-only delta");
        b.acceptIncremental(delta.newestFirst);ok(b.historySize()==1&&b.historySnapshot().get(0)==18,"future only core");

        // Retomada da Activity: o histórico salvo é aquecido, mas o bootstrap visível
        // ainda precisa reconciliar sem apagar a cauda já confirmada da sessão.
        IntegratedSignalBridge resumed=new IntegratedSignalBridge();
        List<Integer> saved=new ArrayList<>();saved.add(12);saved.addAll(base);
        resumed.replaceBootstrap(saved);
        List<Integer> visible=new ArrayList<>(saved.subList(0,12));
        IntegratedSignalBridge.Result recon=resumed.acceptScan(visible);
        ok(recon.accepted,"resume visible reconcile");
        ok(resumed.historySize()==saved.size(),"resume must preserve confirmed tail");
        List<Integer> visibleNext=new ArrayList<>();visibleNext.add(18);visibleNext.addAll(visible);
        recon=resumed.acceptScan(visibleNext);
        ok(recon.accepted&&resumed.historySnapshot().get(0)==18,"resume next spin");

        System.out.println("PASS integrated operational controls");
    }
}
