import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.PrecisionConfluenceEngine;
import com.xspaceart.radar30.core.RegimeDetector;
import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class PrecisionConfluenceProbe {
    public static void main(String[] args) {
        PrecisionConfluenceEngine engine = new PrecisionConfluenceEngine();
        List<Integer> pattern = patternHistory();
        RegimeDetector.Snapshot regime = new RegimeDetector().detect(pattern);
        ConfluenceVerdict verdict = engine.analyze(pattern);
        System.out.println("pattern target=" + verdict.target
                + " score=" + verdict.aurumScore
                + " decision=" + verdict.decision
                + " families=" + verdict.independentFamilies
                + " contradiction=" + verdict.contradictionScore
                + " dominance=" + verdict.dominanceMargin
                + " dispersion=" + verdict.evidenceDispersion
                + " regime=" + regime.currentRegimeStart
                + " regimeConfidence=" + regime.regimeConfidence
                + " coverage=" + verdict.coverage);
        for (String reason : verdict.reasons) System.out.println("  " + reason);

        List<Integer> shifted = new ArrayList<>();
        int[] newRegime = {32, 15, 19, 0, 26, 32, 15};
        for (int i = 0; i < 35; i++) shifted.add(newRegime[i % newRegime.length]);
        for (int i = 0; i < 240; i++) shifted.add(i % 37);
        RegimeDetector.Snapshot shift = new RegimeDetector().detect(shifted);
        System.out.println("shift change=" + shift.changeDetected
                + " length=" + shift.currentRegimeStart
                + " confidence=" + shift.regimeConfidence
                + " divergence=" + shift.divergence
                + " previousWeight=" + shift.previousRegimeWeight);

        List<Integer> exceptional = new ArrayList<>();
        int[] exceptionalLoop = {32, 15, 19, 0, 26, 32, 19, 15, 26, 0};
        for (int i = 0; i < 500; i++) exceptional.add(exceptionalLoop[i % exceptionalLoop.length]);
        ConfluenceVerdict exceptionalVerdict = engine.analyze(exceptional);
        System.out.println("exceptional target=" + exceptionalVerdict.target
                + " score=" + exceptionalVerdict.aurumScore
                + " decision=" + exceptionalVerdict.decision
                + " families=" + exceptionalVerdict.independentFamilies
                + " contradiction=" + exceptionalVerdict.contradictionScore
                + " dominance=" + exceptionalVerdict.dominanceMargin);
        for (String reason : exceptionalVerdict.reasons) System.out.println("  " + reason);

        int entries = 0;
        int prepares = 0;
        int observes = 0;
        int maxScore = 0;
        Random random = new Random(370037L);
        List<Integer> fair = new ArrayList<>();
        for (int i = 0; i < 500; i++) fair.add(random.nextInt(37));
        for (int spin = 0; spin < 500; spin++) {
            fair.add(0, random.nextInt(37));
            if (fair.size() > 500) fair.remove(fair.size() - 1);
            ConfluenceVerdict result = engine.analyze(fair);
            maxScore = Math.max(maxScore, result.aurumScore);
            if (result.decision == ConfluenceVerdict.Decision.ENTRY) entries++;
            else if (result.decision == ConfluenceVerdict.Decision.PREPARE) prepares++;
            else if (result.decision == ConfluenceVerdict.Decision.OBSERVE) observes++;
        }
        System.out.println("fair scans=500 entries=" + entries + " prepares=" + prepares
                + " observes=" + observes + " maxScore=" + maxScore);
    }

    static List<Integer> patternHistory() {
        int[] recent = {11, 23, 6, 29, 25, 14, 10, 5, 21, 33};
        int[] target = {32, 15, 19, 0, 26};
        List<Integer> history = new ArrayList<>();
        for (int value : recent) history.add(value);
        for (int repeat = 0; repeat < 20; repeat++) {
            for (int value : target) history.add(value);
            for (int value : recent) history.add(value);
            history.add(Wheel.EUROPEAN.get((repeat * 7) % 37));
            history.add(Wheel.EUROPEAN.get((repeat * 11 + 3) % 37));
        }
        Random random = new Random(32L);
        while (history.size() < 500) history.add(random.nextInt(37));
        return history;
    }
}
