import com.xspaceart.radar30.core.AnalysisResult;
import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarEngine;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.ScanSynchronizer;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class CoreSmokeTest {
    public static void main(String[] args) {
        assertEquals(Arrays.asList(26, 0, 32, 15, 19),
                Wheel.coverage(32, 2), "coverage 32");

        List<Integer> ordinary = Arrays.asList(
                30, 23, 26, 26, 7, 28, 22, 21, 27, 8,
                22, 3, 31, 35, 9, 13, 25, 15, 8, 27,
                23, 26, 20, 32, 25, 23, 15, 34, 15, 4);
        ScanSynchronizer sync = new ScanSynchronizer();
        ScanSynchronizer.MergeResult bootstrap = sync.merge(ordinary);
        assertTrue(bootstrap.accepted && bootstrap.bootstrap, "bootstrap");

        List<Integer> shifted = new ArrayList<>();
        shifted.add(30); // repetição legítima do número mais recente
        shifted.addAll(ordinary.subList(0, ordinary.size() - 1));
        ScanSynchronizer.MergeResult merge = sync.merge(shifted);
        assertTrue(merge.accepted, "merge accepted");
        assertEquals(Collections.singletonList(30), merge.newNumbers,
                "duplicate newest preserved");

        List<Integer> concentrated = Arrays.asList(
                32, 15, 0, 19, 32,
                4, 15, 26, 32, 19, 0, 15,
                21, 4, 32, 15, 19, 26, 0, 32,
                7, 12, 3, 35, 28, 26, 32, 15, 19, 4);
        AnalysisResult precision = new RadarEngine().analyze(
                concentrated, LearningModel.empty(), true);
        assertEquals(32, precision.target, "deep target");
        assertTrue(precision.coverage.size() == 5, "five-number coverage");
        assertTrue(precision.strength >= 84, "deep strength");
        assertEquals(AnalysisResult.Decision.ENTER, precision.decision,
                "deep multi-block entry");
        assertTrue(precision.confluenceCount >= 6,
                "quality criteria counted");

        List<Integer> terminalFive = Arrays.asList(
                5, 15, 25, 35, 5,
                15, 25, 35, 5, 15, 25, 35,
                5, 15, 25, 35, 5, 15, 25, 35,
                1, 2, 3, 4, 6, 7, 8, 9, 10, 11);
        AnalysisResult terminal = new RadarEngine().analyze(
                terminalFive, LearningModel.empty(), true);
        assertEquals(AnalysisResult.Decision.ENTER, terminal.decision,
                "terminal entry");
        assertEquals("TERMINAL 5", terminal.playLabel, "terminal label");
        assertEquals(Arrays.asList(5, 15, 25, 35), terminal.coverage,
                "terminal coverage");
        SignalUpdate terminalSignal = new RadarSession().update(
                terminalFive, Collections.emptyList(), LearningModel.empty(), true);
        assertEquals(SignalUpdate.Kind.SCANNING, terminalSignal.kind,
                "legacy terminal cannot bypass precision session");
        assertTrue(terminalSignal.coverage.isEmpty(),
                "legacy terminal remains shadow-only");

        List<Integer> protectedSector = Arrays.asList(
                32, 12, 22, 15, 0,
                32, 2, 19, 15, 22, 0, 26,
                32, 12, 15, 19, 2, 0, 22, 26, 4, 21,
                7, 8, 9, 10, 11, 13, 14, 16);
        AnalysisResult protectedResult = new RadarEngine().analyze(
                protectedSector, LearningModel.empty(), true);
        assertEquals(AnalysisResult.Decision.ENTER, protectedResult.decision,
                "protected sector entry");
        assertEquals(32, protectedResult.target, "protected sector target");
        assertEquals(Arrays.asList(26, 0, 32, 15, 19),
                protectedResult.primaryCoverage, "protected primary coverage");
        assertEquals("PROTEÇÃO TERMINAL 2", protectedResult.protectionLabel,
                "protection label");
        assertEquals(Arrays.asList(2, 12, 22),
                protectedResult.protectionCoverage, "protection extras");
        assertTrue(protectedResult.coverage.size() == 8,
                "combined coverage de-duplicates target");
        SignalUpdate protectedSignal = new RadarSession().update(
                protectedSector, Collections.emptyList(),
                LearningModel.empty(), true);
        assertEquals(SignalUpdate.Kind.SCANNING, protectedSignal.kind,
                "legacy protection cannot bypass precision session");
        assertTrue(protectedSignal.coverage.isEmpty(),
                "legacy protection remains shadow-only");

        AnalysisResult ordinaryResult = new RadarEngine().analyze(
                ordinary, LearningModel.empty(), true);
        assertTrue(ordinaryResult.decision != AnalysisResult.Decision.ENTER,
                "ordinary spread rejected");

        List<Integer> burstOnly = Arrays.asList(
                32, 15, 0, 19, 26,
                8, 23, 10, 5, 24, 8, 23,
                1, 2, 3, 4, 6, 7, 9, 11, 12,
                13, 14, 16, 17, 18, 20, 21, 22, 25);
        AnalysisResult burst = new RadarEngine().analyze(
                burstOnly, LearningModel.empty(), true);
        assertTrue(burst.decision != AnalysisResult.Decision.ENTER,
                "recent burst without persistence rejected");

        List<Integer> singleRepeat = new ArrayList<>();
        for (int i = 0; i < 30; i++) singleRepeat.add(32);
        AnalysisResult repeated = new RadarEngine().analyze(
                singleRepeat, LearningModel.empty(), true);
        assertTrue(repeated.decision != AnalysisResult.Decision.ENTER,
                "single number cannot create deep signal alone");

        List<Integer> ambiguous = Arrays.asList(
                32, 15, 0, 10, 23,
                26, 19, 32, 8, 5, 24, 10,
                0, 15, 19, 26, 32, 15,
                10, 23, 8, 5, 24, 10,
                1, 2, 3, 4, 6, 7);
        AnalysisResult tied = new RadarEngine().analyze(
                ambiguous, LearningModel.empty(), true);
        assertTrue(tied.decision != AnalysisResult.Decision.ENTER,
                "competing sectors rejected");

        Map<String, int[]> stableEvidence = new LinkedHashMap<>();
        stableEvidence.put("modelo_geral_v3", new int[]{120, 70, 60, 36});
        LearningModel learned = new LearningModel(stableEvidence, 120, 70);
        assertTrue(learned.isActive(), "learning minimum sample");
        assertTrue(learned.adjustmentFor(
                Collections.singletonList("modelo_geral_v3")) > 0,
                "stable validation adjustment");
        assertTrue(Math.abs(learned.adjustmentFor(
                Collections.singletonList("modelo_geral_v3"))) <= 4,
                "learning adjustment capped");

        Map<String, int[]> coverageEvidence = new LinkedHashMap<>();
        coverageEvidence.put(LearningModel.modelFeature(5),
                new int[]{120, 70, 60, 36});
        LearningModel validatedCoverage = new LearningModel(
                coverageEvidence, 120, 70, 42.4);
        assertTrue(validatedCoverage.isCoverageValidated(5),
                "coverage needs total and recent validation");

        Map<String, int[]> smallEvidence = new LinkedHashMap<>();
        smallEvidence.put(LearningModel.modelFeature(5),
                new int[]{12, 3, 6, 1});
        LearningModel smallSample = new LearningModel(smallEvidence, 12, 3, 4.2);
        assertTrue(!smallSample.isCoverageValidated(5),
                "twelve observations cannot validate a coverage");

        Map<String, int[]> unstableEvidence = new LinkedHashMap<>();
        unstableEvidence.put("modelo_geral_v3", new int[]{120, 60, 60, 12});
        LearningModel unstable = new LearningModel(unstableEvidence, 120, 60);
        assertTrue(unstable.adjustmentFor(
                Collections.singletonList("modelo_geral_v3")) < 0,
                "recent collapse penalized");

        Map<String, int[]> legacyEvidence = new LinkedHashMap<>();
        legacyEvidence.put("curto_forte", new int[]{40, 36});
        LearningModel legacy = new LearningModel(legacyEvidence, 120, 108);
        assertEquals(0, legacy.adjustmentFor(
                Collections.singletonList("curto_forte")),
                "legacy evidence cannot tune v3 without validation split");

        RadarSession session = new RadarSession();
        SignalUpdate signal = session.update(concentrated, Collections.emptyList(),
                LearningModel.empty(), true);
        assertEquals(SignalUpdate.Kind.SCANNING, signal.kind,
                "thirty-result legacy pattern remains shadow-only");
        assertTrue(signal.coverage.isEmpty(),
                "precision session publishes no legacy coverage");

        assertTrue(Math.abs(LearningModel.threeSpinBaseline(8)
                        - (1.0 - Math.pow(29.0 / 37.0, 3.0))) < 0.000001,
                "combined coverage uses its own baseline");

        System.out.println("OK core smoke test");
        System.out.println("Target=" + precision.target + " coverage="
                + precision.coverage + " strength=" + precision.strength);
    }

    private static void assertTrue(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }

    private static void assertEquals(Object expected, Object actual, String label) {
        if (!expected.equals(actual)) {
            throw new AssertionError(label + ": expected=" + expected
                    + " actual=" + actual);
        }
    }
}
