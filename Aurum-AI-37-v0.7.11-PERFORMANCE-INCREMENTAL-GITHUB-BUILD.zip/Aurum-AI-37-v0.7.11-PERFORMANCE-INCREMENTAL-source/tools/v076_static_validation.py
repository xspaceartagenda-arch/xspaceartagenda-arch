from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
app = root / 'app'
build = (app / 'build.gradle').read_text(encoding='utf-8')
manifest = (app / 'src/main/AndroidManifest.xml').read_text(encoding='utf-8')
standalone = (app / 'src/main/java/com/xspaceart/radar30/StandaloneActivity.java').read_text(encoding='utf-8')
service = (app / 'src/main/java/com/xspaceart/radar30/ScreenCaptureService.java').read_text(encoding='utf-8')
store = (app / 'src/main/java/com/xspaceart/radar30/AppStateStore.java').read_text(encoding='utf-8')
overlay = (app / 'src/main/java/com/xspaceart/radar30/OverlayController.java').read_text(encoding='utf-8')
formatter = (app / 'src/main/java/com/xspaceart/radar30/RadarBackstageFormatter.java').read_text(encoding='utf-8')
ledger = (app / 'src/main/java/com/xspaceart/radar30/SessionLedger.java').read_text(encoding='utf-8')
session = (app / 'src/main/java/com/xspaceart/radar30/core/RadarSession.java').read_text(encoding='utf-8')
precision = (app / 'src/main/java/com/xspaceart/radar30/core/PrecisionConfluenceEngine.java').read_text(encoding='utf-8')

assert 'versionCode 7' in build
assert "versionName '0.7.6-radar-backstage-session'" in build
assert 'android:name="com.xspaceart.radar30.StandaloneActivity"' in manifest
assert 'STANDALONE OCR RADAR • v0.7.6' in standalone
assert 'BASTIDOR DO RADAR' in standalone
assert 'PASTA DE SESSÕES' in standalone
assert 'radarFocus' in standalone and 'radarSectors' in standalone and 'radarGate' in standalone
assert 'sessionArchive(this, 12)' in standalone

assert 'RadarBackstageFormatter.focus(verdict)' in service
assert 'RadarBackstageFormatter.sectorRanking(verdict)' in service
assert 'RadarBackstageFormatter.heat(verdict)' in service
assert 'RadarBackstageFormatter.families(verdict)' in service
assert 'RadarBackstageFormatter.gate(verdict, update)' in service
assert 'recordEarlyTouch(previousVerdict' in service
assert 'Não conta como STRYKE' in service

assert 'RADAR_FOCUS' in store and 'RADAR_SECTORS' in store
assert 'RADAR_HEAT' in store and 'RADAR_GATE' in store
assert 'RADAR_EARLY_TOUCH' in store

assert 'Gravity.TOP | Gravity.END' in overlay
assert 'params.y = Ui.dp(context, 72)' in overlay
assert 'Mantém a bolha sempre na faixa superior da tela' in overlay
assert 'Gravity.BOTTOM | Gravity.END' not in overlay

assert 'ALVOS EM DISPUTA' in formatter
assert 'QUENTE' in formatter and 'FRIO / MENOR APOIO' in formatter
assert 'FAMÍLIAS DO FOCO' in formatter
assert 'FAST TRACK 60+' in formatter
assert 'Confirmação = estrutura/persistência' in formatter
assert 'não é necessário o alvo acertar novamente' in formatter
assert 'não é chance matemática do próximo giro' in formatter

assert 'sessionArchive(Context context, int limit)' in ledger
assert 'LOSS/REDS' in ledger

# v0.7.6: exceção muito específica, baseada no cenário físico observado.
assert 'balancedFastTrack(lastVerdict)' in session
assert 'verdict.aurumScore >= 60' in session
assert 'verdict.independentFamilies >= 5' in session
assert 'verdict.contradictionScore <= 0.20' in session
assert 'verdict.dominanceMargin >= 0.15' in session
assert 'fastTrackEntry' in session
assert 'ENTRADA OPORTUNIDADE — BALANCED' in session
# Precision continua congelado.
assert 'if (!verdict.entryQualified || hypothesis.updates < 3) return false;' in session
assert 'hypothesis.recentMinimum(3) < 78' in session
assert 'boolean precision = aurumScore >= 82' in precision
assert 'fusion.supporting.size() >= 6 || fiveExceptional' in precision

# A v0.7.6 autoriza alteração em apenas 1 dos 17 arquivos CORE: RadarSession.java.
baseline = {}
for line in (root / 'CORE_BASELINE_V075_SHA256.txt').read_text(encoding='utf-8').splitlines():
    m = re.match(r'([0-9a-f]{64})\s+(.+)$', line.strip())
    if m:
        baseline[m.group(2)] = m.group(1)
authorized = {'RadarSession.java'}
checked = 0
for name, digest in baseline.items():
    if name in authorized:
        continue
    path = app / 'src/main/java/com/xspaceart/radar30/core' / name
    assert path.exists(), name
    got = hashlib.sha256(path.read_bytes()).hexdigest()
    assert got == digest, f'unauthorized CORE drift: {name}'
    checked += 1
assert checked == 16, checked

print('V076_STATIC_VALIDATION=PASS')
print('ARCHITECTURE=standalone-ocr-preserved+radar-backstage+top-overlay+session-archive')
print('RADAR=top3-targets+hot-cold+families+gate-explainability')
print('BALANCED=exceptional-fast-track-60x5-low-contradiction-strong-dominance')
print('PRECISION=PRESERVED')
print('CORE_PRESERVATION=PASS unchanged=16 authorized=1')
print('PHYSICAL_S25FE=PENDING')
