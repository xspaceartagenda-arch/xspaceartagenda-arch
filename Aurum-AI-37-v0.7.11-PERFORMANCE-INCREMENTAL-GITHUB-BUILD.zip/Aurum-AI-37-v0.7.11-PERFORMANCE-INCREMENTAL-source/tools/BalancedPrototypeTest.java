import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

/** Protótipo para calibrar frequência antes de alterar o motor do aplicativo. */
public final class BalancedPrototypeTest {
    public static void main(String[] args) {
        simulate(500_000, 370402L);
    }

    private static void simulate(int spins, long seed) {
        Random random = new Random(seed);
        List<Integer> history = new ArrayList<>();
        Active active = null;
        int cooldown = 0;
        int starts = 0;
        int hits = 0;
        int expired = 0;
        int previousStart = -1;
        long gapSum = 0;
        int sectorStarts = 0;
        int terminalStarts = 0;
        int prepares = 0;

        for (int spin = 0; spin < spins; spin++) {
            int result = random.nextInt(37);
            history.add(0, result);
            if (history.size() > 50) history.remove(history.size() - 1);

            if (active != null) {
                if (active.zone.contains(result)) {
                    hits++;
                    active = null;
                    cooldown = 1;
                } else if (++active.misses >= 3) {
                    expired++;
                    active = null;
                    cooldown = 1;
                }
                continue;
            }
            if (cooldown > 0) {
                cooldown--;
                continue;
            }
            if (history.size() < 30) continue;

            Candidate candidate = evaluate(history);
            if (!candidate.entry) {
                if (candidate.prepare) prepares++;
                continue;
            }
            starts++;
            if (candidate.terminal) terminalStarts++; else sectorStarts++;
            if (previousStart >= 0) gapSum += spin - previousStart;
            previousStart = spin;
            active = new Active(candidate.zone);
        }

        int resolved = hits + expired;
        System.out.printf(Locale.US,
                "balanced starts=%d resolved=%d hits=%d hit-rate=%.2f%% avg-gap=%.1f spins sectors=%d terminals=%d prepare-frames=%d%n",
                starts, resolved, hits, resolved == 0 ? 0.0 : hits * 100.0 / resolved,
                starts <= 1 ? 0.0 : gapSum / (double) (starts - 1),
                sectorStarts, terminalStarts, prepares);
    }

    private static Candidate evaluate(List<Integer> history) {
        List<Candidate> candidates = new ArrayList<>();
        WindowProfile sectorWindows = windows(history, false);
        for (int center : Wheel.EUROPEAN) {
            candidates.add(build(history, center, Wheel.coverage(center, 2), false,
                    sectorWindows));
        }
        WindowProfile terminalWindows = windows(history, true);
        for (int terminal = 0; terminal <= 9; terminal++) {
            candidates.add(build(history, terminal, terminalCoverage(terminal), true,
                    terminalWindows));
        }

        candidates.sort((first, second) -> Integer.compare(second.score, first.score));
        Candidate best = candidates.get(0);
        Candidate runner = null;
        for (int i = 1; i < candidates.size(); i++) {
            if (overlap(best.zone, candidates.get(i).zone) <= 1) {
                runner = candidates.get(i);
                break;
            }
        }
        int separation = best.score - (runner == null ? 0 : runner.score);
        boolean sectorEmerging = best.recent >= 3 && best.h12 >= 4
                && best.h30 >= 8 && best.distinct >= 3;
        boolean sectorPersistent = best.recent >= 2 && best.confirmation >= 2
                && best.context >= 4 && best.h30 >= 9 && best.distinct >= 3;
        int terminalTotal = best.zone.size() == 4 ? 7 : 6;
        int terminalPersistentTotal = best.zone.size() == 4 ? 8 : 7;
        int terminalDistinct = best.zone.size() == 4 ? 3 : 2;
        boolean terminalEmerging = best.recent >= 3 && best.h12 >= 4
                && best.h30 >= terminalTotal && best.distinct >= terminalDistinct;
        boolean terminalPersistent = best.recent >= 2 && best.confirmation >= 2
                && best.context >= 3 && best.h30 >= terminalPersistentTotal
                && best.distinct >= terminalDistinct;
        boolean route = best.terminal
                ? terminalEmerging || terminalPersistent
                : sectorEmerging || sectorPersistent;
        int scoreThreshold = best.terminal ? 88 : 84;
        int marginThreshold = best.terminal ? 10 : 8;
        best.entry = route && best.stable && best.contradictions <= 1
                && separation >= marginThreshold && best.score >= scoreThreshold;
        best.prepare = !best.entry && best.score >= 74 && best.stable
                && best.distinct >= 2 && separation >= 5 && best.contradictions <= 1
                && (best.recent >= 2 || best.confirmation >= 2);
        return best;
    }

    private static Candidate build(List<Integer> history, int target, List<Integer> zone,
                                   boolean terminal, WindowProfile windows) {
        int recent = hits(history, zone, 0, 5);
        int confirmation = hits(history, zone, 5, 12);
        int context = hits(history, zone, 12, 30);
        int h12 = recent + confirmation;
        int h30 = h12 + context;
        int distinct = distinct(history, zone, 0, 12);
        int withoutNewest = hits(history, zone, 1, 30);
        boolean stable = withoutNewest >= Math.max(0, windows.withoutNewestMax - 1);
        int agreements = 0;
        if (recent == windows.recentMax) agreements++;
        if (confirmation == windows.confirmationMax) agreements++;
        if (context >= Math.max(0, windows.contextMax - 1)) agreements++;
        int contradictions = 0;
        if (recent < 2 && windows.recentMax >= 3) contradictions++;
        if (confirmation < 1 && windows.confirmationMax >= 3) contradictions++;
        int contextFloor = terminal ? 2 : 3;
        int contextPeak = terminal ? 5 : 6;
        if (context < contextFloor && windows.contextMax >= contextPeak) contradictions++;

        int score = recentPoints(recent, terminal)
                + confirmationPoints(confirmation, terminal)
                + contextPoints(context, terminal)
                + Math.min(8, distinct * 2)
                + (stable ? 6 : -8) + (agreements >= 2 ? 4 : 0)
                - contradictions * 5;
        return new Candidate(target, zone, terminal, recent, confirmation,
                context, h12, h30, distinct, stable, contradictions,
                Math.max(0, Math.min(100, score)));
    }

    private static int recentPoints(int hits, boolean terminal) {
        int[] sector = {0, 10, 30, 44, 54, 60};
        int[] terminals = {0, 12, 34, 48, 58, 64};
        int[] points = terminal ? terminals : sector;
        return points[Math.max(0, Math.min(5, hits))];
    }

    private static int confirmationPoints(int hits, boolean terminal) {
        int[] sector = {0, 8, 17, 25, 30, 33, 35, 36};
        int[] terminals = {0, 9, 19, 28, 34, 37, 39, 40};
        int[] points = terminal ? terminals : sector;
        return points[Math.max(0, Math.min(7, hits))];
    }

    private static int contextPoints(int hits, boolean terminal) {
        return Math.min(terminal ? 22 : 20, Math.max(0, hits) * (terminal ? 4 : 3));
    }

    private static WindowProfile windows(List<Integer> history, boolean terminal) {
        int recent = 0;
        int confirmation = 0;
        int context = 0;
        int withoutNewest = 0;
        int count = terminal ? 10 : Wheel.EUROPEAN.size();
        for (int value = 0; value < count; value++) {
            List<Integer> zone = terminal ? terminalCoverage(value) : Wheel.coverage(value, 2);
            recent = Math.max(recent, hits(history, zone, 0, 5));
            confirmation = Math.max(confirmation, hits(history, zone, 5, 12));
            context = Math.max(context, hits(history, zone, 12, 30));
            withoutNewest = Math.max(withoutNewest, hits(history, zone, 1, 30));
        }
        return new WindowProfile(recent, confirmation, context, withoutNewest);
    }

    private static List<Integer> terminalCoverage(int terminal) {
        List<Integer> result = new ArrayList<>();
        for (int number = terminal; number <= 36; number += 10) result.add(number);
        return result;
    }

    private static int hits(List<Integer> history, List<Integer> zone, int start, int end) {
        int count = 0;
        for (int index = start; index < Math.min(end, history.size()); index++) {
            if (zone.contains(history.get(index))) count++;
        }
        return count;
    }

    private static int distinct(List<Integer> history, List<Integer> zone, int start, int end) {
        Set<Integer> values = new HashSet<>();
        for (int index = start; index < Math.min(end, history.size()); index++) {
            int number = history.get(index);
            if (zone.contains(number)) values.add(number);
        }
        return values.size();
    }

    private static int overlap(List<Integer> first, List<Integer> second) {
        int count = 0;
        for (int value : first) if (second.contains(value)) count++;
        return count;
    }

    private static final class WindowProfile {
        final int recentMax;
        final int confirmationMax;
        final int contextMax;
        final int withoutNewestMax;

        WindowProfile(int recentMax, int confirmationMax, int contextMax,
                      int withoutNewestMax) {
            this.recentMax = recentMax;
            this.confirmationMax = confirmationMax;
            this.contextMax = contextMax;
            this.withoutNewestMax = withoutNewestMax;
        }
    }

    private static final class Active {
        final List<Integer> zone;
        int misses;

        Active(List<Integer> zone) {
            this.zone = zone;
        }
    }

    private static final class Candidate {
        final int target;
        final List<Integer> zone;
        final boolean terminal;
        final int recent;
        final int confirmation;
        final int context;
        final int h12;
        final int h30;
        final int distinct;
        final boolean stable;
        final int contradictions;
        final int score;
        boolean prepare;
        boolean entry;

        Candidate(int target, List<Integer> zone, boolean terminal, int recent,
                  int confirmation, int context, int h12, int h30, int distinct,
                  boolean stable, int contradictions, int score) {
            this.target = target;
            this.zone = zone;
            this.terminal = terminal;
            this.recent = recent;
            this.confirmation = confirmation;
            this.context = context;
            this.h12 = h12;
            this.h30 = h30;
            this.distinct = distinct;
            this.stable = stable;
            this.contradictions = contradictions;
            this.score = score;
        }
    }
}
