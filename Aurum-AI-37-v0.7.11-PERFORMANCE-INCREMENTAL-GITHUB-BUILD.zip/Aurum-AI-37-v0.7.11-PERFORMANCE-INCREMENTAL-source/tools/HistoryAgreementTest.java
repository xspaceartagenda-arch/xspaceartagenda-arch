import com.xspaceart.radar30.integrated.scanner.HistoryAgreement;
import java.util.*;

public final class HistoryAgreementTest {
    private static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
    public static void main(String[] args){
        List<Integer> a=Arrays.asList(17,32,5,21,8,14,29,2,35,11,6,24,19,3,27,9,31,12,4,22);
        List<Integer> b=new ArrayList<>(a);
        check(HistoryAgreement.score(a,b)>0.99,"identical histories must agree");
        List<Integer> lag=new ArrayList<>(); lag.add(9); lag.addAll(a);
        check(HistoryAgreement.score(lag,a)>=0.95,"one-spin render lag must agree");
        List<Integer> bad=Arrays.asList(0,0,5,1,0,5,1,0,5,1,0,5,1,0,5,1,0,5,1,0);
        check(HistoryAgreement.score(a,bad)<0.58,"unrelated source must disagree");
        System.out.println("HistoryAgreementTest PASS");
    }
}
