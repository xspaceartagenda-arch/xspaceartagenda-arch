import com.xspaceart.radar30.core.CurrentTableHistory;
import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.ConfluenceVerdict;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Garante que o Balanced operacional libera confluência útil sem afrouxar o Precision. */
public final class V075OperationalGateTest {
    public static void main(String[] args) {
        Result precision = run(true, 500, 370401L);
        Result balanced = run(false, 500, 370401L);
        if (precision.starts != 0) {
            throw new AssertionError("Precision mudou de cadência no vetor congelado: " + precision.starts);
        }
        if (balanced.starts < 3) {
            throw new AssertionError("Balanced operacional ficou travado: " + balanced.starts);
        }
        if (balanced.firstStart < CurrentTableHistory.MIN_DEEP_SCAN_RESULTS - 1 || balanced.firstStart > 90) {
            throw new AssertionError("Primeira entrada Balanced fora da janela operacional: " + balanced.firstStart);
        }
        if (balanced.minimumEntryScore < 68) {
            throw new AssertionError("Entrada abaixo do gate operacional de Radar 68: " + balanced.minimumEntryScore);
        }
        if (balanced.minimumEntryFamilies < 4) {
            throw new AssertionError("Entrada com menos de 4 famílias: " + balanced.minimumEntryFamilies);
        }
        System.out.println("V075_OPERATIONAL_GATE=PASS precision=" + precision.starts
                + " balanced=" + balanced.starts
                + " first=" + balanced.firstStart
                + " minScore=" + balanced.minimumEntryScore
                + " minFamilies=" + balanced.minimumEntryFamilies);
    }

    private static Result run(boolean conservative, int spins, long seed) {
        RadarSession session = new RadarSession();
        List<Integer> history = new ArrayList<>();
        Random random = new Random(seed);
        int starts = 0;
        int firstStart = -1;
        int minimumEntryScore = 101;
        int minimumEntryFamilies = 99;
        for (int spin = 0; spin < spins; spin++) {
            int result = random.nextInt(37);
            history.add(0, result);
            SignalUpdate update = session.update(history,
                    Collections.singletonList(result), LearningModel.empty(), conservative);
            if (update.kind == SignalUpdate.Kind.ENTRY) {
                starts++;
                if (firstStart < 0) firstStart = spin;
                ConfluenceVerdict verdict = session.lastVerdict();
                if (verdict != null) {
                    minimumEntryScore = Math.min(minimumEntryScore, verdict.aurumScore);
                    minimumEntryFamilies = Math.min(minimumEntryFamilies, verdict.independentFamilies);
                }
            }
        }
        if (starts == 0) {
            minimumEntryScore = 0;
            minimumEntryFamilies = 0;
        }
        return new Result(starts, firstStart, minimumEntryScore, minimumEntryFamilies);
    }

    private static final class Result {
        final int starts;
        final int firstStart;
        final int minimumEntryScore;
        final int minimumEntryFamilies;
        Result(int starts, int firstStart, int minimumEntryScore, int minimumEntryFamilies) {
            this.starts = starts;
            this.firstStart = firstStart;
            this.minimumEntryScore = minimumEntryScore;
            this.minimumEntryFamilies = minimumEntryFamilies;
        }
    }
}
