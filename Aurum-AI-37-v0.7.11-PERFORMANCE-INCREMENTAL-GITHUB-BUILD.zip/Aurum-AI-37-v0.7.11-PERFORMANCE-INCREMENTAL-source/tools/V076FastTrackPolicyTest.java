import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.RegimeDetector;
import com.xspaceart.radar30.core.TargetRanking;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Reproduz a política do caso físico Radar ~60 / 5 famílias / baixa contradição. */
public final class V076FastTrackPolicyTest {
    public static void main(String[] args) throws Exception {
        Method method = RadarSession.class.getDeclaredMethod("balancedFastTrack", ConfluenceVerdict.class);
        method.setAccessible(true);

        ConfluenceVerdict physicalLike = verdict(60, 5, 0.18, 0.19,
                TargetRanking.SignalShape.HIGH_DISPERSION,
                Arrays.asList(EvidenceFamily.RECENCY, EvidenceFamily.TRANSITION,
                        EvidenceFamily.TERMINAL, EvidenceFamily.ARITHMETIC,
                        EvidenceFamily.REGIME));
        assertTrue((Boolean) method.invoke(null, physicalLike),
                "caso físico qualificado deveria passar fast track");

        assertFalse((Boolean) method.invoke(null, verdict(59, 5, 0.18, 0.19,
                        TargetRanking.SignalShape.HIGH_DISPERSION,
                        physicalLike.supportingFamilies)), "score abaixo de 60");
        assertFalse((Boolean) method.invoke(null, verdict(61, 4, 0.18, 0.19,
                        TargetRanking.SignalShape.HIGH_DISPERSION,
                        physicalLike.supportingFamilies)), "menos de 5 famílias");
        assertFalse((Boolean) method.invoke(null, verdict(61, 5, 0.21, 0.19,
                        TargetRanking.SignalShape.HIGH_DISPERSION,
                        physicalLike.supportingFamilies)), "contradição acima de 20%");
        assertFalse((Boolean) method.invoke(null, verdict(61, 5, 0.18, 0.14,
                        TargetRanking.SignalShape.HIGH_DISPERSION,
                        physicalLike.supportingFamilies)), "dominância abaixo de 15%");
        assertFalse((Boolean) method.invoke(null, verdict(61, 5, 0.18, 0.19,
                        TargetRanking.SignalShape.HIGH_DISPERSION,
                        Arrays.asList(EvidenceFamily.FREQUENCY, EvidenceFamily.GAP,
                                EvidenceFamily.TERMINAL, EvidenceFamily.ARITHMETIC,
                                EvidenceFamily.CLUSTER))), "sem caminho preditivo/recente");

        ConfluenceVerdict precision = verdict(90, 7, 0.05, 0.30,
                TargetRanking.SignalShape.SINGLE_TARGET,
                physicalLike.supportingFamilies, ConfluenceVerdict.Mode.PRECISION);
        assertFalse((Boolean) method.invoke(null, precision), "fast track não pode alterar Precision");

        System.out.println("V076_FAST_TRACK_POLICY=PASS score=60 families=5 contradiction=18 dominance=19 dispersion=HIGH");
    }

    private static ConfluenceVerdict verdict(int score, int families, double contradiction,
                                              double dominance, TargetRanking.SignalShape shape,
                                              List<EvidenceFamily> support) {
        return verdict(score, families, contradiction, dominance, shape, support,
                ConfluenceVerdict.Mode.BALANCED);
    }

    private static ConfluenceVerdict verdict(int score, int families, double contradiction,
                                              double dominance, TargetRanking.SignalShape shape,
                                              List<EvidenceFamily> support,
                                              ConfluenceVerdict.Mode mode) {
        double[] heat = new double[37];
        heat[3] = 1.0;
        heat[26] = 0.92;
        heat[0] = 0.88;
        heat[32] = 0.86;
        heat[15] = 0.82;
        return new ConfluenceVerdict(ConfluenceVerdict.Decision.OBSERVE, 3,
                Arrays.asList(26, 0, 32, 15, 19), Arrays.asList(3, 26),
                score, families, contradiction, dominance, 0.99, 0.90, 0.72,
                new RegimeDetector().detect(Collections.emptyList()), support,
                Collections.singletonList("vetor físico sintético"), Collections.emptyList(),
                heat, false, false, false, mode,
                -1, Collections.emptyList(), Collections.emptyList(),
                0, 0, 1.0, 0.0, 0.0,
                27, 40, 0.4, TargetRanking.SpatialRegime.DISPERSED,
                shape, Collections.emptyList(), Collections.emptyList(), false);
    }

    private static void assertTrue(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    private static void assertFalse(boolean value, String message) {
        if (value) throw new AssertionError(message);
    }
}
