import com.xspaceart.radar30.core.ConsensusSnapshot;
import com.xspaceart.radar30.core.Evidence;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Verifica o denominador comum físico entre famílias que apontam números vizinhos. */
public final class V077ConsensusSpatialTest {
    public static void main(String[] args) {
        List<Evidence> converging = Arrays.asList(
                evidence(EvidenceFamily.RECENCY, 21),
                evidence(EvidenceFamily.TRANSITION, 2),
                evidence(EvidenceFamily.FREQUENCY, 25),
                evidence(EvidenceFamily.ARITHMETIC, 17),
                evidence(EvidenceFamily.REGIME, 34)
        );
        double[] central = fused(converging);
        ConsensusSnapshot snapshot = ConsensusSnapshot.analyze(converging, central);
        if (snapshot.primary.familyCount < 4) {
            throw new AssertionError("Famílias vizinhas não formaram consenso: " + snapshot.primary.familyCount);
        }
        if (!snapshot.primary.coverage.containsAll(Arrays.asList(21, 2, 25, 17))) {
            throw new AssertionError("Polo não abraçou o conjunto físico esperado: " + snapshot.primary.coverage);
        }
        if (snapshot.primary.score < 65) {
            throw new AssertionError("Consenso local fraco demais: " + snapshot.primary.score);
        }
        if (!snapshot.primary.predictive || !snapshot.primary.recent) {
            throw new AssertionError("Rotas preditiva/recente não detectadas");
        }

        List<Evidence> scattered = Arrays.asList(
                evidence(EvidenceFamily.RECENCY, 0),
                evidence(EvidenceFamily.TRANSITION, 13),
                evidence(EvidenceFamily.FREQUENCY, 8),
                evidence(EvidenceFamily.ARITHMETIC, 31),
                evidence(EvidenceFamily.REGIME, 28)
        );
        ConsensusSnapshot diffuse = ConsensusSnapshot.analyze(scattered, fused(scattered));
        if (diffuse.primary.familyCount >= 4 && diffuse.primary.score >= 65) {
            throw new AssertionError("Mapa espalhado virou consenso artificial: families="
                    + diffuse.primary.familyCount + " score=" + diffuse.primary.score);
        }
        System.out.println("V077_CONSENSUS_SPATIAL=PASS target=" + snapshot.primary.target
                + " score=" + snapshot.primary.score + " families=" + snapshot.primary.familyCount
                + " coverage=" + snapshot.primary.coverage);
    }

    private static Evidence evidence(EvidenceFamily family, int target) {
        double[] heat = new double[37];
        List<Integer> zone = Wheel.coverage(target, 2);
        double[] weights = {0.28, 0.62, 1.0, 0.62, 0.28};
        for (int i = 0; i < zone.size(); i++) heat[zone.get(i)] = Math.max(heat[zone.get(i)], weights[i]);
        return new Evidence(family, heat, 0.90, 0.92, 28,
                0.90, 0.92, 0.05, family + " chama " + target);
    }

    private static double[] fused(List<Evidence> evidence) {
        double[] out = new double[37];
        double total = 0.0;
        for (Evidence e : evidence) {
            double w = e.weight();
            total += w;
            for (int n = 0; n < 37; n++) out[n] += e.heat[n] * w;
        }
        if (total > 0.0) for (int n = 0; n < 37; n++) out[n] /= total;
        return out;
    }
}
