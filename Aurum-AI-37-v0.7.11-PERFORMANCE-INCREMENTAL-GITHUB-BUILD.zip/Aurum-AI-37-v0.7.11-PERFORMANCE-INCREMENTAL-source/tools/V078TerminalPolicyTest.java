import com.xspaceart.radar30.core.*;

import java.util.Arrays;
import java.util.Collections;

/** Valida Terminal Signal e a rota ouro Terminal + Setor, sem tocar na régua Precision. */
public final class V078TerminalPolicyTest {
    public static void main(String[] args) {
        TerminalSnapshot terminal = terminalSnapshot(5, 82, 6, 0.91, 0.14, 0.16);
        ConsensusSnapshot sector25 = sectorSnapshot(25, 78, 6, 0.90, 0.15, 0.11);
        ConfluenceVerdict aligned = verdict(sector25, terminal, ConfluenceVerdict.Mode.BALANCED);

        assertTrue(TerminalSignalPolicy.aligned(aligned), "T5 precisa alinhar com setor 25");
        if (TerminalSignalPolicy.crossScore(aligned) < 78) {
            throw new AssertionError("cross score abaixo do esperado: " + TerminalSignalPolicy.crossScore(aligned));
        }
        assertTrue(TerminalSignalPolicy.terminalReady(aligned, 1, 0.0, false),
                "terminal excepcional deveria liberar");
        assertTrue(TerminalSignalPolicy.maxConfluenceReady(aligned, 1, 0.0, false, false),
                "confluência máxima excepcional deveria liberar");
        assertFalse(TerminalSignalPolicy.maxConfluenceReady(aligned, 1, 0.0, true, false),
                "saturação de setor precisa bloquear");

        ConsensusSnapshot sector17 = sectorSnapshot(17, 80, 6, 0.91, 0.13, 0.12);
        ConfluenceVerdict divergent = verdict(sector17, terminal, ConfluenceVerdict.Mode.BALANCED);
        assertFalse(TerminalSignalPolicy.aligned(divergent), "setor 17 não pertence a T5");
        assertFalse(TerminalSignalPolicy.maxConfluenceReady(divergent, 3, 4.0, false, false),
                "motores divergentes não podem virar ouro");

        ConfluenceVerdict precision = verdict(sector25, terminal, ConfluenceVerdict.Mode.PRECISION);
        assertFalse(TerminalSignalPolicy.terminalReady(precision, 3, 5.0, false),
                "Terminal Engine v0.7.8 não pode relaxar Precision");
        assertFalse(TerminalSignalPolicy.maxConfluenceReady(precision, 3, 5.0, false, false),
                "Confluência Máxima é rota Balanced");

        if (TerminalSignalPolicy.TERMINAL_VALIDITY_SPINS != 5) {
            throw new AssertionError("janela terminal precisa ser exatamente 5 giros máximos");
        }
        System.out.println("V078_TERMINAL_POLICY=PASS cross=" + TerminalSignalPolicy.crossScore(aligned)
                + " validity=" + TerminalSignalPolicy.TERMINAL_VALIDITY_SPINS);
    }

    private static TerminalSnapshot terminalSnapshot(int terminal, int score, int families,
                                                     double alignment, double contradiction,
                                                     double margin) {
        TerminalSnapshot.Candidate p = new TerminalSnapshot.Candidate(terminal, score, families,
                alignment, contradiction, 0.84, 0.88, true, true, Collections.emptyList());
        int secondScore = Math.max(0, score - (int) Math.round(score * margin));
        TerminalSnapshot.Candidate s = new TerminalSnapshot.Candidate((terminal + 1) % 10,
                secondScore, 4, 0.76, 0.24, 0.62, 0.65, true, true, Collections.emptyList());
        return new TerminalSnapshot(p, s, TerminalSnapshot.Candidate.empty(), margin, 7);
    }

    private static ConsensusSnapshot sectorSnapshot(int target, int score, int families,
                                                     double alignment, double contradiction,
                                                     double margin) {
        ConsensusSnapshot.Candidate p = new ConsensusSnapshot.Candidate(target, score, families,
                alignment, contradiction, 0.84, 0.86, true, true, Collections.emptyList());
        int secondScore = Math.max(0, score - (int) Math.round(score * margin));
        ConsensusSnapshot.Candidate s = new ConsensusSnapshot.Candidate(32, secondScore, 4,
                0.74, 0.25, 0.62, 0.64, true, true, Collections.emptyList());
        return new ConsensusSnapshot(p, s, ConsensusSnapshot.Candidate.empty(), margin, 7);
    }

    private static ConfluenceVerdict verdict(ConsensusSnapshot sector, TerminalSnapshot terminal,
                                             ConfluenceVerdict.Mode mode) {
        double[] heat = new double[37];
        heat[sector.primary.target] = 1.0;
        return new ConfluenceVerdict(ConfluenceVerdict.Decision.PREPARE, sector.primary.target,
                Wheel.coverage(sector.primary.target, 2), Arrays.asList(sector.primary.target),
                72, 6, 0.16, 0.10, 0.80, 0.78, 0.64,
                new RegimeDetector().detect(Collections.emptyList()),
                Arrays.asList(EvidenceFamily.RECENCY, EvidenceFamily.TRANSITION,
                        EvidenceFamily.ARITHMETIC, EvidenceFamily.REGIME, EvidenceFamily.SEQUENCE),
                Collections.singletonList("v0.7.8 synthetic"), Collections.emptyList(), heat,
                false, false, false, mode, -1, Collections.emptyList(), Collections.emptyList(),
                0, 0, 1.0, 0.0, 0.0, 32, 50, 0.5,
                TargetRanking.SpatialRegime.CONCENTRATED, TargetRanking.SignalShape.SINGLE_TARGET,
                Collections.emptyList(), Collections.emptyList(), false, sector, terminal);
    }

    private static void assertTrue(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    private static void assertFalse(boolean value, String message) {
        if (value) throw new AssertionError(message);
    }
}
