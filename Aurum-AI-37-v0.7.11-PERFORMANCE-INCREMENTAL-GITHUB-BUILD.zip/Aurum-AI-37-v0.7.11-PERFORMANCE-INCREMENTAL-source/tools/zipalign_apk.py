#!/usr/bin/env python3
"""Regrava um APK v1 mantendo .so armazenadas e alinhadas a 16 KiB."""

from __future__ import annotations

import sys
import zipfile
from pathlib import Path


ALIGN_ID = 0xD935


def padding_extra(current: int, filename_length: int, existing_length: int,
                  alignment: int) -> bytes:
    data_start = current + 30 + filename_length + existing_length
    padding = (-data_start) % alignment
    if padding and padding < 4:
        padding += alignment
    if not padding:
        return b""
    return ALIGN_ID.to_bytes(2, "little") + (padding - 4).to_bytes(2, "little") \
        + bytes(padding - 4)


def clone_info(info: zipfile.ZipInfo) -> zipfile.ZipInfo:
    cloned = zipfile.ZipInfo(info.filename, info.date_time)
    cloned.compress_type = info.compress_type
    cloned.comment = info.comment
    cloned.create_system = info.create_system
    cloned.create_version = info.create_version
    cloned.extract_version = info.extract_version
    cloned.flag_bits = info.flag_bits & ~0x08
    cloned.volume = info.volume
    cloned.internal_attr = info.internal_attr
    cloned.external_attr = info.external_attr
    return cloned


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: zipalign_apk.py INPUT-signed.apk OUTPUT.apk")
    source_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(source_path, "r") as source, zipfile.ZipFile(
        output_path, "w", allowZip64=True
    ) as output:
        output.comment = source.comment
        for info in source.infolist():
            payload = source.read(info.filename)
            cloned = clone_info(info)
            existing = info.extra
            alignment = 1
            if info.compress_type == zipfile.ZIP_STORED:
                alignment = 16384 if info.filename.endswith(".so") else 4
            if alignment > 1:
                extra = padding_extra(
                    output.fp.tell(), len(info.filename.encode("utf-8")),
                    len(existing), alignment,
                )
                cloned.extra = existing + extra
            else:
                cloned.extra = existing
            output.writestr(
                cloned, payload,
                compress_type=info.compress_type,
                compresslevel=9 if info.compress_type == zipfile.ZIP_DEFLATED else None,
            )
    print(output_path)


if __name__ == "__main__":
    main()
