import com.xspaceart.radar30.RadarBackstageFormatter;
import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.RegimeDetector;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.TargetRanking;

import java.util.Arrays;
import java.util.Collections;

/** Garante que o usuário consiga ver o bastidor antes de um sinal oficial. */
public final class V076RadarBackstageTest {
    public static void main(String[] args) {
        double[] heat = new double[37];
        heat[3] = 1.0; heat[26] = 0.94; heat[0] = 0.90; heat[32] = 0.88; heat[15] = 0.84;
        heat[5] = 0.73; heat[24] = 0.70; heat[16] = 0.68; heat[33] = 0.66;
        ConfluenceVerdict v = new ConfluenceVerdict(ConfluenceVerdict.Decision.OBSERVE, 3,
                Arrays.asList(26,0,32,15,19), Arrays.asList(3,26),
                60, 5, 0.18, 0.19, 0.99, 0.91, 0.74,
                new RegimeDetector().detect(Collections.emptyList()),
                Arrays.asList(EvidenceFamily.RECENCY, EvidenceFamily.TRANSITION,
                        EvidenceFamily.TERMINAL, EvidenceFamily.ARITHMETIC, EvidenceFamily.REGIME),
                Collections.singletonList("5 famílias independentes convergem"), Collections.emptyList(), heat,
                false, false, false, ConfluenceVerdict.Mode.BALANCED,
                -1, Collections.emptyList(), Collections.emptyList(), 0, 0, 1.0, 0.0, 0.0,
                5, 55, 0.62, TargetRanking.SpatialRegime.DISPERSED,
                TargetRanking.SignalShape.HIGH_DISPERSION,
                Collections.emptyList(), Collections.emptyList(), false);
        SignalUpdate u = new SignalUpdate(SignalUpdate.Kind.OBSERVE, "OBSERVANDO", "", 3,
                v.coverage, 60, 1, "");

        String focus = RadarBackstageFormatter.focus(v);
        String sectors = RadarBackstageFormatter.sectorRanking(v);
        String heatText = RadarBackstageFormatter.heat(v);
        String families = RadarBackstageFormatter.families(v);
        String gate = RadarBackstageFormatter.gate(v, u);

        mustContain(focus, "FOCO AGORA");
        mustContain(focus, "3 + 2 VIZINHOS");
        mustContain(sectors, "1º alvo");
        mustContain(sectors, "2º alvo");
        mustContain(heatText, "QUENTE");
        mustContain(heatText, "FRIO");
        mustContain(families, "transição");
        mustContain(gate, "FAST TRACK QUALIFICADO");
        mustContain(gate, "não é necessário o alvo acertar");
        System.out.println("V076_RADAR_BACKSTAGE=PASS");
    }

    private static void mustContain(String value, String expected) {
        if (value == null || !value.contains(expected)) {
            throw new AssertionError("Esperado '" + expected + "' em: " + value);
        }
    }
}
