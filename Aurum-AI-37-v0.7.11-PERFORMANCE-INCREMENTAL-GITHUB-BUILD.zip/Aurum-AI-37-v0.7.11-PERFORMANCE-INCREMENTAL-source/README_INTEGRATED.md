# Aurum AI 37 — Stability Pipeline v0.7.3

Continuação direta da v0.7.2 Integrated Operational.

A v0.7.3 não altera o motor estratégico. Ela consolida a camada operacional em um pipeline único com bootstrap obrigatório do histórico visível, fonte sticky, watchdog, OCR hot standby, reconciliação antes de troca de fonte e isolamento do motor/interface Stable durante a sessão Integrated.

Objetivo físico: iniciar uma vez e permanecer lendo continuamente sem precisar limpar, finalizar ou alternar interface para destravar.

Consulte `AURUM_CHECKPOINT.md` antes de qualquer nova alteração.
