# Privacidade — Aurum AI 37

Versão 0.6.0, 27 de agosto de 2026.

O Aurum AI 37 processa no próprio aparelho as imagens que o usuário autoriza por meio da captura de tela do Android. A captura é usada somente para reconhecer números dentro da área calibrada.

O aplicativo não possui permissão de internet, não cria conta, não coleta identificadores, não acessa credenciais do cassino, não lê saldo e não realiza apostas. Prints e vídeos não são gravados em arquivo. A imagem temporária mantida em memória é descartada quando o serviço de captura termina.

O histórico reconhecido (até 500 resultados da sessão atual), as áreas de recorte, as preferências, os nomes de provedor e crupiê, as sessões, os resultados dos sinais, os registros do Shadow Test, os snapshots técnicos do Raio-X e os valores de banca inseridos opcionalmente ficam nas preferências privadas do aplicativo. Esses dados alimentam somente a leitura e a auditoria locais e podem ser removidos ao limpar os dados do aplicativo ou desinstalá-lo.

O compartilhamento de tela só começa após a confirmação explícita no diálogo do Android e pode ser interrompido pela notificação ou pelo botão **Parar leitura**.
