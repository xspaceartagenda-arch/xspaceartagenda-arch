# AURUM AI 37 — CHECKPOINT AUTORITATIVO v0.7.3

Atualizado em: 2026-08-27 — America/Sao_Paulo

## BASE OFICIAL

- Base física anterior: **v0.7.2 Integrated Operational** instalada e testada no Samsung S25 FE.
- Resultado físico da v0.7.2: **REPROVADA EM ESTABILIDADE OPERACIONAL**.
- O motor estratégico mostrou funcionamento e chegou a formar confluência útil, porém a ferramenta perdia continuidade de leitura: histórico às vezes não carregava, às vezes entravam 1–2 giros e a leitura parava, e reiniciar/limpar/alternar interface podia temporariamente fazê-la voltar.
- A v0.7.3 não altera o cérebro estratégico. O foco é exclusivamente consolidar a captura/leitura em um pipeline operacional único e autorrecuperável.

## IDENTIDADE DE UPDATE PRESERVADA

- applicationId base: `com.xspaceart.aurumai37.integratedlab`
- variante instalada: `com.xspaceart.aurumai37.integratedlab.debug`
- v0.7.3: `versionCode 4`
- v0.7.3: `versionName 0.7.3-stability-pipeline` (`-debug` no APK)
- certificado de continuidade SHA-256: validado contra a identidade estável já usada pela v0.7.1/v0.7.2.
- CORE estratégico: **17/17 arquivos preservados por SHA-256**.

## OBJETIVO v0.7.3 — STABILITY PIPELINE

Ao tocar `INICIAR LEITURA`:

1. entrar em BOOTSTRAP;
2. varrer o histórico visível inteiro antes do tracking incremental;
3. preencher/reconciliar o CORE com o bloco visível;
4. calcular Radar/confluência a partir do histórico completo;
5. entrar em TRACKING;
6. aceitar automaticamente cada giro novo;
7. se a fonte operacional perder saúde, recuperar/trocar de fonte sem reiniciar sessão;
8. manter telemetria viva e verificável durante toda a sessão.

## CORREÇÕES IMPLEMENTADAS

### 1. Pipeline único

Foi criado `ReadingPipelineController` com estados:

- IDLE
- BOOTSTRAP
- TRACKING
- RECOVERING
- FINISHED

Fontes:

- DOM
- OCR

A fonte é sticky. O watchdog só propõe uma troca; a nova fonte só é confirmada depois que seu snapshot é reconciliado com o histórico/CORE. Isso impede uma fonte ruim de assumir o pipeline e deixá-lo travado.

### 2. Bootstrap obrigatório do histórico visível

A v0.7.2 podia restaurar uma sessão e pular o bootstrap atual, levando ao comportamento de começar a receber apenas 1 número por vez.

Na v0.7.3:

- sessão restaurada continua preservada;
- porém `initialBootstrapPending` continua ativo;
- o snapshot visível precisa ser reconciliado antes de TRACKING;
- uma grade visível menor não apaga a cauda já confirmada da sessão;
- histórico novo completo entra de uma vez quando a sessão é nova.

### 3. Captura/OCR não executa mais motor Stable em paralelo

Quando `ScreenCaptureService` está em `MODE_INTEGRATED_SOURCE_ONLY`:

- ele captura a tela;
- executa OCR na ROI calibrada;
- publica snapshot + heartbeat;
- retorna **antes** de `ScanSynchronizer`, `RadarSession`, overlay e sinal Stable.

Também:

- não inicia `SessionLedger` Stable em modo Integrated;
- a notificação da captura Integrated reabre `IntegratedActivity`, não `MainActivity`;
- a Integrated não usa `AppStateStore.loadHistory()` da interface Stable como fallback OCR.

Isso remove a disputa entre a interface Integrated e o fluxo básico/Stable observada no teste físico.

### 4. OCR Hot Standby real

OCR agora possui:

- heartbeat contínuo da captura;
- snapshot independente;
- gate de estabilidade de duas leituras consecutivas;
- memória do último snapshot estável;
- orientação temporal própria (`SourceOrderTracker`);
- capacidade de assumir como fonte operacional.

Quando a ROI já foi calibrada e a captura não está ativa, `INICIAR LEITURA` solicita automaticamente autorização de captura para deixar o OCR pronto como hot standby.

Se já existir captura ativa, a Integrated força o serviço para `MODE_INTEGRATED_SOURCE_ONLY` sem abrir um segundo motor.

### 5. Detecção de travamento silencioso do DOM

Problema físico observado: DOM podia continuar parecendo ativo enquanto o histórico deixava de avançar.

Na v0.7.3, se:

- DOM é a fonte ativa;
- OCR está saudável e estável;
- OCR detecta um prefixo novo compatível com o CORE;
- o CORE ainda não recebeu esse giro;

então o hot standby é promovido automaticamente para OCR após confirmação repetida, sem finalizar/reiniciar a sessão.

### 6. Troca de fonte com reconciliação antes da confirmação

A v0.7.2 podia alterar a fonte ativa antes de saber se o histórico da nova fonte era compatível.

Agora:

1. watchdog propõe a fonte;
2. snapshot é testado contra o histórico atual;
3. somente se for aceito a fonte é confirmada;
4. se for recusado, o CORE permanece preservado e a tela informa que ainda está reconciliando.

### 7. Separação total do histórico Stable

OCR Integrated não lê mais o histórico global persistido pela interface Stable.

A única fonte visual aceita é:

- snapshot em memória da captura atual; ou
- snapshot OCR persistido com timestamp próprio.

Isso reduz contaminação cruzada entre abas/interfaces.

### 8. Interface viva sem estatística falsa

Durante leitura ativa:

- pipeline pulse fica ativo;
- radar pulse fica ativo;
- scanner/heartbeat/idade de fonte atualizam continuamente;
- número de scans, análises, CORE, fonte ativa, failovers e recuperações permanecem visíveis;
- Radar/confluência só muda valores quando há dados reais, evitando animação que simule evidência inexistente.

## TESTES HOST / ESTÁTICOS APROVADOS

- `V073_STATIC_VALIDATION=PASS`
- `CORE_PRESERVATION=PASS checked=17`
- `PrecisionCoreTest=PASS`
- `DualTargetCoreTest=PASS A-H`
- `V063BalancedCalibrationTest=PASS`
- `IntegratedOperationalTest=PASS`
  - bootstrap completo
  - giro novo
  - manual
  - correção
  - limpeza
  - delta futuro
  - retomada com histórico salvo + reconciliação do snapshot visível sem apagar a cauda
- `SourceOrderTrackerTest=PASS`
  - newest-first
  - oldest-first
  - orientação aprendida já no bootstrap quando `currentResult` está disponível
- `ManualEchoReconcilerTest=PASS`
- `ReadingPipelineControllerTest=PASS`
  - bootstrap
  - sticky source
  - failover como proposta
  - confirmação somente após reconciliação
  - recovery

## COMPILAÇÃO ANDROID — ESTADO REAL

Tentativa local continua bloqueada porque o ambiente não possui Gradle 8.9 em cache e não consegue baixar `services.gradle.org`.

Portanto neste checkpoint:

- IMPLEMENTADO: **SIM**
- TESTES HOST/ESTÁTICOS: **PASS**
- CORE PRESERVADO: **PASS 17/17**
- ASSINATURA DE CONTINUIDADE DA KEYSTORE: **PASS**
- COMPILADO ANDROID v0.7.3: **PENDENTE GITHUB ACTIONS**
- APK v0.7.3: **AINDA NÃO GERADO**
- INSTALADO S25 FE: **NÃO**
- TESTADO FISICAMENTE v0.7.3: **NÃO**

## CRITÉRIO FÍSICO DE APROVAÇÃO v0.7.3

Não considerar a versão aprovada porque abriu ou leu alguns giros.

Teste mínimo:

1. instalar por cima da v0.7.2 sem limpar dados;
2. abrir WebView e confirmar URL/login;
3. tocar `INICIAR LEITURA` uma única vez;
4. confirmar bootstrap de todos os números visíveis de uma vez;
5. manter sessão contínua por pelo menos 30 minutos;
6. acompanhar vários giros sem `LIMPAR`, `FINALIZAR` ou reiniciar para destravar;
7. confirmar CORE e último giro atualizando automaticamente;
8. confirmar Radar/confluência ativo e coerente com o CORE;
9. provocar/observar perda de DOM e confirmar OCR assumindo sem duplicar giro;
10. confirmar que a interface Stable não executa sinal/motor paralelo durante a sessão Integrated;
11. validar manual/correção/limpeza;
12. finalizar sessão e validar placar.

## PRÓXIMO PASSO EXATO

1. Build no GitHub usando `Aurum-AI-37-Integrated-LAB-GITHUB-BUILD.zip` v0.7.3 e `.github/workflows/build-integrated.yml` v0.7.3.
2. Exigir no workflow:
   - host tests PASS;
   - assembleDebug PASS;
   - package `com.xspaceart.aurumai37.integratedlab.debug`;
   - versionCode 4;
   - versionName `0.7.3-stability-pipeline-debug`;
   - certificado estável;
   - zipalign/integridade PASS.
3. Somente então liberar APK para instalação física.
