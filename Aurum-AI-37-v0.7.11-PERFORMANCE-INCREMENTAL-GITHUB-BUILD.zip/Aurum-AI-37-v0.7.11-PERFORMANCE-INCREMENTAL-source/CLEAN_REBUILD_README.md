# Aurum AI 37 v0.6.2 Clean Install

Objetivo: abandonar a exigência de atualização por cima/preservação do histórico antigo e produzir uma instalação nova, independente e limpa, mantendo o código atual do motor v0.6.x.

## Estratégia

- applicationId novo: `com.xspaceart.aurumai37clean`
- namespace e código Java permanecem `com.xspaceart.radar30` para evitar refatoração desnecessária.
- Activity/Service no Manifest usam nomes totalmente qualificados.
- versionCode reinicia em 1; versionName `0.6.2-clean`.
- chave de assinatura nova em `signing/aurum-ai37-clean.jks`.
- dados/histórico começam zerados por ser um novo applicationId.
- o app antigo pode permanecer instalado durante o teste, porque os package IDs são diferentes.

## O que deve permanecer do motor atual

- Precision/Balanced
- Secondary Confluence / Dual Target
- SINGLE_TARGET / DUAL_TARGET / SINGLE_MACRO_CLUSTER
- Secondary Hit + reanálise do Primary
- Missed Opportunity
- Raio-X
- Shadow Test
- histórico atual até 500
- regime, heatmap, confluências, dominância, dispersão, persistência, velocidade e contraconfluência
- OCR/captura/overlay atuais

## Motivo técnico

O startup crash das versões 0.6.0/0.6.1 foi associado à rota manual de DEX que perdeu classes R de dependências. Um build Gradle limpo a partir desta árvore deve regenerar/empacotar corretamente recursos e dependências, sem depender do DEX quebrado v0.5.0.

## Build recomendado

Use build Gradle canônico. NÃO fazer merge/rebase manual de DEX nesta variante clean se o Gradle estiver disponível.

```bash
./gradlew --no-daemon clean :app:assembleRelease
```

Depois assinar o APK release com a nova chave deste pacote (ou configurar signingConfig localmente sem registrar a senha em Git).

## Critério real de PASS

1. instalar como NOVO app no S25 FE;
2. abrir a tela principal;
3. validar OCR/overlay;
4. validar Precision/Balanced;
5. validar Primary/Secondary, Raio-X, Shadow/Missed Opportunity;
6. só então considerar a clean build funcional.
