# MVP sem minificação. Mantido para futuras versões de produção.
