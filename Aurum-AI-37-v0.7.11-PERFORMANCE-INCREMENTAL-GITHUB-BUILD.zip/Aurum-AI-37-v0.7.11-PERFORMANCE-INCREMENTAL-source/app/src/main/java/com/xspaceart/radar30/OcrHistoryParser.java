package com.xspaceart.radar30;

import android.graphics.Rect;

import com.google.mlkit.vision.text.Text;
import com.xspaceart.radar30.core.Wheel;
import com.xspaceart.radar30.core.CurrentTableHistory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Converte caixas de texto do ML Kit em uma grade: topo primeiro, esquerda para direita. */
public final class OcrHistoryParser {
    private static final Pattern NUMBER = Pattern.compile("(?<!\\d)(?:[0-9]|[12][0-9]|3[0-6])(?!\\d)");

    public List<Integer> parse(Text result) {
        List<Token> tokens = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element element : line.getElements()) {
                    Rect box = element.getBoundingBox();
                    if (box == null) continue;
                    addTokens(tokens, normalize(element.getText()), box);
                }
            }
        }
        if (tokens.isEmpty()) return new ArrayList<>();

        float medianHeight = medianHeight(tokens);
        float tolerance = Math.max(10f, medianHeight * 0.72f);
        tokens.sort(Comparator.comparingDouble(t -> t.cy));

        List<Row> rows = new ArrayList<>();
        for (Token token : tokens) {
            Row best = null;
            float bestDistance = Float.MAX_VALUE;
            for (Row row : rows) {
                float distance = Math.abs(row.meanY - token.cy);
                if (distance <= tolerance && distance < bestDistance) {
                    best = row;
                    bestDistance = distance;
                }
            }
            if (best == null) rows.add(new Row(token));
            else best.add(token);
        }

        rows.sort(Comparator.comparingDouble(r -> r.meanY));
        List<Integer> values = new ArrayList<>();
        for (Row row : rows) {
            row.tokens.sort(Comparator.comparingDouble(t -> t.cx));
            for (Token token : row.tokens) {
                if (Wheel.valid(token.value)) values.add(token.value);
                if (values.size() == CurrentTableHistory.MAX_RESULTS) return values;
            }
        }
        return values;
    }

    private static void addTokens(List<Token> output, String text, Rect box) {
        Matcher matcher = NUMBER.matcher(text);
        List<Integer> found = new ArrayList<>();
        while (matcher.find()) {
            try {
                int value = Integer.parseInt(matcher.group());
                if (Wheel.valid(value)) found.add(value);
            } catch (NumberFormatException ignored) {
                // O regex já restringe, mas preserva o pipeline se houver anomalia.
            }
        }
        if (found.isEmpty()) return;
        float segmentWidth = box.width() / (float) found.size();
        for (int i = 0; i < found.size(); i++) {
            float x = box.left + segmentWidth * (i + 0.5f);
            output.add(new Token(found.get(i), x, box.exactCenterY(), box.height()));
        }
    }

    private static String normalize(String raw) {
        if (raw == null) return "";
        String value = raw.trim().toUpperCase(Locale.ROOT);
        if (value.length() <= 2) {
            value = value.replace('O', '0')
                    .replace('I', '1')
                    .replace('L', '1')
                    .replace('S', '5');
        }
        return value;
    }

    private static float medianHeight(List<Token> tokens) {
        List<Float> heights = new ArrayList<>();
        for (Token token : tokens) heights.add(token.height);
        heights.sort(Float::compareTo);
        return heights.get(heights.size() / 2);
    }

    private static final class Token {
        final int value;
        final float cx;
        final float cy;
        final float height;

        Token(int value, float cx, float cy, float height) {
            this.value = value;
            this.cx = cx;
            this.cy = cy;
            this.height = height;
        }
    }

    private static final class Row {
        final List<Token> tokens = new ArrayList<>();
        float meanY;

        Row(Token first) {
            add(first);
        }

        void add(Token token) {
            tokens.add(token);
            float total = 0;
            for (Token value : tokens) total += value.cy;
            meanY = total / tokens.size();
        }
    }
}
