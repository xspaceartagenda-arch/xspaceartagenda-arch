package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * v0.7.8 — consenso independente por terminal decimal.
 *
 * <p>O motor não assume que um terminal "precisa" aparecer. Ele transforma as
 * mesmas famílias independentes usadas pelo CORE em votos por T0..T9 e mede
 * força estrutural, recência, contradição e separação do segundo colocado.</p>
 */
public final class TerminalSnapshot {
    public static final class FamilyVote {
        public final EvidenceFamily family;
        public final int nativeTarget;
        public final int terminal;
        public final double relativeSupport;
        public final double weight;

        public FamilyVote(EvidenceFamily family, int nativeTarget, int terminal,
                   double relativeSupport, double weight) {
            this.family = family;
            this.nativeTarget = nativeTarget;
            this.terminal = terminal;
            this.relativeSupport = clamp01(relativeSupport);
            this.weight = clamp01(weight);
        }
    }

    public static final class Candidate {
        public final int terminal;
        public final List<Integer> coverage;
        public final int score;
        public final int familyCount;
        public final double alignment;
        public final double contradiction;
        public final double currentContext;
        public final double fusedSupport;
        public final boolean predictive;
        public final boolean recent;
        public final List<FamilyVote> votes;

        public Candidate(int terminal, int score, int familyCount,
                  double alignment, double contradiction,
                  double currentContext, double fusedSupport,
                  boolean predictive, boolean recent,
                  List<FamilyVote> votes) {
            this.terminal = terminal;
            this.coverage = terminal < 0 ? Collections.emptyList()
                    : Collections.unmodifiableList(coverageOf(terminal));
            this.score = clampScore(score);
            this.familyCount = Math.max(0, familyCount);
            this.alignment = clamp01(alignment);
            this.contradiction = clamp01(contradiction);
            this.currentContext = clamp01(currentContext);
            this.fusedSupport = clamp01(fusedSupport);
            this.predictive = predictive;
            this.recent = recent;
            this.votes = votes == null ? Collections.emptyList()
                    : Collections.unmodifiableList(new ArrayList<>(votes));
        }

        public static Candidate empty() {
            return new Candidate(-1, 0, 0, 0.0, 1.0,
                    0.0, 0.0, false, false, Collections.emptyList());
        }

        public String label() {
            return terminal < 0 ? "" : "TERMINAL " + terminal;
        }
    }

    public final Candidate primary;
    public final Candidate secondary;
    public final Candidate third;
    public final double leaderMargin;
    public final int activeFamilies;

    public TerminalSnapshot(Candidate primary, Candidate secondary,
                            Candidate third, double leaderMargin,
                            int activeFamilies) {
        this.primary = primary == null ? Candidate.empty() : primary;
        this.secondary = secondary == null ? Candidate.empty() : secondary;
        this.third = third == null ? Candidate.empty() : third;
        this.leaderMargin = clamp01(leaderMargin);
        this.activeFamilies = Math.max(0, activeFamilies);
    }

    public static TerminalSnapshot empty() {
        return new TerminalSnapshot(Candidate.empty(), Candidate.empty(),
                Candidate.empty(), 0.0, 0);
    }

    public static TerminalSnapshot analyze(List<Evidence> evidence,
                                           double[] fusedHeat,
                                           List<Integer> history) {
        if (evidence == null || evidence.isEmpty()) return empty();
        double fusedPeak = 0.0;
        for (int t = 0; t <= 9; t++) {
            fusedPeak = Math.max(fusedPeak, terminalSupport(fusedHeat, t));
        }

        List<Candidate> ranked = new ArrayList<>();
        for (int terminal = 0; terminal <= 9; terminal++) {
            ranked.add(analyzeCandidate(evidence, fusedHeat, fusedPeak,
                    history, terminal));
        }
        ranked.sort(Comparator.comparingInt((Candidate c) -> c.score).reversed()
                .thenComparingInt(c -> c.terminal));

        Candidate first = ranked.size() > 0 ? ranked.get(0) : Candidate.empty();
        Candidate second = ranked.size() > 1 ? ranked.get(1) : Candidate.empty();
        Candidate third = ranked.size() > 2 ? ranked.get(2) : Candidate.empty();
        double margin = first.score <= 0 ? 0.0
                : clamp01((first.score - second.score) / (double) first.score);
        return new TerminalSnapshot(first, second, third, margin, evidence.size());
    }

    private static Candidate analyzeCandidate(List<Evidence> evidence,
                                              double[] fusedHeat,
                                              double fusedPeak,
                                              List<Integer> history,
                                              int terminal) {
        List<FamilyVote> votes = new ArrayList<>();
        double alignedWeighted = 0.0;
        double voteWeight = 0.0;
        double contradictionWeighted = 0.0;
        boolean predictive = false;
        boolean recent = false;

        for (Evidence item : evidence) {
            TerminalPeak peak = bestTerminal(item.heat);
            if (peak.terminal < 0 || peak.score <= 0.0) continue;
            double local = terminalSupport(item.heat, terminal);
            double relative = clamp01(local / peak.score);
            double weight = clamp01(item.weight());
            boolean nativeVote = peak.terminal == terminal;
            boolean nearTieVote = !nativeVote && relative >= 0.94
                    && peak.margin <= 0.10;
            if ((!nativeVote && !nearTieVote) || local < 0.20 || weight < 0.10) continue;

            int nativeTarget = strongestNumberInTerminal(item.heat, peak.terminal);
            double marginQuality = clamp01(peak.margin / 0.22);
            double quality = nativeVote
                    ? 0.70 * relative + 0.20 * marginQuality + 0.10 * item.reliability
                    : 0.62 * relative + 0.18 * marginQuality + 0.20 * item.reliability;
            quality = clamp01(quality);
            votes.add(new FamilyVote(item.family, nativeTarget, terminal, quality, weight));
            alignedWeighted += quality * weight;
            voteWeight += weight;
            contradictionWeighted += weight * ((1.0 - relative) * 0.58
                    + item.contradiction * 0.42);
            if (isPredictive(item.family)) predictive = true;
            if (isRecent(item.family)) recent = true;
        }

        votes.sort(Comparator.comparingDouble((FamilyVote v) -> v.relativeSupport * v.weight)
                .reversed().thenComparing(v -> v.family.name()));
        int families = votes.size();
        double alignment = voteWeight <= 0.0 ? 0.0
                : clamp01(alignedWeighted / voteWeight);
        double contradiction = voteWeight <= 0.0 ? 1.0
                : clamp01(contradictionWeighted / voteWeight);
        double breadth = clamp01((families - 1.0) / 5.0);
        double context = currentContext(history, terminal);
        double fused = fusedPeak <= 0.0 ? 0.0
                : clamp01(terminalSupport(fusedHeat, terminal) / fusedPeak);

        double quality = 0.30 * alignment
                + 0.27 * breadth
                + 0.16 * context
                + 0.12 * fused
                + 0.15 * (1.0 - contradiction);
        if (!predictive) quality -= 0.07;
        if (!recent) quality -= 0.05;
        if (families < 4) quality -= 0.12;
        int score = clampScore((int) Math.round(quality * 100.0));
        return new Candidate(terminal, score, families, alignment,
                contradiction, context, fused, predictive, recent, votes);
    }

    /** Índice relativo de apoio de um heatmap ao terminal, sem favorecer T0..T6 por terem 4 números. */
    private static double terminalSupport(double[] heat, int terminal) {
        if (heat == null || heat.length < 37 || terminal < 0 || terminal > 9) return 0.0;
        List<Integer> coverage = coverageOf(terminal);
        if (coverage.isEmpty()) return 0.0;
        double sum = 0.0;
        double max = 0.0;
        for (int number : coverage) {
            double value = safe(heat[number]);
            sum += value;
            max = Math.max(max, value);
        }
        double mean = sum / coverage.size();
        // Pico mostra o alvo nativo; média exige que a família também dê algum
        // suporte ao restante do terminal, evitando voto baseado em um único ruído.
        return clamp01(0.62 * max + 0.38 * mean);
    }

    private static TerminalPeak bestTerminal(double[] heat) {
        int best = -1;
        double bestScore = -1.0;
        double second = 0.0;
        for (int terminal = 0; terminal <= 9; terminal++) {
            double score = terminalSupport(heat, terminal);
            if (score > bestScore) {
                second = Math.max(0.0, bestScore);
                bestScore = score;
                best = terminal;
            } else if (score > second) {
                second = score;
            }
        }
        double margin = bestScore <= 0.0 ? 0.0
                : clamp01((bestScore - second) / bestScore);
        return new TerminalPeak(best, Math.max(0.0, bestScore), margin);
    }

    private static int strongestNumberInTerminal(double[] heat, int terminal) {
        int target = -1;
        double best = -1.0;
        for (int number : coverageOf(terminal)) {
            double value = heat == null || number >= heat.length ? 0.0 : safe(heat[number]);
            if (value > best) {
                best = value;
                target = number;
            }
        }
        return target;
    }

    private static double currentContext(List<Integer> history, int terminal) {
        if (history == null || history.isEmpty()) return 0.0;
        double score = 0.0;
        double weight = 0.0;
        int[] windows = {5, 10, 30};
        double[] weights = {0.48, 0.32, 0.20};
        for (int i = 0; i < windows.length; i++) {
            int n = Math.min(windows[i], history.size());
            if (n <= 0) continue;
            int hits = 0;
            for (int j = 0; j < n; j++) {
                if (terminalOf(history.get(j)) == terminal) hits++;
            }
            // Contexto é normalizado pela maior ocupação razoável da janela;
            // não é convertido em chance futura.
            double normalized = clamp01(hits / Math.max(1.0, n * 0.28));
            score += normalized * weights[i];
            weight += weights[i];
        }
        return weight <= 0.0 ? 0.0 : clamp01(score / weight);
    }

    public static int terminalOf(int number) {
        if (!Wheel.valid(number)) return -1;
        return number % 10;
    }

    public static List<Integer> coverageOf(int terminal) {
        if (terminal < 0 || terminal > 9) return Collections.emptyList();
        List<Integer> values = new ArrayList<>();
        for (int number = terminal; number <= 36; number += 10) values.add(number);
        return values;
    }

    private static boolean isPredictive(EvidenceFamily family) {
        return family == EvidenceFamily.TRANSITION
                || family == EvidenceFamily.SEQUENCE
                || family == EvidenceFamily.HISTORICAL_SIMILARITY
                || family == EvidenceFamily.WHEEL_GEOMETRY
                || family == EvidenceFamily.ARITHMETIC;
    }

    private static boolean isRecent(EvidenceFamily family) {
        return family == EvidenceFamily.RECENCY
                || family == EvidenceFamily.REGIME
                || family == EvidenceFamily.TRANSITION;
    }

    private static double safe(double value) {
        if (!Double.isFinite(value)) return 0.0;
        return clamp01(value);
    }

    private static int clampScore(int value) {
        return Math.max(0, Math.min(100, value));
    }

    private static double clamp01(double value) {
        if (!Double.isFinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }

    private static final class TerminalPeak {
        final int terminal;
        final double score;
        final double margin;
        TerminalPeak(int terminal, double score, double margin) {
            this.terminal = terminal;
            this.score = score;
            this.margin = margin;
        }
    }
}
