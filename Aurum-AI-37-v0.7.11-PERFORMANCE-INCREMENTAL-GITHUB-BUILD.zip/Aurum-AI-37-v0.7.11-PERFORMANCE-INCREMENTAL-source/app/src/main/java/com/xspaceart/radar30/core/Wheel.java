package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Ordem física da roleta europeia de zero único. */
public final class Wheel {
    public static final List<Integer> EUROPEAN = Collections.unmodifiableList(Arrays.asList(
            0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23,
            10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
    ));

    private static final Set<Integer> VOISINS = setOf(
            22, 18, 29, 7, 28, 12, 35, 3, 26, 0, 32, 15, 19, 4, 21, 2, 25);
    private static final Set<Integer> TIERS = setOf(
            27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33);
    private static final Set<Integer> ORPHANS = setOf(1, 20, 14, 31, 9, 17, 34, 6);

    private Wheel() {}

    public static boolean valid(int number) {
        return number >= 0 && number <= 36;
    }

    public static List<Integer> coverage(int center, int radius) {
        int index = EUROPEAN.indexOf(center);
        if (index < 0) return Collections.emptyList();
        List<Integer> result = new ArrayList<>();
        for (int offset = -radius; offset <= radius; offset++) {
            result.add(EUROPEAN.get(wrap(index + offset)));
        }
        return result;
    }

    public static int distance(int a, int b) {
        int ia = EUROPEAN.indexOf(a);
        int ib = EUROPEAN.indexOf(b);
        if (ia < 0 || ib < 0) return Integer.MAX_VALUE;
        int direct = Math.abs(ia - ib);
        return Math.min(direct, EUROPEAN.size() - direct);
    }

    public static String sectorOf(int number) {
        if (VOISINS.contains(number)) return "Voisins/Zero";
        if (TIERS.contains(number)) return "Tiers";
        if (ORPHANS.contains(number)) return "Órfãos";
        return "Roda europeia";
    }

    public static String dominantSector(List<Integer> history, int limit) {
        int voisins = 0;
        int tiers = 0;
        int orphans = 0;
        int count = Math.min(limit, history.size());
        for (int i = 0; i < count; i++) {
            int n = history.get(i);
            if (VOISINS.contains(n)) voisins++;
            else if (TIERS.contains(n)) tiers++;
            else if (ORPHANS.contains(n)) orphans++;
        }
        if (voisins >= tiers && voisins >= orphans) return "Voisins/Zero (" + voisins + "/" + count + ")";
        if (tiers >= orphans) return "Tiers (" + tiers + "/" + count + ")";
        return "Órfãos (" + orphans + "/" + count + ")";
    }

    private static int wrap(int index) {
        int size = EUROPEAN.size();
        int value = index % size;
        return value < 0 ? value + size : value;
    }

    private static Set<Integer> setOf(Integer... values) {
        return Collections.unmodifiableSet(new HashSet<>(Arrays.asList(values)));
    }
}
