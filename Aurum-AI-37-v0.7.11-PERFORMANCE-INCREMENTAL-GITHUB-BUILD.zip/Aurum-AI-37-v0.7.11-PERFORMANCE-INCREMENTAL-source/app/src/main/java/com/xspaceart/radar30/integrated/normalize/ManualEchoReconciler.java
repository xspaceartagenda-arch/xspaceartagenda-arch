package com.xspaceart.radar30.integrated.normalize;

import java.util.ArrayList;
import java.util.List;

/** Evita duplicar um giro manual quando a fonte automática o reproduz depois. */
public final class ManualEchoReconciler {
    private final List<Integer> pendingNewestFirst = new ArrayList<>();

    public void record(int number) {
        if (number < 0 || number > 36) return;
        pendingNewestFirst.add(0, number);
        while (pendingNewestFirst.size() > 6) pendingNewestFirst.remove(pendingNewestFirst.size()-1);
    }

    public void clear() { pendingNewestFirst.clear(); }
    public int pendingCount() { return pendingNewestFirst.size(); }

    public List<Integer> suppress(List<Integer> deltaNewestFirst) {
        List<Integer> fresh = deltaNewestFirst == null ? new ArrayList<>() : new ArrayList<>(deltaNewestFirst);
        if (fresh.isEmpty() || pendingNewestFirst.isEmpty()) return fresh;
        int max = Math.min(fresh.size(), pendingNewestFirst.size());
        int matched = 0;
        for (int k=max; k>=1; k--) {
            boolean same = true;
            for (int i=0; i<k; i++) {
                if (!fresh.get(fresh.size()-k+i).equals(pendingNewestFirst.get(pendingNewestFirst.size()-k+i))) {
                    same=false; break;
                }
            }
            if (same) { matched=k; break; }
        }
        if (matched > 0) {
            for (int i=0; i<matched; i++) {
                fresh.remove(fresh.size()-1);
                pendingNewestFirst.remove(pendingNewestFirst.size()-1);
            }
        }
        return fresh;
    }
}
