package com.xspaceart.radar30.core;

/** Regras Balanced v0.7.7 baseadas em consenso espacial e momentum. */
public final class ConsensusPolicy {
    private ConsensusPolicy() {}

    /** Convergência excepcional que pode entrar no primeiro retrato útil. */
    public static boolean immediate(ConfluenceVerdict verdict, boolean saturated) {
        if (saturated || verdict == null || verdict.mode != ConfluenceVerdict.Mode.BALANCED) return false;
        ConsensusSnapshot.Candidate c = verdict.consensus.primary;
        return c.target >= 0
                && matchesTarget(verdict, c)
                && c.score >= 74
                && c.familyCount >= 5
                && c.alignment >= 0.88
                && c.contradiction <= 0.20
                && verdict.consensus.leaderMargin >= 0.10
                && c.predictive && c.recent;
    }

    /** Convergência local madura; não depende da entropia global da mesa. */
    public static boolean persistent(ConfluenceVerdict verdict, int updates,
                                     double leaderVelocity, boolean saturated) {
        if (saturated || verdict == null || verdict.mode != ConfluenceVerdict.Mode.BALANCED) return false;
        ConsensusSnapshot.Candidate c = verdict.consensus.primary;
        return updates >= 2
                && c.target >= 0
                && matchesTarget(verdict, c)
                && c.score >= 66
                && c.familyCount >= 4
                && c.alignment >= 0.80
                && c.contradiction <= 0.28
                && verdict.consensus.leaderMargin >= 0.07
                && leaderVelocity >= -3.0
                && c.predictive && c.recent;
    }

    /** O líder ainda não chegou ao score maduro, mas está separando dos rivais. */
    public static boolean momentum(ConfluenceVerdict verdict, int updates,
                                   double leaderVelocity, double runnerVelocity,
                                   boolean saturated) {
        if (saturated || verdict == null || verdict.mode != ConfluenceVerdict.Mode.BALANCED) return false;
        ConsensusSnapshot.Candidate c = verdict.consensus.primary;
        return updates >= 2
                && c.target >= 0
                && matchesTarget(verdict, c)
                && c.score >= 62
                && c.familyCount >= 4
                && c.alignment >= 0.78
                && c.contradiction <= 0.26
                && verdict.consensus.leaderMargin >= 0.05
                && leaderVelocity >= 3.0
                && runnerVelocity <= 1.5
                && c.predictive && c.recent;
    }

    /** HIGH_DISPERSION global pode ser atravessado quando o consenso local é excepcional. */
    public static boolean localExceptional(ConfluenceVerdict verdict, boolean saturated) {
        if (saturated || verdict == null || verdict.mode != ConfluenceVerdict.Mode.BALANCED) return false;
        ConsensusSnapshot.Candidate c = verdict.consensus.primary;
        return c.target >= 0
                && matchesTarget(verdict, c)
                && c.score >= 64
                && c.familyCount >= 5
                && c.alignment >= 0.84
                && c.contradiction <= 0.22
                && verdict.consensus.leaderMargin >= 0.06
                && c.predictive && c.recent;
    }

    private static boolean matchesTarget(ConfluenceVerdict verdict,
                                         ConsensusSnapshot.Candidate candidate) {
        if (verdict == null || candidate == null || verdict.coverage == null) return false;
        int overlap = 0;
        for (int number : candidate.coverage) {
            if (verdict.coverage.contains(number)) overlap++;
        }
        return overlap >= 3;
    }

    /** Após toque antecipado, só uma nova convergência muito forte reabre a mesma região cedo. */
    public static boolean recurrenceOverride(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.mode != ConfluenceVerdict.Mode.BALANCED) return false;
        ConsensusSnapshot.Candidate c = verdict.consensus.primary;
        return c.target >= 0
                && matchesTarget(verdict, c)
                && c.score >= 78
                && c.familyCount >= 5
                && c.alignment >= 0.90
                && c.contradiction <= 0.16
                && verdict.consensus.leaderMargin >= 0.12
                && c.predictive && c.recent;
    }
}
