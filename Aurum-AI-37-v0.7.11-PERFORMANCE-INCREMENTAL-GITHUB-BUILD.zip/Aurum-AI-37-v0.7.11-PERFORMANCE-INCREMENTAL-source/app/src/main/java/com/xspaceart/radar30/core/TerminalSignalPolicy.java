package com.xspaceart.radar30.core;

/**
 * v0.7.8 — política operacional para os dois modelos de sinal.
 *
 * <p>SECTOR mantém a régua v0.7.7. TERMINAL usa janela máxima de 5 giros.
 * MAX_CONFLUENCE é liberado quando Terminal Engine e Consensus Radar chegam ao
 * mesmo denominador: o centro do setor pertence ao terminal líder.</p>
 */
public final class TerminalSignalPolicy {
    public static final int SECTOR_VALIDITY_SPINS = 3;
    public static final int TERMINAL_VALIDITY_SPINS = 5;

    private TerminalSignalPolicy() {}

    public static boolean terminalPrepare(ConfluenceVerdict verdict) {
        if (!balanced(verdict)) return false;
        TerminalSnapshot.Candidate t = verdict.terminal.primary;
        return t.terminal >= 0
                && t.score >= 62
                && t.familyCount >= 4
                && t.alignment >= 0.74
                && t.contradiction <= 0.32
                && verdict.terminal.leaderMargin >= 0.05
                && t.predictive && t.recent;
    }

    public static boolean terminalReady(ConfluenceVerdict verdict,
                                        int updates, double velocity,
                                        boolean saturated) {
        if (saturated || !balanced(verdict)) return false;
        TerminalSnapshot.Candidate t = verdict.terminal.primary;
        if (t.terminal < 0 || !t.predictive || !t.recent) return false;
        boolean exceptional = t.score >= 80
                && t.familyCount >= 6
                && t.alignment >= 0.88
                && t.contradiction <= 0.18
                && verdict.terminal.leaderMargin >= 0.14;
        boolean mature = updates >= 2
                && t.score >= 72
                && t.familyCount >= 5
                && t.alignment >= 0.82
                && t.contradiction <= 0.24
                && verdict.terminal.leaderMargin >= 0.10
                && velocity >= -3.0;
        return exceptional || mature;
    }

    public static boolean maxConfluenceReady(ConfluenceVerdict verdict,
                                             int terminalUpdates,
                                             double terminalVelocity,
                                             boolean sectorSaturated,
                                             boolean terminalSaturated) {
        if (sectorSaturated || terminalSaturated || !balanced(verdict)
                || !aligned(verdict)) return false;
        TerminalSnapshot.Candidate t = verdict.terminal.primary;
        ConsensusSnapshot.Candidate s = verdict.consensus.primary;
        int cross = crossScore(verdict);
        boolean exceptional = cross >= 78
                && t.score >= 72 && s.score >= 70
                && t.familyCount >= 5 && s.familyCount >= 5
                && t.contradiction <= 0.20 && s.contradiction <= 0.22
                && verdict.terminal.leaderMargin >= 0.10
                && verdict.consensus.leaderMargin >= 0.06;
        boolean mature = terminalUpdates >= 2
                && cross >= 72
                && t.score >= 66 && s.score >= 64
                && t.familyCount >= 4 && s.familyCount >= 4
                && t.alignment >= 0.78 && s.alignment >= 0.78
                && t.contradiction <= 0.26 && s.contradiction <= 0.28
                && verdict.terminal.leaderMargin >= 0.07
                && verdict.consensus.leaderMargin >= 0.05
                && terminalVelocity >= -3.0;
        return (exceptional || mature)
                && t.predictive && t.recent && s.predictive && s.recent;
    }

    public static boolean aligned(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.terminal == null
                || verdict.consensus == null) return false;
        int terminal = verdict.terminal.primary.terminal;
        int sector = verdict.consensus.primary.target;
        return terminal >= 0 && sector >= 0
                && TerminalSnapshot.terminalOf(sector) == terminal;
    }

    public static int crossScore(ConfluenceVerdict verdict) {
        if (!aligned(verdict)) return 0;
        TerminalSnapshot.Candidate t = verdict.terminal.primary;
        ConsensusSnapshot.Candidate s = verdict.consensus.primary;
        double margins = Math.min(1.0,
                (verdict.terminal.leaderMargin + verdict.consensus.leaderMargin) / 0.30);
        double quality = 0.46 * (t.score / 100.0)
                + 0.42 * (s.score / 100.0)
                + 0.12 * margins;
        return clampScore((int) Math.round(quality * 100.0));
    }

    /** Revalidação contínua de um sinal terminal após cada giro sem acerto. */
    public static boolean terminalStillValid(ConfluenceVerdict verdict,
                                             int terminal, boolean maxConfluence) {
        if (!balanced(verdict) || verdict.terminal.primary.terminal != terminal) return false;
        TerminalSnapshot.Candidate t = verdict.terminal.primary;
        if (t.score < 54 || t.familyCount < 3 || t.contradiction > 0.42) return false;
        if (maxConfluence) {
            ConsensusSnapshot.Candidate s = verdict.consensus.primary;
            return aligned(verdict) && s.score >= 54 && s.familyCount >= 3
                    && s.contradiction <= 0.40;
        }
        return true;
    }

    private static boolean balanced(ConfluenceVerdict verdict) {
        return verdict != null && verdict.mode == ConfluenceVerdict.Mode.BALANCED
                && verdict.terminal != null;
    }

    private static int clampScore(int value) {
        return Math.max(0, Math.min(100, value));
    }
}
