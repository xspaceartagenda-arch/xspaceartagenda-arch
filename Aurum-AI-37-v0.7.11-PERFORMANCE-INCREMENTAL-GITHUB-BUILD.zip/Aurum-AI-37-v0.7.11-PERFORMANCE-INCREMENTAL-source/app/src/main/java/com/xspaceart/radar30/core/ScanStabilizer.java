package com.xspaceart.radar30.core;

import java.util.List;

/** Exige duas leituras consecutivas iguais antes de aceitar o OCR. */
public final class ScanStabilizer {
    private String candidate = "";
    private int repeats = 0;
    private String lastEmitted = "";

    public boolean accept(List<Integer> numbers) {
        String fingerprint = fingerprint(numbers);
        if (fingerprint.isEmpty()) return false;
        if (fingerprint.equals(candidate)) repeats++;
        else {
            candidate = fingerprint;
            repeats = 1;
        }
        if (repeats >= 2 && !fingerprint.equals(lastEmitted)) {
            lastEmitted = fingerprint;
            return true;
        }
        return false;
    }


    /** v0.7.11: permite ao capturador pedir o segundo frame imediatamente. */
    public boolean needsConfirmation() {
        return repeats == 1 && !candidate.isEmpty() && !candidate.equals(lastEmitted);
    }

    private static String fingerprint(List<Integer> numbers) {
        if (numbers == null || numbers.size() < 8) return "";
        StringBuilder out = new StringBuilder();
        int end = Math.min(30, numbers.size());
        for (int i = 0; i < end; i++) out.append(numbers.get(i)).append(',');
        return out.toString();
    }
}
