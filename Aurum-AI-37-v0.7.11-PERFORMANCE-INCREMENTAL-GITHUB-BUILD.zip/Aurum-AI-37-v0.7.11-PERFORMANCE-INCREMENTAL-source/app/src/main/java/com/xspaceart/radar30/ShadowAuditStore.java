package com.xspaceart.radar30;

import android.content.Context;
import android.content.SharedPreferences;

import com.xspaceart.radar30.core.AnalysisResult;
import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.SignalUpdate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Auditoria prospectiva dos motores. O Shadow Test nunca publica uma entrada:
 * ele registra o que cada motor teria feito e resolve a hipótese em até três
 * resultados para permitir comparação futura sem contaminar o modo ao vivo.
 */
public final class ShadowAuditStore {
    private static final String PREFS = "aurum_shadow_audit_v1";
    private static final String RECORDS = "records";
    private static final String LATEST = "latest_snapshot";
    private static final int MAX_RECORDS = 240;
    private static final String PRECISION = "precision-confluence-v2";
    private static final String LEGACY = "balanced-v4-shadow";
    private static final String MISSED_WATCH = "missed-opportunity-v1";
    private static final String PENDING = "PENDING";
    private static final String HIT = "HIT";
    private static final String EXPIRED = "EXPIRED";
    private static final String MISSED_OPPORTUNITY = "MISSED_OPPORTUNITY";
    private static final String ENTRY_RELEASED = "ENTRY_RELEASED";

    private ShadowAuditStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized void record(Context context, long sessionId,
                                           List<Integer> history,
                                           List<Integer> newNumbersNewestFirst,
                                           RadarSession.State liveState,
                                           SignalUpdate liveUpdate,
                                           ConfluenceVerdict precision,
                                           AnalysisResult legacy) {
        if (sessionId < 0L) return;
        SharedPreferences p = prefs(context);
        JSONArray records = readArray(p.getString(RECORDS, "[]"));
        try {
            resolvePending(records, sessionId, newNumbersNewestFirst, liveState);

            JSONObject snapshot = snapshot(sessionId, history,
                    newNumbersNewestFirst, liveState, liveUpdate,
                    precision, legacy);
            boolean mayOpenShadow = liveState == RadarSession.State.SCANNING
                    || liveState == RadarSession.State.OBSERVING
                    || liveState == RadarSession.State.BUILDING
                    || liveState == RadarSession.State.PREPARE;
            if (mayOpenShadow && precision != null
                    && precision.decision == ConfluenceVerdict.Decision.ENTRY
                    && !hasPending(records, sessionId, PRECISION)) {
                records.put(newRecord(sessionId, PRECISION, precision.target,
                        precision.combinedCoverage(), precision.aurumScore,
                        precision.independentFamilies, history, snapshot));
            }
            if (mayOpenShadow && precision != null
                    && (liveState == RadarSession.State.PREPARE
                    || precision.decision == ConfluenceVerdict.Decision.PREPARE)
                    && !hasPending(records, sessionId, MISSED_WATCH)) {
                JSONObject watch = newRecord(sessionId, MISSED_WATCH,
                        precision.target, precision.coverage,
                        precision.aurumScore, precision.independentFamilies,
                        history, snapshot);
                watch.put("watchType", "PREPARE");
                watch.put("thresholdBlockers", thresholdBlockers(precision));
                records.put(watch);
            }
            if (mayOpenShadow && legacy != null
                    && legacy.decision == AnalysisResult.Decision.ENTER
                    && !hasPending(records, sessionId, LEGACY)) {
                records.put(newRecord(sessionId, LEGACY, legacy.target,
                        legacy.coverage, legacy.strength,
                        legacy.confluenceCount, history, snapshot));
            }
            trim(records, MAX_RECORDS);
            JSONObject missed = latestRecord(records, sessionId, MISSED_WATCH);
            if (missed != null) snapshot.put("missedOpportunity", missed);
            p.edit()
                    .putString(RECORDS, records.toString())
                    .putString(LATEST, snapshot.toString())
                    .apply();
        } catch (JSONException ignored) {
            // O motor ao vivo não pode parar por causa da auditoria auxiliar.
        }
    }

    public static synchronized void clearLive(Context context) {
        prefs(context).edit().remove(LATEST).apply();
    }

    public static synchronized String latestSnapshotJson(Context context) {
        String value = prefs(context).getString(LATEST, "");
        return value == null ? "" : value;
    }

    public static synchronized String summary(Context context) {
        JSONArray records = readArray(prefs(context).getString(RECORDS, "[]"));
        long sessionId = SessionLedger.activeSessionId(context);
        if (sessionId < 0L) sessionId = latestSession(records);
        if (sessionId < 0L) return "Shadow Test: aguardando dados da sessão.";
        Stats precision = stats(records, sessionId, PRECISION);
        Stats legacy = stats(records, sessionId, LEGACY);
        Stats missed = stats(records, sessionId, MISSED_WATCH);
        return "Shadow Test (não envia entrada)\n"
                + statsLine("Precision raw", precision) + "\n"
                + statsLine("Motor anterior", legacy) + "\n"
                + missedStatsLine(missed);
    }

    public static synchronized String rayX(Context context) {
        String raw = latestSnapshotJson(context);
        if (raw.trim().isEmpty()) {
            return "Aguardando a primeira varredura da sessão atual.";
        }
        try {
            JSONObject root = new JSONObject(raw);
            JSONObject precision = root.optJSONObject("precision");
            JSONObject legacy = root.optJSONObject("legacy");
            StringBuilder out = new StringBuilder();
            out.append("ESTADO: ").append(root.optString("liveState", "SCANNING"));
            out.append(" • histórico ").append(root.optInt("historyCount", 0)).append("/500");
            if (precision == null) {
                out.append("\nMotor Precision aguardando contexto suficiente.");
            } else {
                out.append("\n\nVEREDITO BRUTO\n")
                        .append(precision.optString("decision", "NO_READING"))
                        .append(" • modo ").append(precision.optString("mode", "PRECISION"))
                        .append("\nPRIMARY TARGET: ").append(targetLabel(precision))
                        .append("\nAurum Score ").append(precision.optInt("score", 0)).append("/100")
                        .append(" • famílias ").append(precision.optInt("families", 0))
                        .append("\nSECONDARY TARGET: ")
                        .append(optionalTargetLabel(precision, "secondaryTarget"))
                        .append(" • score ").append(precision.optInt("secondaryScore", 0))
                        .append("/100")
                        .append("\nTHIRD TARGET: ")
                        .append(optionalTargetLabel(precision, "thirdTarget"))
                        .append(" • score ").append(precision.optInt("thirdScore", 0))
                        .append("/100")
                        .append("\nContradição ").append(percent(precision.optDouble("contradiction", 1.0)))
                        .append(" • dominância ").append(percent(precision.optDouble("dominance", 0.0)))
                        .append("\nDual dominance ")
                        .append(percent(precision.optDouble("dualDominance", 0.0)))
                        .append(" • margem secundária ")
                        .append(percent(precision.optDouble("secondaryMargin", 0.0)))
                        .append("\nDispersão ").append(percent(precision.optDouble("dispersion", 1.0)))
                        .append(" • SPATIAL REGIME ")
                        .append(precision.optString("spatialRegime", "DISPERSED"))
                        .append("\nFormato: ")
                        .append(precision.optString("signalShape", "SINGLE_TARGET"))
                        .append(" • corte ativo ")
                        .append(precision.optBoolean("entryQualified", false)
                                ? "aprovado" : "não aprovado")
                        .append("\nCONFLUENCE VELOCITY: ")
                        .append(signed(root.optDouble("confluenceVelocity", 0.0)))
                        .append(" • persistência: ")
                        .append(root.optInt("persistence", 0))
                        .append("\nGATE AO VIVO: ")
                        .append(liveGateSummary(precision, root));

                JSONObject regime = precision.optJSONObject("regime");
                if (regime != null) {
                    out.append("\n\nREGIME\nJanela atual estimada: ")
                            .append(regime.optInt("length", 0)).append(" giros")
                            .append("\nMudança: ")
                            .append(regime.optBoolean("changed", false) ? "detectada" : "não detectada")
                            .append(" • confiança ").append(percent(regime.optDouble("confidence", 0.0)))
                            .append("\nPeso do regime anterior: ")
                            .append(percent(regime.optDouble("previousWeight", 1.0)));
                }

                out.append("\n\nMAPA CENTRAL\nCobertura: ")
                        .append(jsonValues(precision.optJSONArray("coverage")))
                        .append("\nNúcleo: ")
                        .append(jsonValues(precision.optJSONArray("nucleus")))
                        .append("\nPicos: ")
                        .append(heatPeaks(precision.optJSONArray("heat"), 6));

                out.append("\n\nFAMÍLIAS INDEPENDENTES\n")
                        .append(jsonValues(precision.optJSONArray("supportingFamilies")));
                JSONArray reasons = precision.optJSONArray("reasons");
                if (reasons != null && reasons.length() > 0) {
                    out.append("\n\nPRINCIPAIS RAZÕES");
                    for (int i = 0; i < Math.min(5, reasons.length()); i++) {
                        out.append("\n• ").append(reasons.optString(i, ""));
                    }
                }
            }

            JSONObject missed = root.optJSONObject("missedOpportunity");
            out.append("\n\nMISSED OPPORTUNITY\n");
            if (missed == null) {
                out.append("nenhuma oportunidade perdida registrada");
            } else {
                out.append(missed.optString("outcome", PENDING))
                        .append(" • alvo ").append(missed.optInt("target", -1))
                        .append(" • score ").append(missed.optInt("score", 0)).append("/100")
                        .append("\nBloqueio: ")
                        .append(jsonValues(missed.optJSONArray("thresholdBlockers")));
            }

            out.append("\n\nCHAMPION / CHALLENGER\nPrecision: ")
                    .append(precision == null ? "sem leitura" : targetLabel(precision)
                            + " • " + precision.optInt("score", 0) + "/100");
            if (legacy == null) {
                out.append("\nMotor anterior: sem leitura");
            } else {
                out.append("\nMotor anterior: ")
                        .append(legacy.optString("decision", "NO_ENTRY"))
                        .append(" • alvo ").append(legacy.optInt("target", -1))
                        .append(" • ").append(legacy.optInt("score", 0)).append("/100");
            }
            out.append("\n\n").append(summary(context));
            out.append("\n\nO Shadow Test mede resultados prospectivos e não altera o sinal ao vivo.");
            return out.toString();
        } catch (JSONException error) {
            return "Snapshot de depuração indisponível; a leitura ao vivo continua ativa.";
        }
    }

    private static String liveGateSummary(JSONObject precision, JSONObject root) {
        String mode = precision.optString("mode", "PRECISION");
        int score = precision.optInt("score", 0);
        int families = precision.optInt("families", 0);
        double contradiction = precision.optDouble("contradiction", 1.0);
        double dominance = precision.optDouble("dominance", 0.0);
        int persistence = root.optInt("persistence", 0);
        double velocity = root.optDouble("confluenceVelocity", 0.0);
        String decision = precision.optString("decision", "NO_READING");
        String shape = precision.optString("signalShape", "HIGH_DISPERSION");

        if ("PRECISION".equals(mode)) {
            if (precision.optBoolean("entryQualified", false)
                    && persistence >= 3 && score >= 78
                    && contradiction <= 0.16 && velocity >= -2.0
                    && !"HIGH_DISPERSION".equals(shape)) {
                return "PRECISION apto; aguardando publicação/estado ativo.";
            }
            return "PRECISION rígido • corte bruto "
                    + (precision.optBoolean("entryQualified", false) ? "OK" : "NÃO")
                    + " • persistência " + persistence + "/3"
                    + " • score " + score + " • famílias " + families;
        }

        boolean rawStrong = precision.optBoolean("entryQualified", false)
                && contradiction <= 0.22 && !"HIGH_DISPERSION".equals(shape);
        boolean moderateFrame = "PREPARE".equals(decision)
                && score >= 66 && families >= 4
                && contradiction <= 0.30
                && dominance >= 0.05
                && !"HIGH_DISPERSION".equals(shape);
        if (rawStrong) {
            return "BALANCED FORTE apto no corte bruto.";
        }
        if (moderateFrame) {
            return "BALANCED MODERADO em validação • persistência "
                    + persistence + "/2 • velocidade " + signed(velocity);
        }
        return "BALANCED sem liberação • decisão " + decision
                + " • score " + score + " • famílias " + families
                + " • contradição " + percent(contradiction);
    }

    private static JSONObject snapshot(long sessionId, List<Integer> history,
                                       List<Integer> newNumbers,
                                       RadarSession.State liveState,
                                       SignalUpdate liveUpdate,
                                       ConfluenceVerdict precision,
                                       AnalysisResult legacy) throws JSONException {
        JSONObject root = new JSONObject();
        root.put("timestamp", System.currentTimeMillis());
        root.put("session", sessionId);
        root.put("liveState", liveState == null ? "SCANNING" : liveState.name());
        root.put("historyCount", history == null ? 0 : Math.min(500, history.size()));
        root.put("newNumbers", jsonArray(newNumbers, 10));
        root.put("confluenceVelocity", liveUpdate == null
                ? 0.0 : liveUpdate.confluenceVelocity);
        root.put("persistence", liveUpdate == null ? 0 : liveUpdate.nextRound);
        if (liveUpdate != null && !liveUpdate.resultType.isEmpty()) {
            root.put("lastResultType", liveUpdate.resultType);
            root.put("primaryAfterSecondary", liveUpdate.primaryAfterSecondary);
        }
        if (precision != null) root.put("precision", precisionJson(precision));
        if (legacy != null) root.put("legacy", legacyJson(legacy));
        return root;
    }

    private static JSONObject precisionJson(ConfluenceVerdict value) throws JSONException {
        JSONObject out = new JSONObject();
        out.put("decision", value.decision.name());
        out.put("target", value.target);
        out.put("coverage", jsonArray(value.coverage, 37));
        out.put("nucleus", jsonArray(value.nucleus, 37));
        out.put("score", value.aurumScore);
        out.put("families", value.independentFamilies);
        out.put("contradiction", value.contradictionScore);
        out.put("dominance", value.dominanceMargin);
        out.put("dispersion", value.evidenceDispersion);
        out.put("leader", value.leaderScore);
        out.put("runner", value.secondPlaceScore);
        out.put("qualified", value.precisionQualified);
        out.put("precisionQualified", value.precisionQualified);
        out.put("balancedQualified", value.balancedQualified);
        out.put("entryQualified", value.entryQualified);
        out.put("mode", value.mode.name());
        out.put("secondaryTarget", value.secondaryTarget);
        out.put("secondaryCoverage", jsonArray(value.secondaryCoverage, 37));
        out.put("secondaryNucleus", jsonArray(value.secondaryNucleus, 37));
        out.put("secondaryScore", value.secondaryScore);
        out.put("secondaryFamilies", value.secondaryFamilies);
        out.put("secondaryContradiction", value.secondaryContradiction);
        out.put("secondaryMargin", value.secondaryMargin);
        out.put("dualDominance", value.dualDominance);
        out.put("thirdTarget", value.thirdTarget);
        out.put("thirdScore", value.thirdScore);
        out.put("thirdPlaceScore", value.thirdPlaceScore);
        out.put("spatialRegime", value.spatialRegime.name());
        out.put("signalShape", value.signalShape.name());
        out.put("secondaryQualified", value.secondaryQualified);
        out.put("secondarySupportingFamilies",
                familyArray(value.secondarySupportingFamilies));
        out.put("secondaryReasons", stringArray(value.secondaryReasons, 6));
        out.put("supportingFamilies", familyArray(value.supportingFamilies));
        out.put("reasons", stringArray(value.reasons, 8));
        out.put("features", stringArray(value.featureKeys, 40));
        JSONArray heat = new JSONArray();
        for (double score : value.heatMap) heat.put(score);
        out.put("heat", heat);
        if (value.regime != null) {
            JSONObject regime = new JSONObject();
            regime.put("length", value.regime.currentRegimeStart);
            regime.put("confidence", value.regime.regimeConfidence);
            regime.put("previousWeight", value.regime.previousRegimeWeight);
            regime.put("changed", value.regime.changeDetected);
            regime.put("divergence", value.regime.divergence);
            out.put("regime", regime);
        }
        return out;
    }

    private static JSONObject legacyJson(AnalysisResult value) throws JSONException {
        JSONObject out = new JSONObject();
        out.put("decision", value.decision.name());
        out.put("target", value.target);
        out.put("coverage", jsonArray(value.coverage, 37));
        out.put("score", value.strength);
        out.put("confluences", value.confluenceCount);
        out.put("reasons", stringArray(value.reasons, 6));
        return out;
    }

    private static JSONObject newRecord(long sessionId, String engine, int target,
                                        List<Integer> coverage, int score,
                                        int families, List<Integer> history,
                                        JSONObject snapshot) throws JSONException {
        JSONObject out = new JSONObject();
        out.put("id", System.currentTimeMillis() * 1000L + Math.abs(engine.hashCode() % 997));
        out.put("session", sessionId);
        out.put("engine", engine);
        out.put("opened", System.currentTimeMillis());
        out.put("closed", 0L);
        out.put("target", target);
        out.put("coverage", jsonArray(coverage, 37));
        out.put("score", score);
        out.put("families", families);
        out.put("outcome", PENDING);
        out.put("rounds", new JSONArray());
        out.put("hitRound", 0);
        out.put("result", -1);
        out.put("historyTop30", jsonArray(history, 30));
        out.put("confluenceVelocity",
                snapshot.optDouble("confluenceVelocity", 0.0));
        out.put("persistence", snapshot.optInt("persistence", 0));
        JSONObject precision = snapshot.optJSONObject("precision");
        if (precision != null) {
            out.put("contradiction", precision.optDouble("contradiction", 1.0));
            out.put("dominance", precision.optDouble("dominance", 0.0));
            out.put("dispersion", precision.optDouble("dispersion", 1.0));
            out.put("mode", precision.optString("mode", "PRECISION"));
            out.put("signalShape", precision.optString("signalShape", "SINGLE_TARGET"));
            out.put("spatialRegime", precision.optString("spatialRegime", "DISPERSED"));
            out.put("secondaryTarget", precision.optInt("secondaryTarget", -1));
            out.put("secondaryCoverage", precision.optJSONArray("secondaryCoverage"));
            out.put("secondaryScore", precision.optInt("secondaryScore", 0));
            out.put("secondaryMargin", precision.optDouble("secondaryMargin", 0.0));
            out.put("dualDominance", precision.optDouble("dualDominance", 0.0));
            out.put("thirdTarget", precision.optInt("thirdTarget", -1));
            out.put("thirdScore", precision.optInt("thirdScore", 0));
            out.put("regime", precision.optJSONObject("regime"));
            out.put("features", precision.optJSONArray("features"));
            out.put("supportingFamilies",
                    precision.optJSONArray("supportingFamilies"));
        }
        return out;
    }

    private static void resolvePending(JSONArray records, long sessionId,
                                       List<Integer> newestFirst,
                                       RadarSession.State liveState) throws JSONException {
        if (newestFirst == null || newestFirst.isEmpty()) return;
        List<Integer> chronological = new ArrayList<>(newestFirst);
        Collections.reverse(chronological);
        for (int i = 0; i < records.length(); i++) {
            JSONObject record = records.optJSONObject(i);
            if (record == null || record.optLong("session", -1L) != sessionId
                    || !PENDING.equals(record.optString("outcome", ""))) continue;
            JSONArray rounds = record.optJSONArray("rounds");
            if (rounds == null) {
                rounds = new JSONArray();
                record.put("rounds", rounds);
            }
            JSONArray coverage = record.optJSONArray("coverage");
            boolean missedWatch = MISSED_WATCH.equals(
                    record.optString("engine", ""));
            for (int result : chronological) {
                if (!PENDING.equals(record.optString("outcome", ""))) break;
                rounds.put(result);
                if (contains(coverage, result)) {
                    record.put("outcome", missedWatch ? MISSED_OPPORTUNITY : HIT);
                    record.put("closed", System.currentTimeMillis());
                    record.put("hitRound", rounds.length());
                    record.put("result", result);
                } else if (!missedWatch && rounds.length() >= 3) {
                    record.put("outcome", EXPIRED);
                    record.put("closed", System.currentTimeMillis());
                    record.put("hitRound", 0);
                    record.put("result", result);
                }
            }
            if (missedWatch && PENDING.equals(record.optString("outcome", ""))) {
                if (liveState == RadarSession.State.ENTRY) {
                    record.put("outcome", ENTRY_RELEASED);
                    record.put("closed", System.currentTimeMillis());
                } else if (rounds.length() >= 3) {
                    record.put("outcome", EXPIRED);
                    record.put("closed", System.currentTimeMillis());
                    record.put("hitRound", 0);
                    record.put("result", rounds.optInt(rounds.length() - 1, -1));
                }
            }
        }
    }

    private static boolean hasPending(JSONArray records, long sessionId, String engine) {
        for (int i = records.length() - 1; i >= 0; i--) {
            JSONObject value = records.optJSONObject(i);
            if (value != null && value.optLong("session", -1L) == sessionId
                    && engine.equals(value.optString("engine", ""))
                    && PENDING.equals(value.optString("outcome", ""))) return true;
        }
        return false;
    }

    private static Stats stats(JSONArray records, long sessionId, String engine) {
        Stats result = new Stats();
        for (int i = 0; i < records.length(); i++) {
            JSONObject value = records.optJSONObject(i);
            if (value == null || value.optLong("session", -1L) != sessionId
                    || !engine.equals(value.optString("engine", ""))) continue;
            String outcome = value.optString("outcome", "");
            if (HIT.equals(outcome)) {
                result.hits++;
                result.resolved++;
            } else if (MISSED_OPPORTUNITY.equals(outcome)) {
                result.missed++;
                result.resolved++;
            } else if (ENTRY_RELEASED.equals(outcome)) {
                result.released++;
                result.resolved++;
            } else if (EXPIRED.equals(outcome)) {
                result.expired++;
                result.resolved++;
            } else if (PENDING.equals(outcome)) {
                result.pending++;
            }
        }
        return result;
    }

    private static String statsLine(String label, Stats value) {
        if (value.resolved == 0) {
            return label + ": 0 resolvidos" + (value.pending > 0
                    ? " • " + value.pending + " pendente" : "");
        }
        double rate = value.hits * 100.0 / value.resolved;
        return String.format(new Locale("pt", "BR"),
                "%s: %d STRYKE / %d RED • %.1f%% observado%s",
                label, value.hits, value.expired, rate,
                value.pending > 0 ? " • " + value.pending + " pendente" : "");
    }

    private static String missedStatsLine(Stats value) {
        return "Missed Opportunity: " + value.missed + " registrada"
                + (value.missed == 1 ? "" : "s")
                + " • " + value.released + " liberada"
                + (value.released == 1 ? "" : "s")
                + (value.pending > 0 ? " • " + value.pending + " em observação" : "");
    }

    private static long latestSession(JSONArray records) {
        long latest = -1L;
        long opened = -1L;
        for (int i = 0; i < records.length(); i++) {
            JSONObject value = records.optJSONObject(i);
            if (value != null && value.optLong("opened", 0L) >= opened) {
                opened = value.optLong("opened", 0L);
                latest = value.optLong("session", -1L);
            }
        }
        return latest;
    }

    private static JSONObject latestRecord(JSONArray records, long sessionId,
                                           String engine) {
        for (int i = records.length() - 1; i >= 0; i--) {
            JSONObject value = records.optJSONObject(i);
            if (value != null && value.optLong("session", -1L) == sessionId
                    && engine.equals(value.optString("engine", ""))) return value;
        }
        return null;
    }

    private static JSONArray thresholdBlockers(ConfluenceVerdict value) {
        JSONArray blockers = new JSONArray();
        boolean precision = value.mode == ConfluenceVerdict.Mode.PRECISION;
        int scoreGate = precision ? 82 : 76;
        int familyGate = precision ? 6 : 5;
        double contradictionGate = precision ? 0.16 : 0.22;
        if (value.aurumScore < scoreGate) {
            blockers.put("score " + value.aurumScore + " < " + scoreGate);
        }
        if (value.independentFamilies < familyGate) {
            blockers.put("famílias " + value.independentFamilies + " < " + familyGate);
        }
        if (value.contradictionScore > contradictionGate) {
            blockers.put("contradição acima do corte " + percent(contradictionGate));
        }
        if (value.signalShape == com.xspaceart.radar30.core.TargetRanking.SignalShape.HIGH_DISPERSION) {
            blockers.put("HIGH_DISPERSION");
        }
        if (value.entryQualified) {
            blockers.put("persistência/velocidade da máquina de estados");
        }
        if (blockers.length() == 0) blockers.put("alinhamento ou dominância insuficiente");
        return blockers;
    }

    private static String targetLabel(JSONObject precision) {
        int target = precision.optInt("target", -1);
        return target < 0 ? "sem alvo" : target + " + 2 vizinhos";
    }

    private static String optionalTargetLabel(JSONObject precision, String key) {
        int target = precision.optInt(key, -1);
        return target < 0 ? "NONE" : target + " + 2 vizinhos";
    }

    private static String heatPeaks(JSONArray heat, int limit) {
        if (heat == null || heat.length() < 37) return "indisponível";
        List<HeatPoint> points = new ArrayList<>();
        for (int number = 0; number <= 36; number++) {
            points.add(new HeatPoint(number, heat.optDouble(number, 0.0)));
        }
        points.sort(Comparator.comparingDouble((HeatPoint item) -> item.score).reversed());
        StringBuilder out = new StringBuilder();
        double maximum = points.isEmpty() ? 0.0 : points.get(0).score;
        for (int i = 0; i < Math.min(limit, points.size()); i++) {
            if (i > 0) out.append(" • ");
            HeatPoint point = points.get(i);
            int relative = maximum <= 0.0 ? 0 : (int) Math.round(100.0 * point.score / maximum);
            out.append(point.number).append("(").append(relative).append(")");
        }
        return out.toString();
    }

    private static JSONArray jsonArray(List<?> values, int limit) {
        JSONArray out = new JSONArray();
        if (values == null) return out;
        for (int i = 0; i < Math.min(limit, values.size()); i++) out.put(values.get(i));
        return out;
    }

    private static JSONArray familyArray(List<EvidenceFamily> values) {
        JSONArray out = new JSONArray();
        if (values == null) return out;
        for (EvidenceFamily value : values) out.put(value.name());
        return out;
    }

    private static JSONArray stringArray(List<String> values, int limit) {
        JSONArray out = new JSONArray();
        if (values == null) return out;
        for (int i = 0; i < Math.min(limit, values.size()); i++) out.put(values.get(i));
        return out;
    }

    private static String jsonValues(JSONArray values) {
        if (values == null || values.length() == 0) return "nenhum";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < values.length(); i++) {
            if (i > 0) out.append(" · ");
            out.append(values.optString(i, ""));
        }
        return out.toString();
    }

    private static boolean contains(JSONArray values, int number) {
        if (values == null) return false;
        for (int i = 0; i < values.length(); i++) {
            if (values.optInt(i, -1) == number) return true;
        }
        return false;
    }

    private static JSONArray readArray(String raw) {
        try {
            return new JSONArray(raw == null ? "[]" : raw);
        } catch (JSONException ignored) {
            return new JSONArray();
        }
    }

    private static void trim(JSONArray values, int limit) {
        while (values.length() > limit) values.remove(0);
    }

    private static String percent(double value) {
        return Math.round(Math.max(0.0, Math.min(1.0, value)) * 100.0) + "%";
    }

    private static String signed(double value) {
        return String.format(new Locale("pt", "BR"), "%+.1f", value);
    }

    private static final class Stats {
        int hits;
        int expired;
        int pending;
        int resolved;
        int missed;
        int released;
    }

    private static final class HeatPoint {
        final int number;
        final double score;

        HeatPoint(int number, double score) {
            this.number = number;
            this.score = score;
        }
    }
}
