package com.xspaceart.radar30;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Memória de processo da captura: bitmap para calibração + snapshot OCR para a Integrated. */
public final class CaptureRepository {
    private static Bitmap latest;
    private static List<Integer> latestNumbers = new ArrayList<>();
    private static long latestNumbersAt;
    private static long ocrScanCount;

    private CaptureRepository() {}

    public static synchronized void setLatest(Bitmap bitmap) {
        Bitmap previous = latest;
        latest = bitmap;
        if (previous != null && previous != bitmap && !previous.isRecycled()) previous.recycle();
    }

    public static synchronized Bitmap getLatestCopy() {
        if (latest == null || latest.isRecycled()) return null;
        return latest.copy(Bitmap.Config.ARGB_8888, false);
    }

    public static synchronized boolean hasLatest() {
        return latest != null && !latest.isRecycled();
    }

    public static synchronized void setLatestNumbers(List<Integer> numbers, long observedAt) {
        latestNumbers = numbers == null ? new ArrayList<>() : new ArrayList<>(numbers);
        latestNumbersAt = observedAt;
        ocrScanCount++;
    }

    public static synchronized List<Integer> getLatestNumbers() {
        return Collections.unmodifiableList(new ArrayList<>(latestNumbers));
    }

    public static synchronized long latestNumbersAt() { return latestNumbersAt; }
    public static synchronized long ocrScanCount() { return ocrScanCount; }

    public static synchronized void clear() {
        if (latest != null && !latest.isRecycled()) latest.recycle();
        latest = null;
        latestNumbers = new ArrayList<>();
        latestNumbersAt = 0L;
        ocrScanCount = 0L;
    }
}
