package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Calibração local conservadora. Uma característica só influencia o filtro se
 * tiver amostra mínima e mantiver desempenho também na metade mais recente da
 * base. Assim, um acerto isolado ou uma estratégia ajustada ao passado não
 * recebe peso automático.
 */
public final class LearningModel {
    public static final double RANDOM_THREE_SPIN_BASELINE =
            1.0 - Math.pow(32.0 / 37.0, 3.0);
    public static final int MIN_TOTAL_SIGNALS = 100;
    private static final int MIN_FEATURE_SIGNALS = 60;
    private static final int MIN_VALIDATION_SIGNALS = 30;
    private static final int MIN_COVERAGE_VALIDATION_SIGNALS = 50;

    private final Map<String, Evidence> evidence;
    private final int resolvedSignals;
    private final int hits;
    private final double expectedHits;

    /**
     * Cada vetor aceita {tentativas, acertos, tentativas recentes, acertos
     * recentes}. Vetores antigos de duas posições permanecem legíveis, porém
     * não recebem ajuste positivo sem a amostra recente de validação.
     */
    public LearningModel(Map<String, int[]> rawEvidence, int resolvedSignals, int hits) {
        this(rawEvidence, resolvedSignals, hits,
                Math.max(0, resolvedSignals) * RANDOM_THREE_SPIN_BASELINE);
    }

    public LearningModel(Map<String, int[]> rawEvidence, int resolvedSignals, int hits,
                         double expectedHits) {
        Map<String, Evidence> copy = new LinkedHashMap<>();
        if (rawEvidence != null) {
            for (Map.Entry<String, int[]> entry : rawEvidence.entrySet()) {
                int[] values = entry.getValue();
                if (entry.getKey() == null || values == null || values.length < 2) continue;
                int attempts = Math.max(0, values[0]);
                int successes = Math.max(0, Math.min(attempts, values[1]));
                int validationAttempts = values.length >= 4 ? Math.max(0, values[2]) : 0;
                int validationHits = values.length >= 4
                        ? Math.max(0, Math.min(validationAttempts, values[3])) : 0;
                copy.put(entry.getKey(), new Evidence(attempts, successes,
                        validationAttempts, validationHits));
            }
        }
        this.evidence = Collections.unmodifiableMap(copy);
        this.resolvedSignals = Math.max(0, resolvedSignals);
        this.hits = Math.max(0, Math.min(this.resolvedSignals, hits));
        this.expectedHits = Math.max(0.0,
                Math.min(this.resolvedSignals, expectedHits));
    }

    public static LearningModel empty() {
        return new LearningModel(Collections.emptyMap(), 0, 0);
    }

    /** Ajuste máximo de quatro pontos e incapaz de resgatar um sinal-base fraco. */
    public int adjustmentFor(List<String> features) {
        if (!isActive() || features == null || features.isEmpty()) return 0;
        List<Double> approved = new ArrayList<>();
        for (String feature : features) {
            Evidence item = evidence.get(feature);
            if (item == null
                    || item.attempts < MIN_FEATURE_SIGNALS
                    || item.validationAttempts < MIN_VALIDATION_SIGNALS) continue;

            double lower = wilsonLower(item.attempts, item.hits);
            double upper = wilsonUpper(item.attempts, item.hits);
            double recentLower = wilsonLower(item.validationAttempts, item.validationHits);
            double recentUpper = wilsonUpper(item.validationAttempts, item.validationHits);
            double reliability = Math.min(1.0, item.attempts / 80.0);
            double baseline = baselineForFeature(feature);

            if (lower > baseline && recentLower > baseline) {
                double edge = Math.min(lower, recentLower) - baseline;
                approved.add(Math.min(3.0, edge * 24.0 * reliability));
            } else if (upper < baseline || recentUpper < baseline) {
                double deficit = baseline - Math.min(upper, recentUpper);
                approved.add(-Math.min(4.0, Math.max(1.0, deficit * 28.0 * reliability)));
            }
        }
        if (approved.isEmpty()) return 0;
        double total = 0.0;
        for (double value : approved) total += value;
        return Math.max(-4, Math.min(4, (int) Math.round(total / approved.size())));
    }

    public int resolvedSignals() {
        return resolvedSignals;
    }

    public int hits() {
        return hits;
    }

    public double observedHitRate() {
        return resolvedSignals == 0 ? 0.0 : hits / (double) resolvedSignals;
    }

    public double expectedHitRate() {
        return resolvedSignals == 0 ? 0.0 : expectedHits / resolvedSignals;
    }

    public double observedEdge() {
        return observedHitRate() - expectedHitRate();
    }

    public boolean isActive() {
        return resolvedSignals >= MIN_TOTAL_SIGNALS;
    }

    public Evidence evidenceFor(String feature) {
        return evidence.get(feature);
    }

    public Evidence coverageEvidence(int coverageSize) {
        return evidence.get(modelFeature(coverageSize));
    }

    public boolean isCoverageValidated(int coverageSize) {
        Evidence item = coverageEvidence(coverageSize);
        if (item == null
                || item.attempts < MIN_TOTAL_SIGNALS
                || item.validationAttempts < MIN_COVERAGE_VALIDATION_SIGNALS) return false;
        double baseline = threeSpinBaseline(coverageSize);
        return wilsonLower(item.attempts, item.hits) > baseline
                && wilsonLower(item.validationAttempts, item.validationHits) > baseline;
    }

    public double coverageLowerBound(int coverageSize) {
        Evidence item = coverageEvidence(coverageSize);
        return item == null ? 0.0 : wilsonLower(item.attempts, item.hits);
    }

    public static String modelFeature(int coverageSize) {
        return "modelo_cobertura_" + clampCoverage(coverageSize) + "_v4";
    }

    public static String strengthBand(int strength) {
        return strengthBand(strength, 5);
    }

    public static String strengthBand(int strength, int coverageSize) {
        String suffix = "_cobertura_" + Math.max(1, coverageSize) + "_v4";
        if (strength >= 90) return "faixa_90_100" + suffix;
        if (strength >= 84) return "faixa_84_89" + suffix;
        if (strength >= 76) return "faixa_76_83" + suffix;
        return "faixa_abaixo_76" + suffix;
    }

    private static double baselineForFeature(String feature) {
        return threeSpinBaseline(parseCoverageSize(feature));
    }

    public static double threeSpinBaseline(int coverageSize) {
        int pockets = clampCoverage(coverageSize);
        double miss = (37.0 - pockets) / 37.0;
        return 1.0 - Math.pow(miss, 3.0);
    }

    private static int parseCoverageSize(String feature) {
        if (feature == null) return 5;
        String marker = "cobertura_";
        int start = feature.indexOf(marker);
        if (start < 0) return 5;
        start += marker.length();
        int end = start;
        while (end < feature.length() && Character.isDigit(feature.charAt(end))) end++;
        if (end == start) return 5;
        try {
            return clampCoverage(Integer.parseInt(feature.substring(start, end)));
        } catch (NumberFormatException ignored) {
            return 5;
        }
    }

    private static int clampCoverage(int coverageSize) {
        return Math.max(1, Math.min(36, coverageSize));
    }

    private static double wilsonLower(int attempts, int successes) {
        return wilson(attempts, successes, false);
    }

    private static double wilsonUpper(int attempts, int successes) {
        return wilson(attempts, successes, true);
    }

    private static double wilson(int attempts, int successes, boolean upper) {
        if (attempts <= 0) return upper ? 1.0 : 0.0;
        double z = 1.96;
        double n = attempts;
        double rate = successes / n;
        double z2 = z * z;
        double denominator = 1.0 + z2 / n;
        double center = (rate + z2 / (2.0 * n)) / denominator;
        double half = z * Math.sqrt((rate * (1.0 - rate) / n)
                + z2 / (4.0 * n * n)) / denominator;
        return Math.max(0.0, Math.min(1.0, upper ? center + half : center - half));
    }

    public static final class Evidence {
        public final int attempts;
        public final int hits;
        public final int validationAttempts;
        public final int validationHits;

        Evidence(int attempts, int hits, int validationAttempts, int validationHits) {
            this.attempts = attempts;
            this.hits = hits;
            this.validationAttempts = validationAttempts;
            this.validationHits = validationHits;
        }

        public double observedRate() {
            return attempts == 0 ? 0.0 : hits / (double) attempts;
        }

        public double validationRate() {
            return validationAttempts == 0
                    ? 0.0 : validationHits / (double) validationAttempts;
        }
    }
}
