package com.xspaceart.radar30.integrated;

import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.ScanSynchronizer;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.Wheel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Ponte fina: a camada operacional reconcilia fontes, mas o cérebro permanece o core existente. */
public final class IntegratedSignalBridge {
    private ScanSynchronizer sync = new ScanSynchronizer();
    private RadarSession session = new RadarSession();
    private boolean precision = true;

    public void setPrecision(boolean precision) { this.precision = precision; }
    public boolean isPrecision() { return precision; }

    public Result acceptScan(List<Integer> newestFirst) {
        ScanSynchronizer.MergeResult merge = sync.merge(newestFirst);
        if (!merge.accepted) return new Result(false, merge.message, null, session.lastVerdict(), merge.history);
        SignalUpdate u = session.update(merge.history, merge.newNumbers, LearningModel.empty(), precision);
        return new Result(true, merge.message, u, session.lastVerdict(), merge.history);
    }

    /** Aceita somente o prefixo realmente novo detectado desde o snapshot anterior da fonte. */
    public Result acceptIncremental(List<Integer> newestFirstNewNumbers) {
        List<Integer> clean = new ArrayList<>();
        if (newestFirstNewNumbers != null) {
            for (Integer n : newestFirstNewNumbers) if (n != null && Wheel.valid(n)) clean.add(n);
        }
        if (clean.isEmpty()) return new Result(true, "Sem resultado novo", null, session.lastVerdict(), historySnapshot());
        List<Integer> next = new ArrayList<>(clean);
        next.addAll(sync.current());
        sync.restore(next);
        SignalUpdate u = session.update(sync.current(), clean, LearningModel.empty(), precision);
        return new Result(true, clean.size() + (clean.size()==1 ? " resultado novo" : " resultados novos"),
                u, session.lastVerdict(), historySnapshot());
    }

    public Result replaceBootstrap(List<Integer> newestFirst) {
        sync.restore(newestFirst == null ? Collections.emptyList() : newestFirst);
        session = new RadarSession();
        SignalUpdate u = session.update(sync.current(), Collections.emptyList(), LearningModel.empty(), precision);
        return new Result(true, "Histórico sincronizado", u, session.lastVerdict(), historySnapshot());
    }

    public Result prependManual(int number) {
        if (!Wheel.valid(number)) return new Result(false, "Número inválido", null, session.lastVerdict(), historySnapshot());
        return acceptIncremental(Collections.singletonList(number));
    }

    public Result removeLatest() {
        List<Integer> h = historySnapshot();
        if (h.isEmpty()) return new Result(false, "Histórico vazio", null, session.lastVerdict(), h);
        h.remove(0);
        return rebuild(h, "Último giro removido");
    }

    public Result replaceLatest(int number) {
        if (!Wheel.valid(number)) return new Result(false, "Número inválido", null, session.lastVerdict(), historySnapshot());
        List<Integer> h = historySnapshot();
        if (h.isEmpty()) h.add(number); else h.set(0, number);
        return rebuild(h, "Último giro corrigido para " + number);
    }

    public Result clearOperational() { return rebuild(Collections.emptyList(), "Histórico operacional limpo"); }

    private Result rebuild(List<Integer> history, String message) {
        sync = new ScanSynchronizer();
        sync.restore(history);
        session = new RadarSession();
        SignalUpdate u = session.update(sync.current(), Collections.emptyList(), LearningModel.empty(), precision);
        return new Result(true, message, u, session.lastVerdict(), historySnapshot());
    }

    public int historySize() { return sync.current().size(); }
    public List<Integer> historySnapshot() { return new ArrayList<>(sync.current()); }

    public static final class Result {
        public final boolean accepted; public final String message; public final SignalUpdate update;
        public final ConfluenceVerdict verdict; public final List<Integer> history;
        Result(boolean accepted, String message, SignalUpdate update, ConfluenceVerdict verdict, List<Integer> history) {
            this.accepted=accepted; this.message=message; this.update=update; this.verdict=verdict;
            this.history=Collections.unmodifiableList(new ArrayList<>(history));
        }
    }
}
