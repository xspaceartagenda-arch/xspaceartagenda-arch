package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class SignalUpdate {
    public enum Kind {
        SCANNING, BUILDING, PREPARE, ENTRY, ACTIVE, INVALIDATED, COOLDOWN,
        TRIAL, OBSERVE, NO_ENTRY, HIT, SECONDARY_HIT, EXPIRED,
        LATE_WATCH, LATE_HIT, LATE_MISS, WAITING
    }

    public final Kind kind;
    public final String headline;
    public final String detail;
    public final int target;
    public final String playLabel;
    public final List<Integer> primaryCoverage;
    public final String protectionLabel;
    public final List<Integer> protectionCoverage;
    public final List<Integer> coverage;
    public final int strength;
    public final int nextRound;
    public final String speech;
    public final List<String> featureKeys;
    public final int confluenceCount;
    public final int eventResult;
    public final int resolvedRound;
    public final int secondaryTarget;
    public final String secondaryPlayLabel;
    public final List<Integer> secondaryCoverage;
    public final int secondaryStrength;
    public final String signalType;
    public final String resultType;
    public final String spatialRegime;
    public final double confluenceVelocity;
    public final String primaryAfterSecondary;
    public final boolean primaryStillActive;

    public SignalUpdate(Kind kind, String headline, String detail, int target,
                        List<Integer> coverage, int strength, int nextRound, String speech) {
        this(kind, headline, detail, target, coverage, strength, nextRound, speech,
                Collections.emptyList(), 0, -1, 0);
    }

    public SignalUpdate(Kind kind, String headline, String detail, int target,
                        List<Integer> coverage, int strength, int nextRound, String speech,
                        List<String> featureKeys, int confluenceCount,
                        int eventResult, int resolvedRound) {
        this(kind, headline, detail, target, coverage, strength, nextRound, speech,
                featureKeys, confluenceCount, eventResult, resolvedRound,
                target < 0 ? "" : "SETOR " + target + " + 2 VIZINHOS");
    }

    public SignalUpdate(Kind kind, String headline, String detail, int target,
                        List<Integer> coverage, int strength, int nextRound, String speech,
                        List<String> featureKeys, int confluenceCount,
                        int eventResult, int resolvedRound, String playLabel) {
        this(kind, headline, detail, target, coverage, "", Collections.emptyList(),
                coverage, strength, nextRound, speech, featureKeys, confluenceCount,
                eventResult, resolvedRound, playLabel);
    }

    public SignalUpdate(Kind kind, String headline, String detail, int target,
                        List<Integer> primaryCoverage, String protectionLabel,
                        List<Integer> protectionCoverage, List<Integer> coverage,
                        int strength, int nextRound, String speech,
                        List<String> featureKeys, int confluenceCount,
                        int eventResult, int resolvedRound, String playLabel) {
        this(kind, headline, detail, target, primaryCoverage, protectionLabel,
                protectionCoverage, coverage, strength, nextRound, speech,
                featureKeys, confluenceCount, eventResult, resolvedRound,
                playLabel, -1, "", Collections.emptyList(), 0,
                "SINGLE_TARGET_SIGNAL", "", "", 0.0, "", false);
    }

    public SignalUpdate(Kind kind, String headline, String detail, int target,
                        List<Integer> primaryCoverage, String protectionLabel,
                        List<Integer> protectionCoverage, List<Integer> coverage,
                        int strength, int nextRound, String speech,
                        List<String> featureKeys, int confluenceCount,
                        int eventResult, int resolvedRound, String playLabel,
                        int secondaryTarget, String secondaryPlayLabel,
                        List<Integer> secondaryCoverage, int secondaryStrength,
                        String signalType, String resultType,
                        String spatialRegime,
                        double confluenceVelocity,
                        String primaryAfterSecondary,
                        boolean primaryStillActive) {
        this.kind = kind;
        this.headline = headline;
        this.detail = detail;
        this.target = target;
        this.playLabel = playLabel == null ? "" : playLabel;
        this.primaryCoverage = immutable(primaryCoverage);
        this.protectionLabel = protectionLabel == null ? "" : protectionLabel;
        this.protectionCoverage = immutable(protectionCoverage);
        this.coverage = immutable(coverage);
        this.strength = strength;
        this.nextRound = nextRound;
        this.speech = speech == null ? "" : speech;
        this.featureKeys = featureKeys == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(featureKeys));
        this.confluenceCount = Math.max(0, confluenceCount);
        this.eventResult = eventResult;
        this.resolvedRound = Math.max(0, resolvedRound);
        this.secondaryTarget = secondaryTarget;
        this.secondaryPlayLabel = secondaryPlayLabel == null
                ? "" : secondaryPlayLabel;
        this.secondaryCoverage = immutable(secondaryCoverage);
        this.secondaryStrength = Math.max(0, Math.min(100, secondaryStrength));
        this.signalType = signalType == null || signalType.isEmpty()
                ? "SINGLE_TARGET_SIGNAL" : signalType;
        this.resultType = resultType == null ? "" : resultType;
        this.spatialRegime = spatialRegime == null ? "" : spatialRegime;
        this.confluenceVelocity = Double.isFinite(confluenceVelocity)
                ? confluenceVelocity : 0.0;
        this.primaryAfterSecondary = primaryAfterSecondary == null
                ? "" : primaryAfterSecondary;
        this.primaryStillActive = primaryStillActive;
    }

    private static List<Integer> immutable(List<Integer> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        return Collections.unmodifiableList(new ArrayList<>(values));
    }
}
