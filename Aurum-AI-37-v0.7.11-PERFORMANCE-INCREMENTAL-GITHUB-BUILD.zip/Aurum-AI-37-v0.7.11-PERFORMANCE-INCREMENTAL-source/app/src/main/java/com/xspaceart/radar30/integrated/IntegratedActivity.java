package com.xspaceart.radar30.integrated;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.xspaceart.radar30.AppStateStore;
import com.xspaceart.radar30.CalibrationActivity;
import com.xspaceart.radar30.CaptureRepository;
import com.xspaceart.radar30.MainActivity;
import com.xspaceart.radar30.ScreenCaptureService;
import com.xspaceart.radar30.SessionLedger;
import com.xspaceart.radar30.Ui;
import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.ScanStabilizer;
import com.xspaceart.radar30.integrated.normalize.SpinNormalizer;
import com.xspaceart.radar30.integrated.normalize.SourceDelta;
import com.xspaceart.radar30.integrated.normalize.SourceOrderTracker;
import com.xspaceart.radar30.integrated.normalize.ManualEchoReconciler;
import com.xspaceart.radar30.integrated.pipeline.ReadingPipelineController;
import com.xspaceart.radar30.integrated.scanner.DomSourceMemory;
import com.xspaceart.radar30.integrated.scanner.EnvironmentScanner;
import com.xspaceart.radar30.integrated.scanner.EvidenceGraph;
import com.xspaceart.radar30.integrated.scanner.HistoryAgreement;
import com.xspaceart.radar30.integrated.scanner.HistoryQualityGate;
import com.xspaceart.radar30.integrated.scanner.SourceHunter;
import com.xspaceart.radar30.integrated.session.IntegratedSessionStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class IntegratedActivity extends Activity {
    private static final long SCAN_MS = 1200L;
    private static final long UI_TICK_MS = 700L;
    private static final int REQUEST_CAPTURE = 7101;
    private static final int FAMILY_COUNT = EvidenceFamily.values().length;
    private static final int DOM_LOCK_CONFIDENCE = 76;
    private static final int DOM_TRACK_CONFIDENCE = 68;
    private static final int DOM_LOCK_FAILURE_LIMIT = 5;
    private static final int DOM_RELOCK_HITS = 2;
    private static final long DOM_QUARANTINE_MS = 12_000L;
    private static final double DOM_OCR_MIN_AGREEMENT = 0.78;
    private static final String BROWSER_PREFS = "aurum_integrated_browser";
    private static final String LAST_URL = "last_url";

    private enum DomState { DISCOVERY, LOCKED, TRACKING, BLOCKED }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final IntegratedSignalBridge bridge = new IntegratedSignalBridge();
    private final SpinNormalizer normalizer = new SpinNormalizer();
    private final SourceOrderTracker domOrderTracker = new SourceOrderTracker();
    private final SourceOrderTracker ocrOrderTracker = new SourceOrderTracker();
    private ScanStabilizer domStabilizer = new ScanStabilizer();
    private ScanStabilizer ocrStabilizer = new ScanStabilizer();
    private final ManualEchoReconciler manualEchoReconciler = new ManualEchoReconciler();
    private final EnvironmentScanner environmentScanner = new EnvironmentScanner();
    private final EvidenceGraph evidenceGraph = new EvidenceGraph();
    private final ReadingPipelineController pipeline = new ReadingPipelineController();

    private WebView webView;
    private EditText urlInput;
    private ProgressBar pageProgress, confluenceBar, pipelinePulse, radarPulse;
    private TextView liveBadge, signalTitle, signalTarget, signalMeta, secondaryText;
    private TextView scannerText, rayText, sessionText, sourceText, contextText;
    private TextView pipelineText, confluenceText, historyPreviewText, activityText, captureStatusText, analysisPulseText;
    private Switch balancedSwitch;
    private Button startReadingButton, finishButton, newSessionButton, scanToggle;

    private boolean scannerRunning = true;
    private boolean readingActive;
    private boolean receiverRegistered;
    private boolean incrementalSourceMode;
    private boolean ocrFallbackActive;
    private boolean domSemanticHistory;
    private boolean initialBootstrapPending = true;
    private DomState domState = DomState.DISCOVERY;

    private String currentHost = "";
    private String lockedDomSignature = "";
    private String lastDomFingerprint = "";
    private String lastOcrFingerprint = "";
    private String lastAcceptedSource = "—";
    private String domHint = "";
    private String tableContext = "sem contexto auxiliar confirmado";
    private String pendingDomSignature = "";
    private String domQualityReason = "aguardando validação";
    private String domExtractionMode = "NONE";
    private long lastScanAttemptAt;
    private long lastDomHealthyAt;
    private long lastOcrHealthyAt;
    private long lastDomStableAt;
    private long domQuarantineUntil;
    private long lastOcrScanCount;
    private long analysisSerial;
    private long lastDataAt;
    private long scanAttempts;
    private int domHistoryCount;
    private int ocrHistoryCount;
    private int accessibleFrames;
    private int blockedFrames;
    private int domLockFailures;
    private int domDiscoveryFailures;
    private int domConfidence;
    private int pendingDomSignatureHits;
    private int domQualityScore;
    private int domQualityFailures;
    private int domConsensusFailures;
    private int heartbeatTick;
    private int currentResult = -1;
    private double domOcrAgreement = 1.0;
    private ConfluenceVerdict lastVerdict;
    private List<Integer> lastDomObserved = new ArrayList<>();
    private List<Integer> lastDomStableObserved = new ArrayList<>();
    private List<Integer> lastOcrObserved = new ArrayList<>();
    private List<Integer> lastOcrStableObserved = new ArrayList<>();
    private long lastOcrStableAt;
    private int standbyProgressHits;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            syncFromVisualHistory();
            refreshCaptureStatus();
        }
    };

    private final Runnable scanLoop = new Runnable() {
        @Override public void run() {
            if (scannerRunning && webView != null) discoverPage();
            handler.postDelayed(this, SCAN_MS);
        }
    };

    private final Runnable uiTicker = new Runnable() {
        @Override public void run() {
            heartbeatTick++;
            if (readingActive && heartbeatTick % 2 == 0) syncFromVisualHistory();
            watchdogPipeline();
            refreshTelemetryClock();
            handler.postDelayed(this, UI_TICK_MS);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        setContentView(buildUi());
        bridge.setPrecision(true);
        configureWebView();
        registerStateReceiver();
        handler.postDelayed(scanLoop, 700L);
        handler.post(uiTicker);
        refreshSession();
        refreshCaptureStatus();
        syncFromVisualHistory();
        refreshTelemetryClock();
    }

    @Override protected void onResume() {
        super.onResume();
        syncFromVisualHistory();
        refreshCaptureStatus();
    }

    @Override protected void onPause() {
        try { CookieManager.getInstance().flush(); } catch (RuntimeException ignored) {}
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); } catch (IllegalArgumentException ignored) {}
            receiverRegistered = false;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Leitura visual não autorizada.", Toast.LENGTH_LONG).show();
            refreshCaptureStatus();
            return;
        }
        AppStateStore.clearOcrSnapshot(this);
        Intent service = new Intent(this, ScreenCaptureService.class)
                .setAction(ScreenCaptureService.ACTION_START)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                .putExtra(ScreenCaptureService.EXTRA_PIPELINE_MODE, ScreenCaptureService.MODE_INTEGRATED_SOURCE_ONLY);
        startForegroundService(service);
        captureStatusText.setText("OCR • captura autorizada, preparando HOT STANDBY");
        captureStatusText.setTextColor(Ui.CYAN);
        Toast.makeText(this,
                AppStateStore.isCalibrated(this)
                        ? "OCR ativado em hot standby. Ele pode assumir automaticamente se a fonte DOM perder saúde."
                        : "Captura ativada. Calibre somente a área do histórico para habilitar o hot standby OCR.",
                Toast.LENGTH_LONG).show();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this,14),Ui.dp(this,9),Ui.dp(this,14),Ui.dp(this,7));
        TextView brand = Ui.text(this,"AURUM AI 37",22,Ui.GREEN,true);
        TextView lab = Ui.text(this,"  INTEGRATED",11,Ui.AMBER,true);
        liveBadge = Ui.text(this,"● AGUARDANDO INÍCIO",11,Ui.AMBER,true);
        top.addView(brand); top.addView(lab,new LinearLayout.LayoutParams(0,-2,1)); top.addView(liveBadge);
        root.addView(top);

        LinearLayout address = new LinearLayout(this);
        address.setPadding(Ui.dp(this,10),0,Ui.dp(this,10),Ui.dp(this,6));
        urlInput = new EditText(this);
        urlInput.setHint("https://..."); urlInput.setSingleLine(true); urlInput.setTextColor(Ui.TEXT); urlInput.setHintTextColor(Ui.MUTED);
        urlInput.setTextSize(12); urlInput.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        Button open = Ui.button(this,"Abrir",Ui.AMBER,Color.BLACK);
        Button reload = Ui.button(this,"↻",Ui.SURFACE,Ui.TEXT);
        address.addView(urlInput,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));
        address.addView(open,new LinearLayout.LayoutParams(Ui.dp(this,76),Ui.dp(this,44)));
        address.addView(reload,new LinearLayout.LayoutParams(Ui.dp(this,50),Ui.dp(this,44)));
        root.addView(address);
        pageProgress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        pageProgress.setMax(100); pageProgress.setVisibility(View.GONE);
        root.addView(pageProgress,new LinearLayout.LayoutParams(-1,Ui.dp(this,2)));

        webView = new WebView(this); webView.setBackgroundColor(Color.BLACK);
        root.addView(webView,new LinearLayout.LayoutParams(-1,Ui.dp(this,350)));

        ScrollView lowerScroll = new ScrollView(this); lowerScroll.setFillViewport(true);
        LinearLayout lower = new LinearLayout(this); lower.setOrientation(LinearLayout.VERTICAL);
        lower.setPadding(Ui.dp(this,12),Ui.dp(this,10),Ui.dp(this,12),Ui.dp(this,18));
        lowerScroll.addView(lower);

        // 1) Controle operacional imediatamente abaixo da roleta.
        LinearLayout controls = Ui.card(this);
        controls.addView(Ui.text(this,"CONTROLE DE LEITURA",13,Ui.MUTED,true));
        startReadingButton = Ui.button(this,"▶ INICIAR LEITURA",Ui.GREEN,Color.BLACK);
        finishButton = Ui.button(this,"■ FINALIZAR SESSÃO",Ui.SURFACE,Ui.TEXT); finishButton.setEnabled(false);
        newSessionButton = Ui.button(this,"NOVA SESSÃO",Ui.AMBER,Color.BLACK); newSessionButton.setVisibility(View.GONE);
        LinearLayout actionRow = new LinearLayout(this); actionRow.setOrientation(LinearLayout.HORIZONTAL);
        Button clear = Ui.button(this,"↻ LIMPAR",Ui.SURFACE,Ui.TEXT);
        Button correct = Ui.button(this,"✎ CORRIGIR",Ui.SURFACE,Ui.TEXT);
        Button manual = Ui.button(this,"+ GIRO MANUAL",Ui.SURFACE,Ui.TEXT);
        actionRow.addView(clear,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));
        actionRow.addView(correct,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));
        actionRow.addView(manual,new LinearLayout.LayoutParams(0,Ui.dp(this,46),1));
        controls.addView(startReadingButton,Ui.margins(-1,Ui.dp(this,52),this,0,8,0,0));
        controls.addView(finishButton,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        controls.addView(newSessionButton,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        controls.addView(actionRow,Ui.margins(-1,Ui.dp(this,46),this,0,6,0,0));
        lower.addView(controls,Ui.margins(-1,-2,this,0,0,0,10));

        // 2) Telemetria verificável.
        LinearLayout statusCard = Ui.card(this);
        LinearLayout statusHeader = new LinearLayout(this); statusHeader.setOrientation(LinearLayout.HORIZONTAL); statusHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView statusTitle = Ui.text(this,"STATUS OPERACIONAL",14,Ui.CYAN,true);
        activityText = Ui.text(this,"AGUARDANDO INÍCIO",11,Ui.MUTED,false); activityText.setGravity(Gravity.RIGHT);
        statusHeader.addView(statusTitle,new LinearLayout.LayoutParams(0,-2,1)); statusHeader.addView(activityText,new LinearLayout.LayoutParams(0,-2,1));
        statusCard.addView(statusHeader);
        pipelinePulse = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        pipelinePulse.setIndeterminate(true);
        pipelinePulse.setVisibility(View.INVISIBLE);
        pipelineText = Ui.text(this,"CAPTURA — → VALIDAÇÃO — → HISTÓRICO — → CORE — → ANÁLISE —",12,Ui.TEXT,true);
        scannerText = Ui.text(this,"DOM: DISCOVERY\nOCR: STANDBY\nCORE: 0",12,Ui.TEXT,false);
        captureStatusText = Ui.text(this,"OCR • STANDBY",12,Ui.MUTED,false);
        contextText = Ui.text(this,"CONTEXTO: —",11,Ui.MUTED,false);
        statusCard.addView(pipelinePulse,Ui.margins(-1,Ui.dp(this,7),this,0,7,0,0));
        statusCard.addView(pipelineText,Ui.margins(-1,-2,this,0,8,0,0));
        statusCard.addView(scannerText,Ui.margins(-1,-2,this,0,6,0,0));
        statusCard.addView(captureStatusText,Ui.margins(-1,-2,this,0,4,0,0));
        statusCard.addView(contextText,Ui.margins(-1,-2,this,0,4,0,0));
        lower.addView(statusCard,Ui.margins(-1,-2,this,0,0,0,10));

        // 3) Radar imediatamente antes do sinal.
        LinearLayout radar = Ui.card(this);
        radar.addView(Ui.text(this,"RADAR DE CONFLUÊNCIA",14,Ui.CYAN,true));
        confluenceBar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        confluenceBar.setMax(FAMILY_COUNT); confluenceBar.setProgress(0);
        confluenceText = Ui.text(this,"LENDO • 0/"+FAMILY_COUNT+" famílias",13,Ui.CYAN,true);
        analysisPulseText = Ui.text(this,"Scanner aguardando sessão",11,Ui.MUTED,false);
        radarPulse = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        radarPulse.setIndeterminate(true);
        radarPulse.setVisibility(View.INVISIBLE);
        radar.addView(confluenceBar,Ui.margins(-1,Ui.dp(this,10),this,0,8,0,0));
        radar.addView(confluenceText,Ui.margins(-1,-2,this,0,6,0,0));
        radar.addView(radarPulse,Ui.margins(-1,Ui.dp(this,5),this,0,4,0,0));
        radar.addView(analysisPulseText,Ui.margins(-1,-2,this,0,4,0,0));
        lower.addView(radar,Ui.margins(-1,-2,this,0,0,0,10));

        // 4) Sinal grande e evidente.
        LinearLayout hero = Ui.card(this);
        signalTitle = Ui.text(this,"SINAL • PRECISION",13,Ui.CYAN,true);
        signalTarget = Ui.text(this,"AGUARDANDO INÍCIO",30,Ui.TEXT,true);
        signalMeta = Ui.text(this,"Nenhum resultado entra no CORE antes de iniciar a leitura.",13,Ui.MUTED,false);
        secondaryText = Ui.text(this,"",12,Ui.AMBER,true); secondaryText.setVisibility(View.GONE);
        hero.addView(signalTitle); hero.addView(signalTarget); hero.addView(signalMeta); hero.addView(secondaryText);
        lower.addView(hero,Ui.margins(-1,-2,this,0,0,0,10));

        // 5) Histórico confirmado.
        LinearLayout historyCard=Ui.card(this);
        historyCard.addView(Ui.text(this,"HISTÓRICO CONFIRMADO",13,Ui.MUTED,true));
        historyPreviewText=Ui.text(this,"Últimos: —",12,Ui.TEXT,false);
        historyCard.addView(historyPreviewText,Ui.margins(-1,-2,this,0,6,0,0));
        lower.addView(historyCard,Ui.margins(-1,-2,this,0,0,0,10));

        // 6) Sessão.
        LinearLayout sessionCard=Ui.card(this);
        sessionCard.addView(Ui.text(this,"SESSÃO",14,Ui.AMBER,true));
        sessionText=Ui.text(this,"Sinais 0 • STRIKE 0 • LOSS 0",13,Ui.TEXT,true);
        sessionCard.addView(sessionText,Ui.margins(-1,-2,this,0,6,0,0));
        lower.addView(sessionCard,Ui.margins(-1,-2,this,0,0,0,10));

        // 7) Ferramentas secundárias.
        LinearLayout tools = Ui.card(this);
        tools.addView(Ui.text(this,"FERRAMENTAS / DIAGNÓSTICO",12,Ui.MUTED,true));
        balancedSwitch = new Switch(this); balancedSwitch.setText("Balanced calibrado"); balancedSwitch.setTextColor(Ui.TEXT);
        scanToggle = Ui.button(this,"↻ RELOCALIZAR DOM",Ui.CYAN,Color.BLACK);
        Button visualCaptureButton = Ui.button(this,"ATIVAR CAPTURA / OCR",Ui.GREEN,Color.BLACK);
        Button calibrateButton = Ui.button(this,"Calibrar ROI dos resultados",Ui.AMBER,Color.BLACK);
        Button rayOpen = Ui.button(this,"Abrir Raio-X completo",Ui.SURFACE,Ui.TEXT);
        Button stableTools = Ui.button(this,"Abrir ferramentas Stable",Ui.SURFACE,Ui.TEXT);
        sourceText=Ui.text(this,"FONTE: nenhuma confirmada",11,Ui.MUTED,false);
        rayText=Ui.text(this,"Raio-X aguardando análise.",11,Ui.MUTED,false);
        tools.addView(balancedSwitch); tools.addView(scanToggle,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(visualCaptureButton,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(calibrateButton,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(rayOpen,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(stableTools,Ui.margins(-1,Ui.dp(this,46),this,0,5,0,0));
        tools.addView(sourceText,Ui.margins(-1,-2,this,0,6,0,0)); tools.addView(rayText,Ui.margins(-1,-2,this,0,4,0,0));
        lower.addView(tools);

        TextView footer=Ui.text(this,"Aurum Integrated • pipeline único • DOM + OCR reconciliados • CORE preservado",11,Ui.MUTED,true);
        footer.setGravity(Gravity.CENTER); lower.addView(footer,Ui.margins(-1,-2,this,0,14,0,0));
        root.addView(lowerScroll,new LinearLayout.LayoutParams(-1,0,1));

        open.setOnClickListener(v -> openEnteredUrl());
        reload.setOnClickListener(v -> webView.reload());
        startReadingButton.setOnClickListener(v -> startReading());
        finishButton.setOnClickListener(v -> finishSession());
        newSessionButton.setOnClickListener(v -> newSession());
        clear.setOnClickListener(v -> clearOperationalHistory());
        correct.setOnClickListener(v -> showCorrectionDialog());
        manual.setOnClickListener(v -> showNumberDialog("GIRO MANUAL", -1, n -> addManualSpin(n)));
        balancedSwitch.setOnCheckedChangeListener((b,checked) -> { bridge.setPrecision(!checked); signalTitle.setText("SINAL • "+(checked?"BALANCED":"PRECISION")); });
        scanToggle.setOnClickListener(v -> forceDomRediscovery());
        visualCaptureButton.setOnClickListener(v -> requestVisualCapture());
        calibrateButton.setOnClickListener(v -> openCalibration());
        rayOpen.setOnClickListener(v -> showFullRayX());
        stableTools.setOnClickListener(v -> {
            if (readingActive) {
                Toast.makeText(this,"Finalize a sessão Integrated antes de abrir as ferramentas Stable. O motor paralelo fica bloqueado durante a leitura.",Toast.LENGTH_LONG).show();
                return;
            }
            startActivity(new Intent(this,MainActivity.class));
        });
        return root;
    }

    private void configureWebView() {
        BrowserSecurityPolicy.apply(webView);
        CookieManager cm=CookieManager.getInstance(); cm.setAcceptCookie(true); cm.setAcceptThirdPartyCookies(webView,true);
        webView.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView view,int newProgress){pageProgress.setProgress(newProgress);pageProgress.setVisibility(newProgress>=100?View.GONE:View.VISIBLE);}});
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){Uri u=req.getUrl();if(!BrowserSecurityPolicy.isAllowed(u)){Toast.makeText(IntegratedActivity.this,"Link externo bloqueado.",Toast.LENGTH_SHORT).show();return true;}return false;}
            @Override public void onPageFinished(WebView view,String url){
                if(url==null)return; urlInput.setText(BrowserSecurityPolicy.sanitize(url)); persistLastUrl(url); CookieManager.getInstance().flush();
                String host=hostOf(url); if(!host.equals(currentHost)){currentHost=host;lockedDomSignature=DomSourceMemory.load(IntegratedActivity.this,host);domState=lockedDomSignature.isEmpty()?DomState.DISCOVERY:DomState.LOCKED;domLockFailures=0;domDiscoveryFailures=0;lastDomFingerprint="";lastDomObserved=new ArrayList<>();domOrderTracker.reset();}
                discoverPage();
            }
        });
        String saved=browserPrefs().getString(LAST_URL,"");
        if(saved!=null&&!saved.trim().isEmpty()&&BrowserSecurityPolicy.isAllowed(Uri.parse(saved))){urlInput.setText(BrowserSecurityPolicy.sanitize(saved));webView.loadUrl(saved);}else webView.loadUrl("about:blank");
    }

    private SharedPreferences browserPrefs(){return getSharedPreferences(BROWSER_PREFS,MODE_PRIVATE);}
    private void persistLastUrl(String raw){try{Uri u=Uri.parse(raw);if(!BrowserSecurityPolicy.isAllowed(u)||"about".equalsIgnoreCase(u.getScheme()))return;String safe=BrowserSecurityPolicy.sanitize(raw);if(safe.startsWith("http://")||safe.startsWith("https://"))browserPrefs().edit().putString(LAST_URL,safe).apply();}catch(RuntimeException ignored){}}
    private static String hostOf(String raw){try{String h=Uri.parse(raw).getHost();return h==null?"":h;}catch(RuntimeException e){return "";}}

    private void openEnteredUrl(){String raw=urlInput.getText().toString().trim();if(raw.isEmpty())return;if(!raw.contains("://"))raw="https://"+raw;Uri u=Uri.parse(raw);if(!BrowserSecurityPolicy.isAllowed(u)){Toast.makeText(this,"Use endereço http/https.",Toast.LENGTH_SHORT).show();return;}persistLastUrl(raw);webView.loadUrl(raw);}

    private void startReading(){
        if(readingActive)return;
        boolean resuming=IntegratedSessionStore.startedAt(this)>0&&!IntegratedSessionStore.finished(this);
        if(!resuming)IntegratedSessionStore.startNew(this,webView==null?"":webView.getUrl());
        readingActive=true;
        scannerRunning=true;
        ocrFallbackActive=false;
        incrementalSourceMode=false;
        initialBootstrapPending=true;
        standbyProgressHits=0;
        domStabilizer=new ScanStabilizer();
        ocrStabilizer=new ScanStabilizer();
        lastDomStableObserved=new ArrayList<>();lastDomObserved=new ArrayList<>();lastDomStableAt=0L;
        lastOcrStableObserved=new ArrayList<>();lastOcrObserved=new ArrayList<>();lastOcrStableAt=0L;
        domQualityFailures=0;domConsensusFailures=0;domQuarantineUntil=0L;
        lastAcceptedSource="—";
        lastDataAt=0;
        pipeline.start(System.currentTimeMillis());
        startReadingButton.setText("✓ LEITURA ATIVA");
        startReadingButton.setEnabled(false);
        finishButton.setEnabled(true);
        newSessionButton.setVisibility(View.GONE);
        pipelinePulse.setVisibility(View.VISIBLE);
        radarPulse.setVisibility(View.VISIBLE);

        List<Integer> saved=IntegratedSessionStore.loadOperationalHistory(this);
        if(resuming&&!saved.isEmpty()&&bridge.historySize()==0){
            // Restaura a sessão para não perder placar/histórico, mas NÃO pula o bootstrap.
            // A fonte visível precisa ser reconciliada antes de voltar ao TRACKING.
            renderBridge(bridge.replaceBootstrap(saved),"SESSÃO RESTAURADA • CONFIRMANDO FONTE");
            initialBootstrapPending=true;
        }
        syncFromVisualHistory();
        discoverPage();
        attemptBootstrapOrActivation();
        ensureIntegratedCaptureMode();
        refreshTelemetryClock();
    }

    private void finishSession(){
        if(!readingActive&&IntegratedSessionStore.finished(this))return;
        readingActive=false;
        scannerRunning=false;
        ocrFallbackActive=false;
        pipeline.finish();
        pipelinePulse.setVisibility(View.INVISIBLE);
        radarPulse.setVisibility(View.INVISIBLE);
        String summary=IntegratedSessionStore.finish(this,bridge.historySize());
        startReadingButton.setText("SESSÃO FINALIZADA");
        startReadingButton.setEnabled(false);
        finishButton.setEnabled(false);
        newSessionButton.setVisibility(View.VISIBLE);
        Toast.makeText(this,summary,Toast.LENGTH_LONG).show();
        refreshSession();
        refreshTelemetryClock();
    }

    private void newSession(){
        bridge.clearOperational();
        manualEchoReconciler.clear();
        lastVerdict=null;
        IntegratedSessionStore.startNew(this,webView==null?"":webView.getUrl());
        IntegratedSessionStore.saveOperationalHistory(this,Collections.emptyList());
        readingActive=false;
        scannerRunning=true;
        incrementalSourceMode=false;
        initialBootstrapPending=true;
        lastAcceptedSource="—";
        lastDataAt=0;
        standbyProgressHits=0;
        domOrderTracker.reset();
        domStabilizer=new ScanStabilizer();
        lastDomObserved=new ArrayList<>();lastDomStableObserved=new ArrayList<>();lastDomStableAt=0L;
        domQualityFailures=0;domConsensusFailures=0;domQuarantineUntil=0L;
        ocrOrderTracker.reset();
        ocrStabilizer=new ScanStabilizer();
        lastOcrObserved=new ArrayList<>();
        lastOcrStableObserved=new ArrayList<>();
        lastOcrStableAt=0L;
        lastOcrFingerprint="";
        pipeline.idle();
        startReadingButton.setText("▶ INICIAR LEITURA");
        startReadingButton.setEnabled(true);
        finishButton.setEnabled(false);
        newSessionButton.setVisibility(View.GONE);
        pipelinePulse.setVisibility(View.INVISIBLE);
        radarPulse.setVisibility(View.INVISIBLE);
        resetSignalUi("AGUARDANDO INÍCIO","Nova sessão pronta. Ao iniciar, a Aurum fará uma varredura completa do histórico visível antes de acompanhar os próximos giros.");
        refreshSession();
        refreshTelemetryClock();
    }

    private void clearOperationalHistory(){
        if(!readingActive){Toast.makeText(this,"Inicie a leitura para limpar a sessão operacional.",Toast.LENGTH_SHORT).show();return;}
        renderBridge(bridge.clearOperational(),"CONTROLE");
        manualEchoReconciler.clear();
        IntegratedSessionStore.saveOperationalHistory(this,Collections.emptyList());
        incrementalSourceMode=false;
        initialBootstrapPending=true;
        lastVerdict=null;
        lastDataAt=0;
        standbyProgressHits=0;

        // Clear means a true source resynchronization, not merely emptying CORE. The old DOM
        // signature is invalidated so a bad region cannot immediately refill the same garbage.
        if(!currentHost.isEmpty())DomSourceMemory.invalidate(this,currentHost,AppStateStore.provider(this));
        lockedDomSignature="";pendingDomSignature="";pendingDomSignatureHits=0;
        domState=DomState.DISCOVERY;domLockFailures=0;domDiscoveryFailures=0;
        domStabilizer=new ScanStabilizer();domOrderTracker.reset();lastDomObserved=new ArrayList<>();lastDomStableObserved=new ArrayList<>();lastDomStableAt=0L;
        domQualityFailures=0;domConsensusFailures=0;domQuarantineUntil=0L;domQualityReason="ressincronizando";
        ocrStabilizer=new ScanStabilizer();ocrOrderTracker.reset();lastOcrObserved=new ArrayList<>();lastOcrStableObserved=new ArrayList<>();lastOcrStableAt=0L;
        pipeline.resetToBootstrap(System.currentTimeMillis());
        resetSignalUi("RESSINCRONIZANDO","Histórico operacional zerado. Validando novamente a região DOM e a ROI OCR antes de alimentar o CORE.");
        syncFromVisualHistory();
        discoverPage();
        refreshSession();
    }

    private void showCorrectionDialog(){
        if(!readingActive){Toast.makeText(this,"Inicie a leitura antes de corrigir giros.",Toast.LENGTH_SHORT).show();return;}
        if(bridge.historySize()==0){Toast.makeText(this,"Histórico vazio.",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(this).setTitle("CORRIGIR GIRO").setItems(new String[]{"Substituir último giro","Remover último giro"},(d,which)->{
            int before=bridge.historySize();
            if(which==0)showNumberDialog("SUBSTITUIR ÚLTIMO GIRO",bridge.historySnapshot().get(0),n->{IntegratedSessionStore.rollbackLatestResolutionIfAtSpin(this,before);renderBridge(bridge.replaceLatest(n),"CORREÇÃO");afterManualOrCorrection();});
            else {IntegratedSessionStore.rollbackLatestResolutionIfAtSpin(this,before);renderBridge(bridge.removeLatest(),"CORREÇÃO");afterManualOrCorrection();}
        }).setNegativeButton("Cancelar",null).show();
    }

    private interface NumberConsumer{void accept(int number);}
    private void showNumberDialog(String title,int current,NumberConsumer consumer){
        EditText input=new EditText(this); input.setInputType(InputType.TYPE_CLASS_NUMBER); input.setHint("0–36"); if(current>=0)input.setText(String.valueOf(current));
        new AlertDialog.Builder(this).setTitle(title).setView(input).setPositiveButton("Confirmar",(d,w)->{try{int n=Integer.parseInt(input.getText().toString().trim());if(n<0||n>36)throw new NumberFormatException();consumer.accept(n);}catch(NumberFormatException e){Toast.makeText(this,"Digite um número de 0 a 36.",Toast.LENGTH_SHORT).show();}}).setNegativeButton("Cancelar",null).show();
    }

    private void addManualSpin(int n){if(!readingActive){Toast.makeText(this,"Inicie a leitura antes de inserir giro manual.",Toast.LENGTH_SHORT).show();return;}manualEchoReconciler.record(n);renderBridge(bridge.prependManual(n),"MANUAL");afterManualOrCorrection();}
    private void afterManualOrCorrection(){
        incrementalSourceMode=true;
        initialBootstrapPending=false;
        // A partir daqui a fonte precisa avançar antes de poder acrescentar algo ao CORE.
        // Isso impede que um snapshot atrasado desfaça a correção/manual.
        IntegratedSessionStore.saveOperationalHistory(this,bridge.historySnapshot());
        refreshHistoryPreview();
        refreshSession();
    }

    @SuppressWarnings("deprecation") private void requestVisualCapture(){MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(manager.createScreenCaptureIntent(),REQUEST_CAPTURE);}

    /** Garante que uma captura já existente deixe de executar o motor Stable em paralelo. */
    private void ensureIntegratedCaptureMode(){
        if(AppStateStore.captureActive(this)){
            Intent mode=new Intent(this,ScreenCaptureService.class)
                    .setAction(ScreenCaptureService.ACTION_START)
                    .putExtra(ScreenCaptureService.EXTRA_PIPELINE_MODE,ScreenCaptureService.MODE_INTEGRATED_SOURCE_ONLY);
            startForegroundService(mode);
            return;
        }
        // Depois que a ROI foi calibrada uma vez, iniciar leitura já pede a autorização
        // de captura para deixar o OCR em hot standby sem outro botão operacional.
        if(AppStateStore.isCalibrated(this))requestVisualCapture();
    }

    private void openCalibration(){if(!CaptureRepository.hasLatest()){Toast.makeText(this,"Ative primeiro a captura visual e depois calibre somente o histórico.",Toast.LENGTH_LONG).show();requestVisualCapture();return;}startActivity(new Intent(this,CalibrationActivity.class));}
    private void registerStateReceiver(){IntentFilter filter=new IntentFilter(MainActivity.ACTION_STATE_UPDATED);if(Build.VERSION.SDK_INT>=33)registerReceiver(stateReceiver,filter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(stateReceiver,filter);receiverRegistered=true;}

    private void discoverPage(){
        if(webView==null)return;
        lastScanAttemptAt=System.currentTimeMillis();
        scanAttempts++;
        webView.evaluateJavascript(SourceHunter.discoveryScript(lockedDomSignature),value->{
            try{
                JSONObject o=new JSONObject(decodeJsString(value));
                JSONArray a=o.optJSONArray("history");
                List<Integer> raw=new ArrayList<>();
                if(a!=null)for(int i=0;i<a.length();i++)raw.add(a.optInt(i,-1));
                currentResult=o.optInt("currentResult",-1);
                SourceOrderTracker.Order beforeOrder=domOrderTracker.order();
                SourceOrderTracker.Order learnedOrder=domOrderTracker.observe(raw,currentResult);
                List<Integer> history=normalizer.normalize(domOrderTracker.normalize(raw),true);
                domHistoryCount=history.size();
                boolean orderJustLearned=beforeOrder==SourceOrderTracker.Order.UNKNOWN&&learnedOrder!=SourceOrderTracker.Order.UNKNOWN;
                accessibleFrames=o.optInt("accessibleFrames",0);
                blockedFrames=o.optInt("blockedFrames",0);
                domConfidence=o.optInt("confidence",0);
                domHint=o.optString("hint","");
                domExtractionMode=o.optString("extractionMode","NONE");
                int structureScore=o.optInt("structureScore",0);
                String pageUrl=o.optString("url",webView.getUrl());
                String title=o.optString("title","");
                String signature=o.optString("signature","");
                String classification=o.optString("classification","");
                boolean lockMatched=o.optBoolean("lockMatched",false);
                int iframes=o.optInt("iframes",0);
                String host=hostOf(pageUrl);
                if(!host.equals(currentHost)){
                    currentHost=host;
                    lockedDomSignature=DomSourceMemory.load(this,host);
                    domState=lockedDomSignature.isEmpty()?DomState.DISCOVERY:DomState.LOCKED;
                    domLockFailures=0;domDiscoveryFailures=0;pendingDomSignature="";pendingDomSignatureHits=0;
                    lastDomFingerprint="";lastDomObserved=new ArrayList<>();lastDomStableObserved=new ArrayList<>();lastDomStableAt=0L;
                    domStabilizer=new ScanStabilizer();domOrderTracker.reset();domQualityFailures=0;domConsensusFailures=0;domQuarantineUntil=0L;
                    pipeline.invalidateDom();
                }

                HistoryQualityGate.Assessment quality=HistoryQualityGate.assess(
                        history,currentResult,domConfidence,"CELLS".equals(domExtractionMode),structureScore);
                domQualityScore=quality.score;
                domQualityReason=quality.reason;
                domSemanticHistory="HISTORY".equals(classification)&&quality.accepted;

                parseContext(o.optJSONObject("context"));
                EnvironmentScanner.Snapshot env=environmentScanner.inspect(pageUrl,title,iframes,history.size(),domHint,accessibleFrames,blockedFrames);
                updateDomState(history,signature,classification,lockMatched,host,env.provider);
                renderEnvironment(env);

                long now=System.currentTimeMillis();
                boolean quarantined=now<domQuarantineUntil;
                List<Integer> previousStable=new ArrayList<>(lastDomStableObserved);
                boolean stableEvent=false;
                if(domSemanticHistory&&!quarantined&&domStabilizer.accept(history)){
                    stableEvent=true;
                    lastDomStableObserved=new ArrayList<>(history);
                    lastDomObserved=new ArrayList<>(history);
                    lastDomStableAt=now;
                    lastDomFingerprint=normalizer.fingerprint(history);
                }

                boolean ocrFresh=pipeline.ocrHealthy(now)&&lastOcrStableObserved.size()>=ReadingPipelineController.MIN_HISTORY;
                domOcrAgreement=(ocrFresh&&!lastDomStableObserved.isEmpty())
                        ?HistoryAgreement.score(lastDomStableObserved,lastOcrStableObserved):1.0;
                boolean consensusOk=!ocrFresh||domOcrAgreement>=DOM_OCR_MIN_AGREEMENT;

                boolean domCandidatePresent="HISTORY".equals(classification)&&history.size()>=ReadingPipelineController.MIN_HISTORY;
                if(domCandidatePresent&&!quality.accepted&&!quarantined)domQualityFailures++;
                else if(quality.accepted)domQualityFailures=0;
                if(stableEvent&&ocrFresh){
                    if(domOcrAgreement<0.58)domConsensusFailures++;
                    else if(domOcrAgreement>=DOM_OCR_MIN_AGREEMENT)domConsensusFailures=0;
                }

                if(!quarantined&&(domQualityFailures>=3||domConsensusFailures>=2)){
                    String why=domQualityFailures>=3?quality.reason:"DOM/OCR divergiram";
                    quarantineDom(why);
                    quarantined=true;
                    consensusOk=false;
                }

                boolean healthy=domState==DomState.TRACKING&&domSemanticHistory&&!quarantined
                        &&!lastDomStableObserved.isEmpty()&&now-lastDomStableAt<=ReadingPipelineController.HEALTH_STALE_MS
                        &&consensusOk;
                if(healthy)lastDomHealthyAt=now;
                pipeline.observeDom(healthy,healthy?lastDomStableObserved.size():history.size(),now);

                // Orientation may be learned after the first stable snapshots. We never rewrite the
                // CORE from a transient scan; the new orientation must stabilize and reconcile again.
                if(orderJustLearned){
                    domStabilizer=new ScanStabilizer();
                    lastDomStableObserved=new ArrayList<>();
                    lastDomObserved=new ArrayList<>();
                    lastDomStableAt=0L;
                    pipeline.invalidateDom();
                }else if(stableEvent&&healthy){
                    processDomHistory(lastDomStableObserved,previousStable);
                }

                attemptBootstrapOrActivation();
                watchdogPipeline();
                refreshTelemetryClock();
            }catch(Exception error){
                domDiscoveryFailures++;
                if(domDiscoveryFailures>=3&&blockedFrames>0)domState=DomState.BLOCKED;
                pipeline.observeDom(false,domHistoryCount,System.currentTimeMillis());
                watchdogPipeline();
                refreshTelemetryClock();
            }
        });
    }

    private void updateDomState(List<Integer> history,String signature,String classification,boolean lockMatched,String host,String provider){
        boolean semantic=domSemanticHistory&&"HISTORY".equals(classification)&&history.size()>=ReadingPipelineController.MIN_HISTORY;
        if(lockedDomSignature.isEmpty()){
            if(semantic&&domConfidence>=DOM_LOCK_CONFIDENCE&&!signature.isEmpty()){
                lockedDomSignature=signature;
                DomSourceMemory.save(this,host,provider,signature);
                domState=DomState.LOCKED;
                domLockFailures=0;
                domDiscoveryFailures=0;
                pendingDomSignature="";
                pendingDomSignatureHits=0;
            }else{
                domDiscoveryFailures++;
                domState=(domDiscoveryFailures>=3&&blockedFrames>0)?DomState.BLOCKED:DomState.DISCOVERY;
            }
            return;
        }
        if(lockMatched&&semantic&&domConfidence>=DOM_TRACK_CONFIDENCE&&signature.equals(lockedDomSignature)){
            domLockFailures=0;
            domDiscoveryFailures=0;
            pendingDomSignature="";
            pendingDomSignatureHits=0;
            domState=DomState.TRACKING;
            evidenceGraph.upsert("dom-history","DOM_HISTORY",domConfidence/100.0,normalizer.fingerprint(history),"current-history");
            return;
        }

        // A DOM de cassinos costuma trocar classes/ids durante a sessão. Em vez de
        // derrubar o lock após duas oscilações, exige repetição do novo candidato e
        // faz relock automático sem interromper o CORE.
        if(semantic&&domConfidence>=DOM_LOCK_CONFIDENCE&&!signature.isEmpty()){
            if(signature.equals(pendingDomSignature))pendingDomSignatureHits++;
            else{pendingDomSignature=signature;pendingDomSignatureHits=1;}
            domLockFailures++;
            if(pendingDomSignatureHits>=DOM_RELOCK_HITS){
                lockedDomSignature=signature;
                DomSourceMemory.save(this,host,provider,signature);
                domState=DomState.TRACKING;
                domLockFailures=0;
                domDiscoveryFailures=0;
                pendingDomSignature="";
                pendingDomSignatureHits=0;
                evidenceGraph.upsert("dom-history","DOM_HISTORY",domConfidence/100.0,normalizer.fingerprint(history),"current-history");
                return;
            }
            domState=DomState.LOCKED;
            return;
        }

        domLockFailures++;
        if(domLockFailures>=DOM_LOCK_FAILURE_LIMIT){
            DomSourceMemory.invalidate(this,host,provider);
            lockedDomSignature="";
            domState=(blockedFrames>0)?DomState.BLOCKED:DomState.DISCOVERY;
            domLockFailures=0;
            domDiscoveryFailures=0;
            pendingDomSignature="";
            pendingDomSignatureHits=0;
            lastDomFingerprint="";
        }else domState=DomState.LOCKED;
    }

    private void processDomHistory(List<Integer> history,List<Integer> previous){
        if(history==null||history.size()<ReadingPipelineController.MIN_HISTORY)return;
        lastDomObserved=new ArrayList<>(history);
        lastDomFingerprint=normalizer.fingerprint(history);
        if(!readingActive)return;
        if(initialBootstrapPending){attemptBootstrapOrActivation();return;}
        if(pipeline.activeSource()!=ReadingPipelineController.Source.DOM)return;
        ocrFallbackActive=false;
        acceptTrackingDelta("DOM",history,previous);
    }

    private void syncFromVisualHistory(){
        long now=System.currentTimeMillis();
        List<Integer> rawVisual=new ArrayList<>(CaptureRepository.getLatestNumbers());
        boolean inMemory=!rawVisual.isEmpty();
        if(rawVisual.isEmpty())rawVisual=AppStateStore.loadOcrSnapshot(this);

        long observedAt=inMemory?CaptureRepository.latestNumbersAt():AppStateStore.ocrSnapshotAt(this);
        lastOcrScanCount=inMemory?CaptureRepository.ocrScanCount():AppStateStore.ocrScanCount(this);

        // OCR é uma fonte própria da Integrated. Nunca usa o histórico global da tela Stable.
        ocrOrderTracker.observe(rawVisual,currentResult);
        List<Integer> visual=normalizer.normalize(ocrOrderTracker.normalize(rawVisual),true);
        lastOcrObserved=new ArrayList<>(visual);
        ocrHistoryCount=visual.size();

        boolean captureHeartbeat=AppStateStore.captureActive(this)
                &&AppStateStore.isCalibrated(this)
                &&visual.size()>=ReadingPipelineController.MIN_HISTORY
                &&observedAt>0
                &&now-observedAt<=ReadingPipelineController.HEALTH_STALE_MS;

        List<Integer> previousStable=new ArrayList<>(lastOcrStableObserved);
        boolean stableEvent=false;
        if(captureHeartbeat&&ocrStabilizer.accept(visual)){
            stableEvent=true;
            lastOcrStableObserved=new ArrayList<>(visual);
            lastOcrStableAt=observedAt;
            lastOcrFingerprint=normalizer.fingerprint(visual);
            evidenceGraph.upsert("ocr-history","VISUAL_OCR",0.90,lastOcrFingerprint,"current-history");
        }

        boolean healthy=captureHeartbeat&&!lastOcrStableObserved.isEmpty();
        if(healthy)lastOcrHealthyAt=observedAt;
        pipeline.observeOcr(healthy,healthy?lastOcrStableObserved.size():0,healthy?observedAt:now);
        ocrFallbackActive=readingActive&&pipeline.activeSource()==ReadingPipelineController.Source.OCR;

        if(!readingActive){refreshSourceLine();refreshHistoryPreview();refreshTelemetryClock();return;}
        if(initialBootstrapPending){attemptBootstrapOrActivation();return;}
        if(pipeline.activeSource()!=ReadingPipelineController.Source.OCR)return;
        if(!stableEvent)return;

        acceptTrackingDelta("OCR",lastOcrStableObserved,previousStable);
    }

    /**
     * TRACKING é incremental para qualquer fonte. Um snapshot ruim nunca substitui o CORE.
     * Se o delta não puder ser provado, a leitura é preservada e o watchdog/standby ganha
     * a oportunidade de assumir no próximo ciclo.
     */
    private void acceptTrackingDelta(String label,List<Integer> current,List<Integer> previous){
        if(current==null||previous==null||current.size()<ReadingPipelineController.MIN_HISTORY
                ||previous.size()<ReadingPipelineController.MIN_HISTORY)return;
        SourceDelta.Result d=SourceDelta.between(current,previous);
        if(!d.valid){
            signalMeta.setText(label+" oscilou; snapshot descartado sem alterar o CORE • aguardando confirmação");
            refreshTelemetryClock();
            return;
        }
        if(d.newestFirst.isEmpty())return;
        List<Integer> fresh=manualEchoReconciler.suppress(d.newestFirst);
        if(fresh.isEmpty())return;
        renderBridge(bridge.acceptIncremental(fresh),label);
        // Depois que a fonte realmente avançou, a proteção de correção/manual pode sair.
        incrementalSourceMode=false;
    }

    private void updateOcrFallbackState(){
        ocrFallbackActive=readingActive&&pipeline.activeSource()==ReadingPipelineController.Source.OCR;
        refreshCaptureStatus();
    }

    private boolean ocrFallbackEligible(){
        return readingActive&&pipeline.ocrHealthy(System.currentTimeMillis());
    }

    private void attemptBootstrapOrActivation(){
        if(!readingActive)return;
        if(!initialBootstrapPending&&pipeline.activeSource()!=ReadingPipelineController.Source.NONE)return;
        long now=System.currentTimeMillis();
        ReadingPipelineController.Source source=pipeline.chooseBootstrap(now);
        if(source==ReadingPipelineController.Source.NONE)return;
        activateSource(source,initialBootstrapPending||bridge.historySize()==0,"AUTO");
    }

    /**
     * Só confirma a troca de fonte depois que o snapshot foi aceito/reconciliado pelo histórico.
     * Assim uma fonte ruim não pode "roubar" o pipeline e deixá-lo parado.
     */
    private void activateSource(ReadingPipelineController.Source source,boolean bootstrap,String reason){
        if(source==null||source==ReadingPipelineController.Source.NONE)return;
        List<Integer> snapshot=source==ReadingPipelineController.Source.DOM
                ?new ArrayList<>(lastDomObserved):new ArrayList<>(lastOcrStableObserved);
        if(snapshot.size()<ReadingPipelineController.MIN_HISTORY)return;
        String label=source==ReadingPipelineController.Source.DOM?"DOM":"OCR";
        long now=System.currentTimeMillis();

        if(bootstrap){
            IntegratedSignalBridge.Result result=bridge.historySize()<6
                    ?bridge.replaceBootstrap(snapshot):bridge.acceptScan(snapshot);
            if(!result.accepted){
                signalMeta.setText(label+" encontrado, mas o bootstrap ainda não reconciliou • "+result.message);
                refreshTelemetryClock();
                return;
            }
            pipeline.confirmSource(source,now);
            ocrFallbackActive=source==ReadingPipelineController.Source.OCR;
            renderBridge(result,label+" • BOOTSTRAP COMPLETO");
            initialBootstrapPending=false;
            incrementalSourceMode=false;
            standbyProgressHits=0;
            return;
        }

        if(incrementalSourceMode){
            // Correção/manual ativa: troca a fonte, mas espera o próximo delta real para
            // não reintroduzir o valor que o usuário acabou de corrigir.
            pipeline.confirmSource(source,now);
            ocrFallbackActive=source==ReadingPipelineController.Source.OCR;
            signalMeta.setText(label+" assumiu a leitura • aguardando próximo giro para reconciliar a correção");
            refreshTelemetryClock();
            return;
        }

        // Failover também é reconciliado por delta. A nova fonte só assume se conseguir
        // provar que o snapshot atual pertence ao mesmo histórico confirmado do CORE.
        SourceDelta.Result delta=SourceDelta.between(snapshot,bridge.historySnapshot());
        if(!delta.valid){
            signalMeta.setText(label+" disponível, mas failover aguardando reconciliação segura do histórico");
            refreshTelemetryClock();
            return;
        }
        IntegratedSignalBridge.Result result=null;
        List<Integer> fresh=manualEchoReconciler.suppress(delta.newestFirst);
        if(!fresh.isEmpty())result=bridge.acceptIncremental(fresh);
        pipeline.confirmSource(source,now);
        ocrFallbackActive=source==ReadingPipelineController.Source.OCR;
        if(result!=null)renderBridge(result,label+" • "+reason);
        else {
            lastAcceptedSource=label+" • "+reason;
            signalMeta.setText(label+" assumiu a leitura com histórico reconciliado • CORE preservado");
            refreshTelemetryClock();
        }
    }

    private boolean snapshotHasProgress(List<Integer> snapshot){
        if(snapshot==null||snapshot.size()<ReadingPipelineController.MIN_HISTORY||bridge.historySize()<6)return false;
        SourceDelta.Result d=SourceDelta.between(snapshot,bridge.historySnapshot());
        return d.valid&&!d.newestFirst.isEmpty();
    }

    /**
     * Se o DOM continua dizendo "saudável" mas o OCR estável enxerga um giro que o CORE
     * ainda não recebeu, o hot standby assume. Isso resolve o travamento silencioso em que
     * a UI continuava ativa enquanto o histórico DOM parava de avançar.
     */
    private void promoteStandbyIfActiveStalled(){
        if(initialBootstrapPending){standbyProgressHits=0;return;}
        long now=System.currentTimeMillis();
        ReadingPipelineController.Source active=pipeline.activeSource();
        ReadingPipelineController.Source standby=ReadingPipelineController.Source.NONE;
        List<Integer> standbySnapshot=Collections.emptyList();

        if(active==ReadingPipelineController.Source.DOM&&pipeline.ocrHealthy(now)){
            standby=ReadingPipelineController.Source.OCR;
            standbySnapshot=lastOcrStableObserved;
        }else if(active==ReadingPipelineController.Source.OCR&&pipeline.domHealthy(now)){
            standby=ReadingPipelineController.Source.DOM;
            standbySnapshot=lastDomObserved;
        }else{
            standbyProgressHits=0;
            return;
        }

        // Se a fonte secundária já enxerga um giro que o CORE não recebeu, a fonte ativa
        // está funcionalmente atrasada mesmo que continue emitindo heartbeat. Exigimos duas
        // confirmações antes do failover para filtrar um frame transitório.
        if(!snapshotHasProgress(standbySnapshot)){standbyProgressHits=0;return;}
        standbyProgressHits++;
        if(standbyProgressHits>=2){
            activateSource(standby,false,"HOT STANDBY DETECTOU PROGRESSO");
            standbyProgressHits=0;
        }
    }

    private void watchdogPipeline(){
        if(!readingActive)return;
        long now=System.currentTimeMillis();
        promoteStandbyIfActiveStalled();
        ReadingPipelineController.Source action=pipeline.watchdog(now);
        if(action!=ReadingPipelineController.Source.NONE){
            boolean bootstrap=initialBootstrapPending||bridge.historySize()==0;
            activateSource(action,bootstrap,pipeline.phase()==ReadingPipelineController.Phase.RECOVERING?"RECUPERAÇÃO":"FAILOVER");
        }
        ocrFallbackActive=pipeline.activeSource()==ReadingPipelineController.Source.OCR;
        if(pipeline.phase()==ReadingPipelineController.Phase.RECOVERING
                &&now-lastScanAttemptAt>SCAN_MS*2){
            discoverPage();
        }
    }

    private void quarantineDom(String reason){
        long now=System.currentTimeMillis();
        domQuarantineUntil=now+DOM_QUARANTINE_MS;
        if(!currentHost.isEmpty())DomSourceMemory.invalidate(this,currentHost,AppStateStore.provider(this));
        lockedDomSignature="";
        pendingDomSignature="";
        pendingDomSignatureHits=0;
        domLockFailures=0;
        domDiscoveryFailures=0;
        domState=DomState.DISCOVERY;
        lastDomFingerprint="";
        lastDomObserved=new ArrayList<>();
        lastDomStableObserved=new ArrayList<>();
        lastDomStableAt=0L;
        domStabilizer=new ScanStabilizer();
        domOrderTracker.reset();
        domQualityFailures=0;
        domConsensusFailures=0;
        pipeline.invalidateDom();
        domQualityReason="quarentena: "+reason;
        if(readingActive&&pipeline.activeSource()==ReadingPipelineController.Source.DOM&&pipeline.ocrHealthy(now)){
            activateSource(ReadingPipelineController.Source.OCR,false,"DOM REJEITADO PELA VALIDAÇÃO");
        }
    }

    private void forceDomRediscovery(){
        if(!currentHost.isEmpty())DomSourceMemory.invalidate(this,currentHost,AppStateStore.provider(this));
        lockedDomSignature="";
        pendingDomSignature="";
        pendingDomSignatureHits=0;
        domLockFailures=0;
        domDiscoveryFailures=0;
        domState=DomState.DISCOVERY;
        lastDomFingerprint="";
        lastDomObserved=new ArrayList<>();
        lastDomStableObserved=new ArrayList<>();
        lastDomStableAt=0L;
        domStabilizer=new ScanStabilizer();
        domOrderTracker.reset();
        domQualityFailures=0;domConsensusFailures=0;domQuarantineUntil=0L;
        pipeline.invalidateDom();
        scannerRunning=true;
        watchdogPipeline();
        Toast.makeText(this,"DOM em redescoberta. A fonte ativa continuará no OCR se ele estiver saudável.",Toast.LENGTH_SHORT).show();
        discoverPage();
    }

    private void renderEnvironment(EnvironmentScanner.Snapshot s){if(s!=null&&!"Não definido".equals(s.provider))AppStateStore.setProvider(this,s.provider);refreshSourceLine();}

    private void renderBridge(IntegratedSignalBridge.Result r,String source){
        if(!r.accepted){
            signalMeta.setText(source+" • "+r.message+" • histórico preservado");
            refreshTelemetryClock();
            return;
        }
        analysisSerial++;
        lastAcceptedSource=source;
        lastDataAt=System.currentTimeMillis();
        SignalUpdate u=r.update;
        lastVerdict=r.verdict;
        IntegratedSessionStore.saveOperationalHistory(this,r.history);
        if(u!=null){
            int accent=accent(u.kind);
            signalTitle.setText("SINAL • "+(bridge.isPrecision()?"PRECISION":"BALANCED"));
            signalTitle.setTextColor(accent);
            signalTarget.setText(u.target>=0?(u.playLabel.isEmpty()?u.target+" + VIZINHOS":u.playLabel):u.headline);
            String score=lastVerdict==null?"—":String.valueOf(lastVerdict.aurumScore);
            String families=lastVerdict==null?"0":String.valueOf(lastVerdict.independentFamilies);
            signalMeta.setText("Fonte "+source+" • score interno "+score+"/100 • "+families+" famílias • "+r.message+" • "+r.history.size()+" giros");
            if(u.secondaryTarget>=0&&!u.secondaryCoverage.isEmpty()){
                secondaryText.setVisibility(View.VISIBLE);
                secondaryText.setText("SECONDARY • "+u.secondaryPlayLabel+" • score "+u.secondaryStrength);
            }else secondaryText.setVisibility(View.GONE);
            updateConfluence(lastVerdict);
            renderRayX(lastVerdict,u);
            trackSessionOutcome(u,r.history.size());
        }
        refreshHistoryPreview();
        refreshSession();
        refreshTelemetryClock();
    }

    private void trackSessionOutcome(SignalUpdate u,int coreSize){if(u==null)return;if(u.kind==SignalUpdate.Kind.ENTRY)IntegratedSessionStore.recordSignal(this);else if(u.kind==SignalUpdate.Kind.HIT||u.kind==SignalUpdate.Kind.SECONDARY_HIT)IntegratedSessionStore.recordStrike(this,coreSize);else if(u.kind==SignalUpdate.Kind.EXPIRED)IntegratedSessionStore.recordLoss(this,coreSize);}

    private void updateConfluence(ConfluenceVerdict v){
        if(v==null){confluenceBar.setProgress(0);confluenceText.setText("LENDO • 0/"+FAMILY_COUNT+" famílias");confluenceText.setTextColor(Ui.CYAN);return;}int families=Math.min(FAMILY_COUNT,v.independentFamilies);confluenceBar.setProgress(families);String phase;int color;
        switch(v.decision){case ENTRY:phase="SINAL";color=Ui.GREEN;break;case PREPARE:phase="PREPARAR";color=Ui.AMBER;break;case OBSERVE:phase="CONFLUÊNCIA";color=Ui.AMBER;break;default:phase="LENDO";color=Ui.CYAN;break;}confluenceText.setText(phase+" • "+families+"/"+FAMILY_COUNT+" famílias alinhadas");confluenceText.setTextColor(color);
    }

    private void refreshHistoryPreview(){List<Integer> h=bridge.historySnapshot();if(h.isEmpty()){historyPreviewText.setText("Últimos: —");return;}StringBuilder b=new StringBuilder("Últimos: ");int n=Math.min(12,h.size());for(int i=0;i<n;i++){if(i>0)b.append(" • ");b.append(h.get(i));}historyPreviewText.setText(b.toString());}

    private void refreshTelemetryClock(){
        long now=System.currentTimeMillis();
        String updateAge=ageLabel(lastDataAt,now);
        String domAge=ageLabel(pipeline.domHealthyAt(),now);
        String ocrAge=ageLabel(pipeline.ocrHealthyAt(),now);
        boolean domHealthy=pipeline.domHealthy(now);
        boolean ocrHealthy=pipeline.ocrHealthy(now);
        int last=bridge.historySnapshot().isEmpty()?-1:bridge.historySnapshot().get(0);
        String[] pulse={"◐","◓","◑","◒"};
        String beat=pulse[Math.abs(heartbeatTick)%pulse.length];
        String phase=pipeline.phase().name();
        String active=pipeline.activeSource()==ReadingPipelineController.Source.NONE?"—":pipeline.activeSource().name();

        if(!readingActive){
            liveBadge.setText(IntegratedSessionStore.finished(this)?"● SESSÃO FINALIZADA":"● AGUARDANDO INÍCIO");
            liveBadge.setTextColor(Ui.AMBER);
            activityText.setText("AGUARDANDO INÍCIO");
            pipelinePulse.setVisibility(View.INVISIBLE);
            radarPulse.setVisibility(View.INVISIBLE);
            pipelineText.setText("CAPTURA "+(domHealthy||ocrHealthy?"✓":"…")+" → VALIDAÇÃO … → HISTÓRICO BLOQUEADO → CORE "+bridge.historySize()+" → ANÁLISE EM ESPERA");
            analysisPulseText.setText("Scanner aguardando sessão");
        }else{
            pipelinePulse.setVisibility(View.VISIBLE);
            radarPulse.setVisibility(View.VISIBLE);
            boolean recovering=pipeline.phase()==ReadingPipelineController.Phase.RECOVERING;
            liveBadge.setText(recovering?"● LEITURA ATIVA • RECUPERANDO":"● LEITURA ATIVA");
            liveBadge.setTextColor(recovering?Ui.AMBER:Ui.GREEN);
            activityText.setText(beat+" scan "+scanAttempts+" • fonte "+active+" • update "+updateAge);
            boolean capture=domHealthy||ocrHealthy;
            String hist=initialBootstrapPending?"BOOTSTRAP":(bridge.historySize()>0?"✓":"…");
            String analysis=bridge.historySize()>0&&!initialBootstrapPending?"✓":"…";
            pipelineText.setText("CAPTURA "+(capture?"✓":"⚠")+" → VALIDAÇÃO "+(capture?"✓":"…")+" → HISTÓRICO "+hist+" → CORE "+bridge.historySize()+" → ANÁLISE "+analysis);
            analysisPulseText.setText(beat+" VARREDURA #"+scanAttempts+" • análise #"+analysisSerial+" • CORE "+bridge.historySize()+" • "+phase);
        }

        scannerText.setText(
                "FASE: "+phase+" • FONTE ATIVA: "+active+"\n"+
                "DOM: "+domState.name()+" • "+(domHealthy?"SAUDÁVEL ✓":"aguardando")+" • semântica "+domConfidence+"% • qualidade "+domQualityScore+"/100 • "+domExtractionMode+" • visíveis "+domHistoryCount+" • heartbeat "+domAge+" • ordem "+domOrderTracker.order()+"\n"+
                "OCR: "+(AppStateStore.captureActive(this)?"CAPTURA ATIVA":"SEM CAPTURA")+" • "+(ocrHealthy?"SAUDÁVEL ✓":"standby")+" • visíveis "+ocrHistoryCount+" • heartbeat "+ocrAge+" • scans "+lastOcrScanCount+"\n"+
                "CORE: "+bridge.historySize()+" • ÚLTIMO GIRO: "+(last>=0?last+" ✓":"—")+" • FAILOVERS: "+pipeline.sourceSwitches()+" • RECUPERAÇÕES: "+pipeline.recoveries());
        contextText.setText("CONTEXTO: "+tableContext+(currentResult>=0?" • resultado destacado "+currentResult:""));
        refreshSourceLine();
        refreshCaptureStatus();
        refreshSession();
    }

    private void refreshSourceLine(){
        String active=pipeline.activeSource()==ReadingPipelineController.Source.NONE?"nenhuma":pipeline.activeSource().name();
        sourceText.setText("Fonte operacional: "+active+" • última aceita: "+lastAcceptedSource+" • DOM "+domState.name()+"/"+domQualityScore+"q ("+domQualityReason+") • acordo OCR "+String.format(Locale.US,"%.0f%%",domOcrAgreement*100.0)+" • OCR "+(pipeline.ocrHealthy(System.currentTimeMillis())?"HOT STANDBY":"standby")+" • scans DOM "+scanAttempts+" • failovers "+pipeline.sourceSwitches()+(blockedFrames>0?" • iframe bloqueado "+blockedFrames:""));
    }

    private void refreshCaptureStatus(){
        long now=System.currentTimeMillis();
        boolean active=AppStateStore.captureActive(this);
        boolean calibrated=AppStateStore.isCalibrated(this);
        boolean healthy=pipeline.ocrHealthy(now);
        if(readingActive&&pipeline.activeSource()==ReadingPipelineController.Source.OCR&&healthy){
            captureStatusText.setText("OCR • FONTE OPERACIONAL ATIVA ✓ • ROI calibrada • failover automático");
            captureStatusText.setTextColor(Ui.GREEN);
        }else if(active&&healthy){
            captureStatusText.setText("OCR • HOT STANDBY ✓ • ROI calibrada • pronto para assumir sem reiniciar sessão");
            captureStatusText.setTextColor(Ui.CYAN);
        }else if(active&&calibrated){
            captureStatusText.setText("OCR • captura ativa • aguardando snapshot estável da ROI");
            captureStatusText.setTextColor(Ui.AMBER);
        }else if(calibrated){
            captureStatusText.setText("OCR • ROI salva • captura não autorizada nesta sessão");
            captureStatusText.setTextColor(Ui.MUTED);
        }else{
            captureStatusText.setText("OCR • standby • calibre a ROI dos resultados para habilitar hot standby");
            captureStatusText.setTextColor(Ui.MUTED);
        }
    }

    private static String ageLabel(long at,long now){
        if(at<=0)return "—";
        double seconds=Math.max(0,now-at)/1000.0;
        return String.format(Locale.US,"%.1fs",seconds);
    }

    private void parseContext(JSONObject c){if(c==null){tableContext="—";return;}List<String> parts=new ArrayList<>();if(c.optInt("race",0)>0)parts.add("racetrack reconhecida");if(c.optInt("timeline",0)>0)parts.add("timeline");if(c.optInt("stats",0)>0)parts.add("estatísticas");if(c.optInt("current",0)>0)parts.add("resultado atual");if(c.optInt("bet",0)>0)parts.add("tabela de apostas isolada");if(c.optInt("balance",0)>0)parts.add("saldo isolado");tableContext=parts.isEmpty()?"sem contexto auxiliar confirmado":join(parts," • ");}
    private static String join(List<String> xs,String sep){StringBuilder b=new StringBuilder();for(String x:xs){if(b.length()>0)b.append(sep);b.append(x);}return b.toString();}

    private void renderRayX(ConfluenceVerdict v,SignalUpdate u){if(v==null){rayText.setText("Aguardando dados suficientes para leitura profunda.");return;}String mode=bridge.isPrecision()?"Precision":"Balanced";rayText.setText("GATE • "+mode+" • "+v.decision+" • famílias "+v.independentFamilies+"/"+FAMILY_COUNT+" • regime "+v.spatialRegime+" • "+v.signalShape);}
    private void showFullRayX(){if(lastVerdict==null){Toast.makeText(this,"Raio-X ainda sem veredito.",Toast.LENGTH_SHORT).show();return;}StringBuilder b=new StringBuilder();ConfluenceVerdict v=lastVerdict;b.append("FONTE: ").append(lastAcceptedSource).append("\nDECISÃO: ").append(v.decision).append("\nALVO: ").append(v.target).append("\nAURUM SCORE: ").append(v.aurumScore).append("/100\nFAMÍLIAS: ").append(v.independentFamilies).append('/').append(FAMILY_COUNT).append("\nREGIME: ").append(v.spatialRegime).append("\nSHAPE: ").append(v.signalShape).append("\n\nFAMÍLIAS ALINHADAS:\n");for(EvidenceFamily f:v.supportingFamilies)b.append("• ").append(f.name()).append('\n');b.append("\nRAZÕES:\n");for(String s:v.reasons)b.append("• ").append(s).append('\n');TextView t=Ui.text(this,b.toString(),13,Ui.TEXT,false);t.setPadding(Ui.dp(this,16),Ui.dp(this,10),Ui.dp(this,16),Ui.dp(this,20));ScrollView sv=new ScrollView(this);sv.setBackgroundColor(Ui.BG);sv.addView(t);new AlertDialog.Builder(this).setTitle("RAIO-X • INTEGRATED").setView(sv).setPositiveButton("Fechar",null).show();}

    private void refreshSession(){long start=IntegratedSessionStore.startedAt(this);long end=IntegratedSessionStore.endedAt(this);long stop=end>0?end:System.currentTimeMillis();long mins=start<=0?0:Math.max(0,(stop-start)/60000L);sessionText.setText("Sinais "+IntegratedSessionStore.signals(this)+" • STRIKE "+IntegratedSessionStore.strikes(this)+" • LOSS "+IntegratedSessionStore.losses(this)+" • "+bridge.historySize()+" giros • "+mins+" min");}

    private void resetSignalUi(String target,String meta){signalTitle.setText("SINAL • "+(bridge.isPrecision()?"PRECISION":"BALANCED"));signalTitle.setTextColor(Ui.CYAN);signalTarget.setText(target);signalMeta.setText(meta);secondaryText.setVisibility(View.GONE);updateConfluence(null);refreshHistoryPreview();}

    private static String decodeJsString(String value)throws Exception{if(value==null||"null".equals(value))return "{}";if(value.startsWith("\"")&&value.endsWith("\""))return new JSONArray("["+value+"]").getString(0);return value;}
    private static int accent(SignalUpdate.Kind k){if(k==SignalUpdate.Kind.ENTRY||k==SignalUpdate.Kind.ACTIVE||k==SignalUpdate.Kind.HIT||k==SignalUpdate.Kind.SECONDARY_HIT)return Ui.GREEN;if(k==SignalUpdate.Kind.PREPARE||k==SignalUpdate.Kind.OBSERVE||k==SignalUpdate.Kind.BUILDING)return Ui.AMBER;if(k==SignalUpdate.Kind.INVALIDATED||k==SignalUpdate.Kind.EXPIRED)return Ui.RED;return Ui.CYAN;}
}
