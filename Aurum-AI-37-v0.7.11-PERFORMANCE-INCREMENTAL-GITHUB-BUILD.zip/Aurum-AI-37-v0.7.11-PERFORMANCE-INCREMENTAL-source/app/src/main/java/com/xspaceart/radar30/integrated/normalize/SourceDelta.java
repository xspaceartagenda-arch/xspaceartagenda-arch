package com.xspaceart.radar30.integrated.normalize;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Detecta somente o prefixo novo entre dois snapshots newest-first da mesma fonte. */
public final class SourceDelta {
    private SourceDelta() {}

    public static Result between(List<Integer> current, List<Integer> previous) {
        if (current == null || previous == null || current.isEmpty() || previous.isEmpty()) {
            return new Result(false, Collections.emptyList(), 0.0);
        }
        int best = -1, comparedBest = 0;
        double ratioBest = -1.0;
        int max = Math.min(6, current.size() - 1);
        for (int offset = 0; offset <= max; offset++) {
            int compared = Math.min(24, Math.min(current.size() - offset, previous.size()));
            if (compared < 5) continue;
            int equal = 0;
            for (int i = 0; i < compared; i++) if (current.get(offset + i).equals(previous.get(i))) equal++;
            double ratio = equal / (double) compared;
            if (ratio > ratioBest) { ratioBest = ratio; best = offset; comparedBest = compared; }
        }
        if (best < 0 || comparedBest < 5 || ratioBest < 0.84) return new Result(false, Collections.emptyList(), ratioBest);
        if (best == 0) return new Result(true, Collections.emptyList(), ratioBest);
        return new Result(true, new ArrayList<>(current.subList(0, best)), ratioBest);
    }

    public static final class Result {
        public final boolean valid;
        public final List<Integer> newestFirst;
        public final double overlap;
        Result(boolean valid, List<Integer> newestFirst, double overlap) {
            this.valid = valid;
            this.newestFirst = Collections.unmodifiableList(new ArrayList<>(newestFirst));
            this.overlap = overlap;
        }
    }
}
