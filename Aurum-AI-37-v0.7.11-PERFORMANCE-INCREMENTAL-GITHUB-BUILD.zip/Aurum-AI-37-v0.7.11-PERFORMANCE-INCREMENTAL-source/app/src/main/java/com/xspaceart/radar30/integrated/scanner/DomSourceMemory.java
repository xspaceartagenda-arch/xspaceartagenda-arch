package com.xspaceart.radar30.integrated.scanner;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/** Persistência local da assinatura DOM validada por host/provedor. Nunca contém credenciais. */
public final class DomSourceMemory {
    private static final String PREFS = "aurum_integrated_dom_sources";
    private DomSourceMemory() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String load(Context c, String host) {
        if (blank(host)) return "";
        return p(c).getString(hostKey(host), "");
    }

    public static String load(Context c, String host, String provider) {
        if (blank(host)) return "";
        if (!blank(provider)) {
            String exact = p(c).getString(providerKey(host, provider), "");
            if (exact != null && !exact.trim().isEmpty()) return exact;
        }
        return load(c, host);
    }

    public static void save(Context c, String host, String provider, String signature) {
        if (blank(host) || blank(signature)) return;
        SharedPreferences.Editor e=p(c).edit().putString(hostKey(host),signature.trim());
        if (!blank(provider)) e.putString(providerKey(host,provider),signature.trim());
        e.apply();
    }

    public static void invalidate(Context c, String host, String provider) {
        if (blank(host)) return;
        SharedPreferences.Editor e=p(c).edit().remove(hostKey(host));
        if(!blank(provider))e.remove(providerKey(host,provider));
        e.apply();
    }

    private static String hostKey(String host) { return "host_" + clean(host); }
    private static String providerKey(String host,String provider){return hostKey(host)+"__provider_"+clean(provider);}
    private static String clean(String value){return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9._-]+","_");}
    private static boolean blank(String s){return s==null||s.trim().isEmpty();}
}
