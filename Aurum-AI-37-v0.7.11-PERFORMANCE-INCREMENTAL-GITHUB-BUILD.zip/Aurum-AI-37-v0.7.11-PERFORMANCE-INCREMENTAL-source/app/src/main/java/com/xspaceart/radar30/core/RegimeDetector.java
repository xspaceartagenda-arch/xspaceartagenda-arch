package com.xspaceart.radar30.core;

import java.util.List;

/** Detecta uma possível quebra de comportamento sem apagar o histórico. */
public final class RegimeDetector {
    private static final int MIN_REGIME = 18;
    private static final int MAX_REGIME = 150;

    public Snapshot detect(List<Integer> input) {
        List<Integer> history = CurrentTableHistory.clean(input);
        int size = history.size();
        if (size == 0) return Snapshot.empty();
        if (size < 2 * MIN_REGIME) {
            TableSignature signature = TableSignature.from(history, 0, size);
            return new Snapshot(size, 0.0, 1.0, false, 0.0,
                    signature, TableSignature.from(history, size, size));
        }

        int upper = Math.min(MAX_REGIME, size - MIN_REGIME);
        Candidate best = null;
        for (int length = MIN_REGIME; length <= upper; length++) {
            int previousEnd = Math.min(size,
                    length + Math.max(30, Math.min(120, length * 2)));
            if (previousEnd - length < MIN_REGIME) continue;
            TableSignature current = TableSignature.from(history, 0, length);
            TableSignature previous = TableSignature.from(history, length, previousEnd);
            int recentEnd = Math.min(length, 30);
            TableSignature recentCore = TableSignature.from(history, 0, recentEnd);
            double divergence = 1.0 - current.similarity(previous);
            double coherence = recentCore.similarity(current);
            double sample = Math.min(1.0, (length - 12) / 38.0);
            double score = 0.58 * divergence + 0.32 * coherence + 0.10 * sample;
            if (best == null || score > best.score) {
                best = new Candidate(length, score, divergence, coherence,
                        current, previous);
            }
        }

        if (best == null) {
            int length = Math.min(size, MAX_REGIME);
            return new Snapshot(length, 0.0, 1.0, false, 0.0,
                    TableSignature.from(history, 0, length),
                    TableSignature.from(history, length, size));
        }

        // Divergência abaixo de 0,20 é compatível com flutuação normal entre
        // janelas pequenas. Nesse caso o contexto recente é ampliado.
        double confidence = clamp01((best.divergence - 0.20) / 0.38)
                * clamp01((best.coherence - 0.52) / 0.38);
        boolean changed = confidence >= 0.34;
        int regimeLength = changed ? best.length : Math.min(size, MAX_REGIME);
        TableSignature current = changed ? best.current
                : TableSignature.from(history, 0, regimeLength);
        TableSignature previous = changed ? best.previous
                : TableSignature.from(history, regimeLength, size);
        double previousWeight = changed
                ? 0.08 + 0.52 * (1.0 - confidence)
                : 0.72;
        return new Snapshot(regimeLength, confidence, previousWeight, changed,
                best.divergence, current, previous);
    }

    public static final class Snapshot {
        public final int currentRegimeStart;
        public final double regimeConfidence;
        public final double previousRegimeWeight;
        public final boolean changeDetected;
        public final double divergence;
        public final TableSignature currentRegimeSignature;
        public final TableSignature previousRegimeSignature;

        Snapshot(int currentRegimeStart, double regimeConfidence,
                 double previousRegimeWeight, boolean changeDetected,
                 double divergence, TableSignature currentRegimeSignature,
                 TableSignature previousRegimeSignature) {
            this.currentRegimeStart = Math.max(0, currentRegimeStart);
            this.regimeConfidence = clamp01(regimeConfidence);
            this.previousRegimeWeight = clamp01(previousRegimeWeight);
            this.changeDetected = changeDetected;
            this.divergence = clamp01(divergence);
            this.currentRegimeSignature = currentRegimeSignature;
            this.previousRegimeSignature = previousRegimeSignature;
        }

        static Snapshot empty() {
            TableSignature empty = TableSignature.from(java.util.Collections.emptyList(), 0, 0);
            return new Snapshot(0, 0, 1, false, 0, empty, empty);
        }
    }

    private static final class Candidate {
        final int length;
        final double score;
        final double divergence;
        final double coherence;
        final TableSignature current;
        final TableSignature previous;

        Candidate(int length, double score, double divergence, double coherence,
                  TableSignature current, TableSignature previous) {
            this.length = length;
            this.score = score;
            this.divergence = divergence;
            this.coherence = coherence;
            this.current = current;
            this.previous = previous;
        }
    }

    private static double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
}
