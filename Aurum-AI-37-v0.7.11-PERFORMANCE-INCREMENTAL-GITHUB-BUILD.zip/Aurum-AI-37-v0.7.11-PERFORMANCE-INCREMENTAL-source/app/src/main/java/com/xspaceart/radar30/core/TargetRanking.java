package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Leitura espacial do heatmap central. O ranking identifica polos físicos;
 * ele não cria uma entrada e não substitui a votação por famílias.
 */
public final class TargetRanking {
    public enum SpatialRegime { CONCENTRATED, BIMODAL, DISPERSED }

    public enum SignalShape {
        SINGLE_TARGET, DUAL_TARGET, SINGLE_MACRO_CLUSTER, HIGH_DISPERSION
    }

    public static final class Candidate {
        public final int target;
        public final List<Integer> coverage;
        public final double score;

        private Candidate(int target, double score) {
            this.target = target;
            this.coverage = Collections.unmodifiableList(
                    new ArrayList<>(Wheel.coverage(target, 2)));
            this.score = clamp01(score);
        }
    }

    public final Candidate primary;
    public final Candidate secondary;
    public final Candidate third;
    public final Candidate overlappingCluster;
    public final double primaryMargin;
    public final double secondaryMargin;
    public final double dualDominance;
    public final double entropy;
    public final SpatialRegime spatialRegime;
    public final boolean highDispersion;
    public final boolean macroCluster;

    private TargetRanking(Candidate primary, Candidate secondary,
                          Candidate third, Candidate overlappingCluster,
                          double primaryMargin, double secondaryMargin,
                          double dualDominance, double entropy,
                          SpatialRegime spatialRegime,
                          boolean highDispersion, boolean macroCluster) {
        this.primary = primary;
        this.secondary = secondary;
        this.third = third;
        this.overlappingCluster = overlappingCluster;
        this.primaryMargin = clamp01(primaryMargin);
        this.secondaryMargin = clamp01(secondaryMargin);
        this.dualDominance = clamp01(dualDominance);
        this.entropy = clamp01(entropy);
        this.spatialRegime = spatialRegime;
        this.highDispersion = highDispersion;
        this.macroCluster = macroCluster;
    }

    public static TargetRanking fromHeatMap(double[] input) {
        double[] heat = sanitize(input);
        List<Candidate> ranked = new ArrayList<>();
        for (int center : Wheel.EUROPEAN) {
            ranked.add(new Candidate(center, sectorSupport(heat, center)));
        }
        ranked.sort(Comparator.comparingDouble((Candidate item) -> item.score)
                .reversed().thenComparingInt(item -> item.target));

        Candidate primary = ranked.isEmpty() ? new Candidate(-1, 0.0) : ranked.get(0);
        Candidate overlapping = null;
        List<Candidate> independent = new ArrayList<>();
        independent.add(primary);
        for (Candidate candidate : ranked) {
            if (candidate.target == primary.target) continue;
            int distance = Wheel.distance(primary.target, candidate.target);
            int overlap = overlap(primary.coverage, candidate.coverage);
            if (overlapping == null && distance >= 2 && distance <= 3
                    && overlap >= 2 && primary.score > 0.0
                    && candidate.score / primary.score >= 0.82) {
                overlapping = candidate;
            }
            boolean distinct = true;
            for (Candidate selected : independent) {
                if (Wheel.distance(selected.target, candidate.target) < 5) {
                    distinct = false;
                    break;
                }
            }
            if (distinct) independent.add(candidate);
            if (independent.size() >= 4 && overlapping != null) break;
        }

        Candidate secondary = independent.size() > 1
                ? independent.get(1) : new Candidate(-1, 0.0);
        Candidate third = independent.size() > 2
                ? independent.get(2) : new Candidate(-1, 0.0);
        double primaryMargin = margin(primary.score, secondary.score);
        double secondaryMargin = margin(secondary.score, third.score);
        double secondaryRatio = ratio(secondary.score, primary.score);
        double thirdRatio = ratio(third.score, secondary.score);
        double entropy = TableSignature.normalizedEntropy(heat);
        boolean highDispersion = secondaryRatio >= 0.70
                && (thirdRatio >= 0.88 || (entropy >= 0.965 && thirdRatio >= 0.78));
        boolean bimodal = !highDispersion && secondaryRatio >= 0.54
                && secondaryMargin >= 0.10;
        SpatialRegime spatial = highDispersion ? SpatialRegime.DISPERSED
                : bimodal ? SpatialRegime.BIMODAL
                : primaryMargin >= 0.26 || secondaryRatio < 0.58
                ? SpatialRegime.CONCENTRATED : SpatialRegime.DISPERSED;
        double dualDominance = 0.55 * secondaryRatio
                + 0.45 * clamp01(secondaryMargin / 0.34);
        boolean macroCluster = !bimodal && !highDispersion
                && (overlapping != null || broadPlateau(heat, primary.target));
        return new TargetRanking(primary, secondary, third, overlapping,
                primaryMargin, secondaryMargin, dualDominance, entropy,
                spatial, highDispersion, macroCluster);
    }

    public SignalShape shape(boolean secondaryQualified) {
        if (highDispersion) return SignalShape.HIGH_DISPERSION;
        if (secondaryQualified && spatialRegime == SpatialRegime.BIMODAL) {
            return SignalShape.DUAL_TARGET;
        }
        if (macroCluster) return SignalShape.SINGLE_MACRO_CLUSTER;
        return SignalShape.SINGLE_TARGET;
    }

    static double sectorSupport(double[] heat, int center) {
        List<Integer> zone = Wheel.coverage(center, 2);
        if (zone.size() != 5) return 0.0;
        double[] weights = {0.62, 0.84, 1.0, 0.84, 0.62};
        double total = 0.0;
        double weight = 0.0;
        for (int index = 0; index < zone.size(); index++) {
            total += heat[zone.get(index)] * weights[index];
            weight += weights[index];
        }
        return weight <= 0.0 ? 0.0 : clamp01(total / weight);
    }

    private static boolean broadPlateau(double[] heat, int center) {
        if (center < 0) return false;
        List<Integer> zone = Wheel.coverage(center, 2);
        double peak = 0.0;
        for (int number : zone) peak = Math.max(peak, heat[number]);
        if (peak <= 0.0) return false;
        int nearPeak = 0;
        for (int number : zone) {
            if (heat[number] >= peak * 0.90) nearPeak++;
        }
        return nearPeak >= 3;
    }

    private static double[] sanitize(double[] input) {
        double[] result = new double[37];
        if (input == null) return result;
        for (int number = 0; number < Math.min(37, input.length); number++) {
            double value = input[number];
            result[number] = Double.isFinite(value) ? Math.max(0.0, value) : 0.0;
        }
        return result;
    }

    private static int overlap(List<Integer> first, List<Integer> second) {
        int count = 0;
        for (int number : first) if (second.contains(number)) count++;
        return count;
    }

    private static double margin(double leader, double runner) {
        return leader <= 0.0 ? 0.0 : clamp01((leader - runner) / leader);
    }

    private static double ratio(double value, double reference) {
        return reference <= 0.0 ? 0.0 : clamp01(value / reference);
    }

    private static double clamp01(double value) {
        if (!Double.isFinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }
}
