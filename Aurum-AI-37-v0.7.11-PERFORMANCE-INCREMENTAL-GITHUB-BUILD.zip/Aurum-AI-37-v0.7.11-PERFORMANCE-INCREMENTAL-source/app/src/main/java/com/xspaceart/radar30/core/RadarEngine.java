package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Motor de precisão profunda. As janelas 0–4, 5–11 e 12–29 são analisadas
 * separadamente para impedir que a mesma ocorrência seja contada várias vezes
 * como se fossem confluências independentes.
 *
 * A pontuação continua sendo um filtro histórico, não uma probabilidade do
 * próximo giro. O objetivo deste motor é rejeitar sinais frágeis, ambíguos ou
 * dependentes de uma única ocorrência.
 */
public final class RadarEngine {
    private static final int RADIUS = 2;
    private static final double ZONE_BASELINE = 5.0 / 37.0;
    private static final int PRECISION_HISTORY = 30;
    private static final int STANDARD_HISTORY = 20;

    public AnalysisResult analyze(List<Integer> input) {
        return analyze(input, LearningModel.empty(), false);
    }

    public AnalysisResult analyze(List<Integer> input, LearningModel learning,
                                  boolean conservative) {
        List<Integer> history = clean(input, 50);
        if (learning == null) learning = LearningModel.empty();
        if (conservative) return analyzeBalanced(history, learning);

        int required = STANDARD_HISTORY;
        if (history.size() < required) {
            return AnalysisResult.insufficient(history.size(), required);
        }

        int recentEnd = Math.min(5, history.size());
        int confirmationEnd = Math.min(12, history.size());
        int contextEnd = Math.min(30, history.size());
        int extendedEnd = Math.min(50, history.size());

        WindowProfile windows = new WindowProfile(
                maxHits(history, 0, recentEnd),
                maxHits(history, 5, confirmationEnd),
                maxHits(history, 12, contextEnd),
                maxHits(history, 1, contextEnd));

        List<Candidate> candidates = new ArrayList<>();
        for (int center : Wheel.EUROPEAN) {
            candidates.add(buildCandidate(history, center, recentEnd,
                    confirmationEnd, contextEnd, extendedEnd, windows));
        }

        candidates.sort(Comparator
                .comparingInt((Candidate candidate) -> candidate.score).reversed()
                .thenComparing(Comparator
                        .comparingInt((Candidate candidate) -> candidate.h30).reversed())
                .thenComparingInt(candidate -> Wheel.distance(candidate.center, history.get(0)))
                .thenComparingInt(candidate -> candidate.center));

        Candidate best = candidates.get(0);
        Candidate runnerUp = independentRunnerUp(candidates, best);
        int runnerScore = runnerUp == null ? 0 : runnerUp.score;
        int separation = Math.max(0, best.score - runnerScore);

        List<String> features = featureKeys(best, separation);
        int learningAdjustment = learning.adjustmentFor(features);
        int finalScore = clampScore(best.score + learningAdjustment);

        List<String> blockers = conservative
                ? precisionBlockers(best, separation)
                : standardBlockers(best, separation);

        boolean entry = blockers.isEmpty()
                && (conservative ? best.score >= 84 && finalScore >= 84
                : best.score >= 74 && finalScore >= 76);

        AnalysisResult.Decision decision;
        if (entry) {
            decision = AnalysisResult.Decision.ENTER;
        } else if (finalScore >= 50) {
            decision = AnalysisResult.Decision.OBSERVE;
        } else {
            decision = AnalysisResult.Decision.NO_ENTRY;
        }

        int criteria = best.persistence;
        if (best.agreements >= 2) criteria++;
        if (best.stableWithoutNewest) criteria++;
        if (best.distinct12 >= 3) criteria++;
        if (separation >= 12) criteria++;
        if (best.adjustedP30 <= 0.20) criteria++;

        List<String> reasons = new ArrayList<>();
        reasons.add("Blocos separados: " + best.persistence + "/3 • "
                + best.hRecent + "/5, " + best.hConfirmation + "/7 e "
                + best.hContext + "/18");
        reasons.add("Total: " + best.h30 + "/30 • diversidade "
                + best.distinct12 + " números • estabilidade "
                + (best.stableWithoutNewest ? "aprovada" : "reprovada"));
        reasons.add("Margem sobre outro setor: " + separation
                + " • índice concorrente " + runnerScore);
        if (!blockers.isEmpty()) {
            reasons.add("Bloqueio de precisão: " + join(blockers, " • "));
        } else {
            reasons.add("Filtro profundo aprovado: alvo único e persistente");
        }
        reasons.add("Setor recente: " + Wheel.dominantSector(history, 12));
        if (best.family.active()) reasons.add("Padrão auxiliar: " + best.family.display);
        if (learning.isActive()) {
            reasons.add("Auditoria local: " + signed(learningAdjustment)
                    + " • " + learning.resolvedSignals() + " hipóteses");
        } else {
            reasons.add("Auditoria local aguardando: "
                    + learning.resolvedSignals() + "/"
                    + LearningModel.MIN_TOTAL_SIGNALS + " hipóteses");
        }
        reasons.add("Índice estrutural; não é probabilidade do próximo giro");

        return new AnalysisResult(best.center, best.zone, finalScore, decision,
                reasons, features, criteria, learningAdjustment);
    }

    /**
     * Motor estrutural. Compara regiões físicas de cinco números e
     * terminais, mas mantém as janelas 5/7/18 separadas. A pontuação indica a
     * concentração observada; não altera a chance matemática da cobertura.
     */
    private static AnalysisResult analyzeBalanced(List<Integer> history,
                                                   LearningModel learning) {
        if (history.size() < PRECISION_HISTORY) {
            return AnalysisResult.insufficient(history.size(), PRECISION_HISTORY);
        }

        List<BalancedCandidate> candidates = new ArrayList<>();
        WindowProfile sectorWindows = balancedWindows(history, false);
        for (int center : Wheel.EUROPEAN) {
            candidates.add(buildBalancedCandidate(history, center,
                    Wheel.coverage(center, RADIUS), false, sectorWindows));
        }
        WindowProfile terminalWindows = balancedWindows(history, true);
        for (int terminal = 0; terminal <= 9; terminal++) {
            candidates.add(buildBalancedCandidate(history, terminal,
                    terminalCoverage(terminal), true, terminalWindows));
        }

        candidates.sort(Comparator
                .comparingInt((BalancedCandidate candidate) -> candidate.score).reversed()
                .thenComparing(Comparator
                        .comparingInt((BalancedCandidate candidate) -> candidate.h30).reversed())
                .thenComparing(candidate -> candidate.terminal)
                .thenComparingInt(candidate -> candidate.terminal
                        ? 100 : Wheel.distance(candidate.target, history.get(0)))
                .thenComparingInt(candidate -> candidate.target));

        BalancedCandidate best = candidates.get(0);
        BalancedCandidate runner = balancedRunnerUp(candidates, best);
        int runnerScore = runner == null ? 0 : runner.score;
        int separation = Math.max(0, best.score - runnerScore);

        boolean sectorEmerging = best.hRecent >= 3 && best.h12 >= 4
                && best.h30 >= 8 && best.distinct12 >= 3;
        boolean sectorPersistent = best.hRecent >= 2 && best.hConfirmation >= 2
                && best.hContext >= 4 && best.h30 >= 9 && best.distinct12 >= 3;
        int terminalEmergingTotal = best.zone.size() == 4 ? 7 : 6;
        int terminalPersistentTotal = best.zone.size() == 4 ? 8 : 7;
        int terminalDistinct = best.zone.size() == 4 ? 3 : 2;
        boolean terminalEmerging = best.hRecent >= 3 && best.h12 >= 4
                && best.h30 >= terminalEmergingTotal
                && best.distinct12 >= terminalDistinct;
        boolean terminalPersistent = best.hRecent >= 2 && best.hConfirmation >= 2
                && best.hContext >= 3 && best.h30 >= terminalPersistentTotal
                && best.distinct12 >= terminalDistinct;
        boolean emerging = best.terminal ? terminalEmerging : sectorEmerging;
        boolean persistent = best.terminal ? terminalPersistent : sectorPersistent;
        boolean routeApproved = emerging || persistent;

        BalancedCandidate protection = routeApproved
                ? alignedTerminalProtection(candidates, best) : null;
        List<Integer> primaryCoverage = new ArrayList<>(best.zone);
        List<Integer> protectionCoverage = protection == null
                ? new ArrayList<>() : extrasOutside(primaryCoverage, protection.zone);
        List<Integer> totalCoverage = mergeCoverage(primaryCoverage, protectionCoverage);
        String protectionLabel = protection == null || protectionCoverage.isEmpty()
                ? "" : "PROTEÇÃO TERMINAL " + protection.target;

        List<String> features = balancedFeatureKeys(best, separation,
                emerging, persistent, totalCoverage.size(),
                !protectionLabel.isEmpty());
        int learningAdjustment = learning.adjustmentFor(features);
        int finalScore = clampScore(best.score + learningAdjustment);
        int scoreThreshold = best.terminal ? 80 : 78;
        int marginThreshold = best.terminal ? 10 : 8;
        boolean entry = routeApproved && best.stableWithoutNewest
                && best.contradictions <= 1
                && separation >= marginThreshold
                && best.score >= scoreThreshold
                && finalScore >= scoreThreshold;
        boolean prepare = !entry && finalScore >= 74
                && best.stableWithoutNewest
                && best.distinct12 >= 2
                && separation >= 5
                && best.contradictions <= 1
                && (best.hRecent >= 2 || best.hConfirmation >= 2);

        AnalysisResult.Decision decision = entry
                ? AnalysisResult.Decision.ENTER
                : prepare ? AnalysisResult.Decision.OBSERVE
                : AnalysisResult.Decision.NO_ENTRY;

        List<String> blockers = balancedBlockers(best, separation,
                routeApproved, scoreThreshold, marginThreshold);
        int criteria = 0;
        if (routeApproved) criteria++;
        if (best.stableWithoutNewest) criteria++;
        if (best.distinct12 >= terminalDistinct) criteria++;
        if (best.agreements >= 2) criteria++;
        if (best.contradictions <= 1) criteria++;
        if (separation >= marginThreshold) criteria++;
        if (best.score >= scoreThreshold) criteria++;
        if (!protectionLabel.isEmpty()) criteria++;

        String label = best.terminal
                ? "TERMINAL " + best.target
                : best.target + " + 2 VIZINHOS";
        String playLabel = protectionLabel.isEmpty()
                ? label : label + " • PROTEÇÃO T" + protection.target;
        List<String> reasons = new ArrayList<>();
        reasons.add("Blocos separados: " + best.persistence + "/3 • "
                + best.hRecent + "/5, " + best.hConfirmation + "/7 e "
                + best.hContext + "/18");
        reasons.add("Total: " + best.h30 + "/30 • diversidade "
                + best.distinct12 + " números • estabilidade "
                + (best.stableWithoutNewest ? "aprovada" : "reprovada"));
        if (entry) {
            reasons.add("Hipótese prospectiva criada: "
                    + (emerging ? "impulso recente" : "persistência entre blocos"));
        } else if (prepare) {
            reasons.add("Formação relevante, ainda sem hipótese prospectiva");
        } else {
            reasons.add("Bloqueio: " + join(blockers, " • "));
        }
        reasons.add("Margem sobre outra jogada: " + separation
                + " • índice concorrente " + runnerScore);
        if (!protectionLabel.isEmpty()) {
            reasons.add("Proteção independente: terminal " + protection.target
                    + " confirmou o mesmo foco • índice " + protection.score);
        }
        if (learning.isActive()) {
            reasons.add("Auditoria local: " + signed(learningAdjustment)
                    + " • " + learning.resolvedSignals() + " hipóteses");
        } else {
            reasons.add("Auditoria local aguardando: "
                    + learning.resolvedSignals() + "/"
                    + LearningModel.MIN_TOTAL_SIGNALS + " hipóteses");
        }
        reasons.add("Índice estrutural; não é probabilidade do próximo giro");

        return new AnalysisResult(best.target, playLabel, primaryCoverage,
                protectionLabel, protectionCoverage, totalCoverage, finalScore,
                decision, reasons, features, criteria, learningAdjustment);
    }

    private static BalancedCandidate buildBalancedCandidate(
            List<Integer> history, int target, List<Integer> zone,
            boolean terminal, WindowProfile windows) {
        int hRecent = hits(history, zone, 0, 5);
        int hConfirmation = hits(history, zone, 5, 12);
        int hContext = hits(history, zone, 12, 30);
        int h12 = hRecent + hConfirmation;
        int h30 = h12 + hContext;
        int distinct12 = distinctHits(history, zone, 0, 12);
        int withoutNewest = hits(history, zone, 1, 30);
        boolean stable = withoutNewest >= Math.max(0, windows.withoutNewestMax - 1);

        int agreements = 0;
        if (hRecent == windows.recentMax) agreements++;
        if (hConfirmation == windows.confirmationMax) agreements++;
        if (hContext >= Math.max(0, windows.contextMax - 1)) agreements++;

        int contradictions = 0;
        if (hRecent < 2 && windows.recentMax >= 3) contradictions++;
        if (hConfirmation < 1 && windows.confirmationMax >= 3) contradictions++;
        int contextFloor = terminal ? 2 : 3;
        int contextPeak = terminal ? 5 : 6;
        if (hContext < contextFloor && windows.contextMax >= contextPeak) contradictions++;

        int persistence = 0;
        if (hRecent >= 2) persistence++;
        if (hConfirmation >= 2) persistence++;
        if (hContext >= (terminal ? 3 : 4)) persistence++;

        int score = balancedRecentPoints(hRecent, terminal)
                + balancedConfirmationPoints(hConfirmation, terminal)
                + balancedContextPoints(hContext, terminal)
                + Math.min(8, distinct12 * 2)
                + (stable ? 6 : -8)
                + (agreements >= 2 ? 4 : 0)
                - contradictions * 5;

        return new BalancedCandidate(target, zone, terminal, hRecent,
                hConfirmation, hContext, h12, h30, distinct12, persistence,
                agreements, contradictions, stable, clampScore(score));
    }

    private static WindowProfile balancedWindows(List<Integer> history,
                                                 boolean terminal) {
        int recent = 0;
        int confirmation = 0;
        int context = 0;
        int withoutNewest = 0;
        int candidateCount = terminal ? 10 : 37;
        for (int value = 0; value < candidateCount; value++) {
            List<Integer> zone = terminal
                    ? terminalCoverage(value) : Wheel.coverage(value, RADIUS);
            recent = Math.max(recent, hits(history, zone, 0, 5));
            confirmation = Math.max(confirmation, hits(history, zone, 5, 12));
            context = Math.max(context, hits(history, zone, 12, 30));
            withoutNewest = Math.max(withoutNewest, hits(history, zone, 1, 30));
        }
        return new WindowProfile(recent, confirmation, context, withoutNewest);
    }

    private static List<Integer> terminalCoverage(int terminal) {
        List<Integer> result = new ArrayList<>();
        for (int number = terminal; number <= 36; number += 10) result.add(number);
        return result;
    }

    private static int balancedRecentPoints(int hits, boolean terminal) {
        int[] sector = {0, 10, 30, 44, 54, 60};
        int[] terminals = {0, 12, 34, 48, 58, 64};
        int[] points = terminal ? terminals : sector;
        return points[Math.max(0, Math.min(5, hits))];
    }

    private static int balancedConfirmationPoints(int hits, boolean terminal) {
        int[] sector = {0, 8, 17, 25, 30, 33, 35, 36};
        int[] terminals = {0, 9, 19, 28, 34, 37, 39, 40};
        int[] points = terminal ? terminals : sector;
        return points[Math.max(0, Math.min(7, hits))];
    }

    private static int balancedContextPoints(int hits, boolean terminal) {
        return Math.min(terminal ? 22 : 20,
                Math.max(0, hits) * (terminal ? 4 : 3));
    }

    private static BalancedCandidate balancedRunnerUp(
            List<BalancedCandidate> candidates, BalancedCandidate best) {
        for (BalancedCandidate candidate : candidates) {
            if (candidate == best) continue;
            if (alignedSupportPair(best, candidate)) continue;
            if (overlap(best.zone, candidate.zone) <= 1) return candidate;
        }
        return null;
    }

    private static boolean alignedSupportPair(BalancedCandidate first,
                                              BalancedCandidate second) {
        if (first.terminal == second.terminal) return false;
        BalancedCandidate terminal = first.terminal ? first : second;
        BalancedCandidate sector = first.terminal ? second : first;
        if (sector.target % 10 != terminal.target) return false;
        int distinctRequired = terminal.zone.size() == 4 ? 3 : 2;
        return balancedRouteApproved(terminal)
                && terminal.stableWithoutNewest
                && terminal.contradictions <= 1
                && terminal.agreements >= 2
                && terminal.distinct12 >= distinctRequired
                && terminal.score >= 80;
    }

    private static List<String> balancedBlockers(BalancedCandidate best,
                                                 int separation,
                                                 boolean routeApproved,
                                                 int scoreThreshold,
                                                 int marginThreshold) {
        List<String> blockers = new ArrayList<>();
        if (!routeApproved) blockers.add("sem rota completa");
        if (!best.stableWithoutNewest) blockers.add("depende do último número");
        if (best.distinct12 < 2) blockers.add("pouca diversidade");
        if (best.contradictions > 1) blockers.add("blocos contraditórios");
        if (separation < marginThreshold) blockers.add("jogadas concorrentes");
        if (best.score < scoreThreshold) blockers.add("força abaixo do corte");
        if (blockers.isEmpty()) blockers.add("aguardando confirmação adicional");
        return blockers;
    }

    private static List<String> balancedFeatureKeys(BalancedCandidate best,
                                                    int separation,
                                                    boolean emerging,
                                                    boolean persistent,
                                                    int coverageSize,
                                                    boolean protectedPlay) {
        List<String> features = new ArrayList<>();
        String suffix = "_cobertura_" + coverageSize + "_v4";
        features.add("modelo" + suffix);
        String playType = best.terminal ? "jogada_terminal"
                : protectedPlay ? "jogada_setor_protegido" : "jogada_setor";
        features.add(playType + suffix);
        if (protectedPlay) features.add("protecao_terminal_independente" + suffix);
        if (emerging) features.add("rota_impulso" + suffix);
        if (persistent) features.add("rota_persistencia" + suffix);
        if (best.hRecent >= 3) features.add("bloco_recente_3" + suffix);
        if (best.hConfirmation >= 2) features.add("bloco_confirmacao_2" + suffix);
        if (best.hContext >= (best.terminal ? 3 : 4)) {
            features.add("bloco_contexto" + suffix);
        }
        if (best.stableWithoutNewest) features.add("estavel_sem_ultimo" + suffix);
        if (best.distinct12 >= 3) features.add("diversidade_3" + suffix);
        if (separation >= (best.terminal ? 10 : 8)) {
            features.add("margem_aprovada" + suffix);
        }
        features.add(LearningModel.strengthBand(best.score, coverageSize));
        return features;
    }

    /**
     * Acrescenta proteção somente quando o terminal do alvo principal forma
     * uma rota completa por conta própria. Assim, um único agrupamento não é
     * contado duas vezes como setor e terminal.
     */
    private static BalancedCandidate alignedTerminalProtection(
            List<BalancedCandidate> candidates, BalancedCandidate best) {
        if (best.terminal) return null;
        int alignedTerminal = best.target % 10;
        for (BalancedCandidate candidate : candidates) {
            if (!candidate.terminal || candidate.target != alignedTerminal) continue;
            int distinctRequired = candidate.zone.size() == 4 ? 3 : 2;
            if (balancedRouteApproved(candidate)
                    && candidate.stableWithoutNewest
                    && candidate.contradictions <= 1
                    && candidate.agreements >= 2
                    && candidate.distinct12 >= distinctRequired
                    && candidate.score >= 80) {
                return candidate;
            }
        }
        return null;
    }

    private static boolean balancedRouteApproved(BalancedCandidate candidate) {
        if (!candidate.terminal) {
            boolean emerging = candidate.hRecent >= 3 && candidate.h12 >= 4
                    && candidate.h30 >= 8 && candidate.distinct12 >= 3;
            boolean persistent = candidate.hRecent >= 2
                    && candidate.hConfirmation >= 2
                    && candidate.hContext >= 4 && candidate.h30 >= 9
                    && candidate.distinct12 >= 3;
            return emerging || persistent;
        }
        int emergingTotal = candidate.zone.size() == 4 ? 7 : 6;
        int persistentTotal = candidate.zone.size() == 4 ? 8 : 7;
        int distinct = candidate.zone.size() == 4 ? 3 : 2;
        boolean emerging = candidate.hRecent >= 3 && candidate.h12 >= 4
                && candidate.h30 >= emergingTotal
                && candidate.distinct12 >= distinct;
        boolean persistent = candidate.hRecent >= 2
                && candidate.hConfirmation >= 2
                && candidate.hContext >= 3
                && candidate.h30 >= persistentTotal
                && candidate.distinct12 >= distinct;
        return emerging || persistent;
    }

    private static List<Integer> extrasOutside(List<Integer> primary,
                                               List<Integer> candidate) {
        List<Integer> extras = new ArrayList<>();
        for (int number : candidate) {
            if (!primary.contains(number) && !extras.contains(number)) extras.add(number);
        }
        return extras;
    }

    private static List<Integer> mergeCoverage(List<Integer> primary,
                                               List<Integer> protection) {
        List<Integer> merged = new ArrayList<>(primary);
        for (int number : protection) {
            if (!merged.contains(number)) merged.add(number);
        }
        return merged;
    }

    private static Candidate buildCandidate(List<Integer> history, int center,
                                            int recentEnd, int confirmationEnd,
                                            int contextEnd, int extendedEnd,
                                            WindowProfile windows) {
        List<Integer> zone = Wheel.coverage(center, RADIUS);
        int hRecent = hits(history, zone, 0, recentEnd);
        int hConfirmation = hits(history, zone, 5, confirmationEnd);
        int hContext = hits(history, zone, 12, contextEnd);
        int hExtended = hits(history, zone, 30, extendedEnd);
        int h12 = hits(history, zone, 0, confirmationEnd);
        int h30 = hits(history, zone, 0, contextEnd);

        int contextSize = Math.max(0, contextEnd - 12);
        int extendedSize = Math.max(0, extendedEnd - 30);
        int persistence = 0;
        if (hRecent >= 2) persistence++;
        if (hConfirmation >= 2) persistence++;
        if (hContext >= supportThreshold(contextSize)) persistence++;

        int agreements = 0;
        if (hRecent >= windows.recentMax) agreements++;
        if (hConfirmation >= windows.confirmationMax) agreements++;
        if (hContext >= Math.max(0, windows.contextMax - 1)) agreements++;

        int withoutNewest = hits(history, zone, 1, contextEnd);
        boolean stableWithoutNewest = withoutNewest >= Math.max(0, windows.withoutNewestMax - 1);
        int distinct12 = distinctHits(history, zone, 0, confirmationEnd);

        int contradictions = 0;
        if (hRecent < 2 && windows.recentMax >= 3) contradictions++;
        if (hConfirmation < 2 && windows.confirmationMax >= 3) contradictions++;
        if (hContext < supportThreshold(contextSize)
                && windows.contextMax >= supportThreshold(contextSize) + 2) contradictions++;

        double recentEvidence = segmentEvidence(hRecent, recentEnd);
        double confirmationEvidence = segmentEvidence(hConfirmation,
                Math.max(0, confirmationEnd - 5));
        double contextEvidence = segmentEvidence(hContext, contextSize);
        double adjustedP30 = Math.min(1.0,
                37.0 * binomialUpperTail(h30, contextEnd, ZONE_BASELINE));
        double scanEvidence = adjustedP30 >= 1.0
                ? 0.0 : clamp(-Math.log10(Math.max(1.0e-12, adjustedP30)) / 2.0);
        double diversityEvidence = clamp((distinct12 - 1.0) / 4.0);

        double score = 32.0 * recentEvidence
                + 27.0 * confirmationEvidence
                + 23.0 * contextEvidence
                + 12.0 * scanEvidence
                + 6.0 * diversityEvidence;
        score += stableWithoutNewest ? 4.0 : -8.0;
        score += agreements >= 2 ? 4.0 : -5.0;
        score -= contradictions * 7.0;

        if (extendedSize >= 12) {
            int extendedThreshold = supportThreshold(extendedSize);
            if (hExtended >= extendedThreshold + 1) {
                score += 4.0 * segmentEvidence(hExtended, extendedSize);
            } else if (hExtended <= Math.floor(extendedSize * ZONE_BASELINE)) {
                score -= 3.0;
            }
        }

        return new Candidate(center, zone, hRecent, hConfirmation, hContext,
                hExtended, h12, h30, clampScore((int) Math.round(score)),
                persistence, agreements, contradictions, stableWithoutNewest,
                distinct12, adjustedP30, hotFamily(history, zone),
                recentRepeat(history, zone), terminalSupport(history, center));
    }

    private static List<String> precisionBlockers(Candidate best, int separation) {
        List<String> blockers = new ArrayList<>();
        if (best.hRecent < 3) blockers.add("curto abaixo de 3/5");
        if (best.hConfirmation < 3) blockers.add("confirmação abaixo de 3/7");
        if (best.hContext < 6) blockers.add("contexto abaixo de 6/18");
        if (best.persistence < 3) blockers.add("blocos não persistentes");
        if (best.agreements < 2) blockers.add("janelas discordam");
        if (!best.stableWithoutNewest) blockers.add("depende do último número");
        if (best.distinct12 < 3) blockers.add("pouca diversidade");
        if (best.h30 < 12) blockers.add("total abaixo de 12/30");
        if (best.adjustedP30 > 0.20) blockers.add("concentração comum ao acaso");
        if (separation < 12) blockers.add("outro setor está muito próximo");
        if (best.contradictions > 0) blockers.add("há contradição interna");
        return blockers;
    }

    private static List<String> standardBlockers(Candidate best, int separation) {
        List<String> blockers = new ArrayList<>();
        if (best.hRecent < 2) blockers.add("curto abaixo de 2/5");
        if (best.hConfirmation < 2) blockers.add("confirmação abaixo de 2/7");
        if (best.persistence < 3) blockers.add("blocos não persistentes");
        if (!best.stableWithoutNewest) blockers.add("alvo instável");
        if (best.distinct12 < 3) blockers.add("pouca diversidade");
        if (separation < 7) blockers.add("alvos concorrentes");
        if (best.contradictions > 0) blockers.add("há contradição interna");
        return blockers;
    }

    private static List<String> featureKeys(Candidate best, int separation) {
        List<String> features = new ArrayList<>();
        features.add("modelo_geral_v3");
        if (best.hRecent >= 3) features.add("bloco_recente_3");
        if (best.hConfirmation >= 3) features.add("bloco_confirmacao_3");
        if (best.hContext >= 6) features.add("bloco_contexto_6");
        if (best.persistence >= 3) features.add("persistencia_3_blocos");
        if (best.agreements >= 2) features.add("acordo_2_janelas");
        if (best.stableWithoutNewest) features.add("estavel_sem_ultimo");
        if (best.distinct12 >= 3) features.add("diversidade_3");
        if (separation >= 12) features.add("margem_12");
        if (best.adjustedP30 <= 0.20) features.add("concentracao_rara");
        if (best.repeated) features.add("repeticao_auxiliar");
        if (best.terminal) features.add("terminal_auxiliar");
        if (best.family.active()) features.add("familia_" + best.family.key);
        features.add(LearningModel.strengthBand(best.score));
        return features;
    }

    private static Candidate independentRunnerUp(List<Candidate> candidates, Candidate best) {
        for (Candidate candidate : candidates) {
            if (candidate == best) continue;
            if (overlap(best.zone, candidate.zone) <= 1) return candidate;
        }
        return null;
    }

    private static List<Integer> clean(List<Integer> input, int limit) {
        List<Integer> result = new ArrayList<>();
        if (input == null) return result;
        for (Integer number : input) {
            if (number != null && Wheel.valid(number)) result.add(number);
            if (result.size() == limit) break;
        }
        return result;
    }

    private static int hits(List<Integer> history, List<Integer> zone,
                            int startInclusive, int endExclusive) {
        int count = 0;
        int start = Math.max(0, Math.min(startInclusive, history.size()));
        int end = Math.max(start, Math.min(endExclusive, history.size()));
        for (int i = start; i < end; i++) {
            if (zone.contains(history.get(i))) count++;
        }
        return count;
    }

    private static int distinctHits(List<Integer> history, List<Integer> zone,
                                    int startInclusive, int endExclusive) {
        Map<Integer, Boolean> distinct = new HashMap<>();
        int start = Math.max(0, Math.min(startInclusive, history.size()));
        int end = Math.max(start, Math.min(endExclusive, history.size()));
        for (int i = start; i < end; i++) {
            int number = history.get(i);
            if (zone.contains(number)) distinct.put(number, Boolean.TRUE);
        }
        return distinct.size();
    }

    private static int maxHits(List<Integer> history, int start, int end) {
        int maximum = 0;
        for (int center : Wheel.EUROPEAN) {
            maximum = Math.max(maximum,
                    hits(history, Wheel.coverage(center, RADIUS), start, end));
        }
        return maximum;
    }

    private static int supportThreshold(int spins) {
        if (spins <= 0) return Integer.MAX_VALUE;
        return Math.max(2, (int) Math.ceil(spins * ZONE_BASELINE) + 1);
    }

    private static double segmentEvidence(int hits, int spins) {
        if (spins <= 0 || hits <= 0) return 0.0;
        double tail = binomialUpperTail(hits, spins, ZONE_BASELINE);
        return clamp(-Math.log10(Math.max(1.0e-12, tail)) / 3.0);
    }

    /** Probabilidade P(X >= hits) para uma binomial pequena. */
    private static double binomialUpperTail(int hits, int spins, double probability) {
        if (hits <= 0) return 1.0;
        if (hits > spins || spins <= 0) return 0.0;
        double q = 1.0 - probability;
        double term = Math.pow(q, spins);
        double sum = 0.0;
        for (int x = 0; x <= spins; x++) {
            if (x >= hits) sum += term;
            if (x < spins) {
                term *= ((spins - x) / (double) (x + 1)) * (probability / q);
            }
        }
        return Math.max(0.0, Math.min(1.0, sum));
    }

    private static int overlap(List<Integer> first, List<Integer> second) {
        int count = 0;
        for (int number : first) if (second.contains(number)) count++;
        return count;
    }

    private static boolean recentRepeat(List<Integer> history, List<Integer> zone) {
        Map<Integer, Integer> counts = new HashMap<>();
        int end = Math.min(7, history.size());
        for (int i = 0; i < end; i++) {
            int number = history.get(i);
            if (!zone.contains(number)) continue;
            int count = counts.getOrDefault(number, 0) + 1;
            if (count >= 2) return true;
            counts.put(number, count);
        }
        return false;
    }

    private static boolean terminalSupport(List<Integer> history, int center) {
        int terminal = center % 10;
        int count = 0;
        int end = Math.min(12, history.size());
        for (int i = 0; i < end; i++) {
            if (history.get(i) % 10 == terminal) count++;
        }
        return count >= 3;
    }

    private static FamilyMatch hotFamily(List<Integer> history, List<Integer> targetZone) {
        Map<String, int[]> families = new LinkedHashMap<>();
        families.put("rua_ouro", new int[]{10, 11, 12});
        families.put("galaxy", new int[]{13, 14, 15, 16, 17, 18, 31, 32, 33, 34, 35, 36});
        families.put("eixo_6_9", new int[]{6, 9, 25, 26, 28, 29});
        families.put("zona_5_8", new int[]{5, 8, 10, 23, 24});
        families.put("genesis", new int[]{1, 3, 36});

        String bestKey = "";
        int bestCount = 0;
        int end = Math.min(7, history.size());
        for (Map.Entry<String, int[]> entry : families.entrySet()) {
            Map<Integer, Boolean> set = new HashMap<>();
            for (int number : entry.getValue()) set.put(number, Boolean.TRUE);
            int count = 0;
            for (int i = 0; i < end; i++) {
                if (set.containsKey(history.get(i))) count++;
            }
            boolean intersects = false;
            for (int number : targetZone) {
                if (set.containsKey(number)) intersects = true;
            }
            if (intersects && count >= 2 && count > bestCount) {
                bestCount = count;
                bestKey = entry.getKey();
            }
        }
        if (bestKey.isEmpty()) return FamilyMatch.none();
        String name;
        switch (bestKey) {
            case "rua_ouro": name = "Rua do Ouro 10–11–12"; break;
            case "galaxy": name = "13–18 / 31–36"; break;
            case "eixo_6_9": name = "6/9/25/26/28/29"; break;
            case "zona_5_8": name = "5/8/10/23/24"; break;
            default: name = "1/3/36"; break;
        }
        return new FamilyMatch(bestKey,
                String.format(Locale.US, "%s (%d/%d)", name, bestCount, end));
    }

    private static double clamp(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }

    private static int clampScore(int value) {
        return Math.max(0, Math.min(100, value));
    }

    private static String signed(int value) {
        return value > 0 ? "+" + value : Integer.toString(value);
    }

    private static String join(List<String> values, String separator) {
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) output.append(separator);
            output.append(values.get(i));
        }
        return output.toString();
    }

    private static final class WindowProfile {
        final int recentMax;
        final int confirmationMax;
        final int contextMax;
        final int withoutNewestMax;

        WindowProfile(int recentMax, int confirmationMax, int contextMax,
                      int withoutNewestMax) {
            this.recentMax = recentMax;
            this.confirmationMax = confirmationMax;
            this.contextMax = contextMax;
            this.withoutNewestMax = withoutNewestMax;
        }
    }

    private static final class FamilyMatch {
        final String key;
        final String display;

        FamilyMatch(String key, String display) {
            this.key = key;
            this.display = display;
        }

        static FamilyMatch none() {
            return new FamilyMatch("", "");
        }

        boolean active() {
            return !key.isEmpty();
        }
    }

    private static final class Candidate {
        final int center;
        final List<Integer> zone;
        final int hRecent;
        final int hConfirmation;
        final int hContext;
        final int hExtended;
        final int h12;
        final int h30;
        final int score;
        final int persistence;
        final int agreements;
        final int contradictions;
        final boolean stableWithoutNewest;
        final int distinct12;
        final double adjustedP30;
        final FamilyMatch family;
        final boolean repeated;
        final boolean terminal;

        Candidate(int center, List<Integer> zone, int hRecent, int hConfirmation,
                  int hContext, int hExtended, int h12, int h30, int score,
                  int persistence, int agreements, int contradictions,
                  boolean stableWithoutNewest, int distinct12, double adjustedP30,
                  FamilyMatch family, boolean repeated, boolean terminal) {
            this.center = center;
            this.zone = zone;
            this.hRecent = hRecent;
            this.hConfirmation = hConfirmation;
            this.hContext = hContext;
            this.hExtended = hExtended;
            this.h12 = h12;
            this.h30 = h30;
            this.score = score;
            this.persistence = persistence;
            this.agreements = agreements;
            this.contradictions = contradictions;
            this.stableWithoutNewest = stableWithoutNewest;
            this.distinct12 = distinct12;
            this.adjustedP30 = adjustedP30;
            this.family = family;
            this.repeated = repeated;
            this.terminal = terminal;
        }
    }

    private static final class BalancedCandidate {
        final int target;
        final List<Integer> zone;
        final boolean terminal;
        final int hRecent;
        final int hConfirmation;
        final int hContext;
        final int h12;
        final int h30;
        final int distinct12;
        final int persistence;
        final int agreements;
        final int contradictions;
        final boolean stableWithoutNewest;
        final int score;

        BalancedCandidate(int target, List<Integer> zone, boolean terminal,
                          int hRecent, int hConfirmation, int hContext,
                          int h12, int h30, int distinct12, int persistence,
                          int agreements, int contradictions,
                          boolean stableWithoutNewest, int score) {
            this.target = target;
            this.zone = zone;
            this.terminal = terminal;
            this.hRecent = hRecent;
            this.hConfirmation = hConfirmation;
            this.hContext = hContext;
            this.h12 = h12;
            this.h30 = h30;
            this.distinct12 = distinct12;
            this.persistence = persistence;
            this.agreements = agreements;
            this.contradictions = contradictions;
            this.stableWithoutNewest = stableWithoutNewest;
            this.score = score;
        }
    }
}
