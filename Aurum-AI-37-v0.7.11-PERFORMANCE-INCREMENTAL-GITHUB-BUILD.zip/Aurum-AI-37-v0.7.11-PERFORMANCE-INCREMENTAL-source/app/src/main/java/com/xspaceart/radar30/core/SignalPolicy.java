package com.xspaceart.radar30.core;

import java.util.List;

/** Regras puras usadas pela sessão e pela auditoria Shadow. */
public final class SignalPolicy {
    public enum PrimaryAfterSecondary {
        PRIMARY_STRENGTHENED,
        PRIMARY_MAINTAINED,
        PRIMARY_WEAKENED,
        PRIMARY_INVALIDATED
    }

    private SignalPolicy() {}

    public static PrimaryAfterSecondary classifyPrimaryAfterSecondary(
            List<Integer> lockedPrimaryCoverage, int previousScore,
            ConfluenceVerdict current, int remainingSpins) {
        if (remainingSpins <= 0 || current == null || current.target < 0
                || overlap(lockedPrimaryCoverage, current.coverage) < 3) {
            return PrimaryAfterSecondary.PRIMARY_INVALIDATED;
        }
        int delta = current.aurumScore - previousScore;
        if (delta >= 3 && current.aurumScore >= 72
                && current.contradictionScore <= 0.28) {
            return PrimaryAfterSecondary.PRIMARY_STRENGTHENED;
        }
        if (delta >= -7 && current.aurumScore >= 64
                && current.contradictionScore <= 0.32) {
            return PrimaryAfterSecondary.PRIMARY_MAINTAINED;
        }
        if (delta >= -20 && current.aurumScore >= 56
                && current.contradictionScore <= 0.42) {
            return PrimaryAfterSecondary.PRIMARY_WEAKENED;
        }
        return PrimaryAfterSecondary.PRIMARY_INVALIDATED;
    }

    public static boolean isMissedOpportunity(ConfluenceVerdict.Decision decision,
                                              List<Integer> coverage,
                                              int result,
                                              boolean entryReleased) {
        return decision == ConfluenceVerdict.Decision.PREPARE
                && !entryReleased && coverage != null && coverage.contains(result);
    }

    private static int overlap(List<Integer> first, List<Integer> second) {
        if (first == null || second == null) return 0;
        int count = 0;
        for (int number : first) if (second.contains(number)) count++;
        return count;
    }
}
