package com.xspaceart.radar30;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public final class CalibrationActivity extends Activity {
    private CropSelectionView cropView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bitmap screenshot = CaptureRepository.getLatestCopy();
        if (screenshot == null) {
            Toast.makeText(this, "Ainda não há uma imagem capturada. Inicie a leitura e abra a mesa.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
        root.setBackgroundColor(Ui.BG);

        TextView title = Ui.text(this, "Calibrar • " + AppStateStore.provider(this),
                21, Ui.TEXT, true);
        root.addView(title);
        TextView help = Ui.text(this,
                "Arraste para marcar somente a grade de números. O topo deve conter o resultado mais recente. Para mover a seleção, arraste por dentro dela.",
                14, Ui.MUTED, false);
        root.addView(help, Ui.margins(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, this, 0, 6, 0, 12));

        cropView = new CropSelectionView(this);
        RectF saved = AppStateStore.isCalibrated(this) ? AppStateStore.getRoi(this)
                : new RectF(0.05f, 0.25f, 0.95f, 0.75f);
        cropView.setBitmap(screenshot, saved);
        root.addView(cropView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        Button cancel = Ui.button(this, "Cancelar", Ui.SURFACE, Ui.TEXT);
        Button save = Ui.button(this, "Salvar área", Ui.GREEN, Ui.BG);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        actions.addView(save, Ui.margins(0, ViewGroup.LayoutParams.WRAP_CONTENT, this, 10, 0, 0, 0));
        ((LinearLayout.LayoutParams) save.getLayoutParams()).weight = 1f;
        root.addView(actions, Ui.margins(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, this, 0, 12, 0, 0));

        cancel.setOnClickListener(v -> finish());
        save.setOnClickListener(v -> {
            RectF normalized = cropView.getNormalizedSelection();
            AppStateStore.saveRoi(this, normalized);
            Toast.makeText(this, "Área salva. Volte para a mesa.", Toast.LENGTH_LONG).show();
            finish();
        });

        setContentView(root);
    }

    @Override
    protected void onDestroy() {
        if (cropView != null) cropView.release();
        super.onDestroy();
    }
}
