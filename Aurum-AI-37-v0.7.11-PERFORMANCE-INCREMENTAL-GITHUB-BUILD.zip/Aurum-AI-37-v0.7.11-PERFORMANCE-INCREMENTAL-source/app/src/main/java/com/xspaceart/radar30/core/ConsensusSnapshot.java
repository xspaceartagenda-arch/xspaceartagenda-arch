package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * v0.7.7 — leitura de consenso espacial por família.
 *
 * <p>Cada família continua independente. Em vez de exigir que todas apontem
 * para o mesmo número, mede-se quanto os votos independentes convergem para
 * uma mesma região física de 5 casas (alvo + 2 vizinhos). Assim, famílias que
 * chamam 17, 25, 2 e 21 podem formar um único polo quando esses números
 * pertencem ao mesmo setor da roda.</p>
 */
public final class ConsensusSnapshot {
    public static final class FamilyVote {
        public final EvidenceFamily family;
        public final int nativeTarget;
        public final double relativeSupport;
        public final double localSupport;
        public final double weight;

        public FamilyVote(EvidenceFamily family, int nativeTarget,
                          double relativeSupport, double localSupport,
                          double weight) {
            this.family = family;
            this.nativeTarget = nativeTarget;
            this.relativeSupport = clamp01(relativeSupport);
            this.localSupport = clamp01(localSupport);
            this.weight = clamp01(weight);
        }
    }

    public static final class Candidate {
        public final int target;
        public final List<Integer> coverage;
        public final int score;
        public final int familyCount;
        public final double alignment;
        public final double contradiction;
        public final double localHeat;
        public final double currentContext;
        public final boolean predictive;
        public final boolean recent;
        public final List<FamilyVote> votes;

        public Candidate(int target, int score, int familyCount,
                         double alignment, double contradiction,
                         double localHeat, double currentContext,
                         boolean predictive, boolean recent,
                         List<FamilyVote> votes) {
            this.target = target;
            this.coverage = target < 0 ? Collections.emptyList()
                    : Collections.unmodifiableList(new ArrayList<>(Wheel.coverage(target, 2)));
            this.score = clampScore(score);
            this.familyCount = Math.max(0, familyCount);
            this.alignment = clamp01(alignment);
            this.contradiction = clamp01(contradiction);
            this.localHeat = clamp01(localHeat);
            this.currentContext = clamp01(currentContext);
            this.predictive = predictive;
            this.recent = recent;
            this.votes = votes == null ? Collections.emptyList()
                    : Collections.unmodifiableList(new ArrayList<>(votes));
        }

        public static Candidate empty() {
            return new Candidate(-1, 0, 0, 0.0, 1.0,
                    0.0, 0.0, false, false, Collections.emptyList());
        }
    }

    public final Candidate primary;
    public final Candidate secondary;
    public final Candidate third;
    public final double leaderMargin;
    public final int activeFamilies;

    public ConsensusSnapshot(Candidate primary, Candidate secondary,
                             Candidate third, double leaderMargin,
                             int activeFamilies) {
        this.primary = primary == null ? Candidate.empty() : primary;
        this.secondary = secondary == null ? Candidate.empty() : secondary;
        this.third = third == null ? Candidate.empty() : third;
        this.leaderMargin = clamp01(leaderMargin);
        this.activeFamilies = Math.max(0, activeFamilies);
    }

    public static ConsensusSnapshot empty() {
        return new ConsensusSnapshot(Candidate.empty(), Candidate.empty(),
                Candidate.empty(), 0.0, 0);
    }

    public static ConsensusSnapshot analyze(List<Evidence> evidence,
                                            double[] centralHeat) {
        if (evidence == null || evidence.isEmpty()) return empty();
        List<Candidate> ranked = new ArrayList<>();
        for (int center : Wheel.EUROPEAN) {
            ranked.add(analyzeCandidate(evidence, centralHeat, center));
        }
        ranked.sort(Comparator.comparingInt((Candidate c) -> c.score).reversed()
                .thenComparingInt(c -> c.target));

        List<Candidate> distinct = new ArrayList<>();
        for (Candidate candidate : ranked) {
            boolean separated = true;
            for (Candidate selected : distinct) {
                if (Wheel.distance(selected.target, candidate.target) < 5) {
                    separated = false;
                    break;
                }
            }
            if (separated) distinct.add(candidate);
            if (distinct.size() >= 3) break;
        }
        Candidate first = distinct.size() > 0 ? distinct.get(0) : Candidate.empty();
        Candidate second = distinct.size() > 1 ? distinct.get(1) : Candidate.empty();
        Candidate third = distinct.size() > 2 ? distinct.get(2) : Candidate.empty();
        double margin = first.score <= 0 ? 0.0
                : clamp01((first.score - second.score) / (double) first.score);
        return new ConsensusSnapshot(first, second, third, margin, evidence.size());
    }

    private static Candidate analyzeCandidate(List<Evidence> evidence,
                                              double[] centralHeat,
                                              int center) {
        List<FamilyVote> votes = new ArrayList<>();
        double alignedWeighted = 0.0;
        double voteWeight = 0.0;
        double contradictionWeighted = 0.0;
        double contextWeighted = 0.0;
        double contextWeight = 0.0;
        boolean predictive = false;
        boolean recent = false;

        for (Evidence item : evidence) {
            SectorPeak peak = bestSector(item.heat);
            if (peak.score <= 0.0) continue;
            double local = TargetRanking.sectorSupport(item.heat, center);
            double relative = clamp01(local / peak.score);
            double weight = clamp01(item.weight());
            int nativeDistance = Wheel.distance(peak.target, center);
            // O voto precisa nascer perto do polo. Isso evita que heatmaps largos
            // deem "consenso" artificial para vários setores ao mesmo tempo.
            boolean insideCandidateSector = nativeDistance <= 2;
            boolean shoulderOverlap = nativeDistance == 3 && relative >= 0.92;
            boolean spatiallyNative = insideCandidateSector || shoulderOverlap;
            // Se o pico NATIVO da família cai dentro das 5 casas do candidato,
            // ele é um voto espacial legítimo mesmo que o heatmap daquela família
            // seja estreito. É exatamente o denominador comum 21/2/25/17/34.
            double minimumRelative = insideCandidateSector ? 0.42 : 0.92;
            double minimumLocal = insideCandidateSector ? 0.16 : 0.30;
            boolean vote = spatiallyNative && relative >= minimumRelative
                    && local >= minimumLocal && weight >= 0.10
                    && (peak.margin >= 0.025 || relative >= 0.88);
            if (!vote) continue;

            double distanceQuality = insideCandidateSector
                    ? (nativeDistance == 0 ? 1.0 : nativeDistance == 1 ? 0.94 : 0.86)
                    : 0.80;
            double voteQuality = (0.58 * relative + 0.42 * distanceQuality)
                    * (0.76 + 0.24 * clamp01(peak.margin / 0.20));
            votes.add(new FamilyVote(item.family, peak.target, voteQuality, local, weight));
            alignedWeighted += voteQuality * weight;
            voteWeight += weight;
            contradictionWeighted += weight * ((1.0 - relative) * 0.65
                    + item.contradiction * 0.35);

            if (isRecent(item.family)) {
                contextWeighted += relative * weight;
                contextWeight += weight;
                recent = true;
            }
            if (isPredictive(item.family)) predictive = true;
        }

        votes.sort(Comparator.comparingDouble((FamilyVote v) -> v.relativeSupport * v.weight)
                .reversed().thenComparing(v -> v.family.name()));
        int families = votes.size();
        double alignment = voteWeight <= 0.0 ? 0.0 : clamp01(alignedWeighted / voteWeight);
        double contradiction = voteWeight <= 0.0 ? 1.0
                : clamp01(contradictionWeighted / voteWeight);
        double context = contextWeight <= 0.0 ? 0.0
                : clamp01(contextWeighted / contextWeight);
        double breadth = clamp01((families - 1.0) / 5.0);
        double localHeat = TargetRanking.sectorSupport(centralHeat, center);

        // O consenso não pune a entropia global, mas exige origem espacial real
        // dos votos. O score fica deliberadamente conservador: 60+ já significa
        // que várias famílias independentes estão de fato no mesmo setor.
        double quality = 0.29 * alignment
                + 0.27 * breadth
                + 0.18 * localHeat
                + 0.12 * context
                + 0.14 * (1.0 - contradiction);
        if (!predictive) quality -= 0.07;
        if (!recent) quality -= 0.05;
        if (families < 4) quality -= 0.12;
        int score = clampScore((int) Math.round(quality * 100.0));
        return new Candidate(center, score, families, alignment, contradiction,
                localHeat, context, predictive, recent, votes);
    }

    private static SectorPeak bestSector(double[] heat) {
        int target = -1;
        double score = -1.0;
        for (int center : Wheel.EUROPEAN) {
            double value = TargetRanking.sectorSupport(heat, center);
            if (value > score) {
                score = value;
                target = center;
            }
        }
        double runner = 0.0;
        if (target >= 0) {
            for (int center : Wheel.EUROPEAN) {
                if (Wheel.distance(target, center) < 5) continue;
                runner = Math.max(runner, TargetRanking.sectorSupport(heat, center));
            }
        }
        double margin = score <= 0.0 ? 0.0 : clamp01((score - runner) / score);
        return new SectorPeak(target, Math.max(0.0, score), margin);
    }

    private static boolean isPredictive(EvidenceFamily family) {
        return family == EvidenceFamily.TRANSITION
                || family == EvidenceFamily.SEQUENCE
                || family == EvidenceFamily.HISTORICAL_SIMILARITY
                || family == EvidenceFamily.WHEEL_GEOMETRY
                || family == EvidenceFamily.ARITHMETIC;
    }

    private static boolean isRecent(EvidenceFamily family) {
        return family == EvidenceFamily.RECENCY
                || family == EvidenceFamily.REGIME
                || family == EvidenceFamily.TRANSITION;
    }

    private static int clampScore(int value) {
        return Math.max(0, Math.min(100, value));
    }

    private static double clamp01(double value) {
        if (!Double.isFinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }

    private static final class SectorPeak {
        final int target;
        final double score;
        final double margin;
        SectorPeak(int target, double score, double margin) {
            this.target = target;
            this.score = score;
            this.margin = margin;
        }
    }
}
