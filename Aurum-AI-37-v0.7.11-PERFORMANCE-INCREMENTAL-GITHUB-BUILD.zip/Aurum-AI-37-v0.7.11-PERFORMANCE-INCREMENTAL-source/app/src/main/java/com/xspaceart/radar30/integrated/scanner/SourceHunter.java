package com.xspaceart.radar30.integrated.scanner;

/**
 * Semantic DOM scanner. v0.7.4 only accepts history-shaped numeric cell groups; broad
 * container text is a low-confidence fallback and can no longer win merely by containing
 * many values between 0 and 36.
 */
public final class SourceHunter {
    private SourceHunter() {}

    public static String discoveryScript(String lockedSignature) {
        String wanted = js(lockedSignature == null ? "" : lockedSignature);
        return "(function(){try{" +
                "var wanted=\"" + wanted + "\";" +
                "var best=null,locked=null,scanned=0,accessible=0,blocked=0,candidates=0;" +
                "var context={history:0,current:0,race:0,timeline:0,stats:0,bet:0,balance:0,controls:0,ignored:0};" +
                "function txt(e){try{return ((e.innerText||e.textContent||'')+'').trim();}catch(x){return '';}}" +
                "function meta(e){var p=e&&e.parentElement;return (((e.id||'')+' '+(typeof e.className==='string'?e.className:'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('data-testid')||'')+' '+(e.getAttribute('data-name')||'')+' '+(e.getAttribute('data-type')||'')+' '+(e.getAttribute('role')||'')+' '+(e.getAttribute('title')||''))+' '+(p?((p.id||'')+' '+(typeof p.className==='string'?p.className:'')+' '+(p.getAttribute('aria-label')||'')+' '+(p.getAttribute('data-testid')||'')):'')).toLowerCase();}" +
                "function valid(v){return /^(?:[0-9]|[12][0-9]|3[0-6])$/.test((v==null?'':String(v)).trim());}" +
                "function negative(m){return /race.?track|racetrack|voisins|orphelins|tiers|neighbors?|vizinhos|wheel.?sector|statistics?|estat[ií]st|hot.?numbers?|cold.?numbers?|frequency|distribution|percent|porcent|balance|saldo|wallet|cash|credit|deposit|withdraw|bet.?grid|betting|bets?|stake|chips?|wager|payout|odds|straight|split|street|corner|dozen|column|timer|countdown|seconds?|remaining.?time|toolbar|menu/.test(m||'');}" +
                "function cls(m){" +
                "if(/race.?track|racetrack|voisins|orphelins|tiers|neighbors?|vizinhos|wheel.?sector/.test(m))return 'RACETRACK';" +
                "if(/statistics?|estat[ií]st|hot.?numbers?|cold.?numbers?|frequency|distribution|percent|porcent/.test(m))return 'STATISTICS';" +
                "if(/balance|saldo|wallet|cash|credit|currency|deposit|withdraw/.test(m))return 'BALANCE_VALUES';" +
                "if(/bet.?grid|betting|bets?|stake|chips?|wager|payout|odds|straight|split|street|corner|dozen|column/.test(m))return 'BETTING_TABLE';" +
                "if(/timeline|roadmap|trend.?line/.test(m))return 'TIMELINE';" +
                "if(/timer|countdown|seconds?|remaining.?time|controls?|button|toolbar|menu/.test(m))return 'CONTROLS';" +
                "if(/current.?result|last.?result|winner|winning.?number|latest.?number/.test(m))return 'CURRENT_RESULT';" +
                "if(/history|recent.?results?|result.?history|spin.?history|previous.?results?|last.?spins?|winning.?numbers?|outcomes?/.test(m))return 'HISTORY';" +
                "return 'IGNORE';}" +
                "function one(e){try{var attrs=['data-number','data-value','data-result','data-outcome'];for(var i=0;i<attrs.length;i++){var v=e.getAttribute&&e.getAttribute(attrs[i]);if(valid(v))return parseInt(v,10);}var t=txt(e);if(valid(t))return parseInt(t,10);}catch(x){}return -1;}" +
                "function wheelish(a){if(a.length!==37)return false;var seen={};for(var i=0;i<a.length;i++)seen[a[i]]=1;return Object.keys(seen).length===37;}" +
                "function structured(e){var groups=new Map(),nodes=[];try{nodes=e.querySelectorAll('[data-number],[data-value],[data-result],[data-outcome],span,li,div');}catch(x){}" +
                "function add(k,v,attr){if(!k||k===document||k===document.documentElement)return;var g=groups.get(k);if(!g){g={vals:[],attrs:0};groups.set(k,g);}g.vals.push(v);if(attr)g.attrs++;}" +
                "for(var i=0;i<nodes.length;i++){var n=nodes[i],v=one(n);if(v<0)continue;var nm=meta(n);if(negative(nm))continue;var hasAttr=false;try{hasAttr=valid(n.getAttribute('data-number'))||valid(n.getAttribute('data-value'))||valid(n.getAttribute('data-result'))||valid(n.getAttribute('data-outcome'));}catch(x){}var nt=txt(n);if(!hasAttr&&!valid(nt))continue;var p=n.parentElement;add(p,v,hasAttr);if(p&&p.parentElement&&p.parentElement!==e.parentElement)add(p.parentElement,v,hasAttr);}" +
                "var best=null;groups.forEach(function(g,k){var a=g.vals;if(a.length<6||a.length>120)return;var pm=meta(k);if(negative(pm))return;var d={};for(var j=0;j<a.length;j++)d[a[j]]=1;var dn=Object.keys(d).length;var s=42+Math.min(18,a.length)+Math.min(14,g.attrs*2);if(/history|recent.?results?|result.?history|spin.?history|previous.?results?|last.?spins?|winning.?numbers?|outcomes?/.test(pm))s+=18;if(dn>=6)s+=7;if(a.length>=10&&dn<=3)s-=35;if(wheelish(a))s-=90;s=Math.max(0,Math.min(100,s));if(!best||s>best.score||(s===best.score&&a.length>best.vals.length))best={vals:a.slice(0,120),score:s};});" +
                "return best||{vals:[],score:0};}" +
                "function extract(e,t,m){var st=structured(e);if(st.vals.length>=6&&st.score>=55)return {vals:st.vals,mode:'CELLS',structure:st.score};" +
                "if(!/history|recent.?results?|result.?history|spin.?history|previous.?results?|last.?spins?|winning.?numbers?|outcomes?/.test(m)||!t||t.length>700)return {vals:[],mode:'NONE',structure:0};" +
                "var hits=t.match(/(?:^|\\s|[^0-9])(3[0-6]|[12][0-9]|[0-9])(?=$|\\s|[^0-9])/g)||[],a=[];for(var i=0;i<hits.length;i++){var q=hits[i].match(/(3[0-6]|[12][0-9]|[0-9])/);if(q)a.push(parseInt(q[1],10));}if(a.length<8||a.length>40||wheelish(a))a=[];return {vals:a,mode:a.length?'TEXT':'NONE',structure:a.length?35:0};}" +
                "function sig(e,label,m){var tag=(e.tagName||'').toLowerCase();var id=e.id||'';var cl=typeof e.className==='string'?e.className:'';var dt=e.getAttribute('data-testid')||'';var ar=e.getAttribute('aria-label')||'';var role=e.getAttribute('role')||'';return (label+'|'+tag+'|'+id+'|'+cl+'|'+dt+'|'+ar+'|'+role).slice(0,700);}" +
                "function scoreCandidate(kind,m,ex,t){var ns=ex.vals;if(kind!=='HISTORY'||ns.length<8||ns.length>120)return 0;var s=35;if(/history|result.?history|spin.?history|previous.?results?/.test(m))s+=24;if(/recent|last.?spins?|winning.?numbers?|outcomes?/.test(m))s+=12;if(ex.mode==='CELLS')s+=24;else s-=12;s+=Math.min(12,Math.floor(ex.structure/8));var distinct={};for(var i=0;i<Math.min(ns.length,40);i++)distinct[ns[i]]=1;var d=Object.keys(distinct).length;if(ns.length>=12)s+=5;if(d>=6)s+=5;if(ns.length>=16&&d<=3)s-=45;if(wheelish(ns))s-=90;if(negative(m))s-=70;if(t.length>3500)s-=20;return Math.max(0,Math.min(100,s));}" +
                "function inspectRoot(root,label){if(!root||!root.querySelectorAll)return;var els=root.querySelectorAll('[class],[id],[aria-label],[data-testid],[data-number],[data-value],[data-result],[data-outcome],[data-name],[data-type],[role]');" +
                "for(var i=0;i<els.length;i++){var e=els[i];scanned++;var m=meta(e),kind=cls(m);if(kind==='HISTORY')context.history++;else if(kind==='CURRENT_RESULT')context.current++;else if(kind==='RACETRACK')context.race++;else if(kind==='TIMELINE')context.timeline++;else if(kind==='STATISTICS')context.stats++;else if(kind==='BETTING_TABLE')context.bet++;else if(kind==='BALANCE_VALUES')context.balance++;else if(kind==='CONTROLS')context.controls++;else context.ignored++;" +
                "if(kind==='HISTORY'){var t=txt(e);if(t&&t.length<=6000){var ex=extract(e,t,m),ns=ex.vals,conf=scoreCandidate(kind,m,ex,t);if(conf>=58){candidates++;var sg=sig(e,label,m),c={confidence:conf,history:ns,hint:(label+' '+m).slice(0,240),signature:sg,classification:kind,extractionMode:ex.mode,structureScore:ex.structure};if(wanted&&sg===wanted)locked=c;if(!best||conf>best.confidence||(conf===best.confidence&&ns.length>best.history.length))best=c;}}}" +
                "try{if(e.shadowRoot)inspectRoot(e.shadowRoot,label+' shadow');}catch(x){} }" +
                "var frames=root.querySelectorAll('iframe');for(var f=0;f<frames.length;f++){try{var d=frames[f].contentDocument;if(d&&d.documentElement){accessible++;inspectRoot(d,label+' iframe['+f+']');}else blocked++;}catch(x){blocked++;}}}" +
                "inspectRoot(document,'main');var chosen=locked||best;" +
                "var current=-1;try{var ces=document.querySelectorAll('[class],[id],[aria-label],[data-testid],[data-number],[data-value],[data-result],[data-outcome]');for(var z=0;z<ces.length;z++){var cm=meta(ces[z]);if(cls(cm)==='CURRENT_RESULT'){var cv=one(ces[z]);if(cv>=0){current=cv;break;}}}}catch(x){}" +
                "var out={url:location.href,title:document.title||'',iframes:document.querySelectorAll('iframe').length,accessibleFrames:accessible,blockedFrames:blocked,scannedNodes:scanned,candidates:candidates,history:chosen?chosen.history:[],hint:chosen?chosen.hint:'',signature:chosen?chosen.signature:'',classification:chosen?chosen.classification:'',confidence:chosen?chosen.confidence:0,extractionMode:chosen?chosen.extractionMode:'NONE',structureScore:chosen?chosen.structureScore:0,lockRequested:!!wanted,lockMatched:!!locked,currentResult:current,context:context};return JSON.stringify(out);" +
                "}catch(e){return JSON.stringify({error:String(e),url:location.href,title:document.title||'',iframes:0,accessibleFrames:0,blockedFrames:0,scannedNodes:0,candidates:0,history:[],hint:'',signature:'',classification:'',confidence:0,extractionMode:'NONE',structureScore:0,lockRequested:false,lockMatched:false,currentResult:-1,context:{}});}})();";
    }

    public static String discoveryScript() { return discoveryScript(""); }

    private static String js(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }
}
