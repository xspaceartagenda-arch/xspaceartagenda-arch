package com.xspaceart.radar30.integrated.scanner;

import java.util.List;

/** Compares two already-normalized newest-first sources allowing a small render lag. */
public final class HistoryAgreement {
    private HistoryAgreement() {}

    public static double score(List<Integer> a,List<Integer> b){
        if(a==null||b==null||a.size()<6||b.size()<6)return 0.0;
        double best=0.0;
        for(int oa=0;oa<=2;oa++)for(int ob=0;ob<=2;ob++){
            int compared=Math.min(24,Math.min(a.size()-oa,b.size()-ob));
            if(compared<6)continue;
            int equal=0;
            for(int i=0;i<compared;i++)if(a.get(oa+i).equals(b.get(ob+i)))equal++;
            best=Math.max(best,equal/(double)compared);
        }
        return best;
    }

    public static boolean corroborates(List<Integer> a,List<Integer> b){return score(a,b)>=0.78;}
}
