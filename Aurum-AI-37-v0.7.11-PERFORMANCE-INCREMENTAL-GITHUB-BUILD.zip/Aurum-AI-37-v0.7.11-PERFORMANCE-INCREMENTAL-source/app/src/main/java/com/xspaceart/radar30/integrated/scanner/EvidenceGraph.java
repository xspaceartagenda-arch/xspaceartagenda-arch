package com.xspaceart.radar30.integrated.scanner;

import java.util.LinkedHashMap;
import java.util.Map;

/** Rastreia fontes de captura para não apresentar representações duplicadas como fontes independentes. */
public final class EvidenceGraph {
    private final Map<String, Source> sources = new LinkedHashMap<>();

    public void upsert(String id, String type, double confidence, String fingerprint, String correlationGroup) {
        if (id == null || id.trim().isEmpty()) return;
        sources.put(id, new Source(type, clamp(confidence), fingerprint, correlationGroup, System.currentTimeMillis()));
    }

    public int sourceCount() { return sources.size(); }

    public int independentGroups() {
        java.util.HashSet<String> groups = new java.util.HashSet<>();
        for (Map.Entry<String, Source> e : sources.entrySet()) {
            String g = e.getValue().correlationGroup;
            groups.add(g == null || g.isEmpty() ? e.getKey() : g);
        }
        return groups.size();
    }

    private static double clamp(double v) { return Math.max(0.0, Math.min(1.0, v)); }

    private static final class Source {
        final String type, fingerprint, correlationGroup; final double confidence; final long updatedAt;
        Source(String type, double confidence, String fingerprint, String correlationGroup, long updatedAt) {
            this.type=type; this.confidence=confidence; this.fingerprint=fingerprint;
            this.correlationGroup=correlationGroup; this.updatedAt=updatedAt;
        }
    }
}
