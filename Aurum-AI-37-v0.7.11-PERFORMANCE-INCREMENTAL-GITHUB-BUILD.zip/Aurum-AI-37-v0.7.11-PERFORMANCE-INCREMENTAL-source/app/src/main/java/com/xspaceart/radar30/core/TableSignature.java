package com.xspaceart.radar30.core;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** DNA estatístico e físico de uma janela da mesa atual. */
public final class TableSignature {
    private static final Set<Integer> RED = redNumbers();

    public final int length;
    public final double[] wheelHeat;
    public final double[] terminals;
    public final double[] dozens;
    public final double[] columns;
    public final double redRate;
    public final double lowRate;
    public final double evenRate;
    public final double repeatRate;
    public final double alternationRate;
    public final double meanWheelDistance;
    public final double distanceSpread;
    public final double concentration;

    private TableSignature(int length, double[] wheelHeat, double[] terminals,
                           double[] dozens, double[] columns, double redRate,
                           double lowRate, double evenRate, double repeatRate,
                           double alternationRate, double meanWheelDistance,
                           double distanceSpread, double concentration) {
        this.length = length;
        this.wheelHeat = wheelHeat;
        this.terminals = terminals;
        this.dozens = dozens;
        this.columns = columns;
        this.redRate = redRate;
        this.lowRate = lowRate;
        this.evenRate = evenRate;
        this.repeatRate = repeatRate;
        this.alternationRate = alternationRate;
        this.meanWheelDistance = meanWheelDistance;
        this.distanceSpread = distanceSpread;
        this.concentration = concentration;
    }

    public static TableSignature from(List<Integer> history, int start, int end) {
        int safeStart = Math.max(0, start);
        int safeEnd = Math.max(safeStart, Math.min(history == null ? 0 : history.size(), end));
        int length = safeEnd - safeStart;
        double[] wheel = new double[37];
        double[] terminal = new double[10];
        double[] dozen = new double[3];
        double[] column = new double[3];
        if (length == 0) {
            return new TableSignature(0, wheel, terminal, dozen, column,
                    0, 0, 0, 0, 0, 0, 0, 0);
        }

        int red = 0;
        int low = 0;
        int even = 0;
        int nonZero = 0;
        int repeats = 0;
        int alternations = 0;
        int comparableColors = 0;
        double distanceSum = 0.0;
        double distanceSquared = 0.0;
        int distances = 0;
        for (int i = safeStart; i < safeEnd; i++) {
            int number = history.get(i);
            addWheelKernel(wheel, number, 1.0);
            terminal[number % 10] += 1.0;
            if (number > 0) {
                nonZero++;
                if (RED.contains(number)) red++;
                if (number <= 18) low++;
                if (number % 2 == 0) even++;
                dozen[(number - 1) / 12] += 1.0;
                column[(number - 1) % 3] += 1.0;
            }
            if (i + 1 < safeEnd) {
                int older = history.get(i + 1);
                if (number == older) repeats++;
                int distance = Wheel.distance(number, older);
                distanceSum += distance;
                distanceSquared += distance * distance;
                distances++;
                if (number != 0 && older != 0) {
                    comparableColors++;
                    if (RED.contains(number) != RED.contains(older)) alternations++;
                }
            }
        }
        normalize(wheel);
        normalize(terminal);
        normalize(dozen);
        normalize(column);
        double mean = distances == 0 ? 0.0 : distanceSum / distances;
        double variance = distances == 0 ? 0.0
                : Math.max(0.0, distanceSquared / distances - mean * mean);
        return new TableSignature(length, wheel, terminal, dozen, column,
                ratio(red, nonZero), ratio(low, nonZero), ratio(even, nonZero),
                ratio(repeats, Math.max(0, length - 1)),
                ratio(alternations, comparableColors), mean / 18.0,
                Math.sqrt(variance) / 9.0, 1.0 - normalizedEntropy(wheel));
    }

    public double similarity(TableSignature other) {
        if (other == null || length == 0 || other.length == 0) return 0.0;
        double distribution = 0.46 * cosine(wheelHeat, other.wheelHeat)
                + 0.15 * cosine(terminals, other.terminals)
                + 0.08 * cosine(dozens, other.dozens)
                + 0.08 * cosine(columns, other.columns);
        double scalar = averageSimilarity(
                redRate, other.redRate,
                lowRate, other.lowRate,
                evenRate, other.evenRate,
                repeatRate, other.repeatRate,
                alternationRate, other.alternationRate,
                meanWheelDistance, other.meanWheelDistance,
                distanceSpread, other.distanceSpread,
                concentration, other.concentration);
        return clamp01(distribution + 0.23 * scalar);
    }

    public double entropy() {
        return normalizedEntropy(wheelHeat);
    }

    private static void addWheelKernel(double[] target, int number, double weight) {
        int index = Wheel.EUROPEAN.indexOf(number);
        if (index < 0) return;
        int size = Wheel.EUROPEAN.size();
        int[] offsets = {0, -1, 1, -2, 2};
        double[] weights = {1.0, 0.52, 0.52, 0.20, 0.20};
        for (int i = 0; i < offsets.length; i++) {
            int position = (index + offsets[i] + size) % size;
            target[Wheel.EUROPEAN.get(position)] += weight * weights[i];
        }
    }

    private static double averageSimilarity(double... values) {
        double total = 0.0;
        int pairs = values.length / 2;
        for (int i = 0; i + 1 < values.length; i += 2) {
            total += 1.0 - Math.min(1.0, Math.abs(values[i] - values[i + 1]));
        }
        return pairs == 0 ? 0.0 : total / pairs;
    }

    static double cosine(double[] a, double[] b) {
        double dot = 0.0;
        double aa = 0.0;
        double bb = 0.0;
        int end = Math.min(a.length, b.length);
        for (int i = 0; i < end; i++) {
            dot += a[i] * b[i];
            aa += a[i] * a[i];
            bb += b[i] * b[i];
        }
        if (aa <= 0.0 || bb <= 0.0) return 0.0;
        return clamp01(dot / Math.sqrt(aa * bb));
    }

    static double normalizedEntropy(double[] values) {
        double total = 0.0;
        for (double value : values) total += Math.max(0.0, value);
        if (total <= 0.0) return 1.0;
        double entropy = 0.0;
        int positive = 0;
        for (double value : values) {
            if (value <= 0.0) continue;
            positive++;
            double p = value / total;
            entropy -= p * Math.log(p);
        }
        if (positive <= 1) return 0.0;
        return clamp01(entropy / Math.log(values.length));
    }

    private static void normalize(double[] values) {
        double total = 0.0;
        for (double value : values) total += value;
        if (total <= 0.0) return;
        for (int i = 0; i < values.length; i++) values[i] /= total;
    }

    private static double ratio(int numerator, int denominator) {
        return denominator <= 0 ? 0.0 : numerator / (double) denominator;
    }

    private static double clamp01(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }

    private static Set<Integer> redNumbers() {
        int[] values = {1, 3, 5, 7, 9, 12, 14, 16, 18,
                19, 21, 23, 25, 27, 30, 32, 34, 36};
        Set<Integer> result = new HashSet<>();
        for (int value : values) result.add(value);
        return result;
    }
}
