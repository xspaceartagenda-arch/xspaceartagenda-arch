package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Limites e normalização do histórico pertencente à mesa/sessão atual.
 *
 * <p>O banco de sessões antigas não passa por esta classe. Ele é uma fonte de
 * comparação e validação, nunca uma continuação silenciosa da mesa aberta.</p>
 */
public final class CurrentTableHistory {
    public static final int MAX_RESULTS = 500;
    public static final int MIN_DEEP_SCAN_RESULTS = 36;

    private CurrentTableHistory() {}

    public static List<Integer> clean(List<Integer> source) {
        return clean(source, MAX_RESULTS);
    }

    public static List<Integer> clean(List<Integer> source, int limit) {
        List<Integer> result = new ArrayList<>();
        if (source == null) return result;
        int safeLimit = Math.max(0, Math.min(MAX_RESULTS, limit));
        if (safeLimit == 0) return result;
        for (Integer number : source) {
            if (number != null && Wheel.valid(number)) result.add(number);
            if (result.size() >= safeLimit) break;
        }
        return result;
    }
}
