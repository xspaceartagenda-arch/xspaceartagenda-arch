package com.xspaceart.radar30;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

public final class CropSelectionView extends View {
    private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint shadePaint = new Paint();
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF display = new RectF();
    private final RectF selection = new RectF();
    private final RectF original = new RectF();
    private Bitmap bitmap;
    private float downX;
    private float downY;
    private boolean moving;

    public CropSelectionView(Context context) {
        super(context);
        shadePaint.setColor(Color.argb(165, 0, 0, 0));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(Ui.dp(context, 3));
        borderPaint.setColor(Ui.GREEN);
        handlePaint.setColor(Ui.AMBER);
        setBackgroundColor(Ui.BG);
    }

    public void setBitmap(Bitmap bitmap, RectF normalized) {
        this.bitmap = bitmap;
        post(() -> {
            updateDisplayRect();
            if (normalized != null) fromNormalized(normalized);
            invalidate();
        });
    }

    public RectF getNormalizedSelection() {
        if (display.isEmpty() || selection.isEmpty()) return new RectF(0.05f, 0.25f, 0.95f, 0.75f);
        return new RectF(
                clamp((selection.left - display.left) / display.width()),
                clamp((selection.top - display.top) / display.height()),
                clamp((selection.right - display.left) / display.width()),
                clamp((selection.bottom - display.top) / display.height()));
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        RectF normalized = getNormalizedSelection();
        updateDisplayRect();
        fromNormalized(normalized);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bitmap == null || bitmap.isRecycled() || display.isEmpty()) return;
        canvas.drawBitmap(bitmap, null, display, bitmapPaint);
        if (selection.isEmpty()) return;

        canvas.drawRect(display.left, display.top, display.right, selection.top, shadePaint);
        canvas.drawRect(display.left, selection.bottom, display.right, display.bottom, shadePaint);
        canvas.drawRect(display.left, selection.top, selection.left, selection.bottom, shadePaint);
        canvas.drawRect(selection.right, selection.top, display.right, selection.bottom, shadePaint);
        canvas.drawRoundRect(selection, Ui.dp(getContext(), 8), Ui.dp(getContext(), 8), borderPaint);
        float radius = Ui.dp(getContext(), 6);
        canvas.drawCircle(selection.left, selection.top, radius, handlePaint);
        canvas.drawCircle(selection.right, selection.top, radius, handlePaint);
        canvas.drawCircle(selection.left, selection.bottom, radius, handlePaint);
        canvas.drawCircle(selection.right, selection.bottom, radius, handlePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = bound(event.getX(), display.left, display.right);
        float y = bound(event.getY(), display.top, display.bottom);
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                moving = selection.contains(x, y);
                original.set(selection);
                if (!moving) selection.set(x, y, x, y);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (moving) {
                    float dx = x - downX;
                    float dy = y - downY;
                    selection.set(original);
                    selection.offset(dx, dy);
                    keepInside(selection, display);
                } else {
                    selection.set(Math.min(downX, x), Math.min(downY, y),
                            Math.max(downX, x), Math.max(downY, y));
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                float minimum = Ui.dp(getContext(), 50);
                if (selection.width() < minimum || selection.height() < minimum) selection.set(original);
                invalidate();
                return true;
            default:
                return super.onTouchEvent(event);
        }
    }

    public void release() {
        if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        bitmap = null;
    }

    private void updateDisplayRect() {
        if (bitmap == null || getWidth() == 0 || getHeight() == 0) return;
        float scale = Math.min(getWidth() / (float) bitmap.getWidth(), getHeight() / (float) bitmap.getHeight());
        float width = bitmap.getWidth() * scale;
        float height = bitmap.getHeight() * scale;
        float left = (getWidth() - width) / 2f;
        float top = (getHeight() - height) / 2f;
        display.set(left, top, left + width, top + height);
    }

    private void fromNormalized(RectF value) {
        if (display.isEmpty()) return;
        selection.set(
                display.left + display.width() * value.left,
                display.top + display.height() * value.top,
                display.left + display.width() * value.right,
                display.top + display.height() * value.bottom);
    }

    private static void keepInside(RectF rect, RectF bounds) {
        if (rect.left < bounds.left) rect.offset(bounds.left - rect.left, 0);
        if (rect.top < bounds.top) rect.offset(0, bounds.top - rect.top);
        if (rect.right > bounds.right) rect.offset(bounds.right - rect.right, 0);
        if (rect.bottom > bounds.bottom) rect.offset(0, bounds.bottom - rect.bottom);
    }

    private static float bound(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
