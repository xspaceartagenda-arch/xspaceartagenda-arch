package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Resultado único da fusão de todas as famílias do Precision Mode. */
public final class ConfluenceVerdict {
    public enum Decision { NO_READING, OBSERVE, PREPARE, ENTRY }
    public enum Mode { PRECISION, BALANCED }

    public final Decision decision;
    public final int target;
    public final List<Integer> coverage;
    public final List<Integer> nucleus;
    public final int aurumScore;
    public final int independentFamilies;
    public final double contradictionScore;
    public final double dominanceMargin;
    public final double evidenceDispersion;
    public final double leaderScore;
    public final double secondPlaceScore;
    public final RegimeDetector.Snapshot regime;
    public final List<EvidenceFamily> supportingFamilies;
    public final List<String> reasons;
    public final List<String> featureKeys;
    public final double[] heatMap;
    public final boolean precisionQualified;
    public final boolean balancedQualified;
    public final boolean entryQualified;
    public final Mode mode;
    public final int secondaryTarget;
    public final List<Integer> secondaryCoverage;
    public final List<Integer> secondaryNucleus;
    public final int secondaryScore;
    public final int secondaryFamilies;
    public final double secondaryContradiction;
    public final double secondaryMargin;
    public final double dualDominance;
    public final int thirdTarget;
    public final int thirdScore;
    public final double thirdPlaceScore;
    public final TargetRanking.SpatialRegime spatialRegime;
    public final TargetRanking.SignalShape signalShape;
    public final List<EvidenceFamily> secondarySupportingFamilies;
    public final List<String> secondaryReasons;
    public final boolean secondaryQualified;
    public final ConsensusSnapshot consensus;
    public final TerminalSnapshot terminal;

    public ConfluenceVerdict(Decision decision, int target,
                             List<Integer> coverage, List<Integer> nucleus,
                             int aurumScore, int independentFamilies,
                             double contradictionScore, double dominanceMargin,
                             double evidenceDispersion, double leaderScore,
                             double secondPlaceScore,
                             RegimeDetector.Snapshot regime,
                             List<EvidenceFamily> supportingFamilies,
                             List<String> reasons, List<String> featureKeys,
                             double[] heatMap, boolean precisionQualified) {
        this(decision, target, coverage, nucleus, aurumScore,
                independentFamilies, contradictionScore, dominanceMargin,
                evidenceDispersion, leaderScore, secondPlaceScore, regime,
                supportingFamilies, reasons, featureKeys, heatMap,
                precisionQualified, precisionQualified, precisionQualified,
                Mode.PRECISION, -1, Collections.emptyList(),
                Collections.emptyList(), 0, 0, 1.0, 0.0, 0.0,
                -1, 0, 0.0, TargetRanking.SpatialRegime.DISPERSED,
                TargetRanking.SignalShape.SINGLE_TARGET,
                Collections.emptyList(), Collections.emptyList(), false,
                ConsensusSnapshot.empty());
    }

    public ConfluenceVerdict(Decision decision, int target,
                             List<Integer> coverage, List<Integer> nucleus,
                             int aurumScore, int independentFamilies,
                             double contradictionScore, double dominanceMargin,
                             double evidenceDispersion, double leaderScore,
                             double secondPlaceScore,
                             RegimeDetector.Snapshot regime,
                             List<EvidenceFamily> supportingFamilies,
                             List<String> reasons, List<String> featureKeys,
                             double[] heatMap, boolean precisionQualified,
                             boolean balancedQualified, boolean entryQualified,
                             Mode mode, int secondaryTarget,
                             List<Integer> secondaryCoverage,
                             List<Integer> secondaryNucleus,
                             int secondaryScore, int secondaryFamilies,
                             double secondaryContradiction,
                             double secondaryMargin, double dualDominance,
                             int thirdTarget, int thirdScore,
                             double thirdPlaceScore,
                             TargetRanking.SpatialRegime spatialRegime,
                             TargetRanking.SignalShape signalShape,
                             List<EvidenceFamily> secondarySupportingFamilies,
                             List<String> secondaryReasons,
                             boolean secondaryQualified) {
        this(decision, target, coverage, nucleus, aurumScore, independentFamilies,
                contradictionScore, dominanceMargin, evidenceDispersion, leaderScore,
                secondPlaceScore, regime, supportingFamilies, reasons, featureKeys, heatMap,
                precisionQualified, balancedQualified, entryQualified, mode, secondaryTarget,
                secondaryCoverage, secondaryNucleus, secondaryScore, secondaryFamilies,
                secondaryContradiction, secondaryMargin, dualDominance, thirdTarget, thirdScore,
                thirdPlaceScore, spatialRegime, signalShape, secondarySupportingFamilies,
                secondaryReasons, secondaryQualified, ConsensusSnapshot.empty());
    }

    public ConfluenceVerdict(Decision decision, int target,
                             List<Integer> coverage, List<Integer> nucleus,
                             int aurumScore, int independentFamilies,
                             double contradictionScore, double dominanceMargin,
                             double evidenceDispersion, double leaderScore,
                             double secondPlaceScore,
                             RegimeDetector.Snapshot regime,
                             List<EvidenceFamily> supportingFamilies,
                             List<String> reasons, List<String> featureKeys,
                             double[] heatMap, boolean precisionQualified,
                             boolean balancedQualified, boolean entryQualified,
                             Mode mode, int secondaryTarget,
                             List<Integer> secondaryCoverage,
                             List<Integer> secondaryNucleus,
                             int secondaryScore, int secondaryFamilies,
                             double secondaryContradiction,
                             double secondaryMargin, double dualDominance,
                             int thirdTarget, int thirdScore,
                             double thirdPlaceScore,
                             TargetRanking.SpatialRegime spatialRegime,
                             TargetRanking.SignalShape signalShape,
                             List<EvidenceFamily> secondarySupportingFamilies,
                             List<String> secondaryReasons,
                             boolean secondaryQualified,
                             ConsensusSnapshot consensus) {
        this(decision, target, coverage, nucleus, aurumScore, independentFamilies,
                contradictionScore, dominanceMargin, evidenceDispersion, leaderScore,
                secondPlaceScore, regime, supportingFamilies, reasons, featureKeys, heatMap,
                precisionQualified, balancedQualified, entryQualified, mode, secondaryTarget,
                secondaryCoverage, secondaryNucleus, secondaryScore, secondaryFamilies,
                secondaryContradiction, secondaryMargin, dualDominance, thirdTarget, thirdScore,
                thirdPlaceScore, spatialRegime, signalShape, secondarySupportingFamilies,
                secondaryReasons, secondaryQualified, consensus, TerminalSnapshot.empty());
    }

    public ConfluenceVerdict(Decision decision, int target,
                             List<Integer> coverage, List<Integer> nucleus,
                             int aurumScore, int independentFamilies,
                             double contradictionScore, double dominanceMargin,
                             double evidenceDispersion, double leaderScore,
                             double secondPlaceScore,
                             RegimeDetector.Snapshot regime,
                             List<EvidenceFamily> supportingFamilies,
                             List<String> reasons, List<String> featureKeys,
                             double[] heatMap, boolean precisionQualified,
                             boolean balancedQualified, boolean entryQualified,
                             Mode mode, int secondaryTarget,
                             List<Integer> secondaryCoverage,
                             List<Integer> secondaryNucleus,
                             int secondaryScore, int secondaryFamilies,
                             double secondaryContradiction,
                             double secondaryMargin, double dualDominance,
                             int thirdTarget, int thirdScore,
                             double thirdPlaceScore,
                             TargetRanking.SpatialRegime spatialRegime,
                             TargetRanking.SignalShape signalShape,
                             List<EvidenceFamily> secondarySupportingFamilies,
                             List<String> secondaryReasons,
                             boolean secondaryQualified,
                             ConsensusSnapshot consensus,
                             TerminalSnapshot terminal) {
        this.decision = decision;
        this.target = target;
        this.coverage = immutable(coverage);
        this.nucleus = immutable(nucleus);
        this.aurumScore = Math.max(0, Math.min(100, aurumScore));
        this.independentFamilies = Math.max(0, independentFamilies);
        this.contradictionScore = clamp01(contradictionScore);
        this.dominanceMargin = clamp01(dominanceMargin);
        this.evidenceDispersion = clamp01(evidenceDispersion);
        this.leaderScore = clamp01(leaderScore);
        this.secondPlaceScore = clamp01(secondPlaceScore);
        this.regime = regime;
        this.supportingFamilies = supportingFamilies == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(supportingFamilies));
        this.reasons = reasons == null ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(reasons));
        this.featureKeys = featureKeys == null ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(featureKeys));
        this.heatMap = heatMap == null ? new double[37] : heatMap.clone();
        this.precisionQualified = precisionQualified;
        this.balancedQualified = balancedQualified;
        this.entryQualified = entryQualified;
        this.mode = mode == null ? Mode.PRECISION : mode;
        this.secondaryTarget = secondaryTarget;
        this.secondaryCoverage = immutable(secondaryCoverage);
        this.secondaryNucleus = immutable(secondaryNucleus);
        this.secondaryScore = Math.max(0, Math.min(100, secondaryScore));
        this.secondaryFamilies = Math.max(0, secondaryFamilies);
        this.secondaryContradiction = clamp01(secondaryContradiction);
        this.secondaryMargin = clamp01(secondaryMargin);
        this.dualDominance = clamp01(dualDominance);
        this.thirdTarget = thirdTarget;
        this.thirdScore = Math.max(0, Math.min(100, thirdScore));
        this.thirdPlaceScore = clamp01(thirdPlaceScore);
        this.spatialRegime = spatialRegime == null
                ? TargetRanking.SpatialRegime.DISPERSED : spatialRegime;
        this.signalShape = signalShape == null
                ? TargetRanking.SignalShape.SINGLE_TARGET : signalShape;
        this.secondarySupportingFamilies = secondarySupportingFamilies == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(secondarySupportingFamilies));
        this.secondaryReasons = secondaryReasons == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(secondaryReasons));
        this.secondaryQualified = secondaryQualified;
        this.consensus = consensus == null ? ConsensusSnapshot.empty() : consensus;
        this.terminal = terminal == null ? TerminalSnapshot.empty() : terminal;
    }

    public static ConfluenceVerdict insufficient(int count) {
        return insufficient(count, Mode.PRECISION);
    }

    public static ConfluenceVerdict insufficient(int count, Mode mode) {
        List<String> reasons = Collections.singletonList(
                "Carregando contexto da mesa: " + count + "/"
                        + CurrentTableHistory.MIN_DEEP_SCAN_RESULTS);
        return new ConfluenceVerdict(Decision.NO_READING, -1,
                Collections.emptyList(), Collections.emptyList(), 0, 0,
                1.0, 0.0, 1.0, 0.0, 0.0,
                RegimeDetector.Snapshot.empty(), Collections.emptyList(),
                reasons, Collections.emptyList(), new double[37], false,
                false, false, mode, -1, Collections.emptyList(),
                Collections.emptyList(), 0, 0, 1.0, 0.0, 0.0,
                -1, 0, 0.0, TargetRanking.SpatialRegime.DISPERSED,
                TargetRanking.SignalShape.SINGLE_TARGET,
                Collections.emptyList(), Collections.emptyList(), false);
    }

    public String playLabel() {
        return target < 0 ? "" : target + " + 2 VIZINHOS";
    }

    public String secondaryPlayLabel() {
        return secondaryTarget < 0 ? "" : secondaryTarget + " + 2 VIZINHOS";
    }

    public boolean hasSecondary() {
        return secondaryQualified && secondaryTarget >= 0
                && !secondaryCoverage.isEmpty();
    }

    public List<Integer> combinedCoverage() {
        List<Integer> values = new ArrayList<>(coverage);
        if (hasSecondary()) {
            for (int number : secondaryCoverage) {
                if (!values.contains(number)) values.add(number);
            }
        }
        return Collections.unmodifiableList(values);
    }

    private static List<Integer> immutable(List<Integer> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        return Collections.unmodifiableList(new ArrayList<>(values));
    }

    private static double clamp01(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }
}
