package com.xspaceart.radar30.integrated.session;

import android.content.Context;
import android.content.SharedPreferences;

/** Estado operacional da sessão Integrated. Cada nova sessão começa isolada. */
public final class IntegratedSessionStore {
    private static final String P = "aurum_integrated_session";
    private IntegratedSessionStore() {}
    private static SharedPreferences p(Context c) { return c.getSharedPreferences(P, Context.MODE_PRIVATE); }

    public static void startNew(Context c, String url) {
        long now = System.currentTimeMillis();
        p(c).edit()
                .putLong("start", now)
                .remove("end")
                .putString("url", safe(url))
                .putInt("signals", 0)
                .putInt("strikes", 0)
                .putInt("losses", 0)
                .putInt("signal_serial", 0)
                .putInt("resolved_serial", -1)
                .putBoolean("finished", false)
                .putString("history", "")
                .apply();
    }

    /** Compatibilidade com a v0.7.1: não reinicia uma sessão já ativa ao navegar no WebView. */
    public static void start(Context c, String url) {
        if (startedAt(c) <= 0 || finished(c)) startNew(c, url);
        else if (url != null && !url.trim().isEmpty()) p(c).edit().putString("url", safe(url)).apply();
    }

    public static void recordSignal(Context c) {
        SharedPreferences s = p(c);
        int serial = s.getInt("signal_serial", 0) + 1;
        s.edit().putInt("signal_serial", serial)
                .putInt("signals", s.getInt("signals",0)+1)
                .putInt("resolved_serial", -1).apply();
    }

    /** Primeiro desfecho do sinal decide o placar; um secondary hit não pode virar loss depois. */
    public static void recordStrike(Context c, int coreSize) {
        SharedPreferences s = p(c); int serial=s.getInt("signal_serial",0);
        if (serial <= 0 || s.getInt("resolved_serial",-1)==serial) return;
        s.edit().putInt("strikes",s.getInt("strikes",0)+1).putInt("resolved_serial",serial)
                .putString("last_resolution_type","STRIKE").putInt("last_resolution_core_size",Math.max(0,coreSize)).apply();
    }

    public static void recordLoss(Context c, int coreSize) {
        SharedPreferences s = p(c); int serial=s.getInt("signal_serial",0);
        if (serial <= 0 || s.getInt("resolved_serial",-1)==serial) return;
        s.edit().putInt("losses",s.getInt("losses",0)+1).putInt("resolved_serial",serial)
                .putString("last_resolution_type","LOSS").putInt("last_resolution_core_size",Math.max(0,coreSize)).apply();
    }

    /** Se a correção altera exatamente o giro que resolveu o sinal, devolve-o a pendente. */
    public static void rollbackLatestResolutionIfAtSpin(Context c, int coreSize) {
        SharedPreferences s=p(c);
        if (s.getInt("last_resolution_core_size",-1)!=coreSize) return;
        String type=s.getString("last_resolution_type","");
        SharedPreferences.Editor e=s.edit().putInt("resolved_serial",-1)
                .remove("last_resolution_type").remove("last_resolution_core_size");
        if ("STRIKE".equals(type)) e.putInt("strikes",Math.max(0,s.getInt("strikes",0)-1));
        if ("LOSS".equals(type)) e.putInt("losses",Math.max(0,s.getInt("losses",0)-1));
        e.apply();
    }

    public static int signals(Context c) { return p(c).getInt("signals",0); }
    public static int strikes(Context c) { return p(c).getInt("strikes",0); }
    public static int losses(Context c) { return p(c).getInt("losses",0); }
    public static long startedAt(Context c) { return p(c).getLong("start",0); }
    public static long endedAt(Context c) { return p(c).getLong("end",0); }
    public static boolean finished(Context c) { return p(c).getBoolean("finished",false); }

    public static String finish(Context c, int spins) {
        long end=System.currentTimeMillis();
        String summary="Sinais "+signals(c)+" • STRIKE "+strikes(c)+" • LOSS "+losses(c)+" • Giros "+Math.max(0,spins);
        p(c).edit().putLong("end",end).putBoolean("finished",true).putString("last_summary",summary).apply();
        return summary;
    }


    public static void saveOperationalHistory(Context c, java.util.List<Integer> history) {
        StringBuilder b=new StringBuilder();
        if(history!=null) for(Integer n:history){ if(n==null||n<0||n>36) continue; if(b.length()>0)b.append(','); b.append(n); if(b.length()>2400)break; }
        p(c).edit().putString("history",b.toString()).apply();
    }

    public static java.util.List<Integer> loadOperationalHistory(Context c) {
        java.util.List<Integer> out=new java.util.ArrayList<>();
        String raw=p(c).getString("history","");
        if(raw==null||raw.trim().isEmpty())return out;
        for(String token:raw.split(",")){ try{int n=Integer.parseInt(token.trim());if(n>=0&&n<=36)out.add(n);}catch(NumberFormatException ignored){} }
        return out;
    }

    public static String lastSummary(Context c) { return p(c).getString("last_summary",""); }
    private static String safe(String s) { return s == null ? "" : s.trim(); }
}
