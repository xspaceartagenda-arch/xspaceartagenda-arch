package com.xspaceart.radar30.core;

/** Famílias independentes usadas na votação do mapa central. */
public enum EvidenceFamily {
    SEQUENCE,
    TRANSITION,
    WHEEL_GEOMETRY,
    TERMINAL,
    RECENCY,
    FREQUENCY,
    ARITHMETIC,
    HISTORICAL_SIMILARITY,
    REGIME,
    GAP,
    CLUSTER
}
