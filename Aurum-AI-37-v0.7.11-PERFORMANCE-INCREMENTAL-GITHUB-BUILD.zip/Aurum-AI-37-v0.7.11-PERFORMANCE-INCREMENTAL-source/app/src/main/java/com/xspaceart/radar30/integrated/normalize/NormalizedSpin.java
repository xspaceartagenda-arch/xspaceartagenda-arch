package com.xspaceart.radar30.integrated.normalize;

public final class NormalizedSpin {
    public final int number;
    public final long timestamp;
    public final String source;
    public final double confidence;
    public final int sequenceIndex;

    public NormalizedSpin(int number, long timestamp, String source, double confidence, int sequenceIndex) {
        this.number = number; this.timestamp = timestamp; this.source = source == null ? "" : source;
        this.confidence = Math.max(0.0, Math.min(1.0, confidence)); this.sequenceIndex = sequenceIndex;
    }
}
