package com.xspaceart.radar30.core;

import java.util.Arrays;

/** Um voto de uma família independente, antes da fusão do motor. */
public final class Evidence {
    public final EvidenceFamily family;
    public final double[] heat;
    public final double strength;
    public final double recency;
    public final int sampleSize;
    public final double reliability;
    public final double currentRegimeRelevance;
    public final double contradiction;
    public final String explanation;

    public Evidence(EvidenceFamily family, double[] heat, double strength,
                    double recency, int sampleSize, double reliability,
                    double currentRegimeRelevance, double contradiction,
                    String explanation) {
        this.family = family;
        this.heat = normalize(heat);
        this.strength = clamp01(strength);
        this.recency = clamp01(recency);
        this.sampleSize = Math.max(0, sampleSize);
        this.reliability = clamp01(reliability);
        this.currentRegimeRelevance = clamp01(currentRegimeRelevance);
        this.contradiction = clamp01(contradiction);
        this.explanation = explanation == null ? "" : explanation;
    }

    public double weight() {
        return strength * (0.35 + 0.65 * reliability)
                * (0.35 + 0.65 * currentRegimeRelevance)
                * (0.75 + 0.25 * recency);
    }

    private static double[] normalize(double[] source) {
        double[] result = new double[37];
        if (source == null) return result;
        System.arraycopy(source, 0, result, 0, Math.min(37, source.length));
        double max = 0.0;
        for (double value : result) max = Math.max(max, value);
        if (max <= 0.0) return result;
        for (int i = 0; i < result.length; i++) result[i] = clamp01(result[i] / max);
        return result;
    }

    private static double clamp01(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }

    @Override
    public String toString() {
        return family + "{strength=" + strength + ", samples=" + sampleSize
                + ", reliability=" + reliability + ", heat="
                + Arrays.toString(heat) + "}";
    }
}
