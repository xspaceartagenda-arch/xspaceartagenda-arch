package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class AnalysisResult {
    public enum Decision { ENTER, OBSERVE, NO_ENTRY, INSUFFICIENT }

    public final int target;
    public final String playLabel;
    public final List<Integer> primaryCoverage;
    public final String protectionLabel;
    public final List<Integer> protectionCoverage;
    public final List<Integer> coverage;
    public final int strength;
    public final Decision decision;
    public final List<String> reasons;
    public final List<String> featureKeys;
    public final int confluenceCount;
    public final int learningAdjustment;

    public AnalysisResult(int target, List<Integer> coverage, int strength,
                          Decision decision, List<String> reasons) {
        this(target, coverage, strength, decision, reasons,
                Collections.emptyList(), 0, 0);
    }

    public AnalysisResult(int target, List<Integer> coverage, int strength,
                          Decision decision, List<String> reasons,
                          List<String> featureKeys, int confluenceCount,
                          int learningAdjustment) {
        this(target, defaultPlayLabel(target), coverage, strength, decision,
                reasons, featureKeys, confluenceCount, learningAdjustment);
    }

    public AnalysisResult(int target, String playLabel, List<Integer> coverage,
                          int strength, Decision decision, List<String> reasons,
                          List<String> featureKeys, int confluenceCount,
                          int learningAdjustment) {
        this(target, playLabel, coverage, "", Collections.emptyList(), coverage,
                strength, decision, reasons, featureKeys, confluenceCount,
                learningAdjustment);
    }

    public AnalysisResult(int target, String playLabel,
                          List<Integer> primaryCoverage,
                          String protectionLabel,
                          List<Integer> protectionCoverage,
                          List<Integer> coverage,
                          int strength, Decision decision, List<String> reasons,
                          List<String> featureKeys, int confluenceCount,
                          int learningAdjustment) {
        this.target = target;
        this.playLabel = playLabel == null ? "" : playLabel;
        this.primaryCoverage = immutable(primaryCoverage);
        this.protectionLabel = protectionLabel == null ? "" : protectionLabel;
        this.protectionCoverage = immutable(protectionCoverage);
        this.coverage = immutable(coverage);
        this.strength = strength;
        this.decision = decision;
        this.reasons = Collections.unmodifiableList(new ArrayList<>(reasons));
        this.featureKeys = Collections.unmodifiableList(new ArrayList<>(featureKeys));
        this.confluenceCount = Math.max(0, confluenceCount);
        this.learningAdjustment = learningAdjustment;
    }

    public static AnalysisResult insufficient(int count) {
        return insufficient(count, 12);
    }

    public static AnalysisResult insufficient(int count, int required) {
        return new AnalysisResult(-1, Collections.emptyList(), 0, Decision.INSUFFICIENT,
                Collections.singletonList("Aguardando histórico: " + count + "/" + required + " resultados"));
    }

    private static String defaultPlayLabel(int target) {
        return target < 0 ? "" : "SETOR " + target + " + 2 VIZINHOS";
    }

    private static List<Integer> immutable(List<Integer> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        return Collections.unmodifiableList(new ArrayList<>(values));
    }
}
