package com.xspaceart.radar30.integrated.normalize;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Aprende a orientação temporal da lista observando onde o provedor insere o giro novo. */
public final class SourceOrderTracker {
    public enum Order { UNKNOWN, NEWEST_FIRST, OLDEST_FIRST }
    private Order order = Order.UNKNOWN;
    private List<Integer> previousRaw = new ArrayList<>();

    public Order order() { return order; }

    public Order observe(List<Integer> raw) {
        return observe(raw, -1);
    }

    /**
     * O resultado atual destacado permite aprender a orientação já no bootstrap,
     * sem precisar esperar um giro novo para descobrir se a lista está invertida.
     */
    public Order observe(List<Integer> raw, int currentResult) {
        List<Integer> clean = raw == null ? Collections.emptyList() : new ArrayList<>(raw);
        if (order == Order.UNKNOWN && clean.size() >= 5 && currentResult >= 0 && currentResult <= 36) {
            boolean first = clean.get(0) == currentResult;
            boolean last = clean.get(clean.size() - 1) == currentResult;
            if (first && !last) order = Order.NEWEST_FIRST;
            else if (last && !first) order = Order.OLDEST_FIRST;
        }
        if (order == Order.UNKNOWN && previousRaw.size() >= 5 && clean.size() >= 5) {
            SourceDelta.Result front = SourceDelta.between(clean, previousRaw);
            List<Integer> rNow = reversed(clean), rPrev = reversed(previousRaw);
            SourceDelta.Result back = SourceDelta.between(rNow, rPrev);
            boolean frontNew = front.valid && !front.newestFirst.isEmpty();
            boolean backNew = back.valid && !back.newestFirst.isEmpty();
            if (frontNew && (!backNew || front.overlap >= back.overlap)) order = Order.NEWEST_FIRST;
            else if (backNew) order = Order.OLDEST_FIRST;
        }
        if (clean.size() >= 5) previousRaw = clean;
        return order;
    }

    public List<Integer> normalize(List<Integer> raw) {
        List<Integer> out = raw == null ? new ArrayList<>() : new ArrayList<>(raw);
        if (order == Order.OLDEST_FIRST) Collections.reverse(out);
        return out;
    }

    public void reset() { order=Order.UNKNOWN; previousRaw=new ArrayList<>(); }

    private static List<Integer> reversed(List<Integer> in) {
        List<Integer> out=new ArrayList<>(in); Collections.reverse(out); return out;
    }
}
