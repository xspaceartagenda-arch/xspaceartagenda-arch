package com.xspaceart.radar30.integrated.normalize;

import com.xspaceart.radar30.core.Wheel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class SpinNormalizer {
    public List<Integer> normalize(List<Integer> raw, boolean firstIsNewest) {
        ArrayList<Integer> clean = new ArrayList<>();
        if (raw != null) {
            for (Integer n : raw) {
                if (n != null && Wheel.valid(n)) clean.add(n);
                if (clean.size() == 500) break;
            }
        }
        if (!firstIsNewest) Collections.reverse(clean);
        return clean;
    }

    public String fingerprint(List<Integer> values) {
        if (values == null || values.isEmpty()) return "empty";
        StringBuilder s = new StringBuilder();
        int n = Math.min(30, values.size());
        for (int i=0;i<n;i++) { if (i>0) s.append('-'); s.append(values.get(i)); }
        return Integer.toHexString(s.toString().hashCode());
    }
}
