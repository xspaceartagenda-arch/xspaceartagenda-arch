package com.xspaceart.radar30.integrated.scanner;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Quality gate for roulette-history snapshots. This class validates only capture quality;
 * it never changes strategic scoring or signal logic.
 */
public final class HistoryQualityGate {
    private HistoryQualityGate() {}

    public static final int MIN_HISTORY = 8;
    public static final int MAX_VISIBLE_HISTORY = 120;
    public static final int MIN_ACCEPT_SCORE = 68;

    public static Assessment assess(List<Integer> history, int currentResult,
                                    int semanticConfidence, boolean structuredCells,
                                    int structureScore) {
        if (history == null) history = Collections.emptyList();
        int n = history.size();
        if (n < MIN_HISTORY) return reject(0, "histórico curto");
        if (n > MAX_VISIBLE_HISTORY) return reject(0, "região ampla demais");

        int sample = Math.min(40, n);
        Set<Integer> distinct = new HashSet<>();
        Map<Integer,Integer> counts = new HashMap<>();
        for (int i=0;i<sample;i++) {
            Integer v=history.get(i);
            if (v==null || v<0 || v>36) return reject(0, "valor fora de 0–36");
            distinct.add(v);
            counts.put(v, counts.getOrDefault(v,0)+1);
        }

        // Classic false-positive: the roulette betting grid itself (0..36 exactly once).
        if (n==37 && distinct.size()==37) return reject(5, "grade 0–36 detectada");
        if (containsCompleteWheel(history)) return reject(8, "sequência completa da mesa detectada");

        int maxFreq=0;
        for (Integer c:counts.values()) maxFreq=Math.max(maxFreq,c);
        double concentration=maxFreq/(double)sample;

        // Strong contamination signature such as 0,0,0,5,5,1... coming from controls/grid.
        if (sample>=16 && distinct.size()<=3) return reject(12, "pouca diversidade para histórico visível");
        if (sample>=14 && distinct.size()<=5 && concentration>=0.55)
            return reject(18, "repetição estrutural suspeita");

        int score=Math.max(0,Math.min(100,semanticConfidence));
        score += structuredCells ? 14 : -18;
        score += Math.min(12,Math.max(0,structureScore)/8);
        if (n>=12) score+=4;
        if (distinct.size()>=6) score+=4;

        if (currentResult>=0 && currentResult<=36) {
            boolean first=history.get(0)==currentResult;
            boolean last=history.get(n-1)==currentResult;
            if (first||last) score+=8;
            else if (history.subList(0,Math.min(8,n)).contains(currentResult)) score-=5;
            else score-=2; // highlighted result can lead/lag the list by one render frame.
        }

        score=Math.max(0,Math.min(100,score));
        if (!structuredCells && score<78) return reject(score,"extração textual sem estrutura suficiente");
        if (score<MIN_ACCEPT_SCORE) return reject(score,"confiança insuficiente");
        return new Assessment(true,score,"histórico estrutural válido");
    }

    private static boolean containsCompleteWheel(List<Integer> history) {
        if (history.size()<37) return false;
        int limit=Math.min(history.size(),60);
        for (int start=0;start+37<=limit;start++) {
            boolean[] seen=new boolean[37];
            int distinct=0;
            for (int i=start;i<start+37;i++) {
                int v=history.get(i);
                if (v<0||v>36) break;
                if (!seen[v]) {seen[v]=true; distinct++;}
            }
            if (distinct==37) return true;
        }
        return false;
    }

    private static Assessment reject(int score,String reason){return new Assessment(false,score,reason);}

    public static final class Assessment {
        public final boolean accepted;
        public final int score;
        public final String reason;
        Assessment(boolean accepted,int score,String reason){this.accepted=accepted;this.score=score;this.reason=reason;}
    }
}
