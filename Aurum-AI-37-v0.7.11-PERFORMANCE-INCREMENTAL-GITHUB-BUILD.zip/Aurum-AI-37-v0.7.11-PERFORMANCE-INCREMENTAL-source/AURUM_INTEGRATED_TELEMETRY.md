# Aurum Stability Pipeline Telemetry — v0.7.3

- Pipeline único: CAPTURA → VALIDAÇÃO → HISTÓRICO → CORE → RADAR → SINAL.
- Bootstrap obrigatório do histórico visível antes do tracking incremental.
- DOM e OCR são fontes de dados; não executam motores de sinal concorrentes.
- OCR trabalha em source-only/hot standby e pode assumir automaticamente.
- Snapshot OCR exige estabilidade antes de alimentar o pipeline.
- A fonte só é confirmada depois da reconciliação com o CORE.
- Se OCR detecta progresso enquanto DOM parece saudável mas não avança, o hot standby pode assumir sem reiniciar a sessão.
- Telemetria mostra fase, fonte, heartbeat, contagem visível, CORE, último giro, failovers e recuperações.
- Radar/pipeline possuem heartbeat visual, porém scores/famílias só mudam com dado real.
- CORE estratégico permanece byte a byte preservado.
