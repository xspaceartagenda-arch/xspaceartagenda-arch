# AURUM AI 37 — CHECKPOINT v0.7.4 DOM History Accuracy

## Estado
- IMPLEMENTAÇÃO FONTE: concluída como candidata.
- CORE estratégico: preservado por SHA-256 (17/17).
- Host tests novos: PASS.
- Android build: PENDENTE GitHub Actions.
- APK: PENDENTE.
- Instalação Samsung S25 FE: PENDENTE.
- Teste físico: PENDENTE.

## Correção principal
A v0.7.3 estabilizou o pipeline, porém a DOM podia escolher um contêiner amplo e extrair números 0–36 que não pertenciam ao histórico. A v0.7.4 adiciona extração estruturada por células, gate de qualidade, estabilização de dois scans, consenso DOM/OCR, quarentena automática e invalidação do lock no comando LIMPAR.

## Regra de preservação
Não alterar o motor estratégico. O fluxo continua CAPTURA → VALIDAÇÃO → HISTÓRICO → CORE → RADAR → SINAL.
