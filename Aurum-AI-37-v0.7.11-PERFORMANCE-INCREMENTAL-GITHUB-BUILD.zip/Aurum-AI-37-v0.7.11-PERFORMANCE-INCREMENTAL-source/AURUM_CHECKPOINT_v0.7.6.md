# AURUM AI 37 — CHECKPOINT v0.7.6

## Base oficial
v0.7.5 Standalone OCR Radar, fisicamente útil no S25 FE.

## Objetivo
Tornar o Radar legível por dentro sem desmontar a interface standalone: mostrar alvos/setores em disputa, calor/frio, famílias e gates; manter a bolha no topo; registrar sessões; e impedir que um cenário excepcional já forte fique preso apenas por HIGH_DISPERSION.

## Alterações implementadas
- Radar Backstage na tela principal.
- Ranking de 3 polos independentes com cobertura e apoio relativo.
- Quente/frio do heatmap.
- Famílias do foco + contradição/dominância.
- Explicação explícita da régua Balanced/Precision.
- Fast Track Balanced excepcional: 60+, 5 famílias, contradição <=20%, dominância >=15%, preditivo + recente.
- High dispersion continua bloqueando normalmente; somente o Fast Track excepcional atravessa.
- Precision preservado.
- Registro visual de toque antecipado.
- Overlay fixado na faixa superior.
- Pasta de sessões com STRYKES, LOSS/REDS, pendentes e banca.
- versionCode 7.
- versionName 0.7.6-radar-backstage-session-debug no debug.

## CORE
Base v0.7.5: 17 arquivos.
- 16/17 devem permanecer byte-idênticos à v0.7.5.
- Única alteração autorizada na v0.7.6: RadarSession.java (Fast Track Balanced excepcional).
- PrecisionConfluenceEngine.java deve permanecer idêntico à v0.7.5.

## Testes locais
- v076_static_validation.py: PASS.
- PrecisionCoreTest: PASS.
- DualTargetCoreTest: PASS.
- V063BalancedCalibrationTest: PASS.
- V075OperationalGateTest: PASS.
- V076FastTrackPolicyTest: PASS.
- V076RadarBackstageTest: PASS.

## Compilação Android
PENDING. A tentativa local não pôde baixar Gradle por ambiente sem acesso de rede. Isso não é tratado como falha de código; a validação Android deve ocorrer no GitHub Actions.

## Próxima ação exata
1. Enviar Aurum-AI-37-v0.7.6-RADAR-BACKSTAGE-GITHUB-BUILD.zip à raiz do repositório.
2. Enviar .github/workflows/build-standalone-v0.7.6.yml.
3. Acompanhar GitHub Actions.
4. Se verde, auditar package/version/launcher/signature/zipalign.
5. Baixar APK e instalar POR CIMA, sem desinstalar e sem limpar dados.
6. Testar fisicamente no S25 FE.

## Critérios de aprovação física
- OCR continua lendo corretamente a roleta externa.
- Radar mostra 1º/2º/3º alvos antes do sinal.
- Famílias, quente/frio, dominância, contradição, dispersão e gates ficam legíveis.
- Caso semelhante a Radar 60+, 5 famílias, contradição <=20% e dominância >=15% pode liberar Fast Track mesmo com HIGH_DISPERSION.
- Bolha permanece no topo.
- Pasta de sessões persiste após finalizar.
- Sem regressão de transição/captura.
