# Aurum AI 37 — Android

Aplicativo nativo de observação e auditoria de históricos de roleta europeia de zero único (0–36), com captura autorizada pelo Android, OCR local e painel flutuante. O aplicativo não faz login, não toca na mesa, não realiza apostas e não possui permissão de internet.

## Versão 0.6.0 — Secondary Confluence v2

O motor principal procura **convergência excepcional**, não uma opinião para cada giro. Ele pode permanecer em `SCANNING` por qualquer quantidade de resultados quando não há clareza suficiente.

Fluxo operacional:

`SCANNING → OBSERVING → BUILDING → PREPARE → ENTRY → ACTIVE → HIT/EXPIRED/INVALIDATED → COOLDOWN`

- `SCANNING`, `OBSERVING`, `BUILDING` e `PREPARE` não autorizam entrada.
- `ENTRY` exige o corte completo do Precision Mode e persistência em três atualizações.
- A cobertura fica travada por exatamente três novos resultados.
- Sem confirmação no terceiro resultado, o registro fecha como `RED / EXPIRED`.
- A ausência não aumenta o score e não recria o mesmo sinal sem novas evidências.
- Após `STRYKE` ou `RED`, o motor entra em cooldown de três resultados.

O **Aurum Score 0–100** mede a força interna da confluência encontrada. Ele não é porcentagem de acerto, probabilidade matemática ou garantia de lucro.

## Primary e Secondary opcional

- O alvo dominante continua sendo o `PRIMARY` e pode liberar uma entrada sozinho.
- Um `SECONDARY — OPTIONAL` só aparece quando possui score, famílias,
  concentração, persistência e margem próprias.
- Polos fisicamente sobrepostos são fundidos como `SINGLE_MACRO_CLUSTER`.
- Dois polos independentes podem formar `DUAL_TARGET`; três ou mais candidatos
  comparáveis geram `HIGH_DISPERSION` e bloqueiam a entrada.
- Um `SECONDARY_HIT` força novo Raio-X: o Primary pode fortalecer, permanecer,
  enfraquecer ou ser invalidado. A cobertura nunca é perseguida após três giros.

## Histórico atual e mudança de regime

- Até 500 resultados válidos ficam ligados exclusivamente à sessão atual.
- Um recorte OCR curto preserva a parte mais antiga já confirmada, em vez de substituir todo o histórico.
- Os últimos 5, 10 e 30 resultados recebem papel central, com contexto multiescala em 3, 5, 7, 10, 15, 20, 30, 50, 100 e até 500.
- Um detector de mudança de regime estima dinamicamente quantos resultados ainda representam o comportamento atual, entre 18 e 150.
- Quando há quebra detectada, o histórico não é apagado, mas o regime anterior perde peso de forma agressiva.
- Sessões encerradas permanecem somente na auditoria; elas não aquecem a mesa atual.

## Motor de evidências

Cada família deposita no máximo um voto no mapa central, reduzindo contagem duplicada de indicadores derivados do mesmo fenômeno:

- sequência e pares/trincas;
- transições de +1 a +5 resultados;
- similaridade estrutural de sequências de 4 a 10;
- geometria e deslocamentos físicos da roda europeia;
- terminais;
- recência multiescala;
- frequência e aceleração contextual;
- gaps com intervalo estável;
- soma/subtração somente quando validadas na própria sessão;
- regime atual.

O mapa de calor agrega força nos 37 números e nas regiões físicas de cinco números. O veredito mede famílias independentes, contradição, distância para o segundo colocado, dispersão, contexto recente e amostra preditiva. Quente/frio, ausência ou aritmética nunca geram entrada sozinhos.

## Precision e Balanced

O corte padrão para uma leitura bruta qualificada exige, entre outros critérios:

- Aurum Score mínimo 82;
- no mínimo 6 famílias independentes;
- contradição máxima de 16%;
- dominância mínima de 16%;
- mapa de evidências suficientemente concentrado;
- caminho preditivo e caminho recente presentes;
- pelo menos 30 amostras em transições/sequências alinhadas.

A máquina de estados ainda exige que a região permaneça coerente por três atualizações antes de publicar `ENTRY`.

O modo `BALANCED` permanece seletivo, mas aceita evidência suficiente com
cortes menores que o `PRECISION`, reduzindo falsos negativos sem criar uma
meta artificial de sinais.

## Raio-X e Shadow Test

O painel avançado separado mostra:

- estado da máquina;
- regime estimado e peso do regime anterior;
- alvo bruto, cobertura e núcleo;
- Aurum Score, famílias, contradição, dominância e dispersão;
- Primary, Secondary, terceiro candidato, dual dominance e regime espacial;
- velocidade de confluência e persistência;
- principais picos do mapa de calor;
- razões do veredito;
- auditoria de `MISSED_OPPORTUNITY` quando o alvo aparece em `PREPARE` antes de
  a entrada ser liberada;
- comparação entre Precision e o motor anterior.

O Shadow Test registra prospectivamente o que cada motor teria indicado, mas nunca envia entrada. Cada hipótese shadow é resolvida em até três resultados e separada por sessão. Isso permite comparar modelos antes de promover mudanças.

## Sessões e aprendizado local

- Cada entrada real guarda o histórico disponível (até 500), Primary,
  Secondary opcional, terceiro candidato, cobertura, famílias, score, estado,
  regime, contradição, dual dominance, velocidade, persistência, mapa de calor,
  razões e resultado final.
- `STRYKE` e `RED` são preservados para auditoria prospectiva.
- `SINGLE_TARGET_SIGNAL`, `DUAL_TARGET_SIGNAL`, `PRIMARY_HIT`,
  `SECONDARY_HIT`, `DUAL_MISS` e `MISSED_OPPORTUNITY` são diferenciados.
- O desempenho observado é comparado com a chance-base da cobertura.
- Registros Precision v1 e Secondary Confluence v2 permanecem identificados
  por versão e são aceitos pela auditoria local com a cobertura real de cada sinal.
- O aprendizado automático permanente ainda não promove padrões externos: biblioteca intersessões e padrões validados são o próximo bloco de desenvolvimento.

## Uso no Samsung S25 FE

1. Abra o Aurum e inicie uma nova sessão para a mesa atual.
2. Permita notificações e a janela flutuante.
3. Toque em **Iniciar compartilhamento** e autorize a captura no Android.
4. Abra a roleta e deixe a grade de últimos resultados visível.
5. Pela notificação, toque em **Calibrar** e marque somente a área da grade.
6. Para carregar o contexto inicial, mantenha o máximo de histórico disponível visível. Depois, basta manter os resultados recentes na área calibrada.
7. Use a correção manual somente quando o OCR realmente errar.
8. Ao trocar de mesa ou crupiê, finalize a sessão e inicie outra.

O painel flutuante possui proteção para não aparecer dentro da própria captura do OCR.

## Privacidade

- OCR latino do ML Kit incluído no APK e executado no aparelho.
- Nenhuma permissão `INTERNET` ou `ACCESS_NETWORK_STATE` no manifesto final.
- Nenhum vídeo, print, login, saldo ou aposta é enviado.
- Históricos, sessões, Shadow Test e snapshots do Raio-X ficam nas preferências privadas do aplicativo.

## Desenvolvimento

Requisitos: JDK 17, Android SDK 35 e Gradle 8.9.

```bash
./gradlew :app:assembleRelease
```

O Gradle gera um APK release não assinado. Para atualizar uma instalação existente sem apagar os dados, o APK precisa ser assinado com a mesma chave privada da versão instalada.

## Limites

- Somente roleta europeia de zero único; mesas americanas com `00` não são suportadas.
- A leitura depende do layout e da calibração; mudanças visuais podem exigir novo recorte.
- O nome do crupiê é informado manualmente. Esta versão não mede de forma confiável velocidade da bola, rotor ou biomecânica do crupiê.
- O motor analisa padrões do histórico, mas uma roleta justa mantém vantagem matemática da casa e giros independentes.
- Testes sintéticos verificam seletividade e regras de estado; não demonstram vantagem preditiva em dinheiro real.
- Não existe automação de aposta, garantia de acerto ou promessa de lucro.
