# AURUM AI 37 — CLEAN INSTALL CHECKPOINT

Estado: fonte preparada para build limpo independente.

Decisão do operador: histórico/dados da instalação anterior não precisam ser preservados. Prioridade é manter todas as evoluções atuais e voltar a ter runtime estável.

Estratégia autorizada:
- nova instalação;
- novo applicationId;
- nova chave de assinatura;
- dados começam do zero;
- motor atual preservado;
- build Gradle limpo preferido;
- não usar a rota antiga de DEX v0.5.0 como fundamento do clean build.

Próxima tarefa exata: executar build Gradle canônico desta árvore, assinar com `signing/aurum-ai37-clean.jks`, instalar no S25 FE como app independente e validar fisicamente.
