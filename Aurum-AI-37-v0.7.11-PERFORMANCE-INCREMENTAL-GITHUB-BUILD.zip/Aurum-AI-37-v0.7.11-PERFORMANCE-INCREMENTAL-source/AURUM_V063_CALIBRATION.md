# AURUM AI 37 v0.6.3 — Balanced Calibration

Objetivo desta versão: corrigir excesso de falso-negativo observado no teste físico de ~210 giros sem nenhuma entrada, preservando o Precision rígido.

## Alterações
- warm-up profundo continua em 36 resultados; não existe espera obrigatória de 200 giros;
- Precision: limiares de entrada preservados;
- Balanced: corte bruto forte pode publicar sem uma segunda camada redundante de espera;
- Balanced: PREPARE com score >=70, >=4 famílias, baixa contradição e sem alta dispersão pode virar ENTRADA MODERADA imediatamente;
- Balanced: PREPARE persistente pode virar entrada moderada após 2 atualizações da mesma região, com filtros adicionais de score, famílias, dominância, velocidade e caminhos preditivo/recente;
- Balanced tolera pequena migração do centro dentro do mesmo macrosetor (overlap 2 em vez de 3); Precision continua overlap 3;
- Raio-X passa a mostrar gate ao vivo e persistência real;
- sinais moderados aparecem explicitamente como `ENTRADA MODERADA — BALANCED`;
- validade continua em 3 giros, cooldown e anti-chasing preservados;
- Dual Target, Shadow, Missed Opportunity e OCR preservados.

## Assinatura
Build DEBUG usa uma chave de TESTE estável e pública para facilitar atualizações futuras deste ramo. Nunca usar essa chave em release comercial.
