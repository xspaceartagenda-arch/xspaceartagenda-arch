# AURUM AI 37 — CHECKPOINT v0.7.11 PERFORMANCE / INCREMENTAL

Base oficial de comportamento: v0.7.10 Rollback v0.7.8.

## Objetivo único desta versão
Corrigir aquecimento, atraso de OCR e atraso de sinal sem modificar o cérebro dos sinais.

## Comportamento preservado
- histórico confirmado continua acumulado;
- RadarSession não é reiniciada ao alternar entre Aurum e roleta;
- cada resultado novo avança o mesmo motor Setor + Terminal + Confluência Máxima da v0.7.8;
- nenhuma regra Surgical Precision da v0.7.9 foi reintroduzida.

## Infraestrutura nova
- captura sem backlog (`acquireLatestImage` + descarte enquanto OCR ocupado);
- Visual Change Gate na ROI para não rodar ML Kit continuamente em tela parada;
- janela de leitura normal 320 ms e confirmação rápida 180 ms;
- segunda confirmação OCR continua obrigatória;
- FAST_RESYNC ao retomar a interface, sem limpar histórico/hipóteses;
- recuperação estrita de até 12 resultados quando a grade do histórico volta à tela;
- processamento OCR/CORE retirado da thread principal da interface.

## Versão
- versionCode: 12
- versionName: 0.7.11-performance-incremental
- package final debug: com.xspaceart.aurumai37.integratedlab.debug
- launcher: com.xspaceart.radar30.StandaloneActivity
- assinatura esperada SHA-256: 663a96b89181b13c759512229e465ebc895136545f36d1cbd29f7d7e1ad561c4

## Estado
- IMPLEMENTADO: PASS
- HOST TESTS: PASS
- SIGNAL BRAIN v0.7.8: PRESERVADO (arquivos protegidos por SHA-256)
- ANDROID BUILD: PENDENTE GitHub Actions
- INSTALADO: NÃO
- TESTADO FISICAMENTE: NÃO
