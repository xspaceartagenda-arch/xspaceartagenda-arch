package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Máquina de estados do Precision Mode. Uma hipótese precisa sobreviver a
 * várias atualizações antes de se transformar em entrada.
 */
public final class RadarSession {
    public enum State {
        SCANNING, OBSERVING, BUILDING, PREPARE, ENTRY, ACTIVE,
        HIT, EXPIRED, INVALIDATED, COOLDOWN
    }

    private static final int VALIDITY_SPINS = 3;
    private static final int COOLDOWN_SPINS = 3;
    private final PrecisionConfluenceEngine precisionEngine = new PrecisionConfluenceEngine();
    // O motor anterior permanece rodando silenciosamente como champion de
    // comparação. Ele não vota nem aumenta o Aurum Score do Precision Mode.
    private final RadarEngine legacyChampion = new RadarEngine();

    private ActiveHypothesis hypothesis;
    private ActiveTerminalHypothesis terminalHypothesis;
    private ActiveSignal active;
    private int cooldownRemaining;
    private boolean initialized;
    private ConfluenceVerdict lastVerdict;
    private AnalysisResult lastChampionShadow;
    private State state = State.SCANNING;
    // v0.7.7: uma hipótese que tocou durante OBSERVE/BUILDING/PREPARE fica
    // temporariamente saturada; o mesmo setor só reabre cedo com nova convergência excepcional.
    private List<Integer> saturatedCoverage = new ArrayList<>();
    private int saturationRemaining;
    private int lastObservationTouch = -1;
    private int saturatedTerminal = -1;
    private int terminalSaturationRemaining;
    private int lastTerminalObservationTouch = -1;

    public SignalUpdate update(List<Integer> history,
                               List<Integer> newNumbersNewestFirst) {
        return update(history, newNumbersNewestFirst, LearningModel.empty(), true);
    }

    public SignalUpdate update(List<Integer> history,
                               List<Integer> newNumbersNewestFirst,
                               LearningModel learning, boolean conservative) {
        List<Integer> cleanHistory = CurrentTableHistory.clean(history);
        List<Integer> newNumbers = CurrentTableHistory.clean(
                newNumbersNewestFirst, Math.max(0,
                        newNumbersNewestFirst == null ? 0 : newNumbersNewestFirst.size()));
        ConfluenceVerdict.Mode mode = conservative
                ? ConfluenceVerdict.Mode.PRECISION
                : ConfluenceVerdict.Mode.BALANCED;

        SignalUpdate resolution = processActive(newNumbers, cleanHistory, mode);
        if (resolution != null) return resolution;
        if (active != null) return activeUpdate();

        if (saturationRemaining > 0 && !newNumbers.isEmpty()) {
            saturationRemaining = Math.max(0, saturationRemaining - newNumbers.size());
            if (saturationRemaining == 0) {
                saturatedCoverage = new ArrayList<>();
                lastObservationTouch = -1;
            }
        }

        if (terminalSaturationRemaining > 0 && !newNumbers.isEmpty()) {
            terminalSaturationRemaining = Math.max(0,
                    terminalSaturationRemaining - newNumbers.size());
            if (terminalSaturationRemaining == 0) {
                saturatedTerminal = -1;
                lastTerminalObservationTouch = -1;
            }
        }

        if (cooldownRemaining > 0 && !newNumbers.isEmpty()) {
            cooldownRemaining = Math.max(0, cooldownRemaining - newNumbers.size());
            if (cooldownRemaining > 0) {
                state = State.COOLDOWN;
                return cooldownUpdate();
            }
        } else if (cooldownRemaining > 0) {
            state = State.COOLDOWN;
            return cooldownUpdate();
        }

        boolean canAdvance = !initialized || !newNumbers.isEmpty();
        initialized = true;
        if (!canAdvance) {
            if (hypothesis != null) return hypothesisUpdate(hypothesis.state,
                    "Aguardando um novo resultado para atualizar a hipótese.");
            return scanningUpdate(cleanHistory, "Aguardando novo resultado.");
        }

        boolean observationTouch = mode == ConfluenceVerdict.Mode.BALANCED
                && hypothesis != null
                && containsAny(hypothesis.coverage, newNumbers);
        String touchedLabel = hypothesis == null ? "" : hypothesis.playLabel;
        if (observationTouch) {
            lastObservationTouch = firstContained(hypothesis.coverage, newNumbers);
            saturatedCoverage = new ArrayList<>(hypothesis.coverage);
            saturationRemaining = 2;
            hypothesis = null;
        }

        boolean terminalObservationTouch = mode == ConfluenceVerdict.Mode.BALANCED
                && terminalHypothesis != null
                && containsAny(terminalHypothesis.coverage, newNumbers);
        String touchedTerminalLabel = terminalHypothesis == null
                ? "" : terminalHypothesis.playLabel;
        if (terminalObservationTouch) {
            lastTerminalObservationTouch = firstContained(terminalHypothesis.coverage, newNumbers);
            saturatedTerminal = terminalHypothesis.terminal;
            terminalSaturationRemaining = 2;
            terminalHypothesis = null;
        }

        // Champion/challenger: comparação silenciosa, sem contaminar a força.
        try {
            lastChampionShadow = legacyChampion.analyze(cleanHistory,
                    learning == null ? LearningModel.empty() : learning,
                    conservative);
        } catch (RuntimeException ignored) {
            lastChampionShadow = null;
        }
        lastVerdict = precisionEngine.analyze(cleanHistory, mode);
        updateTerminalHypothesis(lastVerdict);

        if (mode == ConfluenceVerdict.Mode.BALANCED && terminalHypothesis != null) {
            boolean terminalSaturated = terminalRegionSaturated(lastVerdict);
            boolean sectorSaturated = regionSaturated(lastVerdict);
            boolean legacyMaxReady = TerminalSignalPolicy.maxConfluenceReady(lastVerdict,
                    terminalHypothesis.updates, terminalHypothesis.velocity(),
                    sectorSaturated, terminalSaturated);
            SurgicalPrecisionGate.Snapshot surgicalGate = SurgicalPrecisionGate.analyze(lastVerdict);
            boolean surgicalStable = surgicalGate.exceptional
                    || terminalHypothesis.surgicalUpdates >= 2;
            boolean maxReady = surgicalStable && SurgicalPrecisionGate.permitMaxConfluence(
                    lastVerdict, legacyMaxReady);
            boolean terminalReady = !maxReady && TerminalSignalPolicy.terminalReady(lastVerdict,
                    terminalHypothesis.updates, terminalHypothesis.velocity(),
                    terminalSaturated);
            if (maxReady || terminalReady) {
                active = ActiveSignal.forTerminal(terminalHypothesis, lastVerdict, maxReady);
                terminalHypothesis = null;
                hypothesis = null;
                state = State.ENTRY;
                return entryUpdate();
            }
        }

        if (lastVerdict.target < 0) {
            if (terminalObservationTouch) {
                return terminalHypothesisUpdate(SignalUpdate.Kind.OBSERVE,
                        "TERMINAL REALIZADO DURANTE OBSERVAÇÃO",
                        touchedTerminalLabel + " tocou em " + lastTerminalObservationTouch
                                + ". Não conta como STRYKE. Terminal em saturação curta.");
            }
            if (mode == ConfluenceVerdict.Mode.BALANCED
                    && TerminalSignalPolicy.terminalPrepare(lastVerdict)
                    && terminalHypothesis != null) {
                return terminalHypothesisUpdate(SignalUpdate.Kind.PREPARE,
                        "TERMINAL EM FORMAÇÃO",
                        "Terminal forte em confirmação. Ainda não entrar.");
            }
            return handleNoCandidate(cleanHistory,
                    firstReason(lastVerdict, "Sem leitura clara."));
        }

        boolean relevant = lastVerdict.decision != ConfluenceVerdict.Decision.NO_READING;
        if (!relevant) {
            if (mode == ConfluenceVerdict.Mode.BALANCED
                    && TerminalSignalPolicy.terminalPrepare(lastVerdict)
                    && terminalHypothesis != null) {
                return terminalHypothesisUpdate(SignalUpdate.Kind.PREPARE,
                        "TERMINAL EM FORMAÇÃO",
                        "Terminal Engine encontrou consenso antes do setor. Ainda não entrar.");
            }
            return handleNoCandidate(cleanHistory,
                    "O melhor setor não atingiu a régua mínima de observação.");
        }

        if (hypothesis == null) {
            hypothesis = new ActiveHypothesis(lastVerdict);
            boolean saturated = regionSaturated(lastVerdict);
            boolean consensusImmediate = ConsensusPolicy.immediate(lastVerdict, saturated)
                    || (ConsensusPolicy.localExceptional(lastVerdict, saturated)
                    && lastVerdict.consensus.primary.score >= 70);
            boolean balancedImmediate = mode == ConfluenceVerdict.Mode.BALANCED
                    && !saturated
                    && (lastVerdict.entryQualified || balancedFastTrack(lastVerdict)
                    || consensusImmediate
                    || (lastVerdict.signalShape != TargetRanking.SignalShape.HIGH_DISPERSION
                    && lastVerdict.decision == ConfluenceVerdict.Decision.PREPARE
                    && lastVerdict.aurumScore >= 68
                    && lastVerdict.independentFamilies >= 4
                    && lastVerdict.contradictionScore <= 0.26));
            if (balancedImmediate) {
                active = new ActiveSignal(hypothesis, lastVerdict);
                hypothesis = null;
                terminalHypothesis = null;
                state = State.ENTRY;
                return entryUpdate();
            }
            state = State.OBSERVING;
            if (observationTouch) {
                return hypothesisUpdate(State.OBSERVING,
                        "HIPÓTESE REALIZADA DURANTE OBSERVAÇÃO • " + touchedLabel
                                + " tocou em " + lastObservationTouch
                                + ". Não conta como STRYKE. O setor entrou em saturação curta "
                                + "e o Radar já procura nova convergência; não exige repetir o acerto.");
            }
            if (saturated) {
                return hypothesisUpdate(State.OBSERVING,
                        "Região ainda em saturação curta após toque antecipado. "
                                + "Só nova convergência excepcional reabre cedo; o Radar continua comparando setores.");
            }
            return hypothesisUpdate(State.OBSERVING,
                    "Confluência inicial detectada. Não apostar.");
        }

        int requiredOverlap = mode == ConfluenceVerdict.Mode.PRECISION ? 3 : 2;
        if (!sameRegion(hypothesis.coverage, lastVerdict.coverage, requiredOverlap)) {
            String previous = hypothesis.playLabel;
            hypothesis = new ActiveHypothesis(lastVerdict);
            state = State.INVALIDATED;
            return simpleUpdate(SignalUpdate.Kind.INVALIDATED,
                    "HIPÓTESE ANTERIOR INVALIDADA",
                    previous + " perdeu convergência. Nova região em observação: "
                            + hypothesis.playLabel + "\nSem entrada.",
                    hypothesis, 0,
                    "Hipótese invalidada. Continue aguardando.");
        }

        hypothesis.update(lastVerdict);
        if (hypothesis.mustInvalidate()) {
            ActiveHypothesis invalid = hypothesis;
            hypothesis = null;
            state = State.INVALIDATED;
            return simpleUpdate(SignalUpdate.Kind.INVALIDATED,
                    "HIPÓTESE INVALIDADA",
                    invalid.playLabel + " perdeu força ou ganhou contradição.\nSem entrada.",
                    invalid, 0, "Hipótese invalidada. Sem entrada.");
        }

        if (entryReady(hypothesis, lastVerdict)) {
            active = new ActiveSignal(hypothesis, lastVerdict);
            hypothesis = null;
            terminalHypothesis = null;
            state = State.ENTRY;
            return entryUpdate();
        }

        State next = hypothesisState(hypothesis, lastVerdict);
        hypothesis.state = next;
        state = next;
        if (next == State.PREPARE) {
            return hypothesisUpdate(next,
                    "Confluência forte em confirmação. SE PREPARAR; ainda não entrar.");
        }
        if (next == State.BUILDING) {
            return hypothesisUpdate(next,
                    "Confluência crescendo. Não apostar enquanto não houver veredito.");
        }
        return hypothesisUpdate(State.OBSERVING,
                "Confluência em observação. Não apostar.");
    }

    public void resetSignal() {
        hypothesis = null;
        terminalHypothesis = null;
        active = null;
        cooldownRemaining = 0;
        initialized = false;
        lastVerdict = null;
        lastChampionShadow = null;
        saturatedCoverage = new ArrayList<>();
        saturationRemaining = 0;
        lastObservationTouch = -1;
        saturatedTerminal = -1;
        terminalSaturationRemaining = 0;
        lastTerminalObservationTouch = -1;
        state = State.SCANNING;
    }

    public State state() {
        return state;
    }

    public ConfluenceVerdict lastVerdict() {
        return lastVerdict;
    }

    public AnalysisResult lastChampionShadow() {
        return lastChampionShadow;
    }

    public double consensusVelocity() {
        return hypothesis == null ? 0.0 : hypothesis.consensusVelocity();
    }

    public double runnerConsensusVelocity() {
        return hypothesis == null ? 0.0 : hypothesis.runnerConsensusVelocity();
    }

    public int saturationRemaining() {
        return saturationRemaining;
    }

    public double terminalVelocity() {
        return terminalHypothesis == null ? 0.0 : terminalHypothesis.velocity();
    }

    public int terminalSaturationRemaining() {
        return terminalSaturationRemaining;
    }

    private SignalUpdate processActive(List<Integer> newestFirst,
                                       List<Integer> currentHistory,
                                       ConfluenceVerdict.Mode mode) {
        if (active == null || newestFirst.isEmpty()) return null;
        List<Integer> chronological = new ArrayList<>(newestFirst);
        Collections.reverse(chronological);
        for (int result : chronological) {
            int round = active.misses + 1;
            if (active.primaryCoverage.contains(result)) {
                ActiveSignal resolved = active;
                active = null;
                cooldownRemaining = COOLDOWN_SPINS;
                state = State.HIT;
                return signalUpdate(SignalUpdate.Kind.HIT,
                        "STRYKE • " + result,
                        "PRIMARY HIT • " + resolved.playLabel
                                + " confirmado no giro " + round + "/"
                                + resolved.validitySpins + ".\nSinal encerrado. Cooldown antes de nova leitura.",
                        resolved, 0, "Primary hit no giro " + round + ".",
                        result, round,
                        resolved.secondaryHit ? "SECONDARY_HIT_PRIMARY_HIT"
                                : "PRIMARY_HIT",
                        "", false);
            }
            if (active.secondaryOpen && active.secondaryCoverage.contains(result)) {
                active.misses++;
                ConfluenceVerdict rescan = precisionEngine.analyze(currentHistory, mode);
                lastVerdict = rescan;
                int remaining = active.validitySpins - active.misses;
                SignalPolicy.PrimaryAfterSecondary primaryStatus =
                        SignalPolicy.classifyPrimaryAfterSecondary(
                                active.primaryCoverage, active.score, rescan, remaining);
                ActiveSignal resolved = active;
                boolean keepPrimary = primaryStatus
                        != SignalPolicy.PrimaryAfterSecondary.PRIMARY_INVALIDATED
                        && remaining > 0;
                if (keepPrimary) {
                    active.secondaryHit = true;
                    active.secondaryOpen = false;
                    active.currentScore = rescan.aurumScore;
                    state = State.ACTIVE;
                } else {
                    resolved.secondaryHit = true;
                    active = null;
                    cooldownRemaining = COOLDOWN_SPINS;
                    state = State.INVALIDATED;
                }
                String detail = "SECONDARY HIT • " + resolved.secondaryPlayLabel
                        + " confirmado no giro " + round + "/" + resolved.validitySpins
                        + ".\nNovo Raio-X: " + primaryStatus
                        + (keepPrimary
                        ? "\nPrimary continua ativo por " + remaining
                        + (remaining == 1 ? " giro." : " giros.")
                        : "\nPrimary encerrado; não perseguir.");
                return signalUpdate(SignalUpdate.Kind.SECONDARY_HIT,
                        "SECONDARY HIT • " + result, detail, resolved,
                        keepPrimary ? active.misses + 1 : 0,
                        "Secondary hit. " + primaryStatus + ".",
                        result, round, "SECONDARY_HIT", primaryStatus.name(),
                        keepPrimary);
            }
            active.misses++;
            if (active.terminalBased && active.misses < active.validitySpins) {
                ConfluenceVerdict rescan = precisionEngine.analyze(currentHistory, mode);
                lastVerdict = rescan;
                if (!TerminalSignalPolicy.terminalStillValid(rescan, active.terminalId,
                        active.maxConfluence)) {
                    ActiveSignal resolved = active;
                    active = null;
                    cooldownRemaining = 2;
                    state = State.INVALIDATED;
                    return signalUpdate(SignalUpdate.Kind.INVALIDATED,
                            "CANCELAR SINAL • ESTRUTURA ROMPEU",
                            resolved.playLabel + " perdeu a confirmação estrutural no giro "
                                    + round + "/" + resolved.validitySpins
                                    + ".\nEntrada encerrada antes do limite; não perseguir o terminal.",
                            resolved, 0, "Cancelar sinal. Estrutura rompeu.",
                            result, round, "STRUCTURAL_CANCEL", "", false);
                }
                active.currentScore = rescan.terminal.primary.score;
            }
            if (active != null && active.misses >= active.validitySpins) {
                ActiveSignal resolved = active;
                active = null;
                cooldownRemaining = COOLDOWN_SPINS;
                state = State.EXPIRED;
                return signalUpdate(SignalUpdate.Kind.EXPIRED,
                        "RED • SINAL EXPIRADO",
                        resolved.playLabel + " não apareceu em " + resolved.validitySpins
                                + " giros.\nSinal encerrado; ausência não aumenta a confiança.",
                        resolved, 0, "Sinal expirado. Não perseguir.",
                        result, resolved.validitySpins,
                        resolved.secondaryHit ? "SECONDARY_HIT_PRIMARY_EXPIRED"
                                : resolved.secondaryTarget >= 0
                                ? "DUAL_MISS" : "EXPIRED",
                        "", false);
            }
        }
        return null;
    }

    private void updateTerminalHypothesis(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.mode != ConfluenceVerdict.Mode.BALANCED
                || verdict.terminal == null || verdict.terminal.primary.terminal < 0
                || verdict.terminal.primary.score < 48
                || verdict.terminal.primary.familyCount < 3) {
            if (terminalHypothesis != null) {
                terminalHypothesis.weakScans++;
                if (terminalHypothesis.weakScans >= 2) terminalHypothesis = null;
            }
            return;
        }
        TerminalSnapshot.Candidate candidate = verdict.terminal.primary;
        if (terminalHypothesis == null || terminalHypothesis.terminal != candidate.terminal) {
            terminalHypothesis = new ActiveTerminalHypothesis(verdict);
        } else {
            terminalHypothesis.update(verdict);
        }
    }

    private SignalUpdate terminalHypothesisUpdate(SignalUpdate.Kind kind,
                                                  String headline, String message) {
        if (terminalHypothesis == null) {
            return new SignalUpdate(kind, headline, message + "\nSem entrada.",
                    -1, Collections.emptyList(), 0, 0, "Aguardando terminal.");
        }
        String detail = message
                + "\n" + terminalHypothesis.playLabel
                + " • cobertura: " + joinNumbers(terminalHypothesis.coverage)
                + "\nTerminal Score: " + terminalHypothesis.lastScore + "/100"
                + " • famílias: " + terminalHypothesis.families
                + " • margem: " + percent(terminalHypothesis.margin)
                + "\nAlinhamento: " + percent(terminalHypothesis.alignment)
                + " • contradição: " + level(terminalHypothesis.contradiction)
                + " • persistência: " + terminalHypothesis.updates
                + " • momentum: " + signed(terminalHypothesis.velocity())
                + (lastVerdict != null && TerminalSignalPolicy.aligned(lastVerdict)
                ? "\nCONFLUÊNCIA CRUZADA • setor "
                + lastVerdict.consensus.primary.target + " +2V confirma T"
                + terminalHypothesis.terminal
                + " • índice cruzado " + TerminalSignalPolicy.crossScore(lastVerdict) + "/100"
                + (terminalHypothesis.surgicalTarget >= 0
                ? "\nMICROALVO EM TESTE • " + terminalHypothesis.surgicalTarget
                + " • " + terminalHypothesis.surgicalScore + "/100"
                + " • persistência " + terminalHypothesis.surgicalUpdates : "")
                : "")
                + "\nAinda não é entrada oficial.";
        return new SignalUpdate(kind, headline, detail, terminalHypothesis.terminal,
                terminalHypothesis.coverage, terminalHypothesis.lastScore,
                terminalHypothesis.updates,
                kind == SignalUpdate.Kind.PREPARE
                        ? "Terminal em formação. Se preparar, ainda não entrar."
                        : "Terminal em observação. Sem entrada.",
                terminalHypothesis.featureKeys, terminalHypothesis.families, -1, 0,
                terminalHypothesis.playLabel);
    }

    private SignalUpdate handleNoCandidate(List<Integer> history, String reason) {
        if (hypothesis == null) {
            state = State.SCANNING;
            return scanningUpdate(history, reason);
        }
        hypothesis.weakScans++;
        hypothesis.lastScore = lastVerdict == null ? 0 : lastVerdict.aurumScore;
        if (hypothesis.weakScans >= 2) {
            ActiveHypothesis invalid = hypothesis;
            hypothesis = null;
            state = State.INVALIDATED;
            return simpleUpdate(SignalUpdate.Kind.INVALIDATED,
                    "HIPÓTESE INVALIDADA",
                    invalid.playLabel + " deixou de receber apoio transversal.\nSem entrada.",
                    invalid, 0, "Hipótese invalidada. Sem entrada.");
        }
        hypothesis.state = State.OBSERVING;
        state = State.OBSERVING;
        return hypothesisUpdate(State.OBSERVING,
                "Hipótese enfraquecida; aguardando confirmação ou invalidação. Sem entrada.");
    }

    private boolean entryReady(ActiveHypothesis hypothesis,
                               ConfluenceVerdict verdict) {
        boolean precision = verdict.mode == ConfluenceVerdict.Mode.PRECISION;
        boolean saturated = regionSaturated(verdict)
                && !ConsensusPolicy.recurrenceOverride(verdict);
        boolean balancedFast = !precision && balancedFastTrack(verdict);
        boolean consensusExceptional = !precision
                && ConsensusPolicy.localExceptional(verdict, saturated);
        if (verdict.signalShape == TargetRanking.SignalShape.HIGH_DISPERSION
                && !balancedFast && !consensusExceptional) return false;

        if (precision) {
            // Precision permanece exatamente na régua rígida da v0.6.2.
            if (!verdict.entryQualified || hypothesis.updates < 3) return false;
            if (hypothesis.recentMinimum(3) < 78) return false;
            if (hypothesis.velocity() < -2.0) return false;
            if (verdict.contradictionScore > 0.16) return false;
        } else {
            // Balanced v0.6.3: evita a duplicação de filtros. O motor bruto já
            // exige múltiplas famílias, caminho preditivo e contexto recente.
            boolean consensusPersistent = ConsensusPolicy.persistent(verdict,
                    hypothesis.updates, hypothesis.consensusVelocity(), saturated);
            boolean consensusMomentum = ConsensusPolicy.momentum(verdict,
                    hypothesis.updates, hypothesis.consensusVelocity(),
                    hypothesis.runnerConsensusVelocity(), saturated);
            boolean strongBalanced = !saturated && ((verdict.entryQualified
                    && verdict.contradictionScore <= 0.22) || balancedFast
                    || consensusExceptional || consensusPersistent || consensusMomentum);

            // Rota moderada: PREPARE persistente pode virar entrada quando a
            // mesma região continua convergindo e não há dispersão/contradição
            // relevante. Não transforma um OBSERVE isolado em sinal.
            boolean persistentModerate = hypothesis.updates >= 2
                    && (verdict.decision == ConfluenceVerdict.Decision.PREPARE
                    || verdict.decision == ConfluenceVerdict.Decision.ENTRY)
                    && verdict.aurumScore >= 64
                    && hypothesis.recentMinimum(2) >= 62
                    && hypothesis.peakScore >= 66
                    && verdict.independentFamilies >= 4
                    && verdict.contradictionScore <= 0.32
                    && (verdict.dominanceMargin >= 0.04 || verdict.secondaryQualified)
                    && hypothesis.velocity() >= -4.0
                    && hasPredictiveSupport(verdict.supportingFamilies)
                    && hasRecentSupport(verdict.supportingFamilies);
            if (saturated) return false;
            if (!strongBalanced && !persistentModerate) return false;
        }

        if (verdict.hasSecondary() && hypothesis.secondaryUpdates < 2) {
            // Um segundo polo nunca é liberado por um único pico instantâneo.
            hypothesis.suppressSecondary();
        }
        return true;
    }


    /**
     * v0.7.6 — fast track excepcional do Balanced.
     *
     * <p>O teste físico mostrou um caso real de Radar ~60 com cinco famílias,
     * contradição baixa e dominância local forte que acertou a cobertura no giro
     * seguinte, mas foi bloqueado apenas pela dispersão global. Esta rota não
     * remove o bloqueio de HIGH_DISPERSION de forma geral: só o ultrapassa quando
     * cinco famílias independentes, baixa contradição, dominância local forte e
     * caminhos preditivo + recente já estão simultaneamente presentes. A confirmação
     * é estrutural; nunca depende de o alvo ter "batido de novo".</p>
     */
    private static boolean balancedFastTrack(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.mode != ConfluenceVerdict.Mode.BALANCED) return false;
        return verdict.aurumScore >= 60
                && verdict.independentFamilies >= 5
                && verdict.contradictionScore <= 0.20
                && verdict.dominanceMargin >= 0.15
                && hasPredictiveSupport(verdict.supportingFamilies)
                && hasRecentSupport(verdict.supportingFamilies);
    }

    private static boolean hasPredictiveSupport(List<EvidenceFamily> families) {
        return families.contains(EvidenceFamily.TRANSITION)
                || families.contains(EvidenceFamily.SEQUENCE)
                || families.contains(EvidenceFamily.HISTORICAL_SIMILARITY)
                || families.contains(EvidenceFamily.WHEEL_GEOMETRY);
    }

    private static boolean hasRecentSupport(List<EvidenceFamily> families) {
        return families.contains(EvidenceFamily.RECENCY)
                || families.contains(EvidenceFamily.REGIME)
                || families.contains(EvidenceFamily.TRANSITION);
    }

    private static State hypothesisState(ActiveHypothesis hypothesis,
                                         ConfluenceVerdict verdict) {
        if (verdict.mode == ConfluenceVerdict.Mode.BALANCED
                && hypothesis.updates >= 2
                && verdict.consensus.primary.familyCount >= 4
                && verdict.consensus.primary.score >= 60
                && verdict.consensus.primary.contradiction <= 0.32) {
            if (verdict.consensus.primary.score >= 66
                    || hypothesis.consensusVelocity() >= 3.0) {
                return hypothesis.updates >= 3 ? State.PREPARE : State.BUILDING;
            }
            return State.BUILDING;
        }
        if ((verdict.decision == ConfluenceVerdict.Decision.PREPARE
                || verdict.decision == ConfluenceVerdict.Decision.ENTRY)
                && verdict.aurumScore >= (verdict.mode == ConfluenceVerdict.Mode.PRECISION
                ? 72 : 64) && hypothesis.updates >= 2) {
            return hypothesis.updates >= 3 ? State.PREPARE : State.BUILDING;
        }
        if (verdict.aurumScore >= 64 && hypothesis.updates >= 2
                && hypothesis.velocity() >= -4.0) return State.BUILDING;
        return State.OBSERVING;
    }

    private SignalUpdate scanningUpdate(List<Integer> history, String reason) {
        String regimeLine = lastVerdict == null || lastVerdict.regime == null
                ? "" : "\nRegime atual estimado: últimos "
                + lastVerdict.regime.currentRegimeStart + " giros";
        return new SignalUpdate(SignalUpdate.Kind.SCANNING,
                "SCANNING • ANALISANDO MESA",
                history.size() + " resultados da sessão atual"
                        + regimeLine + "\n" + reason + "\nSem entrada.",
                -1, Collections.emptyList(), 0, 0,
                "Aurum analisando mesa.");
    }

    private SignalUpdate hypothesisUpdate(State hypothesisState, String message) {
        SignalUpdate.Kind kind;
        String headline;
        if (hypothesisState == State.PREPARE) {
            kind = SignalUpdate.Kind.PREPARE;
            headline = "SE PREPARAR • " + hypothesis.playLabel;
        } else if (hypothesisState == State.BUILDING) {
            kind = SignalUpdate.Kind.BUILDING;
            headline = "CONFLUÊNCIA CRESCENDO • " + hypothesis.playLabel;
        } else {
            kind = SignalUpdate.Kind.OBSERVE;
            headline = "OBSERVANDO REGIÃO • " + hypothesis.playLabel;
        }
        String detail = message
                + "\nAurum Score: " + hypothesis.lastScore + "/100"
                + " • famílias: " + hypothesis.families
                + "\nContradição: " + level(hypothesis.contradiction)
                + " • dominância: " + percent(hypothesis.dominance)
                + "\nPersistência: " + hypothesis.updates + " atualizações"
                + " • velocidade: " + signed(hypothesis.velocity())
                + "\nConsenso espacial: " + hypothesis.consensusScore + "/100"
                + " • " + hypothesis.consensusFamilies + " famílias"
                + " • momentum " + signed(hypothesis.consensusVelocity())
                + " • rival " + hypothesis.runnerConsensusScore + "/100 "
                + signed(hypothesis.runnerConsensusVelocity())
                + "\nModo: " + hypothesis.mode
                + " • espacial: " + hypothesis.spatialRegime
                + (hypothesis.hasSecondary()
                ? "\nSecondary em avaliação: " + hypothesis.secondaryPlayLabel
                + " • " + hypothesis.secondaryScore + "/100"
                + " • persistência " + hypothesis.secondaryUpdates
                : "")
                + "\n" + topReasons(hypothesis.reasons, 3)
                + "\nScore de confluência; não é porcentagem de acerto.";
        return simpleUpdate(kind, headline, detail, hypothesis, hypothesis.updates,
                kind == SignalUpdate.Kind.PREPARE
                        ? "Se preparar. Ainda não entrar."
                        : "Confluência em observação. Sem entrada.");
    }

    private SignalUpdate entryUpdate() {
        String tier;
        String headline;
        if (active.maxConfluence) {
            tier = "BALANCED • CONFLUÊNCIA MÁXIMA TERMINAL + SETOR";
            headline = "ENTRADA OURO • TERMINAL + SETOR";
        } else if (active.terminalBased) {
            tier = "BALANCED • TERMINAL ENGINE CONFIRMADO";
            headline = "ENTRADA • " + active.playLabel;
        } else {
            tier = active.fastTrackEntry
                    ? "BALANCED • FAST TRACK EXCEPCIONAL"
                    : active.moderateEntry
                    ? "BALANCED • CONFLUÊNCIA MODERADA CONFIRMADA"
                    : active.mode + " • CONFLUÊNCIA FORTE";
            headline = active.fastTrackEntry
                    ? "ENTRADA OPORTUNIDADE — BALANCED"
                    : active.moderateEntry
                    ? "ENTRADA MODERADA — BALANCED"
                    : "ENTRADA — CONFLUÊNCIA FORTE";
        }
        String confirmation = active.confirmationSectorTarget >= 0
                ? "\nConfirmação cruzada: SETOR " + active.confirmationSectorTarget
                + " +2V aponta para número do " + active.playLabel
                : "";
        String nucleus = active.primaryNucleus.isEmpty()
                ? "" : "\nNúcleo: " + joinNumbers(active.primaryNucleus);
        String surgical = active.surgicalMicroTarget >= 0
                ? "\nMICROALVO PRIORITÁRIO • " + active.surgicalMicroTarget
                + " • índice cirúrgico " + active.surgicalScore + "/100"
                + " • famílias únicas " + active.surgicalUniqueFamilies
                + " • duais " + active.surgicalDualFamilies
                + " • margem " + percent(active.surgicalMargin)
                : "";
        String detail = tier + "\n\nPRIMARY\n" + active.playLabel
                + "\nCobertura: " + joinNumbers(active.primaryCoverage)
                + nucleus + confirmation + surgical
                + "\nÍndice estrutural: " + active.score + "/100"
                + " • famílias independentes: " + active.families
                + (active.secondaryOpen
                ? "\n\nSECONDARY — OPTIONAL\n" + active.secondaryPlayLabel
                + "\nCobertura: " + joinNumbers(active.secondaryCoverage)
                + "\nAurum Score: " + active.secondaryScore + "/100"
                : "")
                + "\nContradição: " + level(active.contradiction)
                + " • dominância: " + percent(active.dominance)
                + " • persistência: " + active.persistence
                + "\nEspacial: " + active.spatialRegime
                + " • velocidade: " + signed(active.velocity)
                + "\nValidade máxima: próximos " + active.validitySpins + " giros"
                + (active.terminalBased
                ? "\nRevalidação ativa: se o Terminal Engine romper, a Aurum cancela antes do limite."
                : "")
                + "\nPrincipais razões:\n" + topReasons(active.reasons, 5)
                + "\nÍndice de confluência; não é garantia nem probabilidade matemática.";
        String speechLead = active.maxConfluence
                ? "Confluência máxima. "
                : active.terminalBased
                ? "Terminal confirmado. "
                : active.fastTrackEntry
                ? "Entrada oportunidade. "
                : active.moderateEntry
                ? "Entrada moderada. "
                : "Entrada por confluência forte. ";
        return signalUpdate(SignalUpdate.Kind.ENTRY, headline, detail, active, 1,
                speechLead + active.playLabel + ". Válida por até "
                        + active.validitySpins + " giros.",
                -1, 0, "", "", true);
    }

    private SignalUpdate activeUpdate() {
        int round = active.misses + 1;
        return signalUpdate(SignalUpdate.Kind.ACTIVE,
                "MANTER SINAL • " + active.playLabel,
                "Cobertura: " + joinNumbers(active.liveCoverage())
                        + "\nGiro " + round + "/" + active.validitySpins
                        + " • hipótese permanece válida"
                        + (active.terminalBased
                        ? " • Terminal Engine continua sendo revalidado" : "")
                        + (active.surgicalMicroTarget >= 0
                        ? "\nMicroalvo interno: " + active.surgicalMicroTarget
                        + " • ranking " + active.surgicalScore + "/100" : "")
                        + "\nNão criar outra entrada até STRYKE, RED ou CANCELAR.",
                active, round,
                "Manter sinal. Giro " + round + " de " + active.validitySpins + ".",
                -1, 0, "", "", true);
    }

    private static SignalUpdate signalUpdate(SignalUpdate.Kind kind,
                                             String headline, String detail,
                                             ActiveSignal signal, int nextRound,
                                             String speech, int eventResult,
                                             int resolvedRound,
                                             String resultType,
                                             String primaryAfterSecondary,
                                             boolean primaryStillActive) {
        List<Integer> reportedCoverage = kind == SignalUpdate.Kind.SECONDARY_HIT
                && primaryStillActive ? signal.primaryCoverage : signal.coverage;
        return new SignalUpdate(kind, headline, detail, signal.target,
                signal.primaryCoverage, "", Collections.emptyList(),
                reportedCoverage, signal.currentScore, nextRound, speech,
                signal.featureKeys, signal.families, eventResult, resolvedRound,
                signal.playLabel, signal.secondaryTarget,
                signal.secondaryPlayLabel, signal.secondaryCoverage,
                signal.secondaryScore,
                signal.signalType,
                resultType, signal.spatialRegime.name(), signal.velocity,
                primaryAfterSecondary, primaryStillActive);
    }

    private SignalUpdate cooldownUpdate() {
        return new SignalUpdate(SignalUpdate.Kind.COOLDOWN,
                "COOLDOWN • REANALISANDO",
                "Aguardando " + cooldownRemaining
                        + (cooldownRemaining == 1 ? " giro" : " giros")
                        + " antes de construir outra hipótese.\nSem entrada.",
                -1, Collections.emptyList(), 0, 0,
                "Cooldown de leitura.");
    }

    private static SignalUpdate simpleUpdate(SignalUpdate.Kind kind,
                                             String headline, String detail,
                                             ActiveHypothesis hypothesis,
                                             int nextRound, String speech) {
        return new SignalUpdate(kind, headline, detail, hypothesis.target,
                hypothesis.coverage, hypothesis.lastScore, nextRound, speech,
                hypothesis.featureKeys, hypothesis.families, -1, 0,
                hypothesis.playLabel);
    }

    private static boolean sameRegion(List<Integer> first, List<Integer> second) {
        return sameRegion(first, second, 3);
    }

    private static boolean sameRegion(List<Integer> first, List<Integer> second,
                                      int requiredOverlap) {
        int overlap = 0;
        for (int number : first) if (second.contains(number)) overlap++;
        return overlap >= Math.max(1, requiredOverlap);
    }

    private boolean regionSaturated(ConfluenceVerdict verdict) {
        return saturationRemaining > 0 && verdict != null
                && sameRegion(saturatedCoverage, verdict.coverage, 2);
    }

    private boolean terminalRegionSaturated(ConfluenceVerdict verdict) {
        return terminalSaturationRemaining > 0 && verdict != null
                && verdict.terminal != null
                && verdict.terminal.primary.terminal >= 0
                && verdict.terminal.primary.terminal == saturatedTerminal;
    }

    private static boolean containsAny(List<Integer> coverage, List<Integer> values) {
        if (coverage == null || values == null) return false;
        for (int value : values) if (coverage.contains(value)) return true;
        return false;
    }

    private static int firstContained(List<Integer> coverage, List<Integer> values) {
        if (coverage == null || values == null) return -1;
        for (int value : values) if (coverage.contains(value)) return value;
        return -1;
    }

    private static String firstReason(ConfluenceVerdict verdict, String fallback) {
        return verdict == null || verdict.reasons.isEmpty()
                ? fallback : verdict.reasons.get(0);
    }

    private static String topReasons(List<String> reasons, int limit) {
        StringBuilder out = new StringBuilder();
        int end = Math.min(limit, reasons == null ? 0 : reasons.size());
        for (int i = 0; i < end; i++) {
            if (i > 0) out.append("\n");
            out.append("• ").append(reasons.get(i));
        }
        return out.toString();
    }

    private static String joinNumbers(List<Integer> values) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) out.append(" · ");
            out.append(values.get(i));
        }
        return out.toString();
    }

    private static String level(double value) {
        if (value <= 0.10) return "muito baixa";
        if (value <= 0.18) return "baixa";
        if (value <= 0.30) return "moderada";
        return "alta";
    }

    private static String percent(double value) {
        return String.format(new Locale("pt", "BR"), "%.0f%%",
                Math.max(0.0, Math.min(1.0, value)) * 100.0);
    }

    private static String signed(double value) {
        return String.format(new Locale("pt", "BR"), "%+.1f", value);
    }

    private static final class ActiveHypothesis {
        final int target;
        final String playLabel;
        final List<Integer> coverage;
        final List<Integer> scores = new ArrayList<>();
        final List<Integer> consensusScores = new ArrayList<>();
        final List<Integer> runnerConsensusScores = new ArrayList<>();
        List<String> reasons;
        List<String> featureKeys;
        int families;
        int lastScore;
        int peakScore;
        int updates = 1;
        int weakScans;
        double contradiction;
        double dominance;
        ConfluenceVerdict.Mode mode;
        TargetRanking.SpatialRegime spatialRegime;
        TargetRanking.SignalShape signalShape;
        int secondaryTarget = -1;
        String secondaryPlayLabel = "";
        List<Integer> secondaryCoverage = new ArrayList<>();
        List<Integer> secondaryNucleus = new ArrayList<>();
        int secondaryScore;
        int secondaryFamilies;
        int secondaryUpdates;
        int consensusScore;
        int consensusFamilies;
        int runnerConsensusScore;
        State state = State.OBSERVING;

        ActiveHypothesis(ConfluenceVerdict verdict) {
            target = verdict.target;
            playLabel = verdict.playLabel();
            coverage = new ArrayList<>(verdict.coverage);
            reasons = new ArrayList<>(verdict.reasons);
            featureKeys = new ArrayList<>(verdict.featureKeys);
            families = verdict.independentFamilies;
            lastScore = verdict.aurumScore;
            peakScore = lastScore;
            contradiction = verdict.contradictionScore;
            dominance = verdict.dominanceMargin;
            mode = verdict.mode;
            spatialRegime = verdict.spatialRegime;
            signalShape = verdict.signalShape;
            updateSecondary(verdict);
            updateConsensus(verdict);
            scores.add(lastScore);
        }

        void update(ConfluenceVerdict verdict) {
            updates++;
            weakScans = 0;
            lastScore = verdict.aurumScore;
            peakScore = Math.max(peakScore, lastScore);
            families = verdict.independentFamilies;
            contradiction = verdict.contradictionScore;
            dominance = verdict.dominanceMargin;
            mode = verdict.mode;
            spatialRegime = verdict.spatialRegime;
            signalShape = verdict.signalShape;
            updateSecondary(verdict);
            reasons = new ArrayList<>(verdict.reasons);
            featureKeys = new ArrayList<>(verdict.featureKeys);
            updateConsensus(verdict);
            scores.add(lastScore);
            if (scores.size() > 6) scores.remove(0);
        }

        double velocity() {
            if (scores.size() < 2) return 0.0;
            return scores.get(scores.size() - 1) - scores.get(scores.size() - 2);
        }

        double consensusVelocity() {
            if (consensusScores.size() < 2) return 0.0;
            return consensusScores.get(consensusScores.size() - 1)
                    - consensusScores.get(consensusScores.size() - 2);
        }

        double runnerConsensusVelocity() {
            if (runnerConsensusScores.size() < 2) return 0.0;
            return runnerConsensusScores.get(runnerConsensusScores.size() - 1)
                    - runnerConsensusScores.get(runnerConsensusScores.size() - 2);
        }

        int recentMinimum(int count) {
            int start = Math.max(0, scores.size() - count);
            int minimum = 100;
            for (int i = start; i < scores.size(); i++) minimum = Math.min(minimum, scores.get(i));
            return minimum == 100 && scores.isEmpty() ? 0 : minimum;
        }

        boolean mustInvalidate() {
            return contradiction > 0.46
                    || lastScore < 48
                    || peakScore - lastScore >= 20;
        }

        boolean hasSecondary() {
            return secondaryTarget >= 0 && !secondaryCoverage.isEmpty()
                    && secondaryUpdates > 0;
        }

        void suppressSecondary() {
            secondaryTarget = -1;
            secondaryPlayLabel = "";
            secondaryCoverage = new ArrayList<>();
            secondaryNucleus = new ArrayList<>();
            secondaryScore = 0;
            secondaryFamilies = 0;
            secondaryUpdates = 0;
            if (signalShape == TargetRanking.SignalShape.DUAL_TARGET) {
                signalShape = TargetRanking.SignalShape.SINGLE_TARGET;
            }
        }

        private void updateConsensus(ConfluenceVerdict verdict) {
            consensusScore = verdict == null ? 0 : verdict.consensus.primary.score;
            consensusFamilies = verdict == null ? 0 : verdict.consensus.primary.familyCount;
            runnerConsensusScore = verdict == null ? 0 : verdict.consensus.secondary.score;
            consensusScores.add(consensusScore);
            runnerConsensusScores.add(runnerConsensusScore);
            if (consensusScores.size() > 6) consensusScores.remove(0);
            if (runnerConsensusScores.size() > 6) runnerConsensusScores.remove(0);
        }

        private void updateSecondary(ConfluenceVerdict verdict) {
            if (!verdict.hasSecondary()) {
                suppressSecondary();
                return;
            }
            boolean same = secondaryTarget >= 0
                    && sameRegion(secondaryCoverage, verdict.secondaryCoverage);
            secondaryUpdates = same ? secondaryUpdates + 1 : 1;
            secondaryTarget = verdict.secondaryTarget;
            secondaryPlayLabel = verdict.secondaryPlayLabel();
            secondaryCoverage = new ArrayList<>(verdict.secondaryCoverage);
            secondaryNucleus = new ArrayList<>(verdict.secondaryNucleus);
            secondaryScore = verdict.secondaryScore;
            secondaryFamilies = verdict.secondaryFamilies;
        }
    }

    private static final class ActiveTerminalHypothesis {
        final int terminal;
        final String playLabel;
        final List<Integer> coverage;
        final List<Integer> scores = new ArrayList<>();
        List<String> featureKeys;
        int families;
        int lastScore;
        int peakScore;
        int updates = 1;
        int weakScans;
        double alignment;
        double contradiction;
        double margin;
        int surgicalTarget = -1;
        int surgicalScore;
        int surgicalUpdates;

        ActiveTerminalHypothesis(ConfluenceVerdict verdict) {
            TerminalSnapshot.Candidate t = verdict.terminal.primary;
            terminal = t.terminal;
            playLabel = "TERMINAL " + terminal;
            coverage = new ArrayList<>(t.coverage);
            families = t.familyCount;
            lastScore = t.score;
            peakScore = lastScore;
            alignment = t.alignment;
            contradiction = t.contradiction;
            margin = verdict.terminal.leaderMargin;
            featureKeys = new ArrayList<>(verdict.featureKeys);
            updateSurgical(verdict, true);
            scores.add(lastScore);
        }

        void update(ConfluenceVerdict verdict) {
            TerminalSnapshot.Candidate t = verdict.terminal.primary;
            updates++;
            weakScans = 0;
            families = t.familyCount;
            lastScore = t.score;
            peakScore = Math.max(peakScore, lastScore);
            alignment = t.alignment;
            contradiction = t.contradiction;
            margin = verdict.terminal.leaderMargin;
            featureKeys = new ArrayList<>(verdict.featureKeys);
            updateSurgical(verdict, false);
            scores.add(lastScore);
            if (scores.size() > 6) scores.remove(0);
        }

        private void updateSurgical(ConfluenceVerdict verdict, boolean initial) {
            SurgicalPrecisionGate.Snapshot snapshot = SurgicalPrecisionGate.analyze(verdict);
            if (snapshot.microTarget < 0 || !snapshot.aligned) {
                surgicalTarget = -1;
                surgicalScore = 0;
                surgicalUpdates = 0;
                return;
            }
            if (!initial && surgicalTarget == snapshot.microTarget) {
                surgicalUpdates++;
            } else {
                surgicalTarget = snapshot.microTarget;
                surgicalUpdates = 1;
            }
            surgicalScore = snapshot.score;
        }

        double velocity() {
            if (scores.size() < 2) return 0.0;
            return scores.get(scores.size() - 1) - scores.get(scores.size() - 2);
        }
    }

    private static final class ActiveSignal {
        final int target;
        final String playLabel;
        final List<Integer> primaryCoverage;
        final List<Integer> primaryNucleus;
        final int secondaryTarget;
        final String secondaryPlayLabel;
        final List<Integer> secondaryCoverage;
        final List<Integer> secondaryNucleus;
        final int secondaryScore;
        final List<Integer> coverage;
        final int score;
        int currentScore;
        final int families;
        final double contradiction;
        final double dominance;
        final double velocity;
        final ConfluenceVerdict.Mode mode;
        final boolean moderateEntry;
        final boolean fastTrackEntry;
        final TargetRanking.SpatialRegime spatialRegime;
        final int persistence;
        final List<String> reasons;
        final List<String> featureKeys;
        final String signalType;
        final int validitySpins;
        final boolean terminalBased;
        final boolean maxConfluence;
        final int terminalId;
        final int confirmationSectorTarget;
        final int surgicalMicroTarget;
        final int surgicalScore;
        final int surgicalUniqueFamilies;
        final int surgicalDualFamilies;
        final double surgicalMargin;
        boolean secondaryOpen;
        boolean secondaryHit;
        int misses;

        ActiveSignal(ActiveHypothesis hypothesis, ConfluenceVerdict verdict) {
            target = hypothesis.target;
            playLabel = hypothesis.playLabel;
            primaryCoverage = new ArrayList<>(hypothesis.coverage);
            primaryNucleus = new ArrayList<>(verdict.nucleus);
            boolean useSecondary = hypothesis.hasSecondary()
                    && hypothesis.secondaryUpdates >= 2;
            secondaryTarget = useSecondary ? hypothesis.secondaryTarget : -1;
            secondaryPlayLabel = useSecondary
                    ? hypothesis.secondaryPlayLabel : "";
            secondaryCoverage = useSecondary
                    ? new ArrayList<>(hypothesis.secondaryCoverage)
                    : new ArrayList<>();
            secondaryNucleus = useSecondary
                    ? new ArrayList<>(hypothesis.secondaryNucleus)
                    : new ArrayList<>();
            secondaryScore = useSecondary ? hypothesis.secondaryScore : 0;
            coverage = combine(primaryCoverage, secondaryCoverage);
            secondaryOpen = useSecondary;
            score = verdict.aurumScore;
            currentScore = score;
            families = verdict.independentFamilies;
            contradiction = verdict.contradictionScore;
            dominance = verdict.dominanceMargin;
            velocity = hypothesis.velocity();
            mode = verdict.mode;
            moderateEntry = mode == ConfluenceVerdict.Mode.BALANCED
                    && !verdict.entryQualified;
            fastTrackEntry = moderateEntry && balancedFastTrack(verdict);
            spatialRegime = verdict.spatialRegime;
            persistence = hypothesis.updates;
            reasons = new ArrayList<>(verdict.reasons);
            featureKeys = new ArrayList<>(verdict.featureKeys);
            signalType = secondaryTarget >= 0
                    ? "DUAL_TARGET_SIGNAL" : "SECTOR_SIGNAL";
            validitySpins = TerminalSignalPolicy.SECTOR_VALIDITY_SPINS;
            terminalBased = false;
            maxConfluence = false;
            terminalId = -1;
            confirmationSectorTarget = -1;
            surgicalMicroTarget = -1;
            surgicalScore = 0;
            surgicalUniqueFamilies = 0;
            surgicalDualFamilies = 0;
            surgicalMargin = 0.0;
        }

        private ActiveSignal(ActiveTerminalHypothesis hypothesis,
                             ConfluenceVerdict verdict, boolean maxConfluence) {
            TerminalSnapshot.Candidate t = verdict.terminal.primary;
            SurgicalPrecisionGate.Snapshot surgical = SurgicalPrecisionGate.analyze(verdict);
            target = hypothesis.terminal;
            playLabel = hypothesis.playLabel;
            primaryCoverage = new ArrayList<>(hypothesis.coverage);
            primaryNucleus = new ArrayList<>();
            secondaryTarget = -1;
            secondaryPlayLabel = "";
            secondaryCoverage = new ArrayList<>();
            secondaryNucleus = new ArrayList<>();
            secondaryScore = 0;
            coverage = new ArrayList<>(primaryCoverage);
            secondaryOpen = false;
            score = maxConfluence ? TerminalSignalPolicy.crossScore(verdict) : t.score;
            currentScore = score;
            families = maxConfluence
                    ? Math.max(t.familyCount, verdict.consensus.primary.familyCount)
                    : t.familyCount;
            contradiction = maxConfluence
                    ? Math.max(t.contradiction, verdict.consensus.primary.contradiction)
                    : t.contradiction;
            dominance = maxConfluence
                    ? Math.min(verdict.terminal.leaderMargin, verdict.consensus.leaderMargin)
                    : verdict.terminal.leaderMargin;
            velocity = hypothesis.velocity();
            mode = verdict.mode;
            moderateEntry = false;
            fastTrackEntry = false;
            spatialRegime = verdict.spatialRegime;
            persistence = hypothesis.updates;
            reasons = new ArrayList<>();
            if (maxConfluence) {
                reasons.add("Terminal T" + t.terminal + " e setor "
                        + verdict.consensus.primary.target
                        + " +2V chegaram ao mesmo denominador");
                reasons.add("Índice cruzado: " + TerminalSignalPolicy.crossScore(verdict)
                        + "/100 • Terminal " + t.score + "/100 • setor "
                        + verdict.consensus.primary.score + "/100");
            } else {
                reasons.add("Terminal Engine: T" + t.terminal + " " + t.score
                        + "/100 • " + t.familyCount + " famílias independentes");
            }
            reasons.add("Margem terminal " + percent(verdict.terminal.leaderMargin)
                    + " • alinhamento " + percent(t.alignment)
                    + " • contradição " + percent(t.contradiction));
            reasons.addAll(verdict.reasons);
            if (maxConfluence && surgical.microTarget >= 0) {
                reasons.add(0, "MICROALVO " + surgical.microTarget
                        + " • índice cirúrgico " + surgical.score + "/100 • "
                        + surgical.uniqueFamilies + " famílias únicas • "
                        + surgical.dualConfirmingFamilies + " confirmam os dois motores");
            }
            featureKeys = new ArrayList<>(verdict.featureKeys);
            featureKeys.add(maxConfluence ? "signal_max_terminal_sector"
                    : "signal_terminal");
            if (maxConfluence && surgical.microTarget >= 0) {
                featureKeys.add("surgical_micro_target_" + surgical.microTarget);
                featureKeys.add("surgical_score_" + surgical.score);
                featureKeys.add("surgical_unique_families_" + surgical.uniqueFamilies);
                featureKeys.add("surgical_dual_families_" + surgical.dualConfirmingFamilies);
                featureKeys.add("surgical_margin_bp_" + Math.round(surgical.microMargin * 10000.0));
            }
            signalType = maxConfluence
                    ? "MAX_CONFLUENCE_TERMINAL_SECTOR" : "TERMINAL_SIGNAL";
            validitySpins = TerminalSignalPolicy.TERMINAL_VALIDITY_SPINS;
            terminalBased = true;
            this.maxConfluence = maxConfluence;
            terminalId = t.terminal;
            confirmationSectorTarget = maxConfluence
                    ? verdict.consensus.primary.target : -1;
            surgicalMicroTarget = maxConfluence ? surgical.microTarget : -1;
            surgicalScore = maxConfluence ? surgical.score : 0;
            surgicalUniqueFamilies = maxConfluence ? surgical.uniqueFamilies : 0;
            surgicalDualFamilies = maxConfluence ? surgical.dualConfirmingFamilies : 0;
            surgicalMargin = maxConfluence ? surgical.microMargin : 0.0;
        }

        static ActiveSignal forTerminal(ActiveTerminalHypothesis hypothesis,
                                        ConfluenceVerdict verdict,
                                        boolean maxConfluence) {
            return new ActiveSignal(hypothesis, verdict, maxConfluence);
        }

        List<Integer> liveCoverage() {
            return secondaryOpen ? coverage : primaryCoverage;
        }

        private static List<Integer> combine(List<Integer> primary,
                                             List<Integer> secondary) {
            List<Integer> result = new ArrayList<>(primary);
            for (int number : secondary) if (!result.contains(number)) result.add(number);
            return result;
        }
    }

}
