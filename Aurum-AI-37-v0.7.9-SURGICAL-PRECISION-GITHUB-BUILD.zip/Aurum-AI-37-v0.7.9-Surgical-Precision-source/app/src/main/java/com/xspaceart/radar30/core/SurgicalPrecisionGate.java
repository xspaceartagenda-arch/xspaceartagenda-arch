package com.xspaceart.radar30.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * v0.7.9 — camada cirúrgica de desempate e veto.
 *
 * <p>Não cria uma promessa de previsão. Ela reaproveita os votos já produzidos
 * pelos motores de SETOR e TERMINAL para: (1) contar famílias únicas sem somar
 * a mesma evidência duas vezes, (2) medir quantas famílias confirmam os dois
 * motores ao mesmo tempo, (3) ranquear o microalvo dentro do setor vencedor e
 * (4) bloquear confluências cruzadas em que o rival ainda está perto demais.</p>
 */
public final class SurgicalPrecisionGate {
    private SurgicalPrecisionGate() {}

    public static final class Snapshot {
        public final boolean aligned;
        public final int microTarget;
        public final int score;
        public final int uniqueFamilies;
        public final int dualConfirmingFamilies;
        public final int exactVotes;
        public final double microMargin;
        public final double rivalPressure;
        public final boolean permitMaxConfluence;
        public final boolean exceptional;
        public final List<String> reasons;

        Snapshot(boolean aligned, int microTarget, int score,
                 int uniqueFamilies, int dualConfirmingFamilies, int exactVotes,
                 double microMargin, double rivalPressure,
                 boolean permitMaxConfluence, boolean exceptional,
                 List<String> reasons) {
            this.aligned = aligned;
            this.microTarget = microTarget;
            this.score = clampScore(score);
            this.uniqueFamilies = Math.max(0, uniqueFamilies);
            this.dualConfirmingFamilies = Math.max(0, dualConfirmingFamilies);
            this.exactVotes = Math.max(0, exactVotes);
            this.microMargin = clamp01(microMargin);
            this.rivalPressure = clamp01(rivalPressure);
            this.permitMaxConfluence = permitMaxConfluence;
            this.exceptional = exceptional;
            this.reasons = reasons == null ? Collections.emptyList()
                    : Collections.unmodifiableList(new ArrayList<>(reasons));
        }

        public static Snapshot empty() {
            return new Snapshot(false, -1, 0, 0, 0, 0,
                    0.0, 1.0, false, false, Collections.emptyList());
        }
    }

    private static final class CandidateScore {
        final int number;
        final double score;
        CandidateScore(int number, double score) {
            this.number = number;
            this.score = score;
        }
    }

    public static Snapshot analyze(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.consensus == null || verdict.terminal == null
                || verdict.consensus.primary.target < 0
                || verdict.terminal.primary.terminal < 0) return Snapshot.empty();

        boolean aligned = TerminalSignalPolicy.aligned(verdict);
        ConsensusSnapshot.Candidate sector = verdict.consensus.primary;
        TerminalSnapshot.Candidate terminal = verdict.terminal.primary;
        if (!aligned || sector.coverage.isEmpty()) {
            List<String> reasons = new ArrayList<>();
            reasons.add("Setor e Terminal ainda não compartilham o mesmo centro.");
            return new Snapshot(false, -1, 0, unionFamilyCount(sector, terminal),
                    dualFamilyCount(sector, terminal), 0, 0.0,
                    rivalPressure(verdict), false, false, reasons);
        }

        EnumMap<EvidenceFamily, ConsensusSnapshot.FamilyVote> sectorVotes = sectorVotes(sector);
        EnumMap<EvidenceFamily, TerminalSnapshot.FamilyVote> terminalVotes = terminalVotes(terminal);
        Set<EvidenceFamily> union = new HashSet<>(sectorVotes.keySet());
        union.addAll(terminalVotes.keySet());
        Set<EvidenceFamily> dual = new HashSet<>(sectorVotes.keySet());
        dual.retainAll(terminalVotes.keySet());

        double sectorWeight = weightSumSector(sectorVotes);
        double terminalWeight = weightSumTerminal(terminalVotes);
        List<CandidateScore> ranking = new ArrayList<>();
        for (int number : sector.coverage) {
            double sectorSupport = 0.0;
            for (ConsensusSnapshot.FamilyVote vote : sectorVotes.values()) {
                int distance = Wheel.distance(vote.nativeTarget, number);
                double proximity = distance == 0 ? 1.0
                        : distance == 1 ? 0.78
                        : distance == 2 ? 0.52 : 0.0;
                sectorSupport += proximity * vote.relativeSupport * vote.weight;
            }
            sectorSupport = sectorWeight <= 0.0 ? 0.0 : sectorSupport / sectorWeight;

            double terminalSupport = 0.0;
            for (TerminalSnapshot.FamilyVote vote : terminalVotes.values()) {
                double exact = vote.nativeTarget == number ? 1.0
                        : TerminalSnapshot.terminalOf(number) == terminal.terminal ? 0.34 : 0.0;
                terminalSupport += exact * vote.relativeSupport * vote.weight;
            }
            terminalSupport = terminalWeight <= 0.0 ? 0.0 : terminalSupport / terminalWeight;

            double crossFamily = 0.0;
            double crossWeight = 0.0;
            for (EvidenceFamily family : dual) {
                ConsensusSnapshot.FamilyVote sv = sectorVotes.get(family);
                TerminalSnapshot.FamilyVote tv = terminalVotes.get(family);
                int distance = Wheel.distance(sv.nativeTarget, number);
                double spatial = distance == 0 ? 1.0 : distance == 1 ? 0.80 : distance == 2 ? 0.58 : 0.0;
                double exactTerminal = tv.nativeTarget == number ? 1.0
                        : TerminalSnapshot.terminalOf(number) == terminal.terminal ? 0.38 : 0.0;
                double w = Math.min(sv.weight, tv.weight);
                crossFamily += Math.sqrt(Math.max(0.0, spatial * exactTerminal)) * w;
                crossWeight += w;
            }
            crossFamily = crossWeight <= 0.0 ? 0.0 : crossFamily / crossWeight;

            double heat = verdict.heatMap != null && verdict.heatMap.length >= 37
                    ? clamp01(verdict.heatMap[number]) : 0.0;
            double terminalMembership = TerminalSnapshot.terminalOf(number) == terminal.terminal ? 1.0 : 0.0;
            double centerBonus = number == sector.target ? 1.0 : 0.0;

            double quality = 0.31 * sectorSupport
                    + 0.25 * terminalSupport
                    + 0.20 * crossFamily
                    + 0.10 * heat
                    + 0.09 * terminalMembership
                    + 0.05 * centerBonus;
            ranking.add(new CandidateScore(number, clamp01(quality)));
        }
        ranking.sort((a, b) -> {
            int byScore = Double.compare(b.score, a.score);
            if (byScore != 0) return byScore;
            if (a.number == sector.target) return -1;
            if (b.number == sector.target) return 1;
            return Integer.compare(a.number, b.number);
        });

        CandidateScore best = ranking.isEmpty() ? new CandidateScore(-1, 0.0) : ranking.get(0);
        CandidateScore second = ranking.size() < 2 ? new CandidateScore(-1, 0.0) : ranking.get(1);
        double microMargin = best.score <= 0.0 ? 0.0
                : clamp01((best.score - second.score) / best.score);

        int exactVotes = 0;
        for (EvidenceFamily family : union) {
            ConsensusSnapshot.FamilyVote sv = sectorVotes.get(family);
            TerminalSnapshot.FamilyVote tv = terminalVotes.get(family);
            boolean sectorExact = sv != null && sv.nativeTarget == best.number;
            boolean terminalExact = tv != null && tv.nativeTarget == best.number;
            if (sectorExact || terminalExact) exactVotes++;
        }

        int uniqueFamilies = union.size();
        int dualFamilies = dual.size();
        double uniqueBreadth = clamp01((uniqueFamilies - 2.0) / 5.0);
        double dualBreadth = uniqueFamilies == 0 ? 0.0
                : clamp01(dualFamilies / (double) uniqueFamilies);
        double cross = TerminalSignalPolicy.crossScore(verdict) / 100.0;
        double rival = rivalPressure(verdict);

        double surgicalQuality = 0.44 * best.score
                + 0.22 * cross
                + 0.14 * uniqueBreadth
                + 0.10 * dualBreadth
                + 0.10 * microMargin
                - 0.10 * Math.max(0.0, rival - 0.82);
        if (verdict.regime != null && verdict.regime.changeDetected
                && verdict.regime.currentRegimeStart < 24) {
            surgicalQuality -= 0.04;
        }
        int score = clampScore((int) Math.round(clamp01(surgicalQuality) * 100.0));

        boolean exceptional = score >= 76
                && uniqueFamilies >= 5
                && dualFamilies >= 4
                && microMargin >= 0.08
                && rival <= 0.90
                && cross >= 0.78;
        boolean mature = score >= 64
                && uniqueFamilies >= 4
                && dualFamilies >= 3
                && microMargin >= 0.04
                && rival <= 0.95
                && cross >= 0.72;
        boolean permit = exceptional || mature;

        List<String> reasons = new ArrayList<>();
        reasons.add("Microalvo " + best.number + " ranqueado dentro do setor "
                + sector.target + "+2V e Terminal T" + terminal.terminal + ".");
        reasons.add(uniqueFamilies + " famílias únicas • " + dualFamilies
                + " confirmam os dois motores • " + exactVotes + " voto(s) exato(s).");
        reasons.add("Margem micro " + percent(microMargin) + " • pressão rival "
                + percent(rival) + " • índice cirúrgico " + score + "/100.");
        if (!permit) {
            if (uniqueFamilies < 4) reasons.add("VETO: poucas famílias únicas após remover dupla contagem.");
            else if (dualFamilies < 3) reasons.add("VETO: pouco acordo real entre Terminal e Setor.");
            else if (microMargin < 0.04) reasons.add("VETO: microalvo ainda empatado com outro número.");
            else if (rival > 0.95) reasons.add("VETO: rival geral está perto demais do líder.");
            else if (cross < 0.72) reasons.add("VETO: cruzamento Terminal+Setor ainda insuficiente.");
            else reasons.add("VETO: qualidade cirúrgica ainda abaixo da régua.");
        }
        return new Snapshot(true, best.number, score, uniqueFamilies, dualFamilies,
                exactVotes, microMargin, rival, permit, exceptional, reasons);
    }

    /**
     * O gate v0.7.9 só pode reduzir falsos positivos da rota cruzada; ele nunca
     * transforma uma leitura que a v0.7.8 recusaria em entrada.
     */
    public static boolean permitMaxConfluence(ConfluenceVerdict verdict,
                                               boolean legacyReady) {
        if (!legacyReady) return false;
        Snapshot snapshot = analyze(verdict);
        return snapshot.permitMaxConfluence;
    }

    private static EnumMap<EvidenceFamily, ConsensusSnapshot.FamilyVote> sectorVotes(
            ConsensusSnapshot.Candidate candidate) {
        EnumMap<EvidenceFamily, ConsensusSnapshot.FamilyVote> out =
                new EnumMap<>(EvidenceFamily.class);
        if (candidate != null) for (ConsensusSnapshot.FamilyVote vote : candidate.votes) {
            ConsensusSnapshot.FamilyVote previous = out.get(vote.family);
            if (previous == null || vote.relativeSupport * vote.weight
                    > previous.relativeSupport * previous.weight) out.put(vote.family, vote);
        }
        return out;
    }

    private static EnumMap<EvidenceFamily, TerminalSnapshot.FamilyVote> terminalVotes(
            TerminalSnapshot.Candidate candidate) {
        EnumMap<EvidenceFamily, TerminalSnapshot.FamilyVote> out =
                new EnumMap<>(EvidenceFamily.class);
        if (candidate != null) for (TerminalSnapshot.FamilyVote vote : candidate.votes) {
            TerminalSnapshot.FamilyVote previous = out.get(vote.family);
            if (previous == null || vote.relativeSupport * vote.weight
                    > previous.relativeSupport * previous.weight) out.put(vote.family, vote);
        }
        return out;
    }

    private static int unionFamilyCount(ConsensusSnapshot.Candidate sector,
                                        TerminalSnapshot.Candidate terminal) {
        Set<EvidenceFamily> all = new HashSet<>(sectorVotes(sector).keySet());
        all.addAll(terminalVotes(terminal).keySet());
        return all.size();
    }

    private static int dualFamilyCount(ConsensusSnapshot.Candidate sector,
                                       TerminalSnapshot.Candidate terminal) {
        Set<EvidenceFamily> all = new HashSet<>(sectorVotes(sector).keySet());
        all.retainAll(terminalVotes(terminal).keySet());
        return all.size();
    }

    private static double weightSumSector(
            EnumMap<EvidenceFamily, ConsensusSnapshot.FamilyVote> votes) {
        double total = 0.0;
        for (ConsensusSnapshot.FamilyVote vote : votes.values()) total += vote.weight;
        return total;
    }

    private static double weightSumTerminal(
            EnumMap<EvidenceFamily, TerminalSnapshot.FamilyVote> votes) {
        double total = 0.0;
        for (TerminalSnapshot.FamilyVote vote : votes.values()) total += vote.weight;
        return total;
    }

    private static double rivalPressure(ConfluenceVerdict verdict) {
        double sector = verdict.consensus.primary.score <= 0 ? 1.0
                : verdict.consensus.secondary.score / (double) verdict.consensus.primary.score;
        double terminal = verdict.terminal.primary.score <= 0 ? 1.0
                : verdict.terminal.secondary.score / (double) verdict.terminal.primary.score;
        return clamp01(Math.max(sector, terminal));
    }

    private static String percent(double value) {
        return Math.round(clamp01(value) * 100.0) + "%";
    }

    private static int clampScore(int value) {
        return Math.max(0, Math.min(100, value));
    }

    private static double clamp01(double value) {
        if (Double.isNaN(value) || Double.isInfinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }
}
