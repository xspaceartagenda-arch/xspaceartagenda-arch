package com.xspaceart.radar30;

import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.ConsensusPolicy;
import com.xspaceart.radar30.core.ConsensusSnapshot;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.core.SurgicalPrecisionGate;
import com.xspaceart.radar30.core.TargetRanking;
import com.xspaceart.radar30.core.TerminalSignalPolicy;
import com.xspaceart.radar30.core.TerminalSnapshot;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * v0.7.9: expõe setor, Terminal Engine, cruzamento máximo, microalvo cirúrgico e gate de veto.
 * Os percentuais de apoio abaixo são índices normalizados do mapa interno;
 * não representam probabilidade matemática do próximo giro.
 */
public final class RadarBackstageFormatter {
    private RadarBackstageFormatter() {}

    public static String focus(ConfluenceVerdict verdict) {
        if (verdict == null) return "FOCO • ainda sem candidato dominante";
        boolean hasSector = verdict.target >= 0;
        boolean hasTerminal = verdict.terminal != null
                && verdict.terminal.primary.terminal >= 0;
        if (!hasSector && !hasTerminal) return "FOCO • ainda sem candidato dominante";
        StringBuilder out = new StringBuilder();
        if (hasSector) {
            out.append("FOCO AGORA • ").append(verdict.playLabel());
            if (!verdict.coverage.isEmpty()) {
                out.append("\nCobertura física: ").append(numbers(verdict.coverage));
            }
        } else {
            out.append("FOCO TERMINAL • T").append(verdict.terminal.primary.terminal)
                    .append(" • ").append(numbers(verdict.terminal.primary.coverage));
        }
        if (hasSector) {
            out.append("\nEspacial: ").append(spatial(verdict.spatialRegime))
                    .append(" • formato: ").append(shape(verdict.signalShape))
                    .append(" • dispersão global ").append(percent(verdict.evidenceDispersion));
        }
        if (verdict.consensus.primary.target >= 0) {
            out.append("\nCONSENSO LOCAL • ").append(verdict.consensus.primary.score).append("/100")
                    .append(" • ").append(verdict.consensus.primary.familyCount).append(" famílias")
                    .append(" • margem ").append(percent(verdict.consensus.leaderMargin));
        }
        if (verdict.terminal != null && verdict.terminal.primary.terminal >= 0) {
            TerminalSnapshot.Candidate t = verdict.terminal.primary;
            out.append("\nTERMINAL ENGINE • T").append(t.terminal)
                    .append(" ").append(t.score).append("/100")
                    .append(" • ").append(t.familyCount).append(" famílias")
                    .append(" • margem ").append(percent(verdict.terminal.leaderMargin));
            if (TerminalSignalPolicy.aligned(verdict)) {
                out.append(" • CRUZADO com setor ")
                        .append(verdict.consensus.primary.target)
                        .append(" • índice ").append(TerminalSignalPolicy.crossScore(verdict))
                        .append("/100");
                SurgicalPrecisionGate.Snapshot surgical = SurgicalPrecisionGate.analyze(verdict);
                if (surgical.microTarget >= 0) {
                    out.append("\nCIRÚRGICO • microalvo ").append(surgical.microTarget)
                            .append(" ").append(surgical.score).append("/100")
                            .append(" • ").append(surgical.uniqueFamilies).append(" famílias únicas")
                            .append(" • ").append(surgical.dualConfirmingFamilies).append(" duais")
                            .append(" • margem ").append(percent(surgical.microMargin))
                            .append(surgical.permitMaxConfluence ? " • GATE ✓" : " • VETO");
                }
            }
        }
        return out.toString();
    }

    /** Mostra os três polos de consenso mesmo antes de existir hipótese oficial. */
    public static String sectorRanking(ConfluenceVerdict verdict) {
        return sectorRanking(verdict, 0.0, 0.0);
    }

    public static String sectorRanking(ConfluenceVerdict verdict,
                                       double leaderVelocity, double runnerVelocity) {
        if (verdict == null) {
            return "SETORES EM DISPUTA • aguardando consenso espacial";
        }
        if (verdict.consensus.primary.target < 0) {
            if (verdict.heatMap == null || verdict.heatMap.length < 37) {
                return "ALVOS EM DISPUTA • aguardando mapa";
            }
            TargetRanking ranking = TargetRanking.fromHeatMap(verdict.heatMap);
            StringBuilder legacy = new StringBuilder("ALVOS EM DISPUTA");
            appendCandidate(legacy, "\n1º", ranking.primary);
            if (ranking.secondary != null && ranking.secondary.target >= 0) appendCandidate(legacy, "\n2º", ranking.secondary);
            if (ranking.third != null && ranking.third.target >= 0) appendCandidate(legacy, "\n3º", ranking.third);
            legacy.append("\nMargem do líder: ").append(percent(ranking.primaryMargin))
                    .append(" • mapa ").append(spatial(ranking.spatialRegime));
            if (verdict.terminal != null && verdict.terminal.primary.terminal >= 0) {
                legacy.append("\n\nTERMINAIS EM DISPUTA");
                appendTerminalCandidate(legacy, "\n1º", verdict.terminal.primary);
                if (verdict.terminal.secondary.terminal >= 0)
                    appendTerminalCandidate(legacy, "\n2º", verdict.terminal.secondary);
                if (verdict.terminal.third.terminal >= 0)
                    appendTerminalCandidate(legacy, "\n3º", verdict.terminal.third);
                legacy.append("\nMargem terminal: ")
                        .append(percent(verdict.terminal.leaderMargin));
            }
            return legacy.toString();
        }
        ConsensusSnapshot c = verdict.consensus;
        StringBuilder out = new StringBuilder("SETORES EM DISPUTA • CONSENSO ESPACIAL");
        appendConsensusCandidate(out, "\n1º", c.primary);
        if (c.secondary.target >= 0) appendConsensusCandidate(out, "\n2º", c.secondary);
        if (c.third.target >= 0) appendConsensusCandidate(out, "\n3º", c.third);
        out.append("\nMargem do líder: ").append(percent(c.leaderMargin))
                .append(" • momentum líder ").append(signed(leaderVelocity))
                .append(" • rival ").append(signed(runnerVelocity));
        out.append("\nLeitura por região física: famílias podem chamar números diferentes e ainda convergir no mesmo setor.");
        if (verdict.terminal != null && verdict.terminal.primary.terminal >= 0) {
            TerminalSnapshot t = verdict.terminal;
            out.append("\n\nTERMINAIS EM DISPUTA");
            appendTerminalCandidate(out, "\n1º", t.primary);
            if (t.secondary.terminal >= 0) appendTerminalCandidate(out, "\n2º", t.secondary);
            if (t.third.terminal >= 0) appendTerminalCandidate(out, "\n3º", t.third);
            out.append("\nMargem terminal: ").append(percent(t.leaderMargin));
            if (TerminalSignalPolicy.aligned(verdict)) {
                out.append(" • CONFLUÊNCIA MÁXIMA possível com setor ")
                        .append(verdict.consensus.primary.target).append("+2V");
            }
        }
        return out.toString();
    }

    public static String heat(ConfluenceVerdict verdict) {
        if (verdict == null || verdict.heatMap == null || verdict.heatMap.length < 37) {
            return "QUENTE / FRIO • aguardando mapa";
        }
        List<HeatPoint> points = new ArrayList<>();
        for (int number = 0; number < 37; number++) {
            points.add(new HeatPoint(number, safe(verdict.heatMap[number])));
        }
        points.sort(Comparator.comparingDouble((HeatPoint p) -> p.value).reversed()
                .thenComparingInt(p -> p.number));
        StringBuilder out = new StringBuilder("QUENTE • ");
        for (int i = 0; i < Math.min(5, points.size()); i++) {
            if (i > 0) out.append("  ");
            HeatPoint p = points.get(i);
            out.append(p.number).append(" ").append(percent(p.value));
        }
        out.append("\nFRIO / MENOR APOIO • ");
        int start = Math.max(0, points.size() - 4);
        for (int i = start; i < points.size(); i++) {
            if (i > start) out.append("  ");
            HeatPoint p = points.get(i);
            out.append(p.number).append(" ").append(percent(p.value));
        }
        out.append("\nApoio relativo do Radar; não é chance matemática do próximo giro.");
        return out.toString();
    }

    public static String families(ConfluenceVerdict verdict) {
        if (verdict == null) return "DENOMINADOR COMUM • aguardando leitura";
        ConsensusSnapshot.Candidate c = verdict.consensus.primary;
        StringBuilder out = new StringBuilder();
        if (c.target < 0) {
            if (verdict.supportingFamilies == null || verdict.supportingFamilies.isEmpty()) {
                return "FAMÍLIAS DO FOCO • nenhuma família independente confirmada";
            }
            out.append("FAMÍLIAS DO FOCO • ");
            appendFamilies(out, verdict.supportingFamilies);
            out.append("\nTotal: ").append(verdict.independentFamilies)
                    .append(" • contradição ").append(percent(verdict.contradictionScore))
                    .append(" • dominância ").append(percent(verdict.dominanceMargin));
            return out.toString();
        }
        if (!c.votes.isEmpty()) {
            out.append("DENOMINADOR COMUM • setor ").append(c.target).append(" +2V")
                    .append(" • consenso ").append(c.score).append("/100")
                    .append(" • ").append(c.familyCount).append(" famílias");
            int limit = Math.min(7, c.votes.size());
            for (int i = 0; i < limit; i++) {
                ConsensusSnapshot.FamilyVote vote = c.votes.get(i);
                out.append("\n• ").append(label(vote.family))
                        .append(" chama ").append(vote.nativeTarget)
                        .append(" • encaixe no setor ").append(percent(vote.relativeSupport));
            }
            out.append("\nAlinhamento ").append(percent(c.alignment))
                    .append(" • contradição local ").append(percent(c.contradiction))
                    .append(" • contexto atual ").append(percent(c.currentContext));
        } else {
            out.append("DENOMINADOR COMUM • ainda sem polo local consistente");
        }
        if (verdict.terminal != null && verdict.terminal.primary.terminal >= 0
                && !verdict.terminal.primary.votes.isEmpty()) {
            TerminalSnapshot.Candidate t = verdict.terminal.primary;
            out.append("\nTERMINAL ENGINE • T").append(t.terminal)
                    .append(" • ").append(t.score).append("/100")
                    .append(" • ").append(t.familyCount).append(" famílias");
            int terminalLimit = Math.min(6, t.votes.size());
            for (int i = 0; i < terminalLimit; i++) {
                TerminalSnapshot.FamilyVote vote = t.votes.get(i);
                out.append("\n↳ ").append(label(vote.family))
                        .append(" chama ").append(vote.nativeTarget)
                        .append(" → T").append(vote.terminal)
                        .append(" • apoio ").append(percent(vote.relativeSupport));
            }
        }
        if (verdict.supportingFamilies != null && !verdict.supportingFamilies.isEmpty()) {
            out.append("\nFAMÍLIAS DO CORE • ");
            appendFamilies(out, verdict.supportingFamilies);
            out.append(" • total ").append(verdict.independentFamilies);
        }
        return out.toString();
    }

    /** Explica exatamente o que ainda falta para a política liberar o sinal. */
    public static String gate(ConfluenceVerdict verdict, SignalUpdate update) {
        return gate(verdict, update, 0.0, 0.0, 0);
    }

    public static String gate(ConfluenceVerdict verdict, SignalUpdate update,
                              double leaderVelocity, double runnerVelocity,
                              int saturationRemaining) {
        if (verdict == null) return "RÉGUA • aguardando veredito do CORE";
        if (verdict.mode == ConfluenceVerdict.Mode.PRECISION) {
            return precisionGate(verdict, update);
        }
        return balancedGate(verdict, update, leaderVelocity, runnerVelocity,
                saturationRemaining);
    }

    private static String balancedGate(ConfluenceVerdict v, SignalUpdate u,
                                       double leaderVelocity, double runnerVelocity,
                                       int saturationRemaining) {
        boolean saturated = saturationRemaining > 0;
        boolean rawScore = v.aurumScore >= 72;
        boolean rawFamilies = v.independentFamilies >= 4;
        boolean rawContradiction = v.contradictionScore <= 0.26;
        boolean rawDominance = v.dominanceMargin >= 0.07 || v.secondaryQualified;
        boolean predictive = predictive(v.supportingFamilies);
        boolean recent = recent(v.supportingFamilies);
        boolean dispersed = v.signalShape == TargetRanking.SignalShape.HIGH_DISPERSION;
        int updates = u == null ? 0 : Math.max(0, u.nextRound);

        ConsensusSnapshot.Candidate c = v.consensus.primary;
        if (c.target < 0) return legacyBalancedGate(v, u);
        boolean consensusImmediate = ConsensusPolicy.immediate(v, saturated);
        boolean localExceptional = ConsensusPolicy.localExceptional(v, saturated);
        boolean consensusPersistent = ConsensusPolicy.persistent(v, updates, leaderVelocity, saturated);
        boolean consensusMomentum = ConsensusPolicy.momentum(v, updates, leaderVelocity, runnerVelocity, saturated);

        StringBuilder out = new StringBuilder("RÉGUA BALANCED • ");
        if (saturated) out.append("SATURAÇÃO CURTA / REAVALIAÇÃO");
        else if (v.entryQualified) out.append("ENTRADA BRUTA QUALIFICADA");
        else if (consensusImmediate) out.append("CONSENSO EXCEPCIONAL QUALIFICADO");
        else if (consensusPersistent) out.append("CONSENSO MADURO QUALIFICADO");
        else if (consensusMomentum) out.append("MOMENTUM QUALIFICADO");
        else if (localExceptional) out.append("POLO LOCAL EXCEPCIONAL");
        else if (v.decision == ConfluenceVerdict.Decision.PREPARE) out.append("CONVERGINDO / PREPARAR");
        else if (v.decision == ConfluenceVerdict.Decision.OBSERVE) out.append("DISPUTA DE SETORES");
        else out.append("ANALISANDO");

        out.append("\nCONSENSO • setor ").append(c.target < 0 ? "—" : c.target + "+2V")
                .append(" • ").append(c.score).append("/100")
                .append(" • ").append(c.familyCount).append(" famílias")
                .append(" • alinhamento ").append(percent(c.alignment))
                .append(" • margem ").append(percent(v.consensus.leaderMargin));
        out.append("\nMomentum líder ").append(signed(leaderVelocity))
                .append(" • rival ").append(signed(runnerVelocity))
                .append(" • contradição local ").append(percent(c.contradiction));
        if (v.terminal != null && v.terminal.primary.terminal >= 0) {
            TerminalSnapshot.Candidate t = v.terminal.primary;
            out.append("\nTERMINAL • T").append(t.terminal)
                    .append(" ").append(t.score).append("/100")
                    .append(" • ").append(t.familyCount).append(" famílias")
                    .append(" • alinhamento ").append(percent(t.alignment))
                    .append(" • contradição ").append(percent(t.contradiction))
                    .append(" • margem ").append(percent(v.terminal.leaderMargin));
            out.append("\nCRUZAMENTO TERMINAL+SETOR ")
                    .append(TerminalSignalPolicy.aligned(v)
                            ? "✓ índice " + TerminalSignalPolicy.crossScore(v) + "/100"
                            : "✕ ainda sem mesmo denominador");
            if (TerminalSignalPolicy.aligned(v)) {
                SurgicalPrecisionGate.Snapshot surgical = SurgicalPrecisionGate.analyze(v);
                out.append("\nGATE CIRÚRGICO • microalvo ")
                        .append(surgical.microTarget < 0 ? "—" : surgical.microTarget)
                        .append(" • ").append(surgical.score).append("/100")
                        .append(" • famílias únicas ").append(surgical.uniqueFamilies)
                        .append(" • duais ").append(surgical.dualConfirmingFamilies)
                        .append(" • margem ").append(percent(surgical.microMargin))
                        .append(" • rival ").append(percent(surgical.rivalPressure))
                        .append(surgical.permitMaxConfluence ? " • LIBERA ✓" : " • VETA ✕");
                if (!surgical.permitMaxConfluence && !surgical.reasons.isEmpty()) {
                    out.append("\n").append(surgical.reasons.get(surgical.reasons.size() - 1));
                }
            }
        }
        out.append("\nRotas de entrada: consenso excepcional ").append(check(consensusImmediate))
                .append(" • consenso maduro ").append(check(consensusPersistent))
                .append(" • aceleração ").append(check(consensusMomentum))
                .append(" • polo local ").append(check(localExceptional));
        out.append("\nRégua bruta antiga 72+: score ").append(v.aurumScore).append(" ").append(check(rawScore))
                .append(" • 4+ famílias ").append(check(rawFamilies))
                .append(" • contradição ≤26% ").append(check(rawContradiction))
                .append(" • dominância ").append(check(rawDominance));
        out.append("\nPreditivo ").append(check(c.predictive || predictive))
                .append(" • recente ").append(check(c.recent || recent))
                .append(" • persistência ").append(updates);
        if (saturated) {
            out.append("\nHIPÓTESE JÁ REALIZADA EM OBSERVAÇÃO • cooldown estrutural ")
                    .append(saturationRemaining).append(" giro(s). Não exige novo acerto para confirmar; evita perseguir setor já realizado.");
        } else if (dispersed && localExceptional) {
            out.append("\nDispersão global alta, mas várias famílias formaram um polo local comum; HIGH_DISPERSION não bloqueia sozinho.");
        } else if (!v.entryQualified && !consensusImmediate && !consensusPersistent
                && !consensusMomentum && !localExceptional) {
            out.append("\nFALTA AGORA • o líder precisa separar do rival, ganhar consenso/momentum ou amadurecer sem aumentar contradição.");
        }
        out.append("\nConfirmação = convergência estrutural entre famílias; nunca esperar o setor acertar várias vezes para então sinalizar.");
        return out.toString();
    }

    private static String legacyBalancedGate(ConfluenceVerdict v, SignalUpdate u) {
        boolean rawScore = v.aurumScore >= 72;
        boolean rawFamilies = v.independentFamilies >= 4;
        boolean rawContradiction = v.contradictionScore <= 0.26;
        boolean rawDominance = v.dominanceMargin >= 0.07 || v.secondaryQualified;
        boolean predictive = predictive(v.supportingFamilies);
        boolean recent = recent(v.supportingFamilies);
        boolean dispersed = v.signalShape == TargetRanking.SignalShape.HIGH_DISPERSION;
        boolean fastTrack = v.aurumScore >= 60 && v.independentFamilies >= 5
                && v.contradictionScore <= 0.20 && v.dominanceMargin >= 0.15
                && predictive && recent;
        int updates = u == null ? 0 : Math.max(0, u.nextRound);
        boolean persistentRoute = updates >= 2 && v.aurumScore >= 64
                && v.independentFamilies >= 4 && v.contradictionScore <= 0.32
                && (v.dominanceMargin >= 0.04 || v.secondaryQualified)
                && predictive && recent && !dispersed;
        StringBuilder out = new StringBuilder("RÉGUA BALANCED • ");
        if (v.entryQualified) out.append("ENTRADA BRUTA QUALIFICADA");
        else if (fastTrack) out.append("FAST TRACK QUALIFICADO");
        else if (persistentRoute) out.append("ROTA PERSISTENTE QUALIFICADA");
        else if (v.decision == ConfluenceVerdict.Decision.PREPARE) out.append("PREPARAR");
        else if (v.decision == ConfluenceVerdict.Decision.OBSERVE) out.append("OBSERVAR");
        else out.append("AINDA SEM GATE");
        out.append("\nEntrada bruta 72+: score ").append(v.aurumScore).append(" ").append(check(rawScore))
                .append(" • 4+ famílias ").append(check(rawFamilies))
                .append(" • contradição ≤26% ").append(check(rawContradiction))
                .append(" • dominância ≥7%/2º polo ").append(check(rawDominance));
        out.append("\nFAST TRACK 60+: 5+ famílias ").append(check(v.independentFamilies >= 5))
                .append(" • contradição ≤20% ").append(check(v.contradictionScore <= 0.20))
                .append(" • dominância ≥15% ").append(check(v.dominanceMargin >= 0.15));
        out.append("\nPreditivo ").append(check(predictive)).append(" • recente ").append(check(recent))
                .append(" • persistência atual ").append(updates);
        out.append("\nConfirmação = estrutura/persistência; não é necessário o alvo acertar novamente.");
        return out.toString();
    }

    private static String precisionGate(ConfluenceVerdict v, SignalUpdate u) {
        int need = Math.max(0, 82 - v.aurumScore);
        boolean fam = v.independentFamilies >= 6;
        boolean contradiction = v.contradictionScore <= 0.16;
        boolean dominance = v.dominanceMargin >= 0.16 || v.secondaryQualified;
        boolean dispersion = v.signalShape == TargetRanking.SignalShape.HIGH_DISPERSION;
        int updates = u == null ? 0 : Math.max(0, u.nextRound);
        StringBuilder out = new StringBuilder("RÉGUA PRECISION • ");
        out.append(v.entryQualified ? "CORE QUALIFICOU" : "AGUARDANDO");
        out.append("\nScore ").append(v.aurumScore).append("/82 ")
                .append(need == 0 ? "✓" : "• faltam " + need)
                .append(" • 6 famílias (ou 5 excepcionais) ").append(check(fam));
        out.append("\nContradição ≤16% ").append(check(contradiction))
                .append(" • dominância forte ").append(check(dominance))
                .append(" • persistência ").append(updates);
        if (dispersion) out.append("\nBLOQUEIO • HIGH_DISPERSION");
        return out.toString();
    }

    private static boolean predictive(List<EvidenceFamily> families) {
        if (families == null) return false;
        return families.contains(EvidenceFamily.TRANSITION)
                || families.contains(EvidenceFamily.SEQUENCE)
                || families.contains(EvidenceFamily.HISTORICAL_SIMILARITY)
                || families.contains(EvidenceFamily.WHEEL_GEOMETRY);
    }

    private static boolean recent(List<EvidenceFamily> families) {
        if (families == null) return false;
        return families.contains(EvidenceFamily.RECENCY)
                || families.contains(EvidenceFamily.REGIME)
                || families.contains(EvidenceFamily.TRANSITION);
    }

    private static void appendConsensusCandidate(StringBuilder out, String rank,
                                                 ConsensusSnapshot.Candidate c) {
        out.append(rank).append(" setor ").append(c.target).append(" +2V")
                .append(" • consenso ").append(c.score).append("/100")
                .append(" • ").append(c.familyCount).append(" famílias")
                .append(" • alinhamento ").append(percent(c.alignment));
        if (c.coverage != null && !c.coverage.isEmpty()) {
            out.append(" • ").append(numbers(c.coverage));
        }
    }

    private static void appendTerminalCandidate(StringBuilder out, String rank,
                                                TerminalSnapshot.Candidate c) {
        out.append(rank).append(" T").append(c.terminal)
                .append(" • ").append(c.score).append("/100")
                .append(" • ").append(c.familyCount).append(" famílias")
                .append(" • alinhamento ").append(percent(c.alignment));
        if (c.coverage != null && !c.coverage.isEmpty()) {
            out.append(" • ").append(numbers(c.coverage));
        }
    }

    private static void appendCandidate(StringBuilder out, String rank, TargetRanking.Candidate c) {
        out.append(rank).append(" alvo ").append(c.target)
                .append(" +2V • apoio ").append(percent(c.score));
        if (c.coverage != null && !c.coverage.isEmpty()) {
            out.append(" • ").append(numbers(c.coverage));
        }
    }

    private static void appendFamilies(StringBuilder out, List<EvidenceFamily> families) {
        for (int i = 0; i < families.size(); i++) {
            if (i > 0) out.append(" • ");
            out.append(label(families.get(i)));
        }
    }

    private static String numbers(List<Integer> values) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) out.append("·");
            out.append(values.get(i));
        }
        return out.toString();
    }

    private static String signed(double value) {
        return String.format(new Locale("pt", "BR"), "%+.0f", value);
    }

    private static String check(boolean value) { return value ? "✓" : "✕"; }

    private static double safe(double value) {
        if (!Double.isFinite(value)) return 0.0;
        return Math.max(0.0, Math.min(1.0, value));
    }

    private static String percent(double value) {
        return String.format(new Locale("pt", "BR"), "%.0f%%", safe(value) * 100.0);
    }

    private static String spatial(TargetRanking.SpatialRegime regime) {
        if (regime == null) return "—";
        switch (regime) {
            case CONCENTRATED: return "CONCENTRADO";
            case BIMODAL: return "BIMODAL";
            case DISPERSED: return "DISPERSO";
            default: return regime.name();
        }
    }

    private static String shape(TargetRanking.SignalShape value) {
        if (value == null) return "—";
        switch (value) {
            case SINGLE_TARGET: return "ALVO ÚNICO";
            case DUAL_TARGET: return "DUPLO POLO";
            case SINGLE_MACRO_CLUSTER: return "MACRO CLUSTER";
            case HIGH_DISPERSION: return "ALTA DISPERSÃO";
            default: return value.name();
        }
    }

    private static String label(EvidenceFamily family) {
        if (family == null) return "—";
        switch (family) {
            case SEQUENCE: return "sequência";
            case TRANSITION: return "transição";
            case WHEEL_GEOMETRY: return "geometria da roda";
            case TERMINAL: return "terminais";
            case RECENCY: return "recência";
            case FREQUENCY: return "frequência";
            case ARITHMETIC: return "soma/subtração";
            case HISTORICAL_SIMILARITY: return "similaridade";
            case REGIME: return "regime atual";
            case GAP: return "ausência/gap";
            case CLUSTER: return "cluster";
            default: return family.name().toLowerCase(Locale.ROOT);
        }
    }

    private static final class HeatPoint {
        final int number;
        final double value;
        HeatPoint(int number, double value) {
            this.number = number;
            this.value = value;
        }
    }
}
