# AURUM AI 37 — CHECKPOINT v0.7.9 SURGICAL PRECISION

## STATUS AT SOURCE HANDOFF
- IMPLEMENTADO: PASS
- STATIC VALIDATION: PASS
- HOST REGRESSION TESTS: PASS
- ANDROID COMPILE: PENDING GitHub Actions
- SIGNED APK: PENDING GitHub Actions
- INSTALLED: NO
- PHYSICAL S25 FE: PENDING

## BASE
v0.7.8 Terminal + Sector + Confluência Máxima physically tested by the user with promising early signal precision. The v0.7.9 branch is intentionally additive and conservative.

## PROBLEM TARGETED
v0.7.8 combines Sector and Terminal scores well, but both engines can be supported by overlapping evidence families. Treating the two engine scores as fully independent can overstate apparent convergence. Also, an aligned sector/terminal pair can still have a close rival or ambiguity inside the five-number physical sector.

## v0.7.9 SURGICAL LAYER
1. Deduplicates evidence families across Sector and Terminal by union.
2. Measures dual-confirming families without counting them twice.
3. Runs a microtarget tournament inside the winning five-number sector.
4. Adds runner-up pressure veto.
5. Requires two consecutive updates of the same microtarget unless surgical quality is exceptional.
6. Only vetoes legacy v0.7.8 MAX_CONFLUENCE; it cannot manufacture a new signal.
7. Writes surgical telemetry to SessionLedger feature keys.
8. Displays MICROALVO PRIORITÁRIO / GATE CIRÚRGICO in the Radar backstage.

## SYNTHETIC REFERENCE
Sector 25 physical coverage: [21, 2, 25, 17, 34]
Terminal 5 coverage: [5, 15, 25, 35]
The synthetic dual-engine test correctly ranks microtarget 25 and passes the surgical gate. A close-rival version is vetoed.

## PRESERVED
- standalone OCR
- top overlay
- session archive
- v0.7.8 Sector route
- v0.7.8 Terminal route
- max 5-spin Terminal validity
- structural cancellation
- observation != official STRYKE
- strict Precision path
- package/signing continuity

## NEXT EXACT TASK
Upload Aurum-AI-37-v0.7.9-SURGICAL-PRECISION-GITHUB-BUILD.zip to repository root and build-standalone-v0.7.9.yml to .github/workflows/. Require GitHub Actions SUCCESS plus package/version/launcher/signer/zipalign audit before APK handoff. Install over v0.7.8 without uninstalling or clearing data, then physically validate OCR, Sector, Terminal, Surgical Gate, microtarget persistence, rival veto and session telemetry.
