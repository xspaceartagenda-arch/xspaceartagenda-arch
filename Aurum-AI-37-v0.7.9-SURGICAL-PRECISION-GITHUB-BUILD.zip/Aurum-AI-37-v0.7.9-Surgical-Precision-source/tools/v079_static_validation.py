from pathlib import Path
import hashlib
import re

root = Path(__file__).resolve().parents[1]
app = root / 'app'
java = app / 'src/main/java/com/xspaceart/radar30'
core = java / 'core'

build = (app / 'build.gradle').read_text(encoding='utf-8')
manifest = (app / 'src/main/AndroidManifest.xml').read_text(encoding='utf-8')
standalone = (java / 'StandaloneActivity.java').read_text(encoding='utf-8')
overlay = (java / 'OverlayController.java').read_text(encoding='utf-8')
formatter = (java / 'RadarBackstageFormatter.java').read_text(encoding='utf-8')
ledger = (java / 'SessionLedger.java').read_text(encoding='utf-8')
session = (core / 'RadarSession.java').read_text(encoding='utf-8')
precision = (core / 'PrecisionConfluenceEngine.java').read_text(encoding='utf-8')
terminal_policy = (core / 'TerminalSignalPolicy.java').read_text(encoding='utf-8')
surgical = (core / 'SurgicalPrecisionGate.java').read_text(encoding='utf-8')

# Identity / install-over continuity.
assert 'versionCode 10' in build
assert "versionName '0.7.9-surgical-precision'" in build
assert "applicationId 'com.xspaceart.aurumai37.integratedlab'" in build
assert "applicationIdSuffix '.debug'" in build
assert 'signingConfig signingConfigs.aurumStable' in build
assert 'android:name="com.xspaceart.radar30.StandaloneActivity"' in manifest
assert 'STANDALONE OCR RADAR • v0.7.9' in standalone

# v0.7.8 operational architecture preserved.
assert 'Gravity.TOP | Gravity.END' in overlay
assert 'params.y = Ui.dp(context, 72)' in overlay
assert 'MAX_CONFLUENCE_TERMINAL_SECTOR' in session
assert 'TERMINAL_SIGNAL' in session
assert 'SECTOR_SIGNAL' in session
assert 'TERMINAL_VALIDITY_SPINS = 5' in terminal_policy
assert 'TerminalSnapshot.analyze(evidence, centralHeat, history)' in precision

# Surgical layer is additive and can only veto a legacy max-confluence route.
for marker in [
    'class SurgicalPrecisionGate',
    'microTarget',
    'uniqueFamilies',
    'dualConfirmingFamilies',
    'rivalPressure',
    'permitMaxConfluence',
    'legacyReady',
    'if (!legacyReady) return false;',
]:
    assert marker in surgical, marker
assert 'boolean legacyMaxReady = TerminalSignalPolicy.maxConfluenceReady' in session
assert 'SurgicalPrecisionGate.permitMaxConfluence' in session
assert 'terminalHypothesis.surgicalUpdates >= 2' in session
assert 'surgicalGate.exceptional' in session
assert 'MICROALVO PRIORITÁRIO' in session
assert 'surgical_micro_target_' in session
assert 'surgical_score_' in session
assert 'surgical_unique_families_' in session
assert 'surgical_dual_families_' in session

# Explainability visible before and at signal time.
assert 'CIRÚRGICO • microalvo' in formatter
assert 'GATE CIRÚRGICO' in formatter
assert 'famílias únicas' in formatter
assert 'duais' in formatter
assert 'surgical-precision-v079' in ledger

# Precision path remains strict and unchanged in the underlying engine.
assert 'if (!verdict.entryQualified || hypothesis.updates < 3) return false;' in session
assert 'hypothesis.recentMinimum(3) < 78' in session
assert 'boolean precision = aurumScore >= 82' in precision
assert 'fusion.supporting.size() >= 6 || fiveExceptional' in precision

# Preserve every v0.7.8 CORE file byte-for-byte except RadarSession; SurgicalPrecisionGate is additive.
baseline = {}
for line in (root / 'CORE_BASELINE_V078_SHA256.txt').read_text(encoding='utf-8').splitlines():
    m = re.match(r'([0-9a-f]{64})\s+(.+)$', line.strip())
    if m:
        baseline[m.group(2)] = m.group(1)
authorized = {'RadarSession.java'}
checked = 0
for name, digest in baseline.items():
    if name in authorized:
        continue
    path = core / name
    assert path.exists(), name
    got = hashlib.sha256(path.read_bytes()).hexdigest()
    assert got == digest, f'unauthorized CORE drift over v0.7.8: {name}'
    checked += 1
assert checked == 20, checked
assert (core / 'SurgicalPrecisionGate.java').exists()

print('V079_STATIC_VALIDATION=PASS')
print('ARCHITECTURE=v078-preserved+surgical-ranking+unique-family-dedup+rival-veto')
print('SURGICAL=microtarget-inside-winning-sector+terminal-cross-confirmation')
print('SAFETY=gate-can-only-veto-legacy-max-confluence-never-create-new-entry')
print('PRECISION=PRESERVED')
print('CORE_PRESERVATION=PASS unchanged=20 authorized_original=1 additive=1')
print('PHYSICAL_S25FE=PENDING')
