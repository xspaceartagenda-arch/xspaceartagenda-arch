import com.xspaceart.radar30.core.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** v0.7.9: valida microalvo, remoção de dupla contagem e veto por rival próximo. */
public final class V079SurgicalPrecisionGateTest {
    public static void main(String[] args) {
        List<Evidence> evidence = Arrays.asList(
                evidence(EvidenceFamily.TRANSITION, 21, 25),
                evidence(EvidenceFamily.SEQUENCE, 2, 25),
                evidence(EvidenceFamily.ARITHMETIC, 25, 25),
                evidence(EvidenceFamily.RECENCY, 17, 15),
                evidence(EvidenceFamily.REGIME, 34, 35),
                evidence(EvidenceFamily.FREQUENCY, 25, 25)
        );
        double[] fused = fused(evidence);
        ConsensusSnapshot sector = ConsensusSnapshot.analyze(evidence, fused);
        TerminalSnapshot terminal = TerminalSnapshot.analyze(evidence, fused,
                Arrays.asList(12,25,8,15,31,5,17,35,2,24,25,19,15,30,5,22,11,35,6,25,
                        14,15,33,5,28,35,1,25,9,15));
        ConfluenceVerdict verdict = verdict(sector, terminal, fused, 0.10, 0.11);

        if (sector.primary.target != 25) {
            throw new AssertionError("setor esperado 25, veio " + sector.primary.target);
        }
        if (terminal.primary.terminal != 5) {
            throw new AssertionError("terminal esperado T5, veio T" + terminal.primary.terminal);
        }
        SurgicalPrecisionGate.Snapshot surgical = SurgicalPrecisionGate.analyze(verdict);
        if (surgical.microTarget != 25) {
            throw new AssertionError("microalvo esperado 25, veio " + surgical.microTarget);
        }
        if (surgical.uniqueFamilies < 5) {
            throw new AssertionError("famílias únicas insuficientes: " + surgical.uniqueFamilies);
        }
        if (surgical.dualConfirmingFamilies < 4) {
            throw new AssertionError("famílias duais insuficientes: " + surgical.dualConfirmingFamilies);
        }
        if (!surgical.permitMaxConfluence) {
            throw new AssertionError("gate cirúrgico deveria liberar: " + surgical.reasons);
        }

        // Um rival artificialmente colado precisa vetar o cruzamento, mesmo com microalvo definido.
        ConsensusSnapshot closeSector = withCloseRunner(sector);
        TerminalSnapshot closeTerminal = withCloseRunner(terminal);
        ConfluenceVerdict rival = verdict(closeSector, closeTerminal, fused, 0.02, 0.02);
        SurgicalPrecisionGate.Snapshot veto = SurgicalPrecisionGate.analyze(rival);
        if (veto.permitMaxConfluence) {
            throw new AssertionError("rival próximo deveria vetar: " + veto.reasons);
        }

        System.out.println("V079_SURGICAL_GATE=PASS micro=" + surgical.microTarget
                + " score=" + surgical.score + " unique=" + surgical.uniqueFamilies
                + " dual=" + surgical.dualConfirmingFamilies
                + " margin=" + Math.round(surgical.microMargin * 100.0) + "%");
    }

    private static Evidence evidence(EvidenceFamily family, int sectorNative, int terminalNative) {
        double[] heat = new double[37];
        // Estrutura terminal T5 moderadamente ampla.
        for (int n : TerminalSnapshot.coverageOf(5)) heat[n] = 0.70;
        // Polo espacial do setor 25 recebe o pico nativo da família.
        heat[sectorNative] = 1.0;
        // Algumas famílias também têm um nativo exato dentro do terminal.
        heat[terminalNative] = Math.max(heat[terminalNative], 0.96);
        return new Evidence(family, heat, 0.95, 0.95, 40,
                0.94, 0.94, 0.04, family + " synthetic");
    }

    private static double[] fused(List<Evidence> evidence) {
        double[] out = new double[37];
        double total = 0.0;
        for (Evidence e : evidence) {
            double w = e.weight();
            total += w;
            for (int n = 0; n < 37; n++) out[n] += e.heat[n] * w;
        }
        if (total > 0.0) for (int n = 0; n < 37; n++) out[n] /= total;
        double max = 0.0;
        for (double v : out) max = Math.max(max, v);
        if (max > 0.0) for (int n = 0; n < 37; n++) out[n] /= max;
        return out;
    }

    private static ConsensusSnapshot withCloseRunner(ConsensusSnapshot original) {
        ConsensusSnapshot.Candidate p = original.primary;
        ConsensusSnapshot.Candidate r = new ConsensusSnapshot.Candidate(32,
                Math.max(0, p.score - 1), p.familyCount, p.alignment, p.contradiction,
                p.localHeat, p.currentContext, p.predictive, p.recent, p.votes);
        return new ConsensusSnapshot(p, r, original.third, 0.02, original.activeFamilies);
    }

    private static TerminalSnapshot withCloseRunner(TerminalSnapshot original) {
        TerminalSnapshot.Candidate p = original.primary;
        TerminalSnapshot.Candidate r = new TerminalSnapshot.Candidate(6,
                Math.max(0, p.score - 1), p.familyCount, p.alignment, p.contradiction,
                p.currentContext, p.fusedSupport, p.predictive, p.recent, p.votes);
        return new TerminalSnapshot(p, r, original.third, 0.02, original.activeFamilies);
    }

    private static ConfluenceVerdict verdict(ConsensusSnapshot sector, TerminalSnapshot terminal,
                                             double[] heat, double sectorMargin,
                                             double terminalMargin) {
        // Reempacota margens para o teste de pressão rival.
        ConsensusSnapshot s = new ConsensusSnapshot(sector.primary, sector.secondary,
                sector.third, sectorMargin, sector.activeFamilies);
        TerminalSnapshot t = new TerminalSnapshot(terminal.primary, terminal.secondary,
                terminal.third, terminalMargin, terminal.activeFamilies);
        return new ConfluenceVerdict(ConfluenceVerdict.Decision.PREPARE, s.primary.target,
                Wheel.coverage(s.primary.target, 2), Arrays.asList(s.primary.target),
                74, 6, 0.16, 0.11, 0.70, 0.80, 0.60,
                new RegimeDetector().detect(Collections.emptyList()),
                Arrays.asList(EvidenceFamily.RECENCY, EvidenceFamily.TRANSITION,
                        EvidenceFamily.ARITHMETIC, EvidenceFamily.REGIME,
                        EvidenceFamily.SEQUENCE, EvidenceFamily.FREQUENCY),
                Collections.singletonList("v0.7.9 synthetic"), Collections.emptyList(), heat,
                false, false, false, ConfluenceVerdict.Mode.BALANCED,
                -1, Collections.emptyList(), Collections.emptyList(), 0, 0, 1.0,
                0.0, 0.0, 32, 50, 0.5,
                TargetRanking.SpatialRegime.CONCENTRATED,
                TargetRanking.SignalShape.SINGLE_TARGET,
                Collections.emptyList(), Collections.emptyList(), false, s, t);
    }
}
