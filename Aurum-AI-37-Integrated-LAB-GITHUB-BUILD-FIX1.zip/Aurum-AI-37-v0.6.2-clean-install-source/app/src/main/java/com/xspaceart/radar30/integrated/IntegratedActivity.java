package com.xspaceart.radar30.integrated;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.xspaceart.radar30.AppStateStore;
import com.xspaceart.radar30.MainActivity;
import com.xspaceart.radar30.Ui;
import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.EvidenceFamily;
import com.xspaceart.radar30.core.SignalUpdate;
import com.xspaceart.radar30.integrated.normalize.SpinNormalizer;
import com.xspaceart.radar30.integrated.scanner.EnvironmentScanner;
import com.xspaceart.radar30.integrated.scanner.EvidenceGraph;
import com.xspaceart.radar30.integrated.scanner.SourceHunter;
import com.xspaceart.radar30.integrated.session.IntegratedSessionStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class IntegratedActivity extends Activity {
    private static final long SCAN_MS = 2600L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final IntegratedSignalBridge bridge = new IntegratedSignalBridge();
    private final SpinNormalizer normalizer = new SpinNormalizer();
    private final EnvironmentScanner environmentScanner = new EnvironmentScanner();
    private final EvidenceGraph evidenceGraph = new EvidenceGraph();

    private WebView webView;
    private EditText urlInput;
    private ProgressBar progress;
    private TextView liveBadge, signalTitle, signalTarget, signalMeta, secondaryText;
    private TextView scannerText, rayText, sessionText, sourceText;
    private Switch balancedSwitch;
    private Button scanToggle, orderToggle;
    private boolean scannerRunning = true;
    private boolean firstIsNewest = true;
    private String lastFingerprint = "";
    private ConfluenceVerdict lastVerdict;

    private final Runnable scanLoop = new Runnable() {
        @Override public void run() {
            if (scannerRunning && webView != null) discoverPage();
            handler.postDelayed(this, SCAN_MS);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        setContentView(buildUi());
        configureWebView();
        bridge.setPrecision(true);
        IntegratedSessionStore.start(this, "");
        handler.postDelayed(scanLoop, 1200L);
        refreshSession();
    }

    @Override protected void onResume() {
        super.onResume();
        // Se o usuário usou o OCR legado como fallback, traz o histórico confirmado para a Integrated.
        List<Integer> fallback = AppStateStore.loadHistory(this);
        if (fallback.size() >= 8 && fallback.size() > bridge.historySize()) {
            renderBridge(bridge.replaceBootstrap(fallback), "OCR FALLBACK");
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this,14),Ui.dp(this,9),Ui.dp(this,14),Ui.dp(this,7));
        TextView brand = Ui.text(this,"AURUM AI 37",22,Ui.GREEN,true);
        TextView lab = Ui.text(this,"  INTEGRATED LAB",11,Ui.AMBER,true);
        liveBadge = Ui.text(this,"SCANNER",11,Ui.CYAN,true);
        top.addView(brand);
        top.addView(lab, new LinearLayout.LayoutParams(0,-2,1));
        top.addView(liveBadge);
        root.addView(top);

        LinearLayout address = new LinearLayout(this);
        address.setPadding(Ui.dp(this,10),0,Ui.dp(this,10),Ui.dp(this,6));
        urlInput = new EditText(this);
        urlInput.setHint("https://..."); urlInput.setSingleLine(true); urlInput.setTextColor(Ui.TEXT); urlInput.setHintTextColor(Ui.MUTED);
        urlInput.setTextSize(12); urlInput.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        Button open = Ui.button(this,"Abrir",Ui.AMBER,Color.BLACK);
        Button reload = Ui.button(this,"↻",Ui.SURFACE,Ui.TEXT);
        address.addView(urlInput,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));
        address.addView(open, new LinearLayout.LayoutParams(Ui.dp(this,76),Ui.dp(this,44)));
        address.addView(reload,new LinearLayout.LayoutParams(Ui.dp(this,50),Ui.dp(this,44)));
        root.addView(address);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setVisibility(View.GONE); root.addView(progress,new LinearLayout.LayoutParams(-1,Ui.dp(this,2)));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        root.addView(webView,new LinearLayout.LayoutParams(-1,Ui.dp(this,390)));

        ScrollView lowerScroll = new ScrollView(this);
        lowerScroll.setFillViewport(true);
        LinearLayout lower = new LinearLayout(this);
        lower.setOrientation(LinearLayout.VERTICAL);
        lower.setPadding(Ui.dp(this,12),Ui.dp(this,10),Ui.dp(this,12),Ui.dp(this,18));
        lowerScroll.addView(lower);

        LinearLayout hero = Ui.card(this);
        signalTitle = Ui.text(this,"SCANNING",12,Ui.CYAN,true);
        signalTarget = Ui.text(this,"SEM SINAL ATIVO",30,Ui.TEXT,true);
        signalMeta = Ui.text(this,"Aguardando contexto da mesa",13,Ui.MUTED,false);
        secondaryText = Ui.text(this,"",12,Ui.AMBER,true); secondaryText.setVisibility(View.GONE);
        hero.addView(signalTitle); hero.addView(signalTarget); hero.addView(signalMeta); hero.addView(secondaryText);
        lower.addView(hero,Ui.margins(-1,-2,this,0,0,0,10));

        LinearLayout controls = Ui.card(this);
        balancedSwitch = new Switch(this); balancedSwitch.setText("Balanced calibrado"); balancedSwitch.setTextColor(Ui.TEXT);
        scanToggle = Ui.button(this,"Scanner: ATIVO",Ui.CYAN,Color.BLACK);
        orderToggle = Ui.button(this,"Ordem: primeiro = recente",Ui.SURFACE,Ui.TEXT);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(scanToggle,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        row.addView(orderToggle,new LinearLayout.LayoutParams(0,Ui.dp(this,48),1));
        controls.addView(balancedSwitch); controls.addView(row);
        lower.addView(controls,Ui.margins(-1,-2,this,0,0,0,10));

        LinearLayout scanCard = Ui.card(this);
        scanCard.addView(Ui.text(this,"AUTO DISCOVERY",14,Ui.CYAN,true));
        scannerText = Ui.text(this,"MESA —\nPROVEDOR —\nHISTÓRICO 0\nSCANNER ATIVO",13,Ui.TEXT,false);
        sourceText = Ui.text(this,"FONTES 0 • GRUPOS 0",12,Ui.MUTED,false);
        scanCard.addView(scannerText); scanCard.addView(sourceText);
        lower.addView(scanCard,Ui.margins(-1,-2,this,0,0,0,10));

        LinearLayout ray = Ui.card(this);
        ray.addView(Ui.text(this,"RAIO-X",14,Ui.CYAN,true));
        rayText = Ui.text(this,"Aguardando dados suficientes.",13,Ui.TEXT,false);
        Button rayOpen = Ui.button(this,"Abrir Raio-X completo",Ui.SURFACE,Ui.TEXT);
        ray.addView(rayText); ray.addView(rayOpen,Ui.margins(-1,Ui.dp(this,48),this,0,8,0,0));
        lower.addView(ray,Ui.margins(-1,-2,this,0,0,0,10));

        LinearLayout tools = Ui.card(this);
        tools.addView(Ui.text(this,"FALLBACK / SESSÃO",14,Ui.AMBER,true));
        sessionText = Ui.text(this,"Sessão iniciada • 0 sinais",12,Ui.MUTED,false);
        Button fallback = Ui.button(this,"Abrir OCR / ferramentas Stable",Ui.AMBER,Color.BLACK);
        Button finish = Ui.button(this,"Finalizar sessão",Ui.SURFACE,Ui.TEXT);
        tools.addView(sessionText); tools.addView(fallback,Ui.margins(-1,Ui.dp(this,48),this,0,8,0,0)); tools.addView(finish,Ui.margins(-1,Ui.dp(this,48),this,0,6,0,0));
        lower.addView(tools);

        TextView footer = Ui.text(this,"Home   •   Scan   •   Strategy   •   History   •   Settings",11,Ui.MUTED,true);
        footer.setGravity(Gravity.CENTER); lower.addView(footer,Ui.margins(-1,-2,this,0,14,0,0));
        root.addView(lowerScroll,new LinearLayout.LayoutParams(-1,0,1));

        open.setOnClickListener(v -> openEnteredUrl());
        reload.setOnClickListener(v -> webView.reload());
        scanToggle.setOnClickListener(v -> { scannerRunning=!scannerRunning; scanToggle.setText(scannerRunning?"Scanner: ATIVO":"Scanner: PAUSADO"); liveBadge.setText(scannerRunning?"SCANNER":"PAUSADO"); });
        orderToggle.setOnClickListener(v -> { firstIsNewest=!firstIsNewest; orderToggle.setText(firstIsNewest?"Ordem: primeiro = recente":"Ordem: último = recente"); lastFingerprint=""; discoverPage(); });
        balancedSwitch.setOnCheckedChangeListener((b,checked) -> { bridge.setPrecision(!checked); signalMeta.setText(checked?"Balanced v0.6.3 ativo":"Precision ativo"); lastFingerprint=""; });
        rayOpen.setOnClickListener(v -> showFullRayX());
        fallback.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
        finish.setOnClickListener(v -> { IntegratedSessionStore.finish(this); refreshSession(); Toast.makeText(this,"Sessão registrada localmente.",Toast.LENGTH_SHORT).show(); });
        return root;
    }

    private void configureWebView() {
        BrowserSecurityPolicy.apply(webView);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView,true);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int newProgress) {
                progress.setProgress(newProgress); progress.setVisibility(newProgress>=100?View.GONE:View.VISIBLE);
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u=req.getUrl(); if(!BrowserSecurityPolicy.isAllowed(u)) { Toast.makeText(IntegratedActivity.this,"Link externo bloqueado no LAB.",Toast.LENGTH_SHORT).show(); return true; }
                return false;
            }
            @Override public void onPageFinished(WebView view,String url) {
                urlInput.setText(BrowserSecurityPolicy.sanitize(url)); liveBadge.setText("LIVE • SCAN");
                lastFingerprint=""; IntegratedSessionStore.start(IntegratedActivity.this,url); discoverPage();
            }
        });
        webView.loadUrl("about:blank");
    }

    private void openEnteredUrl() {
        String raw=urlInput.getText().toString().trim(); if(raw.isEmpty()) return;
        if(!raw.contains("://")) raw="https://"+raw;
        Uri u=Uri.parse(raw); if(!BrowserSecurityPolicy.isAllowed(u)){ Toast.makeText(this,"Use endereço http/https.",Toast.LENGTH_SHORT).show(); return; }
        webView.loadUrl(raw);
    }

    private void discoverPage() {
        if (webView == null) return;
        webView.evaluateJavascript(SourceHunter.discoveryScript(), value -> {
            try {
                String decoded = decodeJsString(value);
                JSONObject o = new JSONObject(decoded);
                JSONArray a = o.optJSONArray("history");
                List<Integer> raw = new ArrayList<>();
                if(a!=null) for(int i=0;i<a.length();i++) raw.add(a.optInt(i,-1));
                List<Integer> history = normalizer.normalize(raw, firstIsNewest);
                String fingerprint = normalizer.fingerprint(history);
                String pageUrl=o.optString("url",webView.getUrl()); String title=o.optString("title","");
                int iframes=o.optInt("iframes",0); String hint=o.optString("hint","");
                EnvironmentScanner.Snapshot env=environmentScanner.inspect(pageUrl,title,iframes,history.size(),hint);
                renderEnvironment(env);
                if(history.size()>=8) {
                    evidenceGraph.upsert("dom-history","DOM_HISTORY",0.82,fingerprint,"current-history");
                    sourceText.setText("FONTES "+evidenceGraph.sourceCount()+" • GRUPOS "+evidenceGraph.independentGroups()+" • DOM HISTORY ✓");
                    if(!fingerprint.equals(lastFingerprint)) { lastFingerprint=fingerprint; renderBridge(bridge.acceptScan(history),"DOM HISTORY"); }
                } else {
                    sourceText.setText("FONTES "+evidenceGraph.sourceCount()+" • DOM HISTORY —"+(env.crossOriginLikely?" • IFRAME/CROSS-ORIGIN":""));
                }
            } catch(Exception error) {
                scannerText.setText("SCANNER ATIVO\nDOM indisponível nesta página\nFallback OCR disponível");
            }
        });
    }

    private void renderEnvironment(EnvironmentScanner.Snapshot s) {
        scannerText.setText("MESA "+(s.table.startsWith("Mesa não")?"—":"✓ "+shorten(s.table,34))+"\n"+
                "PROVEDOR "+("Não definido".equals(s.provider)?"—":"✓ "+s.provider)+"\n"+
                "HISTÓRICO "+s.historyCount+"\nSCANNER "+(scannerRunning?"ATIVO":"PAUSADO")+
                (s.crossOriginLikely?"\nDOM BLOQUEADO • OCR fallback disponível":""));
    }

    private void renderBridge(IntegratedSignalBridge.Result r, String source) {
        if(!r.accepted){ signalMeta.setText(source+" • "+r.message); return; }
        SignalUpdate u=r.update; lastVerdict=r.verdict;
        if(u==null) return;
        int accent=accent(u.kind);
        signalTitle.setText(u.kind.name()+" • "+(bridge.isPrecision()?"PRECISION":"BALANCED")); signalTitle.setTextColor(accent);
        signalTarget.setText(u.target>=0?(u.playLabel.isEmpty()?u.target+" + VIZINHOS":u.playLabel):u.headline);
        String score=lastVerdict==null?"—":String.valueOf(lastVerdict.aurumScore);
        String families=lastVerdict==null?"—":String.valueOf(lastVerdict.independentFamilies);
        signalMeta.setText("AURUM SCORE "+score+"/100 • FAMÍLIAS "+families+" • "+r.message+" • "+r.history.size()+" giros");
        if(u.secondaryTarget>=0 && !u.secondaryCoverage.isEmpty()) { secondaryText.setVisibility(View.VISIBLE); secondaryText.setText("SECONDARY • "+u.secondaryPlayLabel+" • score "+u.secondaryStrength); }
        else secondaryText.setVisibility(View.GONE);
        renderRayX(lastVerdict,u);
        if(u.kind==SignalUpdate.Kind.ENTRY) IntegratedSessionStore.recordSignal(this);
        refreshSession();
    }

    private void renderRayX(ConfluenceVerdict v, SignalUpdate u) {
        if(v==null){ rayText.setText("Aguardando dados suficientes."); return; }
        String mode=bridge.isPrecision()?"Precision":"Balanced";
        rayText.setText("GATE AO VIVO • "+mode+" • "+v.decision+"\n"+
                "ALINHADAS "+v.independentFamilies+" • CONTRADIÇÃO "+pct(v.contradictionScore)+" • DOMINÂNCIA "+pct(v.dominanceMargin)+"\n"+
                "REGIME "+v.spatialRegime+" • "+v.signalShape+"\n"+
                (u.detail==null?"":shorten(u.detail.replace('\n',' '),170)));
    }

    private void showFullRayX() {
        if(lastVerdict==null){ Toast.makeText(this,"Raio-X ainda sem veredito.",Toast.LENGTH_SHORT).show(); return; }
        StringBuilder b=new StringBuilder(); ConfluenceVerdict v=lastVerdict;
        b.append("DECISÃO: ").append(v.decision).append("\nALVO: ").append(v.target).append("\nAURUM SCORE: ").append(v.aurumScore).append("/100\n")
                .append("FAMÍLIAS: ").append(v.independentFamilies).append("\nCONTRADIÇÃO: ").append(pct(v.contradictionScore)).append("\nDOMINÂNCIA: ").append(pct(v.dominanceMargin)).append("\nDISPERSÃO: ").append(pct(v.evidenceDispersion)).append("\nREGIME: ").append(v.spatialRegime).append("\nSHAPE: ").append(v.signalShape).append("\n\nFAMÍLIAS ALINHADAS:\n");
        for(EvidenceFamily f:v.supportingFamilies) b.append("• ").append(f.name()).append('\n');
        b.append("\nRAZÕES:\n"); for(String s:v.reasons) b.append("• ").append(s).append('\n');
        if(v.hasSecondary()){ b.append("\nSECONDARY: ").append(v.secondaryTarget).append(" • score ").append(v.secondaryScore).append('\n'); for(String s:v.secondaryReasons) b.append("• ").append(s).append('\n'); }
        TextView t=Ui.text(this,b.toString(),13,Ui.TEXT,false); t.setPadding(Ui.dp(this,16),Ui.dp(this,10),Ui.dp(this,16),Ui.dp(this,20));
        ScrollView s=new ScrollView(this); s.setBackgroundColor(Ui.BG); s.addView(t);
        new AlertDialog.Builder(this).setTitle("RAIO-X • INTEGRATED").setView(s).setPositiveButton("Fechar",null).show();
    }

    private void refreshSession() {
        long start=IntegratedSessionStore.startedAt(this); long mins=start<=0?0:Math.max(0,(System.currentTimeMillis()-start)/60000L);
        sessionText.setText("Sessão • "+mins+" min • "+IntegratedSessionStore.signals(this)+" sinais publicados");
    }

    private static String decodeJsString(String value) throws Exception {
        if(value==null||"null".equals(value)) return "{}";
        if(value.startsWith("\"")&&value.endsWith("\"")) return new JSONArray("["+value+"]").getString(0);
        return value;
    }
    private static String shorten(String s,int n){ if(s==null)return ""; s=s.trim(); return s.length()<=n?s:s.substring(0,n-1)+"…"; }
    private static String pct(double v){ return String.format(Locale.US,"%.0f%%",v*100.0); }
    private static int accent(SignalUpdate.Kind k){ if(k==SignalUpdate.Kind.ENTRY||k==SignalUpdate.Kind.ACTIVE||k==SignalUpdate.Kind.HIT||k==SignalUpdate.Kind.SECONDARY_HIT)return Ui.GREEN; if(k==SignalUpdate.Kind.PREPARE||k==SignalUpdate.Kind.OBSERVE)return Ui.AMBER; if(k==SignalUpdate.Kind.INVALIDATED||k==SignalUpdate.Kind.EXPIRED)return Ui.RED; return Ui.CYAN; }
}
