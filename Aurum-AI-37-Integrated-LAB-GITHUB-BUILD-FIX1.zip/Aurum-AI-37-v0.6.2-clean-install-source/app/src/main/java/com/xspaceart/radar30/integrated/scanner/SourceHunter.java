package com.xspaceart.radar30.integrated.scanner;

public final class SourceHunter {
    private SourceHunter() {}

    /**
     * Só lê a DOM que o próprio WebView pode acessar. Não tenta atravessar SOP/cross-origin.
     * Procura containers semanticamente relacionados a histórico/resultados e devolve o melhor candidato.
     */
    public static String discoveryScript() {
        return "(function(){try{" +
                "var kw=/(history|recent|result|last|roulette|roleta|spin|number|numero|número|winner|winning)/i;" +
                "var best={score:-1,nums:[],hint:''};" +
                "var els=document.querySelectorAll('[class],[id],[aria-label],[data-testid],[data-number],[data-value]');" +
                "for(var i=0;i<els.length;i++){var e=els[i];var meta=((e.id||'')+' '+(e.className||'')+' '+(e.getAttribute('aria-label')||'')+' '+(e.getAttribute('data-testid')||''));" +
                "if(!kw.test(meta)) continue; var t=(e.innerText||e.textContent||'').trim(); if(!t||t.length>5000) continue;" +
                "var m=t.match(/(^|\\s|[^0-9])([0-9]|[12][0-9]|3[0-6])(?=$|\\s|[^0-9])/g)||[];" +
                "var nums=[]; for(var j=0;j<m.length;j++){var q=m[j].match(/([0-9]|[12][0-9]|3[0-6])/); if(q) nums.push(parseInt(q[1],10));}" +
                "if(nums.length<8||nums.length>500) continue; var score=nums.length+20; if(/history|recent|result|last/i.test(meta)) score+=25;" +
                "if(score>best.score){best={score:score,nums:nums.slice(0,500),hint:meta.slice(0,180)};} }" +
                "var out={url:location.href,title:document.title||'',iframes:document.querySelectorAll('iframe').length,history:best.nums,hint:best.hint};" +
                "return JSON.stringify(out); }catch(e){return JSON.stringify({error:String(e),url:location.href,title:document.title||'',iframes:0,history:[],hint:''});}})();";
    }
}
