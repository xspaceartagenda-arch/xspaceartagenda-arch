package com.xspaceart.radar30.integrated;

import com.xspaceart.radar30.core.ConfluenceVerdict;
import com.xspaceart.radar30.core.LearningModel;
import com.xspaceart.radar30.core.RadarSession;
import com.xspaceart.radar30.core.ScanSynchronizer;
import com.xspaceart.radar30.core.SignalUpdate;

import java.util.ArrayList;
import java.util.List;

/** Ponte fina: dados integrados entram no mesmo core v0.6.3, sem duplicar o motor. */
public final class IntegratedSignalBridge {
    private final ScanSynchronizer sync = new ScanSynchronizer();
    private final RadarSession session = new RadarSession();
    private boolean precision = true;

    public void setPrecision(boolean precision) { this.precision = precision; }
    public boolean isPrecision() { return precision; }

    public Result acceptScan(List<Integer> newestFirst) {
        ScanSynchronizer.MergeResult merge = sync.merge(newestFirst);
        if (!merge.accepted) return new Result(false, merge.message, null, session.lastVerdict(), merge.history);
        SignalUpdate u = session.update(merge.history, merge.newNumbers, LearningModel.empty(), precision);
        return new Result(true, merge.message, u, session.lastVerdict(), merge.history);
    }

    public Result replaceBootstrap(List<Integer> newestFirst) {
        sync.restore(newestFirst);
        session.resetSignal();
        SignalUpdate u = session.update(newestFirst, new ArrayList<>(), LearningModel.empty(), precision);
        return new Result(true, "Histórico sincronizado", u, session.lastVerdict(), newestFirst);
    }

    public int historySize() { return sync.current().size(); }

    public static final class Result {
        public final boolean accepted; public final String message; public final SignalUpdate update;
        public final ConfluenceVerdict verdict; public final List<Integer> history;
        Result(boolean accepted, String message, SignalUpdate update, ConfluenceVerdict verdict, List<Integer> history) {
            this.accepted=accepted; this.message=message; this.update=update; this.verdict=verdict; this.history=history;
        }
    }
}
