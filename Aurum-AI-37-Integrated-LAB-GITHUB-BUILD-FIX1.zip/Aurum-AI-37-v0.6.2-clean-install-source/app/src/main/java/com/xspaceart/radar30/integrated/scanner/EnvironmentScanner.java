package com.xspaceart.radar30.integrated.scanner;

import android.net.Uri;

import java.util.Locale;

public final class EnvironmentScanner {
    public Snapshot inspect(String url, String title, int iframeCount, int historyCount, String sourceHint) {
        String host = "";
        try { host = Uri.parse(url).getHost(); } catch (RuntimeException ignored) {}
        if (host == null) host = "";
        String lower = (host + " " + title + " " + sourceHint).toLowerCase(Locale.ROOT);
        String provider = "Não definido";
        if (lower.contains("evolution")) provider = "Evolution";
        else if (lower.contains("pragmatic")) provider = "Pragmatic";
        else if (lower.contains("playtech")) provider = "Playtech";
        else if (lower.contains("roulette") || lower.contains("roleta")) provider = "Roleta ao vivo";
        String table = title == null || title.trim().isEmpty() ? "Mesa não identificada" : title.trim();
        boolean dom = historyCount >= 8;
        boolean crossOriginLikely = iframeCount > 0 && !dom;
        return new Snapshot(host, provider, table, iframeCount, historyCount, dom, crossOriginLikely);
    }

    public static final class Snapshot {
        public final String host, provider, table;
        public final int iframeCount, historyCount;
        public final boolean domHistory, crossOriginLikely;
        Snapshot(String host, String provider, String table, int iframeCount, int historyCount,
                 boolean domHistory, boolean crossOriginLikely) {
            this.host = host; this.provider = provider; this.table = table;
            this.iframeCount = iframeCount; this.historyCount = historyCount;
            this.domHistory = domHistory; this.crossOriginLikely = crossOriginLikely;
        }
    }
}
